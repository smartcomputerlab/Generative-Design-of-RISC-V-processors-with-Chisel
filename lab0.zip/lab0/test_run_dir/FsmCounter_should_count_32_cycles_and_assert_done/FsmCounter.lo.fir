FIRRTL version 1.1.0
circuit FsmCounter :
  module FsmCounter :
    input clock : Clock
    input reset : UInt<1>
    input io_start : UInt<1>
    output io_count : UInt<6>
    output io_busy : UInt<1>
    output io_done : UInt<1>

    reg state : UInt<2>, clock with :
      reset => (UInt<1>("h0"), state) @[FsmCounter.scala 19:22]
    reg counter : UInt<6>, clock with :
      reset => (UInt<1>("h0"), counter) @[FsmCounter.scala 22:24]
    node _T = eq(UInt<2>("h0"), state) @[FsmCounter.scala 25:17]
    node _GEN_0 = mux(io_start, UInt<1>("h0"), counter) @[FsmCounter.scala 28:22 29:17 22:24]
    node _GEN_1 = mux(io_start, UInt<2>("h1"), state) @[FsmCounter.scala 28:22 30:15 19:22]
    node _T_1 = eq(UInt<2>("h1"), state) @[FsmCounter.scala 25:17]
    node _counter_T = add(counter, UInt<1>("h1")) @[FsmCounter.scala 35:26]
    node _counter_T_1 = tail(_counter_T, 1) @[FsmCounter.scala 35:26]
    node _T_2 = eq(counter, UInt<5>("h1f")) @[FsmCounter.scala 37:20]
    node _GEN_2 = mux(_T_2, UInt<2>("h2"), state) @[FsmCounter.scala 37:30 38:15 19:22]
    node _T_3 = eq(UInt<2>("h2"), state) @[FsmCounter.scala 25:17]
    node _GEN_3 = mux(_T_3, UInt<2>("h0"), state) @[FsmCounter.scala 25:17 43:13 19:22]
    node _GEN_4 = mux(_T_1, _counter_T_1, counter) @[FsmCounter.scala 25:17 35:15 22:24]
    node _GEN_5 = mux(_T_1, _GEN_2, _GEN_3) @[FsmCounter.scala 25:17]
    node _GEN_6 = mux(_T, _GEN_0, _GEN_4) @[FsmCounter.scala 25:17]
    node _GEN_7 = mux(_T, _GEN_1, _GEN_5) @[FsmCounter.scala 25:17]
    node _io_busy_T = eq(state, UInt<2>("h1")) @[FsmCounter.scala 49:21]
    node _io_done_T = eq(state, UInt<2>("h2")) @[FsmCounter.scala 50:21]
    io_count <= counter @[FsmCounter.scala 48:12]
    io_busy <= _io_busy_T @[FsmCounter.scala 49:12]
    io_done <= _io_done_T @[FsmCounter.scala 50:12]
    state <= mux(reset, UInt<2>("h0"), _GEN_7) @[FsmCounter.scala 19:{22,22}]
    counter <= mux(reset, UInt<6>("h0"), _GEN_6) @[FsmCounter.scala 22:{24,24}]
