FIRRTL version 1.1.0
circuit MainMemory :
  module MainMemory :
    input clock : Clock
    input reset : UInt<1>
    input io_valid : UInt<1>
    input io_wen : UInt<1>
    input io_addr : UInt<4>
    input io_wdata : UInt<32>
    output io_ready : UInt<1>
    output io_respValid : UInt<1>
    output io_rdata : UInt<32>
    output io_reads : UInt<8>
    output io_writes : UInt<8>

    reg mem_0 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), mem_0) @[CacheSyst.scala 21:23]
    reg mem_1 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), mem_1) @[CacheSyst.scala 21:23]
    reg mem_2 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), mem_2) @[CacheSyst.scala 21:23]
    reg mem_3 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), mem_3) @[CacheSyst.scala 21:23]
    reg mem_4 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), mem_4) @[CacheSyst.scala 21:23]
    reg mem_5 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), mem_5) @[CacheSyst.scala 21:23]
    reg mem_6 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), mem_6) @[CacheSyst.scala 21:23]
    reg mem_7 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), mem_7) @[CacheSyst.scala 21:23]
    reg mem_8 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), mem_8) @[CacheSyst.scala 21:23]
    reg mem_9 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), mem_9) @[CacheSyst.scala 21:23]
    reg mem_10 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), mem_10) @[CacheSyst.scala 21:23]
    reg mem_11 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), mem_11) @[CacheSyst.scala 21:23]
    reg mem_12 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), mem_12) @[CacheSyst.scala 21:23]
    reg mem_13 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), mem_13) @[CacheSyst.scala 21:23]
    reg mem_14 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), mem_14) @[CacheSyst.scala 21:23]
    reg mem_15 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), mem_15) @[CacheSyst.scala 21:23]
    reg busy : UInt<1>, clock with :
      reset => (UInt<1>("h0"), busy) @[CacheSyst.scala 22:23]
    reg cnt : UInt<2>, clock with :
      reset => (UInt<1>("h0"), cnt) @[CacheSyst.scala 23:19]
    reg rWen : UInt<1>, clock with :
      reset => (UInt<1>("h0"), rWen) @[CacheSyst.scala 24:19]
    reg rAddr : UInt<4>, clock with :
      reset => (UInt<1>("h0"), rAddr) @[CacheSyst.scala 25:19]
    reg rWdata : UInt<32>, clock with :
      reset => (UInt<1>("h0"), rWdata) @[CacheSyst.scala 26:19]
    reg reads : UInt<8>, clock with :
      reset => (UInt<1>("h0"), reads) @[CacheSyst.scala 27:23]
    reg writes : UInt<8>, clock with :
      reset => (UInt<1>("h0"), writes) @[CacheSyst.scala 28:23]
    node _io_ready_T = eq(busy, UInt<1>("h0")) @[CacheSyst.scala 30:15]
    node _T = eq(busy, UInt<1>("h0")) @[CacheSyst.scala 31:20]
    node _T_1 = and(io_valid, _T) @[CacheSyst.scala 31:17]
    node _writes_T = add(writes, UInt<1>("h1")) @[CacheSyst.scala 34:37]
    node _writes_T_1 = tail(_writes_T, 1) @[CacheSyst.scala 34:37]
    node _reads_T = add(reads, UInt<1>("h1")) @[CacheSyst.scala 34:72]
    node _reads_T_1 = tail(_reads_T, 1) @[CacheSyst.scala 34:72]
    node _GEN_0 = mux(io_wen, _writes_T_1, writes) @[CacheSyst.scala 34:18 28:23 34:27]
    node _GEN_1 = mux(io_wen, reads, _reads_T_1) @[CacheSyst.scala 34:18 27:23 34:63]
    node _GEN_2 = mux(_T_1, UInt<1>("h1"), busy) @[CacheSyst.scala 31:27 32:10 22:23]
    node _GEN_3 = mux(_T_1, UInt<2>("h2"), cnt) @[CacheSyst.scala 23:19 31:27 32:25]
    node _GEN_4 = mux(_T_1, io_wen, rWen) @[CacheSyst.scala 31:27 33:10 24:19]
    node _GEN_5 = mux(_T_1, io_addr, rAddr) @[CacheSyst.scala 25:19 31:27 33:27]
    node _GEN_6 = mux(_T_1, io_wdata, rWdata) @[CacheSyst.scala 26:19 31:27 33:46]
    node _GEN_7 = mux(_T_1, _GEN_0, writes) @[CacheSyst.scala 28:23 31:27]
    node _GEN_8 = mux(_T_1, _GEN_1, reads) @[CacheSyst.scala 27:23 31:27]
    node _io_respValid_T = eq(cnt, UInt<1>("h0")) @[CacheSyst.scala 37:31]
    node _io_respValid_T_1 = and(busy, _io_respValid_T) @[CacheSyst.scala 37:24]
    node _GEN_9 = validif(eq(UInt<1>("h0"), rAddr), mem_0) @[CacheSyst.scala 38:{16,16}]
    node _GEN_10 = mux(eq(UInt<1>("h1"), rAddr), mem_1, _GEN_9) @[CacheSyst.scala 38:{16,16}]
    node _GEN_11 = mux(eq(UInt<2>("h2"), rAddr), mem_2, _GEN_10) @[CacheSyst.scala 38:{16,16}]
    node _GEN_12 = mux(eq(UInt<2>("h3"), rAddr), mem_3, _GEN_11) @[CacheSyst.scala 38:{16,16}]
    node _GEN_13 = mux(eq(UInt<3>("h4"), rAddr), mem_4, _GEN_12) @[CacheSyst.scala 38:{16,16}]
    node _GEN_14 = mux(eq(UInt<3>("h5"), rAddr), mem_5, _GEN_13) @[CacheSyst.scala 38:{16,16}]
    node _GEN_15 = mux(eq(UInt<3>("h6"), rAddr), mem_6, _GEN_14) @[CacheSyst.scala 38:{16,16}]
    node _GEN_16 = mux(eq(UInt<3>("h7"), rAddr), mem_7, _GEN_15) @[CacheSyst.scala 38:{16,16}]
    node _GEN_17 = mux(eq(UInt<4>("h8"), rAddr), mem_8, _GEN_16) @[CacheSyst.scala 38:{16,16}]
    node _GEN_18 = mux(eq(UInt<4>("h9"), rAddr), mem_9, _GEN_17) @[CacheSyst.scala 38:{16,16}]
    node _GEN_19 = mux(eq(UInt<4>("ha"), rAddr), mem_10, _GEN_18) @[CacheSyst.scala 38:{16,16}]
    node _GEN_20 = mux(eq(UInt<4>("hb"), rAddr), mem_11, _GEN_19) @[CacheSyst.scala 38:{16,16}]
    node _GEN_21 = mux(eq(UInt<4>("hc"), rAddr), mem_12, _GEN_20) @[CacheSyst.scala 38:{16,16}]
    node _GEN_22 = mux(eq(UInt<4>("hd"), rAddr), mem_13, _GEN_21) @[CacheSyst.scala 38:{16,16}]
    node _GEN_23 = mux(eq(UInt<4>("he"), rAddr), mem_14, _GEN_22) @[CacheSyst.scala 38:{16,16}]
    node _GEN_24 = mux(eq(UInt<4>("hf"), rAddr), mem_15, _GEN_23) @[CacheSyst.scala 38:{16,16}]
    node _T_2 = eq(cnt, UInt<1>("h0")) @[CacheSyst.scala 40:14]
    node _mem_rAddr_0 = rWdata @[CacheSyst.scala 42:{31,31}]
    node _GEN_25 = mux(eq(UInt<1>("h0"), rAddr), _mem_rAddr_0, mem_0) @[CacheSyst.scala 21:23 42:{31,31}]
    node _GEN_26 = mux(eq(UInt<1>("h1"), rAddr), _mem_rAddr_0, mem_1) @[CacheSyst.scala 21:23 42:{31,31}]
    node _GEN_27 = mux(eq(UInt<2>("h2"), rAddr), _mem_rAddr_0, mem_2) @[CacheSyst.scala 21:23 42:{31,31}]
    node _GEN_28 = mux(eq(UInt<2>("h3"), rAddr), _mem_rAddr_0, mem_3) @[CacheSyst.scala 21:23 42:{31,31}]
    node _GEN_29 = mux(eq(UInt<3>("h4"), rAddr), _mem_rAddr_0, mem_4) @[CacheSyst.scala 21:23 42:{31,31}]
    node _GEN_30 = mux(eq(UInt<3>("h5"), rAddr), _mem_rAddr_0, mem_5) @[CacheSyst.scala 21:23 42:{31,31}]
    node _GEN_31 = mux(eq(UInt<3>("h6"), rAddr), _mem_rAddr_0, mem_6) @[CacheSyst.scala 21:23 42:{31,31}]
    node _GEN_32 = mux(eq(UInt<3>("h7"), rAddr), _mem_rAddr_0, mem_7) @[CacheSyst.scala 21:23 42:{31,31}]
    node _GEN_33 = mux(eq(UInt<4>("h8"), rAddr), _mem_rAddr_0, mem_8) @[CacheSyst.scala 21:23 42:{31,31}]
    node _GEN_34 = mux(eq(UInt<4>("h9"), rAddr), _mem_rAddr_0, mem_9) @[CacheSyst.scala 21:23 42:{31,31}]
    node _GEN_35 = mux(eq(UInt<4>("ha"), rAddr), _mem_rAddr_0, mem_10) @[CacheSyst.scala 21:23 42:{31,31}]
    node _GEN_36 = mux(eq(UInt<4>("hb"), rAddr), _mem_rAddr_0, mem_11) @[CacheSyst.scala 21:23 42:{31,31}]
    node _GEN_37 = mux(eq(UInt<4>("hc"), rAddr), _mem_rAddr_0, mem_12) @[CacheSyst.scala 21:23 42:{31,31}]
    node _GEN_38 = mux(eq(UInt<4>("hd"), rAddr), _mem_rAddr_0, mem_13) @[CacheSyst.scala 21:23 42:{31,31}]
    node _GEN_39 = mux(eq(UInt<4>("he"), rAddr), _mem_rAddr_0, mem_14) @[CacheSyst.scala 21:23 42:{31,31}]
    node _GEN_40 = mux(eq(UInt<4>("hf"), rAddr), _mem_rAddr_0, mem_15) @[CacheSyst.scala 21:23 42:{31,31}]
    node _GEN_41 = mux(rWen, _GEN_25, mem_0) @[CacheSyst.scala 42:18 21:23]
    node _GEN_42 = mux(rWen, _GEN_26, mem_1) @[CacheSyst.scala 42:18 21:23]
    node _GEN_43 = mux(rWen, _GEN_27, mem_2) @[CacheSyst.scala 42:18 21:23]
    node _GEN_44 = mux(rWen, _GEN_28, mem_3) @[CacheSyst.scala 42:18 21:23]
    node _GEN_45 = mux(rWen, _GEN_29, mem_4) @[CacheSyst.scala 42:18 21:23]
    node _GEN_46 = mux(rWen, _GEN_30, mem_5) @[CacheSyst.scala 42:18 21:23]
    node _GEN_47 = mux(rWen, _GEN_31, mem_6) @[CacheSyst.scala 42:18 21:23]
    node _GEN_48 = mux(rWen, _GEN_32, mem_7) @[CacheSyst.scala 42:18 21:23]
    node _GEN_49 = mux(rWen, _GEN_33, mem_8) @[CacheSyst.scala 42:18 21:23]
    node _GEN_50 = mux(rWen, _GEN_34, mem_9) @[CacheSyst.scala 42:18 21:23]
    node _GEN_51 = mux(rWen, _GEN_35, mem_10) @[CacheSyst.scala 42:18 21:23]
    node _GEN_52 = mux(rWen, _GEN_36, mem_11) @[CacheSyst.scala 42:18 21:23]
    node _GEN_53 = mux(rWen, _GEN_37, mem_12) @[CacheSyst.scala 42:18 21:23]
    node _GEN_54 = mux(rWen, _GEN_38, mem_13) @[CacheSyst.scala 42:18 21:23]
    node _GEN_55 = mux(rWen, _GEN_39, mem_14) @[CacheSyst.scala 42:18 21:23]
    node _GEN_56 = mux(rWen, _GEN_40, mem_15) @[CacheSyst.scala 42:18 21:23]
    node _cnt_T = sub(cnt, UInt<1>("h1")) @[CacheSyst.scala 43:30]
    node _cnt_T_1 = tail(_cnt_T, 1) @[CacheSyst.scala 43:30]
    node _GEN_57 = mux(_T_2, UInt<1>("h0"), _GEN_2) @[CacheSyst.scala 40:23 41:12]
    node _GEN_58 = mux(_T_2, _GEN_41, mem_0) @[CacheSyst.scala 21:23 40:23]
    node _GEN_59 = mux(_T_2, _GEN_42, mem_1) @[CacheSyst.scala 21:23 40:23]
    node _GEN_60 = mux(_T_2, _GEN_43, mem_2) @[CacheSyst.scala 21:23 40:23]
    node _GEN_61 = mux(_T_2, _GEN_44, mem_3) @[CacheSyst.scala 21:23 40:23]
    node _GEN_62 = mux(_T_2, _GEN_45, mem_4) @[CacheSyst.scala 21:23 40:23]
    node _GEN_63 = mux(_T_2, _GEN_46, mem_5) @[CacheSyst.scala 21:23 40:23]
    node _GEN_64 = mux(_T_2, _GEN_47, mem_6) @[CacheSyst.scala 21:23 40:23]
    node _GEN_65 = mux(_T_2, _GEN_48, mem_7) @[CacheSyst.scala 21:23 40:23]
    node _GEN_66 = mux(_T_2, _GEN_49, mem_8) @[CacheSyst.scala 21:23 40:23]
    node _GEN_67 = mux(_T_2, _GEN_50, mem_9) @[CacheSyst.scala 21:23 40:23]
    node _GEN_68 = mux(_T_2, _GEN_51, mem_10) @[CacheSyst.scala 21:23 40:23]
    node _GEN_69 = mux(_T_2, _GEN_52, mem_11) @[CacheSyst.scala 21:23 40:23]
    node _GEN_70 = mux(_T_2, _GEN_53, mem_12) @[CacheSyst.scala 21:23 40:23]
    node _GEN_71 = mux(_T_2, _GEN_54, mem_13) @[CacheSyst.scala 21:23 40:23]
    node _GEN_72 = mux(_T_2, _GEN_55, mem_14) @[CacheSyst.scala 21:23 40:23]
    node _GEN_73 = mux(_T_2, _GEN_56, mem_15) @[CacheSyst.scala 21:23 40:23]
    node _GEN_74 = mux(_T_2, _GEN_3, _cnt_T_1) @[CacheSyst.scala 40:23 43:23]
    node _GEN_75 = mux(busy, _GEN_57, _GEN_2) @[CacheSyst.scala 39:14]
    node _GEN_76 = mux(busy, _GEN_58, mem_0) @[CacheSyst.scala 39:14 21:23]
    node _GEN_77 = mux(busy, _GEN_59, mem_1) @[CacheSyst.scala 39:14 21:23]
    node _GEN_78 = mux(busy, _GEN_60, mem_2) @[CacheSyst.scala 39:14 21:23]
    node _GEN_79 = mux(busy, _GEN_61, mem_3) @[CacheSyst.scala 39:14 21:23]
    node _GEN_80 = mux(busy, _GEN_62, mem_4) @[CacheSyst.scala 39:14 21:23]
    node _GEN_81 = mux(busy, _GEN_63, mem_5) @[CacheSyst.scala 39:14 21:23]
    node _GEN_82 = mux(busy, _GEN_64, mem_6) @[CacheSyst.scala 39:14 21:23]
    node _GEN_83 = mux(busy, _GEN_65, mem_7) @[CacheSyst.scala 39:14 21:23]
    node _GEN_84 = mux(busy, _GEN_66, mem_8) @[CacheSyst.scala 39:14 21:23]
    node _GEN_85 = mux(busy, _GEN_67, mem_9) @[CacheSyst.scala 39:14 21:23]
    node _GEN_86 = mux(busy, _GEN_68, mem_10) @[CacheSyst.scala 39:14 21:23]
    node _GEN_87 = mux(busy, _GEN_69, mem_11) @[CacheSyst.scala 39:14 21:23]
    node _GEN_88 = mux(busy, _GEN_70, mem_12) @[CacheSyst.scala 39:14 21:23]
    node _GEN_89 = mux(busy, _GEN_71, mem_13) @[CacheSyst.scala 39:14 21:23]
    node _GEN_90 = mux(busy, _GEN_72, mem_14) @[CacheSyst.scala 39:14 21:23]
    node _GEN_91 = mux(busy, _GEN_73, mem_15) @[CacheSyst.scala 39:14 21:23]
    node _GEN_92 = mux(busy, _GEN_74, _GEN_3) @[CacheSyst.scala 39:14]
    node _mem_WIRE_0 = UInt<32>("h100") @[CacheSyst.scala 21:{31,31}]
    node _mem_WIRE_1 = UInt<32>("h101") @[CacheSyst.scala 21:{31,31}]
    node _mem_WIRE_2 = UInt<32>("h102") @[CacheSyst.scala 21:{31,31}]
    node _mem_WIRE_3 = UInt<32>("h103") @[CacheSyst.scala 21:{31,31}]
    node _mem_WIRE_4 = UInt<32>("h104") @[CacheSyst.scala 21:{31,31}]
    node _mem_WIRE_5 = UInt<32>("h105") @[CacheSyst.scala 21:{31,31}]
    node _mem_WIRE_6 = UInt<32>("h106") @[CacheSyst.scala 21:{31,31}]
    node _mem_WIRE_7 = UInt<32>("h107") @[CacheSyst.scala 21:{31,31}]
    node _mem_WIRE_8 = UInt<32>("h108") @[CacheSyst.scala 21:{31,31}]
    node _mem_WIRE_9 = UInt<32>("h109") @[CacheSyst.scala 21:{31,31}]
    node _mem_WIRE_10 = UInt<32>("h10a") @[CacheSyst.scala 21:{31,31}]
    node _mem_WIRE_11 = UInt<32>("h10b") @[CacheSyst.scala 21:{31,31}]
    node _mem_WIRE_12 = UInt<32>("h10c") @[CacheSyst.scala 21:{31,31}]
    node _mem_WIRE_13 = UInt<32>("h10d") @[CacheSyst.scala 21:{31,31}]
    node _mem_WIRE_14 = UInt<32>("h10e") @[CacheSyst.scala 21:{31,31}]
    node _mem_WIRE_15 = UInt<32>("h10f") @[CacheSyst.scala 21:{31,31}]
    node _mem_rAddr = _GEN_24 @[CacheSyst.scala 38:16]
    io_ready <= _io_ready_T @[CacheSyst.scala 30:12]
    io_respValid <= _io_respValid_T_1 @[CacheSyst.scala 37:16]
    io_rdata <= _mem_rAddr @[CacheSyst.scala 38:16]
    io_reads <= reads @[CacheSyst.scala 46:13]
    io_writes <= writes @[CacheSyst.scala 47:13]
    mem_0 <= mux(reset, _mem_WIRE_0, _GEN_76) @[CacheSyst.scala 21:{23,23}]
    mem_1 <= mux(reset, _mem_WIRE_1, _GEN_77) @[CacheSyst.scala 21:{23,23}]
    mem_2 <= mux(reset, _mem_WIRE_2, _GEN_78) @[CacheSyst.scala 21:{23,23}]
    mem_3 <= mux(reset, _mem_WIRE_3, _GEN_79) @[CacheSyst.scala 21:{23,23}]
    mem_4 <= mux(reset, _mem_WIRE_4, _GEN_80) @[CacheSyst.scala 21:{23,23}]
    mem_5 <= mux(reset, _mem_WIRE_5, _GEN_81) @[CacheSyst.scala 21:{23,23}]
    mem_6 <= mux(reset, _mem_WIRE_6, _GEN_82) @[CacheSyst.scala 21:{23,23}]
    mem_7 <= mux(reset, _mem_WIRE_7, _GEN_83) @[CacheSyst.scala 21:{23,23}]
    mem_8 <= mux(reset, _mem_WIRE_8, _GEN_84) @[CacheSyst.scala 21:{23,23}]
    mem_9 <= mux(reset, _mem_WIRE_9, _GEN_85) @[CacheSyst.scala 21:{23,23}]
    mem_10 <= mux(reset, _mem_WIRE_10, _GEN_86) @[CacheSyst.scala 21:{23,23}]
    mem_11 <= mux(reset, _mem_WIRE_11, _GEN_87) @[CacheSyst.scala 21:{23,23}]
    mem_12 <= mux(reset, _mem_WIRE_12, _GEN_88) @[CacheSyst.scala 21:{23,23}]
    mem_13 <= mux(reset, _mem_WIRE_13, _GEN_89) @[CacheSyst.scala 21:{23,23}]
    mem_14 <= mux(reset, _mem_WIRE_14, _GEN_90) @[CacheSyst.scala 21:{23,23}]
    mem_15 <= mux(reset, _mem_WIRE_15, _GEN_91) @[CacheSyst.scala 21:{23,23}]
    busy <= mux(reset, UInt<1>("h0"), _GEN_75) @[CacheSyst.scala 22:{23,23}]
    cnt <= _GEN_92
    rWen <= _GEN_4
    rAddr <= _GEN_5
    rWdata <= _GEN_6
    reads <= mux(reset, UInt<8>("h0"), _GEN_8) @[CacheSyst.scala 27:{23,23}]
    writes <= mux(reset, UInt<8>("h0"), _GEN_7) @[CacheSyst.scala 28:{23,23}]
