package rv32i

import chisel3._
import chisel3.util._

class Control extends Module {
  val io = IO(new Bundle {
    val instr = Input(UInt(32.W))
    val aluOp = Output(UInt(ALUOp.width.W))
    val aluSrc, regWrite, memRead, memWrite, memToReg =
      Output(Bool())
    val branch, jump, jalr, valid = Output(Bool())
  })

  val op = io.instr(6, 0)
  val f3 = io.instr(14, 12)
  val f7 = io.instr(31, 25)

  val OP = "b0110011".U
  val IMM = "b0010011".U
  val LD = "b0000011".U
  val ST = "b0100011".U
  val BR = "b1100011".U
  val JAL = "b1101111".U
  val JALR = "b1100111".U
  val LUI = "b0110111".U
  val AUIPC = "b0010111".U

  val isR = op === OP
  val isI = op === IMM
  val isLd = op === LD
  val isSt = op === ST
  val isBr = op === BR
  val isJal = op === JAL
  val isJalr = (op === JALR) && (f3 === 0.U)
  val isU = (op === LUI) || (op === AUIPC)

  io.valid := isR || isI || isLd || isSt || isBr ||
              isJal || isJalr || isU
  io.regWrite := isR || isI || isLd || isJal || isJalr || isU
  io.aluSrc := isI || isLd || isSt || isJal || isJalr || isU
  io.memRead := isLd
  io.memWrite := isSt
  io.memToReg := isLd
  io.branch := isBr
  io.jump := isJal
  io.jalr := isJalr

  val aluFun = MuxLookup(f3, ALUOp.NOP, Seq(
    0.U -> Mux(isR && (f7 === "b0100000".U), ALUOp.SUB, ALUOp.ADD),
    1.U -> ALUOp.SLL,
    2.U -> ALUOp.SLT,
    3.U -> ALUOp.SLTU,
    4.U -> ALUOp.XOR,
    5.U -> Mux(f7 === "b0100000".U, ALUOp.SRA, ALUOp.SRL),
    6.U -> ALUOp.OR,
    7.U -> ALUOp.AND
  ))

  val branchFun = MuxLookup(f3, ALUOp.NOP, Seq(
    0.U -> ALUOp.EQ,
    1.U -> ALUOp.NE,
    4.U -> ALUOp.SLT,
    5.U -> ALUOp.SLT,
    6.U -> ALUOp.SLTU,
    7.U -> ALUOp.SLTU
  ))

  io.aluOp := Mux(isR || isI, aluFun,
              Mux(isBr, branchFun,
              Mux(isLd || isSt || isJal || isJalr || isU,
                  ALUOp.ADD, ALUOp.NOP)))
}

