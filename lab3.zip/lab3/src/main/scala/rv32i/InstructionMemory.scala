package rv32i

import chisel3._
import chisel3.util._
import chisel3.util.experimental.loadMemoryFromFile

class InstructionMemory(p: CoreParams) extends Module {

  val io = IO(new Bundle {
    val addr = Input(UInt(p.xlen.W))
    val instr = Output(UInt(32.W))
  })

  val mem = Mem(p.instrMemWords, UInt(32.W))

  loadMemoryFromFile(mem, "memory.hex")

  val wordAddr = io.addr >> 2.U

  io.instr := mem(wordAddr)
}

