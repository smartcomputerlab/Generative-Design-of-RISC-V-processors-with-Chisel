package rv32i

import chisel3._

class RV32ICore(p: CoreParams) extends Module {

  val io = IO(new Bundle {
    val pc = Output(UInt(p.xlen.W))
    val nextPc = Output(UInt(p.xlen.W))

    val writeBack = Output(UInt(p.xlen.W))

    val debugX1 = Output(UInt(p.xlen.W))
    val debugX2 = Output(UInt(p.xlen.W))
    val debugX3 = Output(UInt(p.xlen.W))
    val debugX4 = Output(UInt(p.xlen.W))

    val debugALU = Output(UInt(p.xlen.W))
    val debugImm = Output(UInt(p.xlen.W))
  })

  val pcReg = RegInit(0.U(p.xlen.W))

  val instructionMemory = Module(new InstructionMemory(p))
  val datapath = Module(new Datapath(p))
  val dataMemory = Module(new DataMemory(p))

  instructionMemory.io.addr := pcReg

  datapath.io.instr := instructionMemory.io.instr
  datapath.io.pc := pcReg

  dataMemory.io.addr := datapath.io.memAddr
  dataMemory.io.wdata := datapath.io.memWdata
  dataMemory.io.memRead := datapath.io.memRead
  dataMemory.io.memWrite := datapath.io.memWrite
  dataMemory.io.funct3 := datapath.io.memFunct3

  datapath.io.memRdata := dataMemory.io.rdata

  pcReg := datapath.io.nextPc

  io.pc := pcReg
  io.nextPc := datapath.io.nextPc

  io.writeBack := datapath.io.writeBack

  io.debugX1 := datapath.io.debugX1
  io.debugX2 := datapath.io.debugX2
  io.debugX3 := datapath.io.debugX3
  io.debugX4 := datapath.io.debugX4

  io.debugALU := datapath.io.debugALU
  io.debugImm := datapath.io.debugImm
}

