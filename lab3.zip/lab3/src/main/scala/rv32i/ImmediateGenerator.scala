package rv32i

import chisel3._
import chisel3.util._

class ImmediateGenerator(p: CoreParams) extends Module {
  val io = IO(new Bundle {
    val instr = Input(UInt(32.W))
    val imm   = Output(UInt(p.xlen.W))
  })

  val inst = io.instr
  val opcode = inst(6, 0)

  val iImm = Cat(Fill(20, inst(31)), inst(31, 20))
  val sImm = Cat(Fill(20, inst(31)), inst(31, 25), inst(11, 7))
  val bImm = Cat(Fill(19, inst(31)), inst(31), inst(7),
                 inst(30, 25), inst(11, 8), 0.U(1.W))
  val uImm = Cat(inst(31, 12), 0.U(12.W))
  val jImm = Cat(Fill(11, inst(31)), inst(31), inst(19, 12),
                 inst(20), inst(30, 21), 0.U(1.W))

  io.imm := MuxLookup(opcode, 0.U(p.xlen.W), Seq(
    "b0000011".U -> iImm, // LOAD
    "b0010011".U -> iImm, // OP-IMM
    "b1100111".U -> iImm, // JALR
    "b0100011".U -> sImm, // STORE
    "b1100011".U -> bImm, // BRANCH
    "b0110111".U -> uImm, // LUI
    "b0010111".U -> uImm, // AUIPC
    "b1101111".U -> jImm  // JAL
  ))
}

