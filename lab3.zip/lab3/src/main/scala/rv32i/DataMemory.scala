package rv32i

import chisel3._
import chisel3.util._

class DataMemory(params: CoreParams) extends Module {
  val io = IO(new Bundle {
    val addr     = Input(UInt(params.xlen.W))
    val wdata    = Input(UInt(params.xlen.W))
    val rdata    = Output(UInt(params.xlen.W))
    val memRead  = Input(Bool())
    val memWrite = Input(Bool())
    val funct3   = Input(UInt(3.W))
  })
  val mem = Mem(params.dataMemWords, UInt(8.W))
  val b = (0 until 4).map(i => mem(io.addr + i.U))
  io.rdata := 0.U
  when(io.memRead) {
    switch(io.funct3) {
      is("b000".U) { io.rdata := Cat(Fill(24, b(0)(7)), b(0)) }       // LB
      is("b001".U) { io.rdata := Cat(Fill(16, b(1)(7)), b(1), b(0)) } // LH
      is("b010".U) { io.rdata := Cat(b.reverse) }                    // LW
      is("b100".U) { io.rdata := Cat(0.U(24.W), b(0)) }              // LBU
      is("b101".U) { io.rdata := Cat(0.U(16.W), b(1), b(0)) }        // LHU
    }
  }
  when(io.memWrite) {
    switch(io.funct3) {
      is("b000".U) { mem(io.addr) := io.wdata(7, 0) } // SB
      is("b001".U) {                                 // SH
        for (i <- 0 until 2) mem(io.addr + i.U) := io.wdata(8*i+7, 8*i)
      }
      is("b010".U) {                                 // SW
        for (i <- 0 until 4) mem(io.addr + i.U) := io.wdata(8*i+7, 8*i)
      }
    }
  }
}

