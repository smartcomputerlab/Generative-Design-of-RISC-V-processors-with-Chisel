package rv32i

import chisel3._
import chisel3.util._

class PCUpdate(p: CoreParams) extends Module {
  val io = IO(new Bundle {
    val pc, rs1, imm, aluResult = Input(UInt(p.xlen.W))
    val funct3 = Input(UInt(3.W))
    val branch, jump, jalr = Input(Bool())
    val nextPc = Output(UInt(p.xlen.W))
  })

  val branchTaken = io.branch && MuxLookup(io.funct3, false.B, Seq(
    0.U -> (io.aluResult === 1.U), // BEQ
    1.U -> (io.aluResult === 1.U), // BNE
    4.U -> (io.aluResult === 1.U), // BLT
    5.U -> (io.aluResult === 0.U), // BGE
    6.U -> (io.aluResult === 1.U), // BLTU
    7.U -> (io.aluResult === 0.U)  // BGEU
  ))

  io.nextPc := Mux(io.jalr, (io.rs1 + io.imm) & (~1.U(p.xlen.W)),
               Mux(io.jump || branchTaken, io.pc + io.imm, io.pc + 4.U))
}

