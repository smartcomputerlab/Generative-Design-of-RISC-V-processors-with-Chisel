package rv32i

object RV32IEncoding {

  def rType(
    funct7: Int,
    rs2: Int,
    rs1: Int,
    funct3: Int,
    rd: Int
  ): BigInt = {
    (BigInt(funct7 & 0x7f) << 25) |
    (BigInt(rs2 & 0x1f) << 20) |
    (BigInt(rs1 & 0x1f) << 15) |
    (BigInt(funct3 & 0x7) << 12) |
    (BigInt(rd & 0x1f) << 7) |
    BigInt(0x33)
  }

  def iType(
    imm: Int,
    rs1: Int,
    funct3: Int,
    rd: Int,
    opcode: Int = 0x13
  ): BigInt = {
    (BigInt(imm & 0xfff) << 20) |
    (BigInt(rs1 & 0x1f) << 15) |
    (BigInt(funct3 & 0x7) << 12) |
    (BigInt(rd & 0x1f) << 7) |
    BigInt(opcode & 0x7f)
  }

  def sType(
    imm: Int,
    rs1: Int,
    rs2: Int,
    funct3: Int,
    opcode: Int = 0x23
  ): BigInt = {
    val imm12 = imm & 0xfff

    val imm11_5 = (imm12 >> 5) & 0x7f
    val imm4_0  = imm12 & 0x1f

    (BigInt(imm11_5) << 25) |
    (BigInt(rs2 & 0x1f) << 20) |
    (BigInt(rs1 & 0x1f) << 15) |
    (BigInt(funct3 & 0x7) << 12) |
    (BigInt(imm4_0) << 7) |
    BigInt(opcode & 0x7f)
  }

  def bType(
    imm: Int,
    rs1: Int,
    rs2: Int,
    funct3: Int,
    opcode: Int = 0x63
  ): BigInt = {
    val imm13 = imm & 0x1fff

    val imm12   = (imm13 >> 12) & 0x1
    val imm11   = (imm13 >> 11) & 0x1
    val imm10_5 = (imm13 >> 5)  & 0x3f
    val imm4_1  = (imm13 >> 1)  & 0xf

    (BigInt(imm12) << 31) |
    (BigInt(imm10_5) << 25) |
    (BigInt(rs2 & 0x1f) << 20) |
    (BigInt(rs1 & 0x1f) << 15) |
    (BigInt(funct3 & 0x7) << 12) |
    (BigInt(imm4_1) << 8) |
    (BigInt(imm11) << 7) |
    BigInt(opcode & 0x7f)
  }

  def uType(
    imm: Int,
    rd: Int,
    opcode: Int
  ): BigInt = {
    (BigInt(imm & 0xfffff) << 12) |
    (BigInt(rd & 0x1f) << 7) |
    BigInt(opcode & 0x7f)
  }

  def jType(
    imm: Int,
    rd: Int,
    opcode: Int = 0x6f
  ): BigInt = {
    val imm21 = imm & 0x1fffff

    val imm20    = (imm21 >> 20) & 0x1
    val imm10_1  = (imm21 >> 1)  & 0x3ff
    val imm11    = (imm21 >> 11) & 0x1
    val imm19_12 = (imm21 >> 12) & 0xff

    (BigInt(imm20) << 31) |
    (BigInt(imm10_1) << 21) |
    (BigInt(imm11) << 20) |
    (BigInt(imm19_12) << 12) |
    (BigInt(rd & 0x1f) << 7) |
    BigInt(opcode & 0x7f)
  }

  def add(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x00, rs2, rs1, 0x0, rd)

  def sub(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x20, rs2, rs1, 0x0, rd)

  def sll(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x00, rs2, rs1, 0x1, rd)

  def slt(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x00, rs2, rs1, 0x2, rd)

  def sltu(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x00, rs2, rs1, 0x3, rd)

  def xor(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x00, rs2, rs1, 0x4, rd)

  def srl(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x00, rs2, rs1, 0x5, rd)

  def sra(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x20, rs2, rs1, 0x5, rd)

  def or(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x00, rs2, rs1, 0x6, rd)

  def and(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x00, rs2, rs1, 0x7, rd)

  def addi(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x0, rd)

  def slti(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x2, rd)

  def sltiu(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x3, rd)

  def xori(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x4, rd)

  def ori(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x6, rd)

  def andi(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x7, rd)

  def slli(rd: Int, rs1: Int, shamt: Int): BigInt =
    iType(shamt & 0x1f, rs1, 0x1, rd)

  def srli(rd: Int, rs1: Int, shamt: Int): BigInt =
    iType(shamt & 0x1f, rs1, 0x5, rd)

  def srai(rd: Int, rs1: Int, shamt: Int): BigInt =
    iType(0x400 | (shamt & 0x1f), rs1, 0x5, rd)

  def lb(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x0, rd, 0x03)

  def lh(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x1, rd, 0x03)

  def lw(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x2, rd, 0x03)

  def lbu(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x4, rd, 0x03)

  def lhu(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x5, rd, 0x03)

  def sb(rs2: Int, rs1: Int, imm: Int): BigInt =
    sType(imm, rs1, rs2, 0x0)

  def sh(rs2: Int, rs1: Int, imm: Int): BigInt =
    sType(imm, rs1, rs2, 0x1)

  def sw(rs2: Int, rs1: Int, imm: Int): BigInt =
    sType(imm, rs1, rs2, 0x2)

  def beq(rs1: Int, rs2: Int, imm: Int): BigInt =
    bType(imm, rs1, rs2, 0x0)

  def bne(rs1: Int, rs2: Int, imm: Int): BigInt =
    bType(imm, rs1, rs2, 0x1)

  def blt(rs1: Int, rs2: Int, imm: Int): BigInt =
    bType(imm, rs1, rs2, 0x4)

  def bge(rs1: Int, rs2: Int, imm: Int): BigInt =
    bType(imm, rs1, rs2, 0x5)

  def bltu(rs1: Int, rs2: Int, imm: Int): BigInt =
    bType(imm, rs1, rs2, 0x6)

  def bgeu(rs1: Int, rs2: Int, imm: Int): BigInt =
    bType(imm, rs1, rs2, 0x7)

  def jal(rd: Int, imm: Int): BigInt =
    jType(imm, rd)

  def jalr(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x0, rd, 0x67)

  def lui(rd: Int, imm: Int): BigInt =
    uType(imm, rd, 0x37)

  def auipc(rd: Int, imm: Int): BigInt =
    uType(imm, rd, 0x17)
}

