package rv32i

import chisel3._
import chisel3.util._

class Decoder extends Module {
  val io = IO(new Bundle {
    val instr = Input(UInt(32.W))
    val rs1 = Output(UInt(5.W))
    val rs2 = Output(UInt(5.W))
    val rd = Output(UInt(5.W))
    val funct3 = Output(UInt(3.W))
    val aluOp = Output(UInt(ALUOp.width.W))
    val aluSrc, regWrite, memRead, memWrite, memToReg = Output(Bool())
    val branch, jump, jalr, valid = Output(Bool())
  })

  def oneOf(x: UInt, xs: UInt*): Bool = xs.map(x === _).reduce(_ || _)

  val op = io.instr(6, 0)
  val f3 = io.instr(14, 12)
  val f7 = io.instr(31, 25)
  val fn = Cat(f7, f3)

  io.rs1 := io.instr(19, 15)
  io.rs2 := io.instr(24, 20)
  io.rd := io.instr(11, 7)
  io.funct3 := f3

  val rType = op === "b0110011".U
  val iType = op === "b0010011".U
  val load  = op === "b0000011".U
  val store = op === "b0100011".U
  val br    = op === "b1100011".U
  val jal   = op === "b1101111".U
  val jalr  = op === "b1100111".U && f3 === 0.U

  val rOps = Seq(
    "b0000000000".U -> ALUOp.ADD,  "b0100000000".U -> ALUOp.SUB,
    "b0000000001".U -> ALUOp.SLL,  "b0000000010".U -> ALUOp.SLT,
    "b0000000011".U -> ALUOp.SLTU, "b0000000100".U -> ALUOp.XOR,
    "b0000000101".U -> ALUOp.SRL,  "b0100000101".U -> ALUOp.SRA,
    "b0000000110".U -> ALUOp.OR,   "b0000000111".U -> ALUOp.AND
  )

  val iOps = Seq(
    0.U -> ALUOp.ADD, 2.U -> ALUOp.SLT, 3.U -> ALUOp.SLTU,
    4.U -> ALUOp.XOR, 6.U -> ALUOp.OR,  7.U -> ALUOp.AND
  )

  val rValid = oneOf(fn, rOps.map(_._1): _*)
  val iShift = (f3 === 1.U && f7 === 0.U) ||
               (f3 === 5.U && oneOf(f7, 0.U, "b0100000".U))
  val iValid = oneOf(f3, 0.U, 2.U, 3.U, 4.U, 6.U, 7.U) || iShift

  io.aluOp := ALUOp.NOP
  when(rType) {
    io.aluOp := MuxLookup(fn, ALUOp.NOP, rOps)
  }.elsewhen(iType) {
    io.aluOp := MuxLookup(f3, ALUOp.NOP, iOps)
    when(f3 === 1.U && f7 === 0.U) { io.aluOp := ALUOp.SLL }
    when(f3 === 5.U) {
      when(f7 === 0.U) { io.aluOp := ALUOp.SRL }
        .elsewhen(f7 === "b0100000".U) { io.aluOp := ALUOp.SRA }
    }
  }.elsewhen(load || store || jalr) {
    io.aluOp := ALUOp.ADD
  }

  io.valid := (rType && rValid) || (iType && iValid) ||
    (load && oneOf(f3, 0.U, 1.U, 2.U, 4.U, 5.U)) ||
    (store && oneOf(f3, 0.U, 1.U, 2.U)) ||
    (br && oneOf(f3, 0.U, 1.U, 4.U, 5.U, 6.U, 7.U)) ||
    jal || jalr

  io.aluSrc  := iType || load || store || jalr
  io.memRead := load
  io.memWrite := store
  io.memToReg := load
  io.branch := br
  io.jump := jal
  io.jalr := jalr
  io.regWrite := io.valid && (rType || iType || load || jal || jalr)
}

