package rv32i

import chisel3._
import chisel3.util._

class ALU(p: CoreParams) extends Module {

  val io = IO(new Bundle {
    val a  = Input(UInt(p.xlen.W))
    val b  = Input(UInt(p.xlen.W))
    val op = Input(UInt(ALUOp.width.W))
    val y  = Output(UInt(p.xlen.W))
  })

  val shamt = io.b(log2Ceil(p.xlen) - 1, 0)

  val signedA = io.a.asSInt
  val signedB = io.b.asSInt

  val equal    = io.a === io.b
  val notEqual = io.a =/= io.b

  io.y := MuxLookup(io.op, 0.U, Seq(
    ALUOp.ADD  -> (io.a + io.b),
    ALUOp.SUB  -> (io.a - io.b),
    ALUOp.SLL  -> (io.a << shamt),
    ALUOp.SLT  -> (signedA < signedB).asUInt,
    ALUOp.SLTU -> (io.a < io.b).asUInt,
    ALUOp.XOR  -> (io.a ^ io.b),
    ALUOp.SRL  -> (io.a >> shamt),
    ALUOp.SRA  -> (signedA >> shamt).asUInt,
    ALUOp.OR   -> (io.a | io.b),
    ALUOp.AND  -> (io.a & io.b),
    ALUOp.EQ   -> Mux(equal, 1.U(p.xlen.W), 0.U(p.xlen.W)),
    ALUOp.NE   -> Mux(notEqual, 1.U(p.xlen.W), 0.U(p.xlen.W))
  ))
}

