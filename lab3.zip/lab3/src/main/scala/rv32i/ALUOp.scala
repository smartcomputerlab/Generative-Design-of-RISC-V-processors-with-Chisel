package rv32i

import chisel3._

object ALUOp {
  val width = 4

  val ADD  = 0.U(width.W)
  val SUB  = 1.U(width.W)
  val SLL  = 2.U(width.W)
  val SLT  = 3.U(width.W)
  val SLTU = 4.U(width.W)
  val XOR  = 5.U(width.W)
  val SRL  = 6.U(width.W)
  val SRA  = 7.U(width.W)
  val OR   = 8.U(width.W)
  val AND  = 9.U(width.W)
  val EQ   = 10.U(width.W)
  val NE   = 11.U(width.W)
  val NOP  = 15.U(width.W)
}

