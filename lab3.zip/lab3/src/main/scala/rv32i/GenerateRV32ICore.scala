package rv32i

import chisel3.stage.ChiselStage

object GenerateRV32ICore extends App {
  val p = CoreParams()

  (new ChiselStage).emitVerilog(
    new RV32ICore(p),
    Array("--target-dir", "generated")
  )
}

