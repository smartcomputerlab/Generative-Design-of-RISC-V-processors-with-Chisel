package rv32i

import chisel3._
import chisel3.util._

class RegisterFile(p: CoreParams, initialValues: Seq[BigInt] = Seq.empty) extends Module {
  require(initialValues.isEmpty || initialValues.length == p.numRegs)

  val io = IO(new Bundle {
    val rs1, rs2, rd = Input(UInt(log2Ceil(p.numRegs).W))
    val writeData = Input(UInt(p.xlen.W))
    val writeEnable = Input(Bool())
    val readData1, readData2 = Output(UInt(p.xlen.W))
    val debugRead = Output(Vec(p.numRegs, UInt(p.xlen.W)))
  })

  // Initialize registers
  val init = if (initialValues.nonEmpty) initialValues
             else Seq.fill(p.numRegs)(BigInt(0))

  val regs = RegInit(VecInit(init.map(_.U(p.xlen.W))))

  // Read registers (x0 always returns zero)
  io.readData1 := Mux(io.rs1 === 0.U, 0.U, regs(io.rs1))
  io.readData2 := Mux(io.rs2 === 0.U, 0.U, regs(io.rs2))

  // Write register (x0 cannot be modified)
  when(io.writeEnable && io.rd =/= 0.U) {
    regs(io.rd) := io.writeData
  }

  // Debug outputs
  for (i <- 0 until p.numRegs) {
    io.debugRead(i) := (if (i == 0) 0.U else regs(i))
  }
}

