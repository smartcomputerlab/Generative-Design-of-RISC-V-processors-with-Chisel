package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class DecoderTest
    extends AnyFlatSpec
    with ChiselScalatestTester {

  behavior of "Decoder"

  it should "decode R-type and I-type instructions sequentially" in {

    test(new Decoder)
      .withAnnotations(Seq(WriteVcdAnnotation)) { dut =>

      dut.io.instr.poke(RV32IEncoding.add(3, 1, 2).U)
      dut.io.rs1.expect(1.U)
      dut.io.rs2.expect(2.U)
      dut.io.rd.expect(3.U)
      dut.io.aluOp.expect(ALUOp.ADD)
      dut.io.aluSrc.expect(false.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.sub(4, 2, 5).U)
      dut.io.rs1.expect(2.U)
      dut.io.rs2.expect(5.U)
      dut.io.rd.expect(4.U)
      dut.io.aluOp.expect(ALUOp.SUB)
      dut.io.aluSrc.expect(false.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.sll(5, 3, 6).U)
      dut.io.rs1.expect(3.U)
      dut.io.rs2.expect(6.U)
      dut.io.rd.expect(5.U)
      dut.io.aluOp.expect(ALUOp.SLL)
      dut.io.aluSrc.expect(false.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.slt(6, 4, 7).U)
      dut.io.rs1.expect(4.U)
      dut.io.rs2.expect(7.U)
      dut.io.rd.expect(6.U)
      dut.io.aluOp.expect(ALUOp.SLT)
      dut.io.aluSrc.expect(false.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.sltu(7, 5, 8).U)
      dut.io.rs1.expect(5.U)
      dut.io.rs2.expect(8.U)
      dut.io.rd.expect(7.U)
      dut.io.aluOp.expect(ALUOp.SLTU)
      dut.io.aluSrc.expect(false.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.xor(8, 6, 9).U)
      dut.io.rs1.expect(6.U)
      dut.io.rs2.expect(9.U)
      dut.io.rd.expect(8.U)
      dut.io.aluOp.expect(ALUOp.XOR)
      dut.io.aluSrc.expect(false.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.srl(9, 7, 10).U)
      dut.io.rs1.expect(7.U)
      dut.io.rs2.expect(10.U)
      dut.io.rd.expect(9.U)
      dut.io.aluOp.expect(ALUOp.SRL)
      dut.io.aluSrc.expect(false.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.sra(10, 8, 11).U)
      dut.io.rs1.expect(8.U)
      dut.io.rs2.expect(11.U)
      dut.io.rd.expect(10.U)
      dut.io.aluOp.expect(ALUOp.SRA)
      dut.io.aluSrc.expect(false.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.or(11, 9, 12).U)
      dut.io.rs1.expect(9.U)
      dut.io.rs2.expect(12.U)
      dut.io.rd.expect(11.U)
      dut.io.aluOp.expect(ALUOp.OR)
      dut.io.aluSrc.expect(false.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.and(12, 10, 13).U)
      dut.io.rs1.expect(10.U)
      dut.io.rs2.expect(13.U)
      dut.io.rd.expect(12.U)
      dut.io.aluOp.expect(ALUOp.AND)
      dut.io.aluSrc.expect(false.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.addi(13, 1, 10).U)
      dut.io.rs1.expect(1.U)
      dut.io.rd.expect(13.U)
      dut.io.aluOp.expect(ALUOp.ADD)
      dut.io.aluSrc.expect(true.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.addi(14, 2, -10).U)
      dut.io.rs1.expect(2.U)
      dut.io.rd.expect(14.U)
      dut.io.aluOp.expect(ALUOp.ADD)
      dut.io.aluSrc.expect(true.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(
        RV32IEncoding.slti(15, 3, 100).U
      )
      dut.io.rs1.expect(3.U)
      dut.io.rd.expect(15.U)
      dut.io.aluOp.expect(ALUOp.SLT)
      dut.io.aluSrc.expect(true.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(
        RV32IEncoding.sltiu(16, 4, 100).U
      )
      dut.io.rs1.expect(4.U)
      dut.io.rd.expect(16.U)
      dut.io.aluOp.expect(ALUOp.SLTU)
      dut.io.aluSrc.expect(true.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(
        RV32IEncoding.xori(17, 5, 0x55).U
      )
      dut.io.rs1.expect(5.U)
      dut.io.rd.expect(17.U)
      dut.io.aluOp.expect(ALUOp.XOR)
      dut.io.aluSrc.expect(true.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(
        RV32IEncoding.ori(18, 6, 0x55).U
      )
      dut.io.rs1.expect(6.U)
      dut.io.rd.expect(18.U)
      dut.io.aluOp.expect(ALUOp.OR)
      dut.io.aluSrc.expect(true.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(
        RV32IEncoding.andi(19, 7, 0x55).U
      )
      dut.io.rs1.expect(7.U)
      dut.io.rd.expect(19.U)
      dut.io.aluOp.expect(ALUOp.AND)
      dut.io.aluSrc.expect(true.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(
        RV32IEncoding.slli(20, 8, 3).U
      )
      dut.io.rs1.expect(8.U)
      dut.io.rd.expect(20.U)
      dut.io.aluOp.expect(ALUOp.SLL)
      dut.io.aluSrc.expect(true.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(
        RV32IEncoding.srli(21, 9, 3).U
      )
      dut.io.rs1.expect(9.U)
      dut.io.rd.expect(21.U)
      dut.io.aluOp.expect(ALUOp.SRL)
      dut.io.aluSrc.expect(true.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()

      dut.io.instr.poke(
        RV32IEncoding.srai(22, 10, 3).U
      )
      dut.io.rs1.expect(10.U)
      dut.io.rd.expect(22.U)
      dut.io.aluOp.expect(ALUOp.SRA)
      dut.io.aluSrc.expect(true.B)
      dut.io.regWrite.expect(true.B)
      dut.io.valid.expect(true.B)
      dut.clock.step()
    }
  }
}

