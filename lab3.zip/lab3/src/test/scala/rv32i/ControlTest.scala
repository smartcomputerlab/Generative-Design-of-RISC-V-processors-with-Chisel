package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class ControlTest extends AnyFlatSpec with ChiselScalatestTester {

  behavior of "Control"

  it should "decode all instructions sequentially" in {
    test(new Control)
      .withAnnotations(Seq(WriteVcdAnnotation)) { dut =>

      // R-type

      dut.io.instr.poke(RV32IEncoding.add(1, 2, 3).U)
      dut.clock.step()
      dut.io.valid.expect(true.B)
      dut.io.regWrite.expect(true.B)
      dut.io.aluSrc.expect(false.B)
      dut.io.aluOp.expect(ALUOp.ADD)

      dut.io.instr.poke(RV32IEncoding.sub(1, 2, 3).U)
      dut.clock.step()
      dut.io.aluOp.expect(ALUOp.SUB)

      dut.io.instr.poke(RV32IEncoding.sll(1, 2, 3).U)
      dut.clock.step()
      dut.io.aluOp.expect(ALUOp.SLL)

      dut.io.instr.poke(RV32IEncoding.slt(1, 2, 3).U)
      dut.clock.step()
      dut.io.aluOp.expect(ALUOp.SLT)

      dut.io.instr.poke(RV32IEncoding.sltu(1, 2, 3).U)
      dut.clock.step()
      dut.io.aluOp.expect(ALUOp.SLTU)

      dut.io.instr.poke(RV32IEncoding.xor(1, 2, 3).U)
      dut.clock.step()
      dut.io.aluOp.expect(ALUOp.XOR)

      dut.io.instr.poke(RV32IEncoding.srl(1, 2, 3).U)
      dut.clock.step()
      dut.io.aluOp.expect(ALUOp.SRL)

      dut.io.instr.poke(RV32IEncoding.sra(1, 2, 3).U)
      dut.clock.step()
      dut.io.aluOp.expect(ALUOp.SRA)

      dut.io.instr.poke(RV32IEncoding.or(1, 2, 3).U)
      dut.clock.step()
      dut.io.aluOp.expect(ALUOp.OR)

      dut.io.instr.poke(RV32IEncoding.and(1, 2, 3).U)
      dut.clock.step()
      dut.io.aluOp.expect(ALUOp.AND)

      // I-type ALU

      dut.io.instr.poke(RV32IEncoding.addi(1, 2, 10).U)
      dut.clock.step()
      dut.io.valid.expect(true.B)
      dut.io.regWrite.expect(true.B)
      dut.io.aluSrc.expect(true.B)
      dut.io.aluOp.expect(ALUOp.ADD)

      dut.io.instr.poke(RV32IEncoding.slti(1, 2, 10).U)
      dut.clock.step()
      dut.io.aluOp.expect(ALUOp.SLT)

      dut.io.instr.poke(RV32IEncoding.sltiu(1, 2, 10).U)
      dut.clock.step()
      dut.io.aluOp.expect(ALUOp.SLTU)

      dut.io.instr.poke(RV32IEncoding.xori(1, 2, 10).U)
      dut.clock.step()
      dut.io.aluOp.expect(ALUOp.XOR)

      dut.io.instr.poke(RV32IEncoding.ori(1, 2, 10).U)
      dut.clock.step()
      dut.io.aluOp.expect(ALUOp.OR)

      dut.io.instr.poke(RV32IEncoding.andi(1, 2, 10).U)
      dut.clock.step()
      dut.io.aluOp.expect(ALUOp.AND)

      dut.io.instr.poke(RV32IEncoding.slli(1, 2, 3).U)
      dut.clock.step()
      dut.io.aluOp.expect(ALUOp.SLL)

      dut.io.instr.poke(RV32IEncoding.srli(1, 2, 3).U)
      dut.clock.step()
      dut.io.aluOp.expect(ALUOp.SRL)

      dut.io.instr.poke(RV32IEncoding.srai(1, 2, 3).U)
      dut.clock.step()
      dut.io.aluOp.expect(ALUOp.SRA)

      // Loads

      dut.io.instr.poke(RV32IEncoding.lb(1, 2, 0).U)
      dut.clock.step()
      dut.io.valid.expect(true.B)
      dut.io.regWrite.expect(true.B)
      dut.io.aluSrc.expect(true.B)
      dut.io.memRead.expect(true.B)
      dut.io.memWrite.expect(false.B)
      dut.io.memToReg.expect(true.B)
      dut.io.aluOp.expect(ALUOp.ADD)

      dut.io.instr.poke(RV32IEncoding.lh(1, 2, 0).U)
      dut.clock.step()
      dut.io.memRead.expect(true.B)
      dut.io.memToReg.expect(true.B)

      dut.io.instr.poke(RV32IEncoding.lw(1, 2, 0).U)
      dut.clock.step()
      dut.io.memRead.expect(true.B)

      dut.io.instr.poke(RV32IEncoding.lbu(1, 2, 0).U)
      dut.clock.step()
      dut.io.memRead.expect(true.B)

      dut.io.instr.poke(RV32IEncoding.lhu(1, 2, 0).U)
      dut.clock.step()
      dut.io.memRead.expect(true.B)

      // Stores

      dut.io.instr.poke(RV32IEncoding.sb(2, 1, 0).U)
      dut.clock.step()
      dut.io.valid.expect(true.B)
      dut.io.regWrite.expect(false.B)
      dut.io.aluSrc.expect(true.B)
      dut.io.memRead.expect(false.B)
      dut.io.memWrite.expect(true.B)
      dut.io.memToReg.expect(false.B)
      dut.io.aluOp.expect(ALUOp.ADD)

      dut.io.instr.poke(RV32IEncoding.sh(2, 1, 4).U)
      dut.clock.step()
      dut.io.memWrite.expect(true.B)

      dut.io.instr.poke(RV32IEncoding.sw(2, 1, 8).U)
      dut.clock.step()
      dut.io.memWrite.expect(true.B)

      // Branches

      dut.io.instr.poke(RV32IEncoding.beq(1, 2, 8).U)
      dut.clock.step()
      dut.io.valid.expect(true.B)
      dut.io.branch.expect(true.B)
      dut.io.jump.expect(false.B)
      dut.io.jalr.expect(false.B)
      dut.io.regWrite.expect(false.B)
      dut.io.aluSrc.expect(false.B)
      dut.io.aluOp.expect(ALUOp.EQ)

      dut.io.instr.poke(RV32IEncoding.bne(1, 2, 8).U)
      dut.clock.step()
      dut.io.branch.expect(true.B)
      dut.io.aluOp.expect(ALUOp.NE)

      dut.io.instr.poke(RV32IEncoding.blt(1, 2, 8).U)
      dut.clock.step()
      dut.io.branch.expect(true.B)
      dut.io.aluOp.expect(ALUOp.SLT)

      dut.io.instr.poke(RV32IEncoding.bge(1, 2, 8).U)
      dut.clock.step()
      dut.io.branch.expect(true.B)
      dut.io.aluOp.expect(ALUOp.SLT)

      dut.io.instr.poke(RV32IEncoding.bltu(1, 2, 8).U)
      dut.clock.step()
      dut.io.branch.expect(true.B)
      dut.io.aluOp.expect(ALUOp.SLTU)

      dut.io.instr.poke(RV32IEncoding.bgeu(1, 2, 8).U)
      dut.clock.step()
      dut.io.branch.expect(true.B)
      dut.io.aluOp.expect(ALUOp.SLTU)

      // JAL

      dut.io.instr.poke(RV32IEncoding.jal(1, 16).U)
      dut.clock.step()
      dut.io.valid.expect(true.B)
      dut.io.jump.expect(true.B)
      dut.io.jalr.expect(false.B)
      dut.io.branch.expect(false.B)
      dut.io.regWrite.expect(true.B)

      // JALR

      dut.io.instr.poke(RV32IEncoding.jalr(1, 2, 4).U)
      dut.clock.step()
      dut.io.valid.expect(true.B)
      dut.io.jump.expect(false.B)
      dut.io.jalr.expect(true.B)
      dut.io.branch.expect(false.B)
      dut.io.regWrite.expect(true.B)
      dut.io.aluSrc.expect(true.B)
      dut.io.aluOp.expect(ALUOp.ADD)

      // LUI

      dut.io.instr.poke(RV32IEncoding.lui(1, 0x12345).U)
      dut.clock.step()
      dut.io.valid.expect(true.B)
      dut.io.regWrite.expect(true.B)
      dut.io.aluSrc.expect(true.B)
      dut.io.aluOp.expect(ALUOp.ADD)

      // AUIPC

      dut.io.instr.poke(RV32IEncoding.auipc(1, 0x12345).U)
      dut.clock.step()
      dut.io.valid.expect(true.B)
      dut.io.regWrite.expect(true.B)
      dut.io.aluSrc.expect(true.B)
      dut.io.aluOp.expect(ALUOp.ADD)

      // Invalid instruction

      dut.io.instr.poke("hFFFFFFFF".U)
      dut.clock.step()
      dut.io.valid.expect(false.B)
      dut.io.regWrite.expect(false.B)
      dut.io.memRead.expect(false.B)
      dut.io.memWrite.expect(false.B)
      dut.io.memToReg.expect(false.B)
      dut.io.branch.expect(false.B)
      dut.io.jump.expect(false.B)
      dut.io.jalr.expect(false.B)
      dut.io.aluOp.expect(ALUOp.NOP)

      dut.clock.step(2)
    }
  }
}

