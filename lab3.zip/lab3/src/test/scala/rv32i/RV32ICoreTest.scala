package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class RV32ICoreTest extends AnyFlatSpec with ChiselScalatestTester {

  behavior of "RV32ICore"

  it should "execute the program from memory.hex and generate a VCD" in {

    test(new RV32ICore(new CoreParams))
      .withAnnotations(Seq(WriteVcdAnnotation)) { dut =>

      for (cycle <- 0 until 60) {

        println(
          f"cycle=$cycle%2d  " +
          f"pc=0x${dut.io.pc.peek().litValue.toInt}%08x  " +
          f"x1=${dut.io.debugX1.peek().litValue}%d  " +
          f"x2=${dut.io.debugX2.peek().litValue}%d  " +
          f"x3=${dut.io.debugX3.peek().litValue}%d  " +
          f"x4=${dut.io.debugX4.peek().litValue}%d  " +
          f"alu=0x${dut.io.debugALU.peek().litValue.toInt}%08x  " +
          f"imm=${dut.io.debugImm.peek().litValue}%d"
        )

        dut.clock.step()
      }

      dut.io.debugX1.expect(6.U)
      dut.io.debugX2.expect(7.U)
      dut.io.debugX3.expect(42.U)
      dut.io.debugX4.expect(6.U)
    }
  }
}

