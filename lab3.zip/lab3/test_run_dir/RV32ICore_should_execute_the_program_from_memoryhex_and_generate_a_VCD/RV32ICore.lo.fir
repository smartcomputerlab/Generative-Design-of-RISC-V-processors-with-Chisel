FIRRTL version 1.1.0
circuit RV32ICore :
  module InstructionMemory :
    input clock : Clock
    input reset : UInt<1>
    input io_addr : UInt<32>
    output io_instr : UInt<32>

    mem mem : @[InstructionMemory.scala 14:16]
      data-type => UInt<32>
      depth => 1024
      read-latency => 0
      write-latency => 1
      reader => io_instr_MPORT
      read-under-write => undefined
    node wordAddr = dshr(io_addr, UInt<2>("h2")) @[InstructionMemory.scala 18:26]
    node _io_instr_T = bits(wordAddr, 9, 0) @[InstructionMemory.scala 20:18]
    io_instr <= mem.io_instr_MPORT.data @[InstructionMemory.scala 20:12]
    mem.io_instr_MPORT.addr <= _io_instr_T @[InstructionMemory.scala 20:18]
    mem.io_instr_MPORT.en <= UInt<1>("h1") @[InstructionMemory.scala 20:18]
    mem.io_instr_MPORT.clk <= clock @[InstructionMemory.scala 20:18]

  module Decoder :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    output io_rs1 : UInt<5>
    output io_rs2 : UInt<5>
    output io_rd : UInt<5>
    output io_funct3 : UInt<3>
    output io_aluOp : UInt<4>
    output io_aluSrc : UInt<1>
    output io_regWrite : UInt<1>
    output io_memRead : UInt<1>
    output io_memWrite : UInt<1>
    output io_memToReg : UInt<1>
    output io_branch : UInt<1>
    output io_jump : UInt<1>
    output io_jalr : UInt<1>
    output io_valid : UInt<1>

    node op = bits(io_instr, 6, 0) @[Decoder.scala 20:20]
    node f3 = bits(io_instr, 14, 12) @[Decoder.scala 21:20]
    node f7 = bits(io_instr, 31, 25) @[Decoder.scala 22:20]
    node fn = cat(f7, f3) @[Cat.scala 33:92]
    node _io_rs1_T = bits(io_instr, 19, 15) @[Decoder.scala 25:21]
    node _io_rs2_T = bits(io_instr, 24, 20) @[Decoder.scala 26:21]
    node _io_rd_T = bits(io_instr, 11, 7) @[Decoder.scala 27:20]
    node rType = eq(op, UInt<6>("h33")) @[Decoder.scala 30:18]
    node iType = eq(op, UInt<5>("h13")) @[Decoder.scala 31:18]
    node load = eq(op, UInt<2>("h3")) @[Decoder.scala 32:18]
    node store = eq(op, UInt<6>("h23")) @[Decoder.scala 33:18]
    node br = eq(op, UInt<7>("h63")) @[Decoder.scala 34:18]
    node jal = eq(op, UInt<7>("h6f")) @[Decoder.scala 35:18]
    node _jalr_T = eq(op, UInt<7>("h67")) @[Decoder.scala 36:18]
    node _jalr_T_1 = eq(f3, UInt<1>("h0")) @[Decoder.scala 36:41]
    node jalr = and(_jalr_T, _jalr_T_1) @[Decoder.scala 36:35]
    node _rValid_T = eq(fn, UInt<1>("h0")) @[Decoder.scala 18:50]
    node _rValid_T_1 = eq(fn, UInt<9>("h100")) @[Decoder.scala 18:50]
    node _rValid_T_2 = eq(fn, UInt<1>("h1")) @[Decoder.scala 18:50]
    node _rValid_T_3 = eq(fn, UInt<2>("h2")) @[Decoder.scala 18:50]
    node _rValid_T_4 = eq(fn, UInt<2>("h3")) @[Decoder.scala 18:50]
    node _rValid_T_5 = eq(fn, UInt<3>("h4")) @[Decoder.scala 18:50]
    node _rValid_T_6 = eq(fn, UInt<3>("h5")) @[Decoder.scala 18:50]
    node _rValid_T_7 = eq(fn, UInt<9>("h105")) @[Decoder.scala 18:50]
    node _rValid_T_8 = eq(fn, UInt<3>("h6")) @[Decoder.scala 18:50]
    node _rValid_T_9 = eq(fn, UInt<3>("h7")) @[Decoder.scala 18:50]
    node _rValid_T_10 = or(_rValid_T, _rValid_T_1) @[Decoder.scala 18:66]
    node _rValid_T_11 = or(_rValid_T_10, _rValid_T_2) @[Decoder.scala 18:66]
    node _rValid_T_12 = or(_rValid_T_11, _rValid_T_3) @[Decoder.scala 18:66]
    node _rValid_T_13 = or(_rValid_T_12, _rValid_T_4) @[Decoder.scala 18:66]
    node _rValid_T_14 = or(_rValid_T_13, _rValid_T_5) @[Decoder.scala 18:66]
    node _rValid_T_15 = or(_rValid_T_14, _rValid_T_6) @[Decoder.scala 18:66]
    node _rValid_T_16 = or(_rValid_T_15, _rValid_T_7) @[Decoder.scala 18:66]
    node _rValid_T_17 = or(_rValid_T_16, _rValid_T_8) @[Decoder.scala 18:66]
    node rValid = or(_rValid_T_17, _rValid_T_9) @[Decoder.scala 18:66]
    node _iShift_T = eq(f3, UInt<1>("h1")) @[Decoder.scala 52:20]
    node _iShift_T_1 = eq(f7, UInt<1>("h0")) @[Decoder.scala 52:34]
    node _iShift_T_2 = and(_iShift_T, _iShift_T_1) @[Decoder.scala 52:28]
    node _iShift_T_3 = eq(f3, UInt<3>("h5")) @[Decoder.scala 53:20]
    node _iShift_T_4 = eq(f7, UInt<1>("h0")) @[Decoder.scala 18:50]
    node _iShift_T_5 = eq(f7, UInt<6>("h20")) @[Decoder.scala 18:50]
    node _iShift_T_6 = or(_iShift_T_4, _iShift_T_5) @[Decoder.scala 18:66]
    node _iShift_T_7 = and(_iShift_T_3, _iShift_T_6) @[Decoder.scala 53:28]
    node iShift = or(_iShift_T_2, _iShift_T_7) @[Decoder.scala 52:43]
    node _iValid_T = eq(f3, UInt<1>("h0")) @[Decoder.scala 18:50]
    node _iValid_T_1 = eq(f3, UInt<2>("h2")) @[Decoder.scala 18:50]
    node _iValid_T_2 = eq(f3, UInt<2>("h3")) @[Decoder.scala 18:50]
    node _iValid_T_3 = eq(f3, UInt<3>("h4")) @[Decoder.scala 18:50]
    node _iValid_T_4 = eq(f3, UInt<3>("h6")) @[Decoder.scala 18:50]
    node _iValid_T_5 = eq(f3, UInt<3>("h7")) @[Decoder.scala 18:50]
    node _iValid_T_6 = or(_iValid_T, _iValid_T_1) @[Decoder.scala 18:66]
    node _iValid_T_7 = or(_iValid_T_6, _iValid_T_2) @[Decoder.scala 18:66]
    node _iValid_T_8 = or(_iValid_T_7, _iValid_T_3) @[Decoder.scala 18:66]
    node _iValid_T_9 = or(_iValid_T_8, _iValid_T_4) @[Decoder.scala 18:66]
    node _iValid_T_10 = or(_iValid_T_9, _iValid_T_5) @[Decoder.scala 18:66]
    node iValid = or(_iValid_T_10, iShift) @[Decoder.scala 54:56]
    node _io_aluOp_T = eq(UInt<1>("h0"), fn) @[Mux.scala 81:61]
    node _io_aluOp_T_1 = mux(_io_aluOp_T, UInt<4>("h0"), UInt<4>("hf")) @[Mux.scala 81:58]
    node _io_aluOp_T_2 = eq(UInt<9>("h100"), fn) @[Mux.scala 81:61]
    node _io_aluOp_T_3 = mux(_io_aluOp_T_2, UInt<4>("h1"), _io_aluOp_T_1) @[Mux.scala 81:58]
    node _io_aluOp_T_4 = eq(UInt<1>("h1"), fn) @[Mux.scala 81:61]
    node _io_aluOp_T_5 = mux(_io_aluOp_T_4, UInt<4>("h2"), _io_aluOp_T_3) @[Mux.scala 81:58]
    node _io_aluOp_T_6 = eq(UInt<2>("h2"), fn) @[Mux.scala 81:61]
    node _io_aluOp_T_7 = mux(_io_aluOp_T_6, UInt<4>("h3"), _io_aluOp_T_5) @[Mux.scala 81:58]
    node _io_aluOp_T_8 = eq(UInt<2>("h3"), fn) @[Mux.scala 81:61]
    node _io_aluOp_T_9 = mux(_io_aluOp_T_8, UInt<4>("h4"), _io_aluOp_T_7) @[Mux.scala 81:58]
    node _io_aluOp_T_10 = eq(UInt<3>("h4"), fn) @[Mux.scala 81:61]
    node _io_aluOp_T_11 = mux(_io_aluOp_T_10, UInt<4>("h5"), _io_aluOp_T_9) @[Mux.scala 81:58]
    node _io_aluOp_T_12 = eq(UInt<3>("h5"), fn) @[Mux.scala 81:61]
    node _io_aluOp_T_13 = mux(_io_aluOp_T_12, UInt<4>("h6"), _io_aluOp_T_11) @[Mux.scala 81:58]
    node _io_aluOp_T_14 = eq(UInt<9>("h105"), fn) @[Mux.scala 81:61]
    node _io_aluOp_T_15 = mux(_io_aluOp_T_14, UInt<4>("h7"), _io_aluOp_T_13) @[Mux.scala 81:58]
    node _io_aluOp_T_16 = eq(UInt<3>("h6"), fn) @[Mux.scala 81:61]
    node _io_aluOp_T_17 = mux(_io_aluOp_T_16, UInt<4>("h8"), _io_aluOp_T_15) @[Mux.scala 81:58]
    node _io_aluOp_T_18 = eq(UInt<3>("h7"), fn) @[Mux.scala 81:61]
    node _io_aluOp_T_19 = mux(_io_aluOp_T_18, UInt<4>("h9"), _io_aluOp_T_17) @[Mux.scala 81:58]
    node _io_aluOp_T_20 = eq(UInt<1>("h0"), f3) @[Mux.scala 81:61]
    node _io_aluOp_T_21 = mux(_io_aluOp_T_20, UInt<4>("h0"), UInt<4>("hf")) @[Mux.scala 81:58]
    node _io_aluOp_T_22 = eq(UInt<2>("h2"), f3) @[Mux.scala 81:61]
    node _io_aluOp_T_23 = mux(_io_aluOp_T_22, UInt<4>("h3"), _io_aluOp_T_21) @[Mux.scala 81:58]
    node _io_aluOp_T_24 = eq(UInt<2>("h3"), f3) @[Mux.scala 81:61]
    node _io_aluOp_T_25 = mux(_io_aluOp_T_24, UInt<4>("h4"), _io_aluOp_T_23) @[Mux.scala 81:58]
    node _io_aluOp_T_26 = eq(UInt<3>("h4"), f3) @[Mux.scala 81:61]
    node _io_aluOp_T_27 = mux(_io_aluOp_T_26, UInt<4>("h5"), _io_aluOp_T_25) @[Mux.scala 81:58]
    node _io_aluOp_T_28 = eq(UInt<3>("h6"), f3) @[Mux.scala 81:61]
    node _io_aluOp_T_29 = mux(_io_aluOp_T_28, UInt<4>("h8"), _io_aluOp_T_27) @[Mux.scala 81:58]
    node _io_aluOp_T_30 = eq(UInt<3>("h7"), f3) @[Mux.scala 81:61]
    node _io_aluOp_T_31 = mux(_io_aluOp_T_30, UInt<4>("h9"), _io_aluOp_T_29) @[Mux.scala 81:58]
    node _T = eq(f3, UInt<1>("h1")) @[Decoder.scala 61:13]
    node _T_1 = eq(f7, UInt<1>("h0")) @[Decoder.scala 61:27]
    node _T_2 = and(_T, _T_1) @[Decoder.scala 61:21]
    node _GEN_0 = mux(_T_2, UInt<4>("h2"), _io_aluOp_T_31) @[Decoder.scala 60:14 61:{36,47}]
    node _T_3 = eq(f3, UInt<3>("h5")) @[Decoder.scala 62:13]
    node _T_4 = eq(f7, UInt<1>("h0")) @[Decoder.scala 63:15]
    node _T_5 = eq(f7, UInt<6>("h20")) @[Decoder.scala 64:22]
    node _GEN_1 = mux(_T_5, UInt<4>("h7"), _GEN_0) @[Decoder.scala 64:{40,51}]
    node _GEN_2 = mux(_T_4, UInt<4>("h6"), _GEN_1) @[Decoder.scala 63:{24,35}]
    node _GEN_3 = mux(_T_3, _GEN_2, _GEN_0) @[Decoder.scala 62:22]
    node _T_6 = or(load, store) @[Decoder.scala 66:19]
    node _T_7 = or(_T_6, jalr) @[Decoder.scala 66:28]
    node _GEN_4 = mux(_T_7, UInt<4>("h0"), UInt<4>("hf")) @[Decoder.scala 56:12 66:37 67:14]
    node _GEN_5 = mux(iType, _GEN_3, _GEN_4) @[Decoder.scala 59:21]
    node _GEN_6 = mux(rType, _io_aluOp_T_19, _GEN_5) @[Decoder.scala 57:15 58:14]
    node _io_valid_T = and(rType, rValid) @[Decoder.scala 70:22]
    node _io_valid_T_1 = and(iType, iValid) @[Decoder.scala 70:43]
    node _io_valid_T_2 = or(_io_valid_T, _io_valid_T_1) @[Decoder.scala 70:33]
    node _io_valid_T_3 = eq(f3, UInt<1>("h0")) @[Decoder.scala 18:50]
    node _io_valid_T_4 = eq(f3, UInt<1>("h1")) @[Decoder.scala 18:50]
    node _io_valid_T_5 = eq(f3, UInt<2>("h2")) @[Decoder.scala 18:50]
    node _io_valid_T_6 = eq(f3, UInt<3>("h4")) @[Decoder.scala 18:50]
    node _io_valid_T_7 = eq(f3, UInt<3>("h5")) @[Decoder.scala 18:50]
    node _io_valid_T_8 = or(_io_valid_T_3, _io_valid_T_4) @[Decoder.scala 18:66]
    node _io_valid_T_9 = or(_io_valid_T_8, _io_valid_T_5) @[Decoder.scala 18:66]
    node _io_valid_T_10 = or(_io_valid_T_9, _io_valid_T_6) @[Decoder.scala 18:66]
    node _io_valid_T_11 = or(_io_valid_T_10, _io_valid_T_7) @[Decoder.scala 18:66]
    node _io_valid_T_12 = and(load, _io_valid_T_11) @[Decoder.scala 71:11]
    node _io_valid_T_13 = or(_io_valid_T_2, _io_valid_T_12) @[Decoder.scala 70:54]
    node _io_valid_T_14 = eq(f3, UInt<1>("h0")) @[Decoder.scala 18:50]
    node _io_valid_T_15 = eq(f3, UInt<1>("h1")) @[Decoder.scala 18:50]
    node _io_valid_T_16 = eq(f3, UInt<2>("h2")) @[Decoder.scala 18:50]
    node _io_valid_T_17 = or(_io_valid_T_14, _io_valid_T_15) @[Decoder.scala 18:66]
    node _io_valid_T_18 = or(_io_valid_T_17, _io_valid_T_16) @[Decoder.scala 18:66]
    node _io_valid_T_19 = and(store, _io_valid_T_18) @[Decoder.scala 72:12]
    node _io_valid_T_20 = or(_io_valid_T_13, _io_valid_T_19) @[Decoder.scala 71:50]
    node _io_valid_T_21 = eq(f3, UInt<1>("h0")) @[Decoder.scala 18:50]
    node _io_valid_T_22 = eq(f3, UInt<1>("h1")) @[Decoder.scala 18:50]
    node _io_valid_T_23 = eq(f3, UInt<3>("h4")) @[Decoder.scala 18:50]
    node _io_valid_T_24 = eq(f3, UInt<3>("h5")) @[Decoder.scala 18:50]
    node _io_valid_T_25 = eq(f3, UInt<3>("h6")) @[Decoder.scala 18:50]
    node _io_valid_T_26 = eq(f3, UInt<3>("h7")) @[Decoder.scala 18:50]
    node _io_valid_T_27 = or(_io_valid_T_21, _io_valid_T_22) @[Decoder.scala 18:66]
    node _io_valid_T_28 = or(_io_valid_T_27, _io_valid_T_23) @[Decoder.scala 18:66]
    node _io_valid_T_29 = or(_io_valid_T_28, _io_valid_T_24) @[Decoder.scala 18:66]
    node _io_valid_T_30 = or(_io_valid_T_29, _io_valid_T_25) @[Decoder.scala 18:66]
    node _io_valid_T_31 = or(_io_valid_T_30, _io_valid_T_26) @[Decoder.scala 18:66]
    node _io_valid_T_32 = and(br, _io_valid_T_31) @[Decoder.scala 73:9]
    node _io_valid_T_33 = or(_io_valid_T_20, _io_valid_T_32) @[Decoder.scala 72:41]
    node _io_valid_T_34 = or(_io_valid_T_33, jal) @[Decoder.scala 73:53]
    node _io_valid_T_35 = or(_io_valid_T_34, jalr) @[Decoder.scala 74:9]
    node _io_aluSrc_T = or(iType, load) @[Decoder.scala 76:23]
    node _io_aluSrc_T_1 = or(_io_aluSrc_T, store) @[Decoder.scala 76:31]
    node _io_aluSrc_T_2 = or(_io_aluSrc_T_1, jalr) @[Decoder.scala 76:40]
    node _io_regWrite_T = or(rType, iType) @[Decoder.scala 83:37]
    node _io_regWrite_T_1 = or(_io_regWrite_T, load) @[Decoder.scala 83:46]
    node _io_regWrite_T_2 = or(_io_regWrite_T_1, jal) @[Decoder.scala 83:54]
    node _io_regWrite_T_3 = or(_io_regWrite_T_2, jalr) @[Decoder.scala 83:61]
    node _io_regWrite_T_4 = and(io_valid, _io_regWrite_T_3) @[Decoder.scala 83:27]
    io_rs1 <= _io_rs1_T @[Decoder.scala 25:10]
    io_rs2 <= _io_rs2_T @[Decoder.scala 26:10]
    io_rd <= _io_rd_T @[Decoder.scala 27:9]
    io_funct3 <= f3 @[Decoder.scala 28:13]
    io_aluOp <= _GEN_6
    io_aluSrc <= _io_aluSrc_T_2 @[Decoder.scala 76:14]
    io_regWrite <= _io_regWrite_T_4 @[Decoder.scala 83:15]
    io_memRead <= load @[Decoder.scala 77:14]
    io_memWrite <= store @[Decoder.scala 78:15]
    io_memToReg <= load @[Decoder.scala 79:15]
    io_branch <= br @[Decoder.scala 80:13]
    io_jump <= jal @[Decoder.scala 81:11]
    io_jalr <= jalr @[Decoder.scala 82:11]
    io_valid <= _io_valid_T_35 @[Decoder.scala 70:12]

  module Control :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    output io_aluOp : UInt<4>
    output io_aluSrc : UInt<1>
    output io_regWrite : UInt<1>
    output io_memRead : UInt<1>
    output io_memWrite : UInt<1>
    output io_memToReg : UInt<1>
    output io_branch : UInt<1>
    output io_jump : UInt<1>
    output io_jalr : UInt<1>
    output io_valid : UInt<1>

    node op = bits(io_instr, 6, 0) @[Control.scala 15:20]
    node f3 = bits(io_instr, 14, 12) @[Control.scala 16:20]
    node f7 = bits(io_instr, 31, 25) @[Control.scala 17:20]
    node isR = eq(op, UInt<6>("h33")) @[Control.scala 29:16]
    node isI = eq(op, UInt<5>("h13")) @[Control.scala 30:16]
    node isLd = eq(op, UInt<2>("h3")) @[Control.scala 31:17]
    node isSt = eq(op, UInt<6>("h23")) @[Control.scala 32:17]
    node isBr = eq(op, UInt<7>("h63")) @[Control.scala 33:17]
    node isJal = eq(op, UInt<7>("h6f")) @[Control.scala 34:18]
    node _isJalr_T = eq(op, UInt<7>("h67")) @[Control.scala 35:20]
    node _isJalr_T_1 = eq(f3, UInt<1>("h0")) @[Control.scala 35:37]
    node isJalr = and(_isJalr_T, _isJalr_T_1) @[Control.scala 35:30]
    node _isU_T = eq(op, UInt<6>("h37")) @[Control.scala 36:17]
    node _isU_T_1 = eq(op, UInt<5>("h17")) @[Control.scala 36:33]
    node isU = or(_isU_T, _isU_T_1) @[Control.scala 36:26]
    node _io_valid_T = or(isR, isI) @[Control.scala 38:19]
    node _io_valid_T_1 = or(_io_valid_T, isLd) @[Control.scala 38:26]
    node _io_valid_T_2 = or(_io_valid_T_1, isSt) @[Control.scala 38:34]
    node _io_valid_T_3 = or(_io_valid_T_2, isBr) @[Control.scala 38:42]
    node _io_valid_T_4 = or(_io_valid_T_3, isJal) @[Control.scala 38:50]
    node _io_valid_T_5 = or(_io_valid_T_4, isJalr) @[Control.scala 39:21]
    node _io_valid_T_6 = or(_io_valid_T_5, isU) @[Control.scala 39:31]
    node _io_regWrite_T = or(isR, isI) @[Control.scala 40:22]
    node _io_regWrite_T_1 = or(_io_regWrite_T, isLd) @[Control.scala 40:29]
    node _io_regWrite_T_2 = or(_io_regWrite_T_1, isJal) @[Control.scala 40:37]
    node _io_regWrite_T_3 = or(_io_regWrite_T_2, isJalr) @[Control.scala 40:46]
    node _io_regWrite_T_4 = or(_io_regWrite_T_3, isU) @[Control.scala 40:56]
    node _io_aluSrc_T = or(isI, isLd) @[Control.scala 41:20]
    node _io_aluSrc_T_1 = or(_io_aluSrc_T, isSt) @[Control.scala 41:28]
    node _io_aluSrc_T_2 = or(_io_aluSrc_T_1, isJal) @[Control.scala 41:36]
    node _io_aluSrc_T_3 = or(_io_aluSrc_T_2, isJalr) @[Control.scala 41:45]
    node _io_aluSrc_T_4 = or(_io_aluSrc_T_3, isU) @[Control.scala 41:55]
    node _aluFun_T = eq(f7, UInt<6>("h20")) @[Control.scala 50:27]
    node _aluFun_T_1 = and(isR, _aluFun_T) @[Control.scala 50:20]
    node _aluFun_T_2 = mux(_aluFun_T_1, UInt<4>("h1"), UInt<4>("h0")) @[Control.scala 50:15]
    node _aluFun_T_3 = eq(f7, UInt<6>("h20")) @[Control.scala 55:19]
    node _aluFun_T_4 = mux(_aluFun_T_3, UInt<4>("h7"), UInt<4>("h6")) @[Control.scala 55:15]
    node _aluFun_T_5 = eq(UInt<1>("h1"), f3) @[Mux.scala 81:61]
    node _aluFun_T_6 = mux(_aluFun_T_5, UInt<4>("h2"), _aluFun_T_2) @[Mux.scala 81:58]
    node _aluFun_T_7 = eq(UInt<2>("h2"), f3) @[Mux.scala 81:61]
    node _aluFun_T_8 = mux(_aluFun_T_7, UInt<4>("h3"), _aluFun_T_6) @[Mux.scala 81:58]
    node _aluFun_T_9 = eq(UInt<2>("h3"), f3) @[Mux.scala 81:61]
    node _aluFun_T_10 = mux(_aluFun_T_9, UInt<4>("h4"), _aluFun_T_8) @[Mux.scala 81:58]
    node _aluFun_T_11 = eq(UInt<3>("h4"), f3) @[Mux.scala 81:61]
    node _aluFun_T_12 = mux(_aluFun_T_11, UInt<4>("h5"), _aluFun_T_10) @[Mux.scala 81:58]
    node _aluFun_T_13 = eq(UInt<3>("h5"), f3) @[Mux.scala 81:61]
    node _aluFun_T_14 = mux(_aluFun_T_13, _aluFun_T_4, _aluFun_T_12) @[Mux.scala 81:58]
    node _aluFun_T_15 = eq(UInt<3>("h6"), f3) @[Mux.scala 81:61]
    node _aluFun_T_16 = mux(_aluFun_T_15, UInt<4>("h8"), _aluFun_T_14) @[Mux.scala 81:58]
    node _aluFun_T_17 = eq(UInt<3>("h7"), f3) @[Mux.scala 81:61]
    node aluFun = mux(_aluFun_T_17, UInt<4>("h9"), _aluFun_T_16) @[Mux.scala 81:58]
    node _branchFun_T = eq(UInt<1>("h0"), f3) @[Mux.scala 81:61]
    node _branchFun_T_1 = mux(_branchFun_T, UInt<4>("ha"), UInt<4>("hf")) @[Mux.scala 81:58]
    node _branchFun_T_2 = eq(UInt<1>("h1"), f3) @[Mux.scala 81:61]
    node _branchFun_T_3 = mux(_branchFun_T_2, UInt<4>("hb"), _branchFun_T_1) @[Mux.scala 81:58]
    node _branchFun_T_4 = eq(UInt<3>("h4"), f3) @[Mux.scala 81:61]
    node _branchFun_T_5 = mux(_branchFun_T_4, UInt<4>("h3"), _branchFun_T_3) @[Mux.scala 81:58]
    node _branchFun_T_6 = eq(UInt<3>("h5"), f3) @[Mux.scala 81:61]
    node _branchFun_T_7 = mux(_branchFun_T_6, UInt<4>("h3"), _branchFun_T_5) @[Mux.scala 81:58]
    node _branchFun_T_8 = eq(UInt<3>("h6"), f3) @[Mux.scala 81:61]
    node _branchFun_T_9 = mux(_branchFun_T_8, UInt<4>("h4"), _branchFun_T_7) @[Mux.scala 81:58]
    node _branchFun_T_10 = eq(UInt<3>("h7"), f3) @[Mux.scala 81:61]
    node branchFun = mux(_branchFun_T_10, UInt<4>("h4"), _branchFun_T_9) @[Mux.scala 81:58]
    node _io_aluOp_T = or(isR, isI) @[Control.scala 69:23]
    node _io_aluOp_T_1 = or(isLd, isSt) @[Control.scala 71:24]
    node _io_aluOp_T_2 = or(_io_aluOp_T_1, isJal) @[Control.scala 71:32]
    node _io_aluOp_T_3 = or(_io_aluOp_T_2, isJalr) @[Control.scala 71:41]
    node _io_aluOp_T_4 = or(_io_aluOp_T_3, isU) @[Control.scala 71:51]
    node _io_aluOp_T_5 = mux(_io_aluOp_T_4, UInt<4>("h0"), UInt<4>("hf")) @[Control.scala 71:18]
    node _io_aluOp_T_6 = mux(isBr, branchFun, _io_aluOp_T_5) @[Control.scala 70:18]
    node _io_aluOp_T_7 = mux(_io_aluOp_T, aluFun, _io_aluOp_T_6) @[Control.scala 69:18]
    io_aluOp <= _io_aluOp_T_7 @[Control.scala 69:12]
    io_aluSrc <= _io_aluSrc_T_4 @[Control.scala 41:13]
    io_regWrite <= _io_regWrite_T_4 @[Control.scala 40:15]
    io_memRead <= isLd @[Control.scala 42:14]
    io_memWrite <= isSt @[Control.scala 43:15]
    io_memToReg <= isLd @[Control.scala 44:15]
    io_branch <= isBr @[Control.scala 45:13]
    io_jump <= isJal @[Control.scala 46:11]
    io_jalr <= isJalr @[Control.scala 47:11]
    io_valid <= _io_valid_T_6 @[Control.scala 38:12]

  module ImmediateGenerator :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    output io_imm : UInt<32>

    node opcode = bits(io_instr, 6, 0) @[ImmediateGenerator.scala 13:20]
    node _iImm_T = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 15:31]
    node _iImm_T_1 = bits(_iImm_T, 0, 0) @[Bitwise.scala 77:15]
    node _iImm_T_2 = mux(_iImm_T_1, UInt<20>("hfffff"), UInt<20>("h0")) @[Bitwise.scala 77:12]
    node _iImm_T_3 = bits(io_instr, 31, 20) @[ImmediateGenerator.scala 15:42]
    node iImm = cat(_iImm_T_2, _iImm_T_3) @[Cat.scala 33:92]
    node _sImm_T = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 16:31]
    node _sImm_T_1 = bits(_sImm_T, 0, 0) @[Bitwise.scala 77:15]
    node _sImm_T_2 = mux(_sImm_T_1, UInt<20>("hfffff"), UInt<20>("h0")) @[Bitwise.scala 77:12]
    node _sImm_T_3 = bits(io_instr, 31, 25) @[ImmediateGenerator.scala 16:42]
    node _sImm_T_4 = bits(io_instr, 11, 7) @[ImmediateGenerator.scala 16:56]
    node sImm_hi = cat(_sImm_T_2, _sImm_T_3) @[Cat.scala 33:92]
    node sImm = cat(sImm_hi, _sImm_T_4) @[Cat.scala 33:92]
    node _bImm_T = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 17:31]
    node _bImm_T_1 = bits(_bImm_T, 0, 0) @[Bitwise.scala 77:15]
    node _bImm_T_2 = mux(_bImm_T_1, UInt<19>("h7ffff"), UInt<19>("h0")) @[Bitwise.scala 77:12]
    node _bImm_T_3 = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 17:42]
    node _bImm_T_4 = bits(io_instr, 7, 7) @[ImmediateGenerator.scala 17:52]
    node _bImm_T_5 = bits(io_instr, 30, 25) @[ImmediateGenerator.scala 18:22]
    node _bImm_T_6 = bits(io_instr, 11, 8) @[ImmediateGenerator.scala 18:36]
    node bImm_lo_hi = cat(_bImm_T_5, _bImm_T_6) @[Cat.scala 33:92]
    node bImm_lo = cat(bImm_lo_hi, UInt<1>("h0")) @[Cat.scala 33:92]
    node bImm_hi_hi = cat(_bImm_T_2, _bImm_T_3) @[Cat.scala 33:92]
    node bImm_hi = cat(bImm_hi_hi, _bImm_T_4) @[Cat.scala 33:92]
    node bImm = cat(bImm_hi, bImm_lo) @[Cat.scala 33:92]
    node _uImm_T = bits(io_instr, 31, 12) @[ImmediateGenerator.scala 19:22]
    node uImm = cat(_uImm_T, UInt<12>("h0")) @[Cat.scala 33:92]
    node _jImm_T = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 20:31]
    node _jImm_T_1 = bits(_jImm_T, 0, 0) @[Bitwise.scala 77:15]
    node _jImm_T_2 = mux(_jImm_T_1, UInt<11>("h7ff"), UInt<11>("h0")) @[Bitwise.scala 77:12]
    node _jImm_T_3 = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 20:42]
    node _jImm_T_4 = bits(io_instr, 19, 12) @[ImmediateGenerator.scala 20:52]
    node _jImm_T_5 = bits(io_instr, 20, 20) @[ImmediateGenerator.scala 21:22]
    node _jImm_T_6 = bits(io_instr, 30, 21) @[ImmediateGenerator.scala 21:32]
    node jImm_lo_hi = cat(_jImm_T_5, _jImm_T_6) @[Cat.scala 33:92]
    node jImm_lo = cat(jImm_lo_hi, UInt<1>("h0")) @[Cat.scala 33:92]
    node jImm_hi_hi = cat(_jImm_T_2, _jImm_T_3) @[Cat.scala 33:92]
    node jImm_hi = cat(jImm_hi_hi, _jImm_T_4) @[Cat.scala 33:92]
    node jImm = cat(jImm_hi, jImm_lo) @[Cat.scala 33:92]
    node _io_imm_T = eq(UInt<2>("h3"), opcode) @[Mux.scala 81:61]
    node _io_imm_T_1 = mux(_io_imm_T, iImm, UInt<32>("h0")) @[Mux.scala 81:58]
    node _io_imm_T_2 = eq(UInt<5>("h13"), opcode) @[Mux.scala 81:61]
    node _io_imm_T_3 = mux(_io_imm_T_2, iImm, _io_imm_T_1) @[Mux.scala 81:58]
    node _io_imm_T_4 = eq(UInt<7>("h67"), opcode) @[Mux.scala 81:61]
    node _io_imm_T_5 = mux(_io_imm_T_4, iImm, _io_imm_T_3) @[Mux.scala 81:58]
    node _io_imm_T_6 = eq(UInt<6>("h23"), opcode) @[Mux.scala 81:61]
    node _io_imm_T_7 = mux(_io_imm_T_6, sImm, _io_imm_T_5) @[Mux.scala 81:58]
    node _io_imm_T_8 = eq(UInt<7>("h63"), opcode) @[Mux.scala 81:61]
    node _io_imm_T_9 = mux(_io_imm_T_8, bImm, _io_imm_T_7) @[Mux.scala 81:58]
    node _io_imm_T_10 = eq(UInt<6>("h37"), opcode) @[Mux.scala 81:61]
    node _io_imm_T_11 = mux(_io_imm_T_10, uImm, _io_imm_T_9) @[Mux.scala 81:58]
    node _io_imm_T_12 = eq(UInt<5>("h17"), opcode) @[Mux.scala 81:61]
    node _io_imm_T_13 = mux(_io_imm_T_12, uImm, _io_imm_T_11) @[Mux.scala 81:58]
    node _io_imm_T_14 = eq(UInt<7>("h6f"), opcode) @[Mux.scala 81:61]
    node _io_imm_T_15 = mux(_io_imm_T_14, jImm, _io_imm_T_13) @[Mux.scala 81:58]
    io_imm <= _io_imm_T_15 @[ImmediateGenerator.scala 23:10]

  module RegisterFile :
    input clock : Clock
    input reset : UInt<1>
    input io_rs1 : UInt<5>
    input io_rs2 : UInt<5>
    input io_rd : UInt<5>
    input io_writeData : UInt<32>
    input io_writeEnable : UInt<1>
    output io_readData1 : UInt<32>
    output io_readData2 : UInt<32>
    output io_debugRead_0 : UInt<32>
    output io_debugRead_1 : UInt<32>
    output io_debugRead_2 : UInt<32>
    output io_debugRead_3 : UInt<32>
    output io_debugRead_4 : UInt<32>
    output io_debugRead_5 : UInt<32>
    output io_debugRead_6 : UInt<32>
    output io_debugRead_7 : UInt<32>
    output io_debugRead_8 : UInt<32>
    output io_debugRead_9 : UInt<32>
    output io_debugRead_10 : UInt<32>
    output io_debugRead_11 : UInt<32>
    output io_debugRead_12 : UInt<32>
    output io_debugRead_13 : UInt<32>
    output io_debugRead_14 : UInt<32>
    output io_debugRead_15 : UInt<32>
    output io_debugRead_16 : UInt<32>
    output io_debugRead_17 : UInt<32>
    output io_debugRead_18 : UInt<32>
    output io_debugRead_19 : UInt<32>
    output io_debugRead_20 : UInt<32>
    output io_debugRead_21 : UInt<32>
    output io_debugRead_22 : UInt<32>
    output io_debugRead_23 : UInt<32>
    output io_debugRead_24 : UInt<32>
    output io_debugRead_25 : UInt<32>
    output io_debugRead_26 : UInt<32>
    output io_debugRead_27 : UInt<32>
    output io_debugRead_28 : UInt<32>
    output io_debugRead_29 : UInt<32>
    output io_debugRead_30 : UInt<32>
    output io_debugRead_31 : UInt<32>

    reg regs_0 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_0) @[RegisterFile.scala 21:21]
    reg regs_1 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_1) @[RegisterFile.scala 21:21]
    reg regs_2 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_2) @[RegisterFile.scala 21:21]
    reg regs_3 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_3) @[RegisterFile.scala 21:21]
    reg regs_4 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_4) @[RegisterFile.scala 21:21]
    reg regs_5 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_5) @[RegisterFile.scala 21:21]
    reg regs_6 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_6) @[RegisterFile.scala 21:21]
    reg regs_7 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_7) @[RegisterFile.scala 21:21]
    reg regs_8 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_8) @[RegisterFile.scala 21:21]
    reg regs_9 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_9) @[RegisterFile.scala 21:21]
    reg regs_10 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_10) @[RegisterFile.scala 21:21]
    reg regs_11 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_11) @[RegisterFile.scala 21:21]
    reg regs_12 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_12) @[RegisterFile.scala 21:21]
    reg regs_13 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_13) @[RegisterFile.scala 21:21]
    reg regs_14 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_14) @[RegisterFile.scala 21:21]
    reg regs_15 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_15) @[RegisterFile.scala 21:21]
    reg regs_16 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_16) @[RegisterFile.scala 21:21]
    reg regs_17 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_17) @[RegisterFile.scala 21:21]
    reg regs_18 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_18) @[RegisterFile.scala 21:21]
    reg regs_19 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_19) @[RegisterFile.scala 21:21]
    reg regs_20 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_20) @[RegisterFile.scala 21:21]
    reg regs_21 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_21) @[RegisterFile.scala 21:21]
    reg regs_22 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_22) @[RegisterFile.scala 21:21]
    reg regs_23 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_23) @[RegisterFile.scala 21:21]
    reg regs_24 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_24) @[RegisterFile.scala 21:21]
    reg regs_25 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_25) @[RegisterFile.scala 21:21]
    reg regs_26 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_26) @[RegisterFile.scala 21:21]
    reg regs_27 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_27) @[RegisterFile.scala 21:21]
    reg regs_28 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_28) @[RegisterFile.scala 21:21]
    reg regs_29 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_29) @[RegisterFile.scala 21:21]
    reg regs_30 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_30) @[RegisterFile.scala 21:21]
    reg regs_31 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_31) @[RegisterFile.scala 21:21]
    node _io_readData1_T = eq(io_rs1, UInt<1>("h0")) @[RegisterFile.scala 24:30]
    node _GEN_0 = validif(eq(UInt<1>("h0"), io_rs1), regs_0) @[RegisterFile.scala 24:{22,22}]
    node _GEN_1 = mux(eq(UInt<1>("h1"), io_rs1), regs_1, _GEN_0) @[RegisterFile.scala 24:{22,22}]
    node _GEN_2 = mux(eq(UInt<2>("h2"), io_rs1), regs_2, _GEN_1) @[RegisterFile.scala 24:{22,22}]
    node _GEN_3 = mux(eq(UInt<2>("h3"), io_rs1), regs_3, _GEN_2) @[RegisterFile.scala 24:{22,22}]
    node _GEN_4 = mux(eq(UInt<3>("h4"), io_rs1), regs_4, _GEN_3) @[RegisterFile.scala 24:{22,22}]
    node _GEN_5 = mux(eq(UInt<3>("h5"), io_rs1), regs_5, _GEN_4) @[RegisterFile.scala 24:{22,22}]
    node _GEN_6 = mux(eq(UInt<3>("h6"), io_rs1), regs_6, _GEN_5) @[RegisterFile.scala 24:{22,22}]
    node _GEN_7 = mux(eq(UInt<3>("h7"), io_rs1), regs_7, _GEN_6) @[RegisterFile.scala 24:{22,22}]
    node _GEN_8 = mux(eq(UInt<4>("h8"), io_rs1), regs_8, _GEN_7) @[RegisterFile.scala 24:{22,22}]
    node _GEN_9 = mux(eq(UInt<4>("h9"), io_rs1), regs_9, _GEN_8) @[RegisterFile.scala 24:{22,22}]
    node _GEN_10 = mux(eq(UInt<4>("ha"), io_rs1), regs_10, _GEN_9) @[RegisterFile.scala 24:{22,22}]
    node _GEN_11 = mux(eq(UInt<4>("hb"), io_rs1), regs_11, _GEN_10) @[RegisterFile.scala 24:{22,22}]
    node _GEN_12 = mux(eq(UInt<4>("hc"), io_rs1), regs_12, _GEN_11) @[RegisterFile.scala 24:{22,22}]
    node _GEN_13 = mux(eq(UInt<4>("hd"), io_rs1), regs_13, _GEN_12) @[RegisterFile.scala 24:{22,22}]
    node _GEN_14 = mux(eq(UInt<4>("he"), io_rs1), regs_14, _GEN_13) @[RegisterFile.scala 24:{22,22}]
    node _GEN_15 = mux(eq(UInt<4>("hf"), io_rs1), regs_15, _GEN_14) @[RegisterFile.scala 24:{22,22}]
    node _GEN_16 = mux(eq(UInt<5>("h10"), io_rs1), regs_16, _GEN_15) @[RegisterFile.scala 24:{22,22}]
    node _GEN_17 = mux(eq(UInt<5>("h11"), io_rs1), regs_17, _GEN_16) @[RegisterFile.scala 24:{22,22}]
    node _GEN_18 = mux(eq(UInt<5>("h12"), io_rs1), regs_18, _GEN_17) @[RegisterFile.scala 24:{22,22}]
    node _GEN_19 = mux(eq(UInt<5>("h13"), io_rs1), regs_19, _GEN_18) @[RegisterFile.scala 24:{22,22}]
    node _GEN_20 = mux(eq(UInt<5>("h14"), io_rs1), regs_20, _GEN_19) @[RegisterFile.scala 24:{22,22}]
    node _GEN_21 = mux(eq(UInt<5>("h15"), io_rs1), regs_21, _GEN_20) @[RegisterFile.scala 24:{22,22}]
    node _GEN_22 = mux(eq(UInt<5>("h16"), io_rs1), regs_22, _GEN_21) @[RegisterFile.scala 24:{22,22}]
    node _GEN_23 = mux(eq(UInt<5>("h17"), io_rs1), regs_23, _GEN_22) @[RegisterFile.scala 24:{22,22}]
    node _GEN_24 = mux(eq(UInt<5>("h18"), io_rs1), regs_24, _GEN_23) @[RegisterFile.scala 24:{22,22}]
    node _GEN_25 = mux(eq(UInt<5>("h19"), io_rs1), regs_25, _GEN_24) @[RegisterFile.scala 24:{22,22}]
    node _GEN_26 = mux(eq(UInt<5>("h1a"), io_rs1), regs_26, _GEN_25) @[RegisterFile.scala 24:{22,22}]
    node _GEN_27 = mux(eq(UInt<5>("h1b"), io_rs1), regs_27, _GEN_26) @[RegisterFile.scala 24:{22,22}]
    node _GEN_28 = mux(eq(UInt<5>("h1c"), io_rs1), regs_28, _GEN_27) @[RegisterFile.scala 24:{22,22}]
    node _GEN_29 = mux(eq(UInt<5>("h1d"), io_rs1), regs_29, _GEN_28) @[RegisterFile.scala 24:{22,22}]
    node _GEN_30 = mux(eq(UInt<5>("h1e"), io_rs1), regs_30, _GEN_29) @[RegisterFile.scala 24:{22,22}]
    node _GEN_31 = mux(eq(UInt<5>("h1f"), io_rs1), regs_31, _GEN_30) @[RegisterFile.scala 24:{22,22}]
    node _regs_io_rs1 = _GEN_31 @[RegisterFile.scala 24:22]
    node _io_readData1_T_1 = mux(_io_readData1_T, UInt<1>("h0"), _regs_io_rs1) @[RegisterFile.scala 24:22]
    node _io_readData2_T = eq(io_rs2, UInt<1>("h0")) @[RegisterFile.scala 25:30]
    node _GEN_32 = validif(eq(UInt<1>("h0"), io_rs2), regs_0) @[RegisterFile.scala 25:{22,22}]
    node _GEN_33 = mux(eq(UInt<1>("h1"), io_rs2), regs_1, _GEN_32) @[RegisterFile.scala 25:{22,22}]
    node _GEN_34 = mux(eq(UInt<2>("h2"), io_rs2), regs_2, _GEN_33) @[RegisterFile.scala 25:{22,22}]
    node _GEN_35 = mux(eq(UInt<2>("h3"), io_rs2), regs_3, _GEN_34) @[RegisterFile.scala 25:{22,22}]
    node _GEN_36 = mux(eq(UInt<3>("h4"), io_rs2), regs_4, _GEN_35) @[RegisterFile.scala 25:{22,22}]
    node _GEN_37 = mux(eq(UInt<3>("h5"), io_rs2), regs_5, _GEN_36) @[RegisterFile.scala 25:{22,22}]
    node _GEN_38 = mux(eq(UInt<3>("h6"), io_rs2), regs_6, _GEN_37) @[RegisterFile.scala 25:{22,22}]
    node _GEN_39 = mux(eq(UInt<3>("h7"), io_rs2), regs_7, _GEN_38) @[RegisterFile.scala 25:{22,22}]
    node _GEN_40 = mux(eq(UInt<4>("h8"), io_rs2), regs_8, _GEN_39) @[RegisterFile.scala 25:{22,22}]
    node _GEN_41 = mux(eq(UInt<4>("h9"), io_rs2), regs_9, _GEN_40) @[RegisterFile.scala 25:{22,22}]
    node _GEN_42 = mux(eq(UInt<4>("ha"), io_rs2), regs_10, _GEN_41) @[RegisterFile.scala 25:{22,22}]
    node _GEN_43 = mux(eq(UInt<4>("hb"), io_rs2), regs_11, _GEN_42) @[RegisterFile.scala 25:{22,22}]
    node _GEN_44 = mux(eq(UInt<4>("hc"), io_rs2), regs_12, _GEN_43) @[RegisterFile.scala 25:{22,22}]
    node _GEN_45 = mux(eq(UInt<4>("hd"), io_rs2), regs_13, _GEN_44) @[RegisterFile.scala 25:{22,22}]
    node _GEN_46 = mux(eq(UInt<4>("he"), io_rs2), regs_14, _GEN_45) @[RegisterFile.scala 25:{22,22}]
    node _GEN_47 = mux(eq(UInt<4>("hf"), io_rs2), regs_15, _GEN_46) @[RegisterFile.scala 25:{22,22}]
    node _GEN_48 = mux(eq(UInt<5>("h10"), io_rs2), regs_16, _GEN_47) @[RegisterFile.scala 25:{22,22}]
    node _GEN_49 = mux(eq(UInt<5>("h11"), io_rs2), regs_17, _GEN_48) @[RegisterFile.scala 25:{22,22}]
    node _GEN_50 = mux(eq(UInt<5>("h12"), io_rs2), regs_18, _GEN_49) @[RegisterFile.scala 25:{22,22}]
    node _GEN_51 = mux(eq(UInt<5>("h13"), io_rs2), regs_19, _GEN_50) @[RegisterFile.scala 25:{22,22}]
    node _GEN_52 = mux(eq(UInt<5>("h14"), io_rs2), regs_20, _GEN_51) @[RegisterFile.scala 25:{22,22}]
    node _GEN_53 = mux(eq(UInt<5>("h15"), io_rs2), regs_21, _GEN_52) @[RegisterFile.scala 25:{22,22}]
    node _GEN_54 = mux(eq(UInt<5>("h16"), io_rs2), regs_22, _GEN_53) @[RegisterFile.scala 25:{22,22}]
    node _GEN_55 = mux(eq(UInt<5>("h17"), io_rs2), regs_23, _GEN_54) @[RegisterFile.scala 25:{22,22}]
    node _GEN_56 = mux(eq(UInt<5>("h18"), io_rs2), regs_24, _GEN_55) @[RegisterFile.scala 25:{22,22}]
    node _GEN_57 = mux(eq(UInt<5>("h19"), io_rs2), regs_25, _GEN_56) @[RegisterFile.scala 25:{22,22}]
    node _GEN_58 = mux(eq(UInt<5>("h1a"), io_rs2), regs_26, _GEN_57) @[RegisterFile.scala 25:{22,22}]
    node _GEN_59 = mux(eq(UInt<5>("h1b"), io_rs2), regs_27, _GEN_58) @[RegisterFile.scala 25:{22,22}]
    node _GEN_60 = mux(eq(UInt<5>("h1c"), io_rs2), regs_28, _GEN_59) @[RegisterFile.scala 25:{22,22}]
    node _GEN_61 = mux(eq(UInt<5>("h1d"), io_rs2), regs_29, _GEN_60) @[RegisterFile.scala 25:{22,22}]
    node _GEN_62 = mux(eq(UInt<5>("h1e"), io_rs2), regs_30, _GEN_61) @[RegisterFile.scala 25:{22,22}]
    node _GEN_63 = mux(eq(UInt<5>("h1f"), io_rs2), regs_31, _GEN_62) @[RegisterFile.scala 25:{22,22}]
    node _regs_io_rs2 = _GEN_63 @[RegisterFile.scala 25:22]
    node _io_readData2_T_1 = mux(_io_readData2_T, UInt<1>("h0"), _regs_io_rs2) @[RegisterFile.scala 25:22]
    node _T = neq(io_rd, UInt<1>("h0")) @[RegisterFile.scala 28:32]
    node _T_1 = and(io_writeEnable, _T) @[RegisterFile.scala 28:23]
    node _regs_io_rd = io_writeData @[RegisterFile.scala 29:{17,17}]
    node _GEN_64 = mux(eq(UInt<1>("h0"), io_rd), _regs_io_rd, regs_0) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_65 = mux(eq(UInt<1>("h1"), io_rd), _regs_io_rd, regs_1) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_66 = mux(eq(UInt<2>("h2"), io_rd), _regs_io_rd, regs_2) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_67 = mux(eq(UInt<2>("h3"), io_rd), _regs_io_rd, regs_3) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_68 = mux(eq(UInt<3>("h4"), io_rd), _regs_io_rd, regs_4) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_69 = mux(eq(UInt<3>("h5"), io_rd), _regs_io_rd, regs_5) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_70 = mux(eq(UInt<3>("h6"), io_rd), _regs_io_rd, regs_6) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_71 = mux(eq(UInt<3>("h7"), io_rd), _regs_io_rd, regs_7) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_72 = mux(eq(UInt<4>("h8"), io_rd), _regs_io_rd, regs_8) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_73 = mux(eq(UInt<4>("h9"), io_rd), _regs_io_rd, regs_9) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_74 = mux(eq(UInt<4>("ha"), io_rd), _regs_io_rd, regs_10) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_75 = mux(eq(UInt<4>("hb"), io_rd), _regs_io_rd, regs_11) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_76 = mux(eq(UInt<4>("hc"), io_rd), _regs_io_rd, regs_12) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_77 = mux(eq(UInt<4>("hd"), io_rd), _regs_io_rd, regs_13) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_78 = mux(eq(UInt<4>("he"), io_rd), _regs_io_rd, regs_14) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_79 = mux(eq(UInt<4>("hf"), io_rd), _regs_io_rd, regs_15) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_80 = mux(eq(UInt<5>("h10"), io_rd), _regs_io_rd, regs_16) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_81 = mux(eq(UInt<5>("h11"), io_rd), _regs_io_rd, regs_17) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_82 = mux(eq(UInt<5>("h12"), io_rd), _regs_io_rd, regs_18) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_83 = mux(eq(UInt<5>("h13"), io_rd), _regs_io_rd, regs_19) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_84 = mux(eq(UInt<5>("h14"), io_rd), _regs_io_rd, regs_20) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_85 = mux(eq(UInt<5>("h15"), io_rd), _regs_io_rd, regs_21) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_86 = mux(eq(UInt<5>("h16"), io_rd), _regs_io_rd, regs_22) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_87 = mux(eq(UInt<5>("h17"), io_rd), _regs_io_rd, regs_23) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_88 = mux(eq(UInt<5>("h18"), io_rd), _regs_io_rd, regs_24) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_89 = mux(eq(UInt<5>("h19"), io_rd), _regs_io_rd, regs_25) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_90 = mux(eq(UInt<5>("h1a"), io_rd), _regs_io_rd, regs_26) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_91 = mux(eq(UInt<5>("h1b"), io_rd), _regs_io_rd, regs_27) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_92 = mux(eq(UInt<5>("h1c"), io_rd), _regs_io_rd, regs_28) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_93 = mux(eq(UInt<5>("h1d"), io_rd), _regs_io_rd, regs_29) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_94 = mux(eq(UInt<5>("h1e"), io_rd), _regs_io_rd, regs_30) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_95 = mux(eq(UInt<5>("h1f"), io_rd), _regs_io_rd, regs_31) @[RegisterFile.scala 29:{17,17} 21:21]
    node _GEN_96 = mux(_T_1, _GEN_64, regs_0) @[RegisterFile.scala 21:21 28:41]
    node _GEN_97 = mux(_T_1, _GEN_65, regs_1) @[RegisterFile.scala 21:21 28:41]
    node _GEN_98 = mux(_T_1, _GEN_66, regs_2) @[RegisterFile.scala 21:21 28:41]
    node _GEN_99 = mux(_T_1, _GEN_67, regs_3) @[RegisterFile.scala 21:21 28:41]
    node _GEN_100 = mux(_T_1, _GEN_68, regs_4) @[RegisterFile.scala 21:21 28:41]
    node _GEN_101 = mux(_T_1, _GEN_69, regs_5) @[RegisterFile.scala 21:21 28:41]
    node _GEN_102 = mux(_T_1, _GEN_70, regs_6) @[RegisterFile.scala 21:21 28:41]
    node _GEN_103 = mux(_T_1, _GEN_71, regs_7) @[RegisterFile.scala 21:21 28:41]
    node _GEN_104 = mux(_T_1, _GEN_72, regs_8) @[RegisterFile.scala 21:21 28:41]
    node _GEN_105 = mux(_T_1, _GEN_73, regs_9) @[RegisterFile.scala 21:21 28:41]
    node _GEN_106 = mux(_T_1, _GEN_74, regs_10) @[RegisterFile.scala 21:21 28:41]
    node _GEN_107 = mux(_T_1, _GEN_75, regs_11) @[RegisterFile.scala 21:21 28:41]
    node _GEN_108 = mux(_T_1, _GEN_76, regs_12) @[RegisterFile.scala 21:21 28:41]
    node _GEN_109 = mux(_T_1, _GEN_77, regs_13) @[RegisterFile.scala 21:21 28:41]
    node _GEN_110 = mux(_T_1, _GEN_78, regs_14) @[RegisterFile.scala 21:21 28:41]
    node _GEN_111 = mux(_T_1, _GEN_79, regs_15) @[RegisterFile.scala 21:21 28:41]
    node _GEN_112 = mux(_T_1, _GEN_80, regs_16) @[RegisterFile.scala 21:21 28:41]
    node _GEN_113 = mux(_T_1, _GEN_81, regs_17) @[RegisterFile.scala 21:21 28:41]
    node _GEN_114 = mux(_T_1, _GEN_82, regs_18) @[RegisterFile.scala 21:21 28:41]
    node _GEN_115 = mux(_T_1, _GEN_83, regs_19) @[RegisterFile.scala 21:21 28:41]
    node _GEN_116 = mux(_T_1, _GEN_84, regs_20) @[RegisterFile.scala 21:21 28:41]
    node _GEN_117 = mux(_T_1, _GEN_85, regs_21) @[RegisterFile.scala 21:21 28:41]
    node _GEN_118 = mux(_T_1, _GEN_86, regs_22) @[RegisterFile.scala 21:21 28:41]
    node _GEN_119 = mux(_T_1, _GEN_87, regs_23) @[RegisterFile.scala 21:21 28:41]
    node _GEN_120 = mux(_T_1, _GEN_88, regs_24) @[RegisterFile.scala 21:21 28:41]
    node _GEN_121 = mux(_T_1, _GEN_89, regs_25) @[RegisterFile.scala 21:21 28:41]
    node _GEN_122 = mux(_T_1, _GEN_90, regs_26) @[RegisterFile.scala 21:21 28:41]
    node _GEN_123 = mux(_T_1, _GEN_91, regs_27) @[RegisterFile.scala 21:21 28:41]
    node _GEN_124 = mux(_T_1, _GEN_92, regs_28) @[RegisterFile.scala 21:21 28:41]
    node _GEN_125 = mux(_T_1, _GEN_93, regs_29) @[RegisterFile.scala 21:21 28:41]
    node _GEN_126 = mux(_T_1, _GEN_94, regs_30) @[RegisterFile.scala 21:21 28:41]
    node _GEN_127 = mux(_T_1, _GEN_95, regs_31) @[RegisterFile.scala 21:21 28:41]
    node _regs_WIRE_0 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_1 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_2 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_3 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_4 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_5 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_6 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_7 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_8 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_9 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_10 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_11 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_12 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_13 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_14 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_15 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_16 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_17 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_18 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_19 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_20 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_21 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_22 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_23 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_24 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_25 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_26 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_27 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_28 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_29 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_30 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    node _regs_WIRE_31 = UInt<32>("h0") @[RegisterFile.scala 21:{29,29}]
    io_readData1 <= _io_readData1_T_1 @[RegisterFile.scala 24:16]
    io_readData2 <= _io_readData2_T_1 @[RegisterFile.scala 25:16]
    io_debugRead_0 <= UInt<32>("h0") @[RegisterFile.scala 34:21]
    io_debugRead_1 <= regs_1 @[RegisterFile.scala 34:21]
    io_debugRead_2 <= regs_2 @[RegisterFile.scala 34:21]
    io_debugRead_3 <= regs_3 @[RegisterFile.scala 34:21]
    io_debugRead_4 <= regs_4 @[RegisterFile.scala 34:21]
    io_debugRead_5 <= regs_5 @[RegisterFile.scala 34:21]
    io_debugRead_6 <= regs_6 @[RegisterFile.scala 34:21]
    io_debugRead_7 <= regs_7 @[RegisterFile.scala 34:21]
    io_debugRead_8 <= regs_8 @[RegisterFile.scala 34:21]
    io_debugRead_9 <= regs_9 @[RegisterFile.scala 34:21]
    io_debugRead_10 <= regs_10 @[RegisterFile.scala 34:21]
    io_debugRead_11 <= regs_11 @[RegisterFile.scala 34:21]
    io_debugRead_12 <= regs_12 @[RegisterFile.scala 34:21]
    io_debugRead_13 <= regs_13 @[RegisterFile.scala 34:21]
    io_debugRead_14 <= regs_14 @[RegisterFile.scala 34:21]
    io_debugRead_15 <= regs_15 @[RegisterFile.scala 34:21]
    io_debugRead_16 <= regs_16 @[RegisterFile.scala 34:21]
    io_debugRead_17 <= regs_17 @[RegisterFile.scala 34:21]
    io_debugRead_18 <= regs_18 @[RegisterFile.scala 34:21]
    io_debugRead_19 <= regs_19 @[RegisterFile.scala 34:21]
    io_debugRead_20 <= regs_20 @[RegisterFile.scala 34:21]
    io_debugRead_21 <= regs_21 @[RegisterFile.scala 34:21]
    io_debugRead_22 <= regs_22 @[RegisterFile.scala 34:21]
    io_debugRead_23 <= regs_23 @[RegisterFile.scala 34:21]
    io_debugRead_24 <= regs_24 @[RegisterFile.scala 34:21]
    io_debugRead_25 <= regs_25 @[RegisterFile.scala 34:21]
    io_debugRead_26 <= regs_26 @[RegisterFile.scala 34:21]
    io_debugRead_27 <= regs_27 @[RegisterFile.scala 34:21]
    io_debugRead_28 <= regs_28 @[RegisterFile.scala 34:21]
    io_debugRead_29 <= regs_29 @[RegisterFile.scala 34:21]
    io_debugRead_30 <= regs_30 @[RegisterFile.scala 34:21]
    io_debugRead_31 <= regs_31 @[RegisterFile.scala 34:21]
    regs_0 <= mux(reset, _regs_WIRE_0, _GEN_96) @[RegisterFile.scala 21:{21,21}]
    regs_1 <= mux(reset, _regs_WIRE_1, _GEN_97) @[RegisterFile.scala 21:{21,21}]
    regs_2 <= mux(reset, _regs_WIRE_2, _GEN_98) @[RegisterFile.scala 21:{21,21}]
    regs_3 <= mux(reset, _regs_WIRE_3, _GEN_99) @[RegisterFile.scala 21:{21,21}]
    regs_4 <= mux(reset, _regs_WIRE_4, _GEN_100) @[RegisterFile.scala 21:{21,21}]
    regs_5 <= mux(reset, _regs_WIRE_5, _GEN_101) @[RegisterFile.scala 21:{21,21}]
    regs_6 <= mux(reset, _regs_WIRE_6, _GEN_102) @[RegisterFile.scala 21:{21,21}]
    regs_7 <= mux(reset, _regs_WIRE_7, _GEN_103) @[RegisterFile.scala 21:{21,21}]
    regs_8 <= mux(reset, _regs_WIRE_8, _GEN_104) @[RegisterFile.scala 21:{21,21}]
    regs_9 <= mux(reset, _regs_WIRE_9, _GEN_105) @[RegisterFile.scala 21:{21,21}]
    regs_10 <= mux(reset, _regs_WIRE_10, _GEN_106) @[RegisterFile.scala 21:{21,21}]
    regs_11 <= mux(reset, _regs_WIRE_11, _GEN_107) @[RegisterFile.scala 21:{21,21}]
    regs_12 <= mux(reset, _regs_WIRE_12, _GEN_108) @[RegisterFile.scala 21:{21,21}]
    regs_13 <= mux(reset, _regs_WIRE_13, _GEN_109) @[RegisterFile.scala 21:{21,21}]
    regs_14 <= mux(reset, _regs_WIRE_14, _GEN_110) @[RegisterFile.scala 21:{21,21}]
    regs_15 <= mux(reset, _regs_WIRE_15, _GEN_111) @[RegisterFile.scala 21:{21,21}]
    regs_16 <= mux(reset, _regs_WIRE_16, _GEN_112) @[RegisterFile.scala 21:{21,21}]
    regs_17 <= mux(reset, _regs_WIRE_17, _GEN_113) @[RegisterFile.scala 21:{21,21}]
    regs_18 <= mux(reset, _regs_WIRE_18, _GEN_114) @[RegisterFile.scala 21:{21,21}]
    regs_19 <= mux(reset, _regs_WIRE_19, _GEN_115) @[RegisterFile.scala 21:{21,21}]
    regs_20 <= mux(reset, _regs_WIRE_20, _GEN_116) @[RegisterFile.scala 21:{21,21}]
    regs_21 <= mux(reset, _regs_WIRE_21, _GEN_117) @[RegisterFile.scala 21:{21,21}]
    regs_22 <= mux(reset, _regs_WIRE_22, _GEN_118) @[RegisterFile.scala 21:{21,21}]
    regs_23 <= mux(reset, _regs_WIRE_23, _GEN_119) @[RegisterFile.scala 21:{21,21}]
    regs_24 <= mux(reset, _regs_WIRE_24, _GEN_120) @[RegisterFile.scala 21:{21,21}]
    regs_25 <= mux(reset, _regs_WIRE_25, _GEN_121) @[RegisterFile.scala 21:{21,21}]
    regs_26 <= mux(reset, _regs_WIRE_26, _GEN_122) @[RegisterFile.scala 21:{21,21}]
    regs_27 <= mux(reset, _regs_WIRE_27, _GEN_123) @[RegisterFile.scala 21:{21,21}]
    regs_28 <= mux(reset, _regs_WIRE_28, _GEN_124) @[RegisterFile.scala 21:{21,21}]
    regs_29 <= mux(reset, _regs_WIRE_29, _GEN_125) @[RegisterFile.scala 21:{21,21}]
    regs_30 <= mux(reset, _regs_WIRE_30, _GEN_126) @[RegisterFile.scala 21:{21,21}]
    regs_31 <= mux(reset, _regs_WIRE_31, _GEN_127) @[RegisterFile.scala 21:{21,21}]

  module ALU :
    input clock : Clock
    input reset : UInt<1>
    input io_a : UInt<32>
    input io_b : UInt<32>
    input io_op : UInt<4>
    output io_y : UInt<32>

    node shamt = bits(io_b, 4, 0) @[ALU.scala 15:19]
    node signedA = asSInt(io_a) @[ALU.scala 17:22]
    node signedB = asSInt(io_b) @[ALU.scala 18:22]
    node equal = eq(io_a, io_b) @[ALU.scala 20:23]
    node notEqual = neq(io_a, io_b) @[ALU.scala 21:23]
    node _io_y_T = add(io_a, io_b) @[ALU.scala 24:25]
    node _io_y_T_1 = tail(_io_y_T, 1) @[ALU.scala 24:25]
    node _io_y_T_2 = sub(io_a, io_b) @[ALU.scala 25:25]
    node _io_y_T_3 = tail(_io_y_T_2, 1) @[ALU.scala 25:25]
    node _io_y_T_4 = dshl(io_a, shamt) @[ALU.scala 26:25]
    node _io_y_T_5 = lt(signedA, signedB) @[ALU.scala 27:28]
    node _io_y_T_6 = lt(io_a, io_b) @[ALU.scala 28:25]
    node _io_y_T_7 = xor(io_a, io_b) @[ALU.scala 29:25]
    node _io_y_T_8 = dshr(io_a, shamt) @[ALU.scala 30:25]
    node _io_y_T_9 = dshr(signedA, shamt) @[ALU.scala 31:28]
    node _io_y_T_10 = asUInt(_io_y_T_9) @[ALU.scala 31:38]
    node _io_y_T_11 = or(io_a, io_b) @[ALU.scala 32:25]
    node _io_y_T_12 = and(io_a, io_b) @[ALU.scala 33:25]
    node _io_y_T_13 = mux(equal, UInt<32>("h1"), UInt<32>("h0")) @[ALU.scala 34:22]
    node _io_y_T_14 = mux(notEqual, UInt<32>("h1"), UInt<32>("h0")) @[ALU.scala 35:22]
    node _io_y_T_15 = eq(UInt<4>("h0"), io_op) @[Mux.scala 81:61]
    node _io_y_T_16 = mux(_io_y_T_15, _io_y_T_1, UInt<1>("h0")) @[Mux.scala 81:58]
    node _io_y_T_17 = eq(UInt<4>("h1"), io_op) @[Mux.scala 81:61]
    node _io_y_T_18 = mux(_io_y_T_17, _io_y_T_3, _io_y_T_16) @[Mux.scala 81:58]
    node _io_y_T_19 = eq(UInt<4>("h2"), io_op) @[Mux.scala 81:61]
    node _io_y_T_20 = mux(_io_y_T_19, _io_y_T_4, _io_y_T_18) @[Mux.scala 81:58]
    node _io_y_T_21 = eq(UInt<4>("h3"), io_op) @[Mux.scala 81:61]
    node _io_y_T_22 = mux(_io_y_T_21, _io_y_T_5, _io_y_T_20) @[Mux.scala 81:58]
    node _io_y_T_23 = eq(UInt<4>("h4"), io_op) @[Mux.scala 81:61]
    node _io_y_T_24 = mux(_io_y_T_23, _io_y_T_6, _io_y_T_22) @[Mux.scala 81:58]
    node _io_y_T_25 = eq(UInt<4>("h5"), io_op) @[Mux.scala 81:61]
    node _io_y_T_26 = mux(_io_y_T_25, _io_y_T_7, _io_y_T_24) @[Mux.scala 81:58]
    node _io_y_T_27 = eq(UInt<4>("h6"), io_op) @[Mux.scala 81:61]
    node _io_y_T_28 = mux(_io_y_T_27, _io_y_T_8, _io_y_T_26) @[Mux.scala 81:58]
    node _io_y_T_29 = eq(UInt<4>("h7"), io_op) @[Mux.scala 81:61]
    node _io_y_T_30 = mux(_io_y_T_29, _io_y_T_10, _io_y_T_28) @[Mux.scala 81:58]
    node _io_y_T_31 = eq(UInt<4>("h8"), io_op) @[Mux.scala 81:61]
    node _io_y_T_32 = mux(_io_y_T_31, _io_y_T_11, _io_y_T_30) @[Mux.scala 81:58]
    node _io_y_T_33 = eq(UInt<4>("h9"), io_op) @[Mux.scala 81:61]
    node _io_y_T_34 = mux(_io_y_T_33, _io_y_T_12, _io_y_T_32) @[Mux.scala 81:58]
    node _io_y_T_35 = eq(UInt<4>("ha"), io_op) @[Mux.scala 81:61]
    node _io_y_T_36 = mux(_io_y_T_35, _io_y_T_13, _io_y_T_34) @[Mux.scala 81:58]
    node _io_y_T_37 = eq(UInt<4>("hb"), io_op) @[Mux.scala 81:61]
    node _io_y_T_38 = mux(_io_y_T_37, _io_y_T_14, _io_y_T_36) @[Mux.scala 81:58]
    io_y <= bits(_io_y_T_38, 31, 0) @[ALU.scala 23:8]

  module PCUpdate :
    input clock : Clock
    input reset : UInt<1>
    input io_pc : UInt<32>
    input io_rs1 : UInt<32>
    input io_imm : UInt<32>
    input io_aluResult : UInt<32>
    input io_funct3 : UInt<3>
    input io_branch : UInt<1>
    input io_jump : UInt<1>
    input io_jalr : UInt<1>
    output io_nextPc : UInt<32>

    node _branchTaken_T = eq(io_aluResult, UInt<1>("h1")) @[PCUpdate.scala 15:26]
    node _branchTaken_T_1 = eq(io_aluResult, UInt<1>("h1")) @[PCUpdate.scala 16:26]
    node _branchTaken_T_2 = eq(io_aluResult, UInt<1>("h1")) @[PCUpdate.scala 17:26]
    node _branchTaken_T_3 = eq(io_aluResult, UInt<1>("h0")) @[PCUpdate.scala 18:26]
    node _branchTaken_T_4 = eq(io_aluResult, UInt<1>("h1")) @[PCUpdate.scala 19:26]
    node _branchTaken_T_5 = eq(io_aluResult, UInt<1>("h0")) @[PCUpdate.scala 20:26]
    node _branchTaken_T_6 = eq(UInt<1>("h0"), io_funct3) @[Mux.scala 81:61]
    node _branchTaken_T_7 = mux(_branchTaken_T_6, _branchTaken_T, UInt<1>("h0")) @[Mux.scala 81:58]
    node _branchTaken_T_8 = eq(UInt<1>("h1"), io_funct3) @[Mux.scala 81:61]
    node _branchTaken_T_9 = mux(_branchTaken_T_8, _branchTaken_T_1, _branchTaken_T_7) @[Mux.scala 81:58]
    node _branchTaken_T_10 = eq(UInt<3>("h4"), io_funct3) @[Mux.scala 81:61]
    node _branchTaken_T_11 = mux(_branchTaken_T_10, _branchTaken_T_2, _branchTaken_T_9) @[Mux.scala 81:58]
    node _branchTaken_T_12 = eq(UInt<3>("h5"), io_funct3) @[Mux.scala 81:61]
    node _branchTaken_T_13 = mux(_branchTaken_T_12, _branchTaken_T_3, _branchTaken_T_11) @[Mux.scala 81:58]
    node _branchTaken_T_14 = eq(UInt<3>("h6"), io_funct3) @[Mux.scala 81:61]
    node _branchTaken_T_15 = mux(_branchTaken_T_14, _branchTaken_T_4, _branchTaken_T_13) @[Mux.scala 81:58]
    node _branchTaken_T_16 = eq(UInt<3>("h7"), io_funct3) @[Mux.scala 81:61]
    node _branchTaken_T_17 = mux(_branchTaken_T_16, _branchTaken_T_5, _branchTaken_T_15) @[Mux.scala 81:58]
    node branchTaken = and(io_branch, _branchTaken_T_17) @[PCUpdate.scala 14:31]
    node _io_nextPc_T = add(io_rs1, io_imm) @[PCUpdate.scala 23:37]
    node _io_nextPc_T_1 = tail(_io_nextPc_T, 1) @[PCUpdate.scala 23:37]
    node _io_nextPc_T_2 = not(UInt<32>("h1")) @[PCUpdate.scala 23:50]
    node _io_nextPc_T_3 = and(_io_nextPc_T_1, _io_nextPc_T_2) @[PCUpdate.scala 23:47]
    node _io_nextPc_T_4 = or(io_jump, branchTaken) @[PCUpdate.scala 24:28]
    node _io_nextPc_T_5 = add(io_pc, io_imm) @[PCUpdate.scala 24:50]
    node _io_nextPc_T_6 = tail(_io_nextPc_T_5, 1) @[PCUpdate.scala 24:50]
    node _io_nextPc_T_7 = add(io_pc, UInt<3>("h4")) @[PCUpdate.scala 24:66]
    node _io_nextPc_T_8 = tail(_io_nextPc_T_7, 1) @[PCUpdate.scala 24:66]
    node _io_nextPc_T_9 = mux(_io_nextPc_T_4, _io_nextPc_T_6, _io_nextPc_T_8) @[PCUpdate.scala 24:19]
    node _io_nextPc_T_10 = mux(io_jalr, _io_nextPc_T_3, _io_nextPc_T_9) @[PCUpdate.scala 23:19]
    io_nextPc <= _io_nextPc_T_10 @[PCUpdate.scala 23:13]

  module Datapath :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    input io_pc : UInt<32>
    output io_nextPc : UInt<32>
    output io_memRead : UInt<1>
    output io_memWrite : UInt<1>
    output io_memAddr : UInt<32>
    output io_memWdata : UInt<32>
    input io_memRdata : UInt<32>
    output io_memFunct3 : UInt<3>
    output io_writeBack : UInt<32>
    output io_debugX1 : UInt<32>
    output io_debugX2 : UInt<32>
    output io_debugX3 : UInt<32>
    output io_debugX4 : UInt<32>
    output io_debugALU : UInt<32>
    output io_debugImm : UInt<32>

    inst decoder of Decoder @[Datapath.scala 32:23]
    inst control of Control @[Datapath.scala 33:23]
    inst immGen of ImmediateGenerator @[Datapath.scala 34:23]
    inst regFile of RegisterFile @[Datapath.scala 35:23]
    inst alu of ALU @[Datapath.scala 36:23]
    inst pcUpdate of PCUpdate @[Datapath.scala 37:24]
    node aluB = mux(control.io_aluSrc, immGen.io_imm, regFile.io_readData2) @[Datapath.scala 59:17]
    node _writeBackData_T = or(control.io_jump, control.io_jalr) @[Datapath.scala 87:23]
    node _writeBackData_T_1 = add(io_pc, UInt<3>("h4")) @[Datapath.scala 88:13]
    node _writeBackData_T_2 = tail(_writeBackData_T_1, 1) @[Datapath.scala 88:13]
    node _writeBackData_T_3 = mux(_writeBackData_T, _writeBackData_T_2, alu.io_y) @[Datapath.scala 86:8]
    node writeBackData = mux(control.io_memToReg, io_memRdata, _writeBackData_T_3) @[Datapath.scala 83:26]
    io_nextPc <= pcUpdate.io_nextPc @[Datapath.scala 109:13]
    io_memRead <= control.io_memRead @[Datapath.scala 73:16]
    io_memWrite <= control.io_memWrite @[Datapath.scala 74:16]
    io_memAddr <= alu.io_y @[Datapath.scala 75:16]
    io_memWdata <= regFile.io_readData2 @[Datapath.scala 76:16]
    io_memFunct3 <= decoder.io_funct3 @[Datapath.scala 77:16]
    io_writeBack <= writeBackData @[Datapath.scala 115:16]
    io_debugX1 <= regFile.io_debugRead_1 @[Datapath.scala 117:14]
    io_debugX2 <= regFile.io_debugRead_2 @[Datapath.scala 118:14]
    io_debugX3 <= regFile.io_debugRead_3 @[Datapath.scala 119:14]
    io_debugX4 <= regFile.io_debugRead_4 @[Datapath.scala 120:14]
    io_debugALU <= alu.io_y @[Datapath.scala 122:15]
    io_debugImm <= immGen.io_imm @[Datapath.scala 123:15]
    decoder.clock <= clock
    decoder.reset <= reset
    decoder.io_instr <= io_instr @[Datapath.scala 43:20]
    control.clock <= clock
    control.reset <= reset
    control.io_instr <= io_instr @[Datapath.scala 44:20]
    immGen.clock <= clock
    immGen.reset <= reset
    immGen.io_instr <= io_instr @[Datapath.scala 45:20]
    regFile.clock <= clock
    regFile.reset <= reset
    regFile.io_rs1 <= decoder.io_rs1 @[Datapath.scala 51:18]
    regFile.io_rs2 <= decoder.io_rs2 @[Datapath.scala 52:18]
    regFile.io_rd <= decoder.io_rd @[Datapath.scala 53:18]
    regFile.io_writeData <= writeBackData @[Datapath.scala 93:26]
    regFile.io_writeEnable <= control.io_regWrite @[Datapath.scala 94:26]
    alu.clock <= clock
    alu.reset <= reset
    alu.io_a <= regFile.io_readData1 @[Datapath.scala 65:13]
    alu.io_b <= aluB @[Datapath.scala 66:13]
    alu.io_op <= control.io_aluOp @[Datapath.scala 67:13]
    pcUpdate.clock <= clock
    pcUpdate.reset <= reset
    pcUpdate.io_pc <= io_pc @[Datapath.scala 100:25]
    pcUpdate.io_rs1 <= regFile.io_readData1 @[Datapath.scala 101:25]
    pcUpdate.io_imm <= immGen.io_imm @[Datapath.scala 102:25]
    pcUpdate.io_aluResult <= alu.io_y @[Datapath.scala 107:25]
    pcUpdate.io_funct3 <= decoder.io_funct3 @[Datapath.scala 103:25]
    pcUpdate.io_branch <= control.io_branch @[Datapath.scala 104:25]
    pcUpdate.io_jump <= control.io_jump @[Datapath.scala 105:25]
    pcUpdate.io_jalr <= control.io_jalr @[Datapath.scala 106:25]

  module DataMemory :
    input clock : Clock
    input reset : UInt<1>
    input io_addr : UInt<32>
    input io_wdata : UInt<32>
    output io_rdata : UInt<32>
    input io_memRead : UInt<1>
    input io_memWrite : UInt<1>
    input io_funct3 : UInt<3>

    mem mem : @[DataMemory.scala 15:16]
      data-type => UInt<8>
      depth => 1024
      read-latency => 0
      write-latency => 1
      reader => b_0
      reader => b_1
      reader => b_2
      reader => b_3
      writer => MPORT
      writer => MPORT_1
      writer => MPORT_2
      writer => MPORT_3
      writer => MPORT_4
      writer => MPORT_5
      writer => MPORT_6
      read-under-write => undefined
    node _b_T = add(io_addr, UInt<1>("h0")) @[DataMemory.scala 16:44]
    node _b_T_1 = tail(_b_T, 1) @[DataMemory.scala 16:44]
    node _b_T_2 = bits(_b_T_1, 9, 0) @[DataMemory.scala 16:35]
    node _b_T_3 = add(io_addr, UInt<1>("h1")) @[DataMemory.scala 16:44]
    node _b_T_4 = tail(_b_T_3, 1) @[DataMemory.scala 16:44]
    node _b_T_5 = bits(_b_T_4, 9, 0) @[DataMemory.scala 16:35]
    node _b_T_6 = add(io_addr, UInt<2>("h2")) @[DataMemory.scala 16:44]
    node _b_T_7 = tail(_b_T_6, 1) @[DataMemory.scala 16:44]
    node _b_T_8 = bits(_b_T_7, 9, 0) @[DataMemory.scala 16:35]
    node _b_T_9 = add(io_addr, UInt<2>("h3")) @[DataMemory.scala 16:44]
    node _b_T_10 = tail(_b_T_9, 1) @[DataMemory.scala 16:44]
    node _b_T_11 = bits(_b_T_10, 9, 0) @[DataMemory.scala 16:35]
    node _T = eq(UInt<1>("h0"), io_funct3) @[DataMemory.scala 19:23]
    node _io_rdata_T = bits(mem.b_0.data, 7, 7) @[DataMemory.scala 20:51]
    node _io_rdata_T_1 = bits(_io_rdata_T, 0, 0) @[Bitwise.scala 77:15]
    node _io_rdata_T_2 = mux(_io_rdata_T_1, UInt<24>("hffffff"), UInt<24>("h0")) @[Bitwise.scala 77:12]
    node _io_rdata_T_3 = cat(_io_rdata_T_2, mem.b_0.data) @[Cat.scala 33:92]
    node _T_1 = eq(UInt<1>("h1"), io_funct3) @[DataMemory.scala 19:23]
    node _io_rdata_T_4 = bits(mem.b_1.data, 7, 7) @[DataMemory.scala 21:51]
    node _io_rdata_T_5 = bits(_io_rdata_T_4, 0, 0) @[Bitwise.scala 77:15]
    node _io_rdata_T_6 = mux(_io_rdata_T_5, UInt<16>("hffff"), UInt<16>("h0")) @[Bitwise.scala 77:12]
    node io_rdata_hi = cat(_io_rdata_T_6, mem.b_1.data) @[Cat.scala 33:92]
    node _io_rdata_T_7 = cat(io_rdata_hi, mem.b_0.data) @[Cat.scala 33:92]
    node _T_2 = eq(UInt<2>("h2"), io_funct3) @[DataMemory.scala 19:23]
    node io_rdata_lo = cat(mem.b_1.data, mem.b_0.data) @[Cat.scala 33:92]
    node io_rdata_hi_1 = cat(mem.b_3.data, mem.b_2.data) @[Cat.scala 33:92]
    node _io_rdata_T_8 = cat(io_rdata_hi_1, io_rdata_lo) @[Cat.scala 33:92]
    node _T_3 = eq(UInt<3>("h4"), io_funct3) @[DataMemory.scala 19:23]
    node _io_rdata_T_9 = cat(UInt<24>("h0"), mem.b_0.data) @[Cat.scala 33:92]
    node _T_4 = eq(UInt<3>("h5"), io_funct3) @[DataMemory.scala 19:23]
    node io_rdata_hi_2 = cat(UInt<16>("h0"), mem.b_1.data) @[Cat.scala 33:92]
    node _io_rdata_T_10 = cat(io_rdata_hi_2, mem.b_0.data) @[Cat.scala 33:92]
    node _GEN_0 = mux(_T_4, _io_rdata_T_10, UInt<1>("h0")) @[DataMemory.scala 17:12 19:23 24:31]
    node _GEN_1 = mux(_T_3, _io_rdata_T_9, _GEN_0) @[DataMemory.scala 19:23 23:31]
    node _GEN_2 = mux(_T_2, _io_rdata_T_8, _GEN_1) @[DataMemory.scala 19:23 22:31]
    node _GEN_3 = mux(_T_1, _io_rdata_T_7, _GEN_2) @[DataMemory.scala 19:23 21:31]
    node _GEN_4 = mux(_T, _io_rdata_T_3, _GEN_3) @[DataMemory.scala 19:23 20:31]
    node _GEN_5 = mux(io_memRead, _GEN_4, UInt<1>("h0")) @[DataMemory.scala 17:12 18:20]
    node _T_5 = eq(UInt<1>("h0"), io_funct3) @[DataMemory.scala 28:23]
    node _T_6 = bits(io_addr, 9, 0) @[DataMemory.scala 29:25]
    node _T_7 = bits(io_wdata, 7, 0) @[DataMemory.scala 29:46]
    node _T_8 = eq(UInt<1>("h1"), io_funct3) @[DataMemory.scala 28:23]
    node _T_9 = add(io_addr, UInt<1>("h0")) @[DataMemory.scala 31:42]
    node _T_10 = tail(_T_9, 1) @[DataMemory.scala 31:42]
    node _T_11 = bits(_T_10, 9, 0) @[DataMemory.scala 31:33]
    node _T_12 = bits(io_wdata, 7, 0) @[DataMemory.scala 31:60]
    node _T_13 = add(io_addr, UInt<1>("h1")) @[DataMemory.scala 31:42]
    node _T_14 = tail(_T_13, 1) @[DataMemory.scala 31:42]
    node _T_15 = bits(_T_14, 9, 0) @[DataMemory.scala 31:33]
    node _T_16 = bits(io_wdata, 15, 8) @[DataMemory.scala 31:60]
    node _T_17 = eq(UInt<2>("h2"), io_funct3) @[DataMemory.scala 28:23]
    node _T_18 = add(io_addr, UInt<1>("h0")) @[DataMemory.scala 34:42]
    node _T_19 = tail(_T_18, 1) @[DataMemory.scala 34:42]
    node _T_20 = bits(_T_19, 9, 0) @[DataMemory.scala 34:33]
    node _T_21 = bits(io_wdata, 7, 0) @[DataMemory.scala 34:60]
    node _T_22 = add(io_addr, UInt<1>("h1")) @[DataMemory.scala 34:42]
    node _T_23 = tail(_T_22, 1) @[DataMemory.scala 34:42]
    node _T_24 = bits(_T_23, 9, 0) @[DataMemory.scala 34:33]
    node _T_25 = bits(io_wdata, 15, 8) @[DataMemory.scala 34:60]
    node _T_26 = add(io_addr, UInt<2>("h2")) @[DataMemory.scala 34:42]
    node _T_27 = tail(_T_26, 1) @[DataMemory.scala 34:42]
    node _T_28 = bits(_T_27, 9, 0) @[DataMemory.scala 34:33]
    node _T_29 = bits(io_wdata, 23, 16) @[DataMemory.scala 34:60]
    node _T_30 = add(io_addr, UInt<2>("h3")) @[DataMemory.scala 34:42]
    node _T_31 = tail(_T_30, 1) @[DataMemory.scala 34:42]
    node _T_32 = bits(_T_31, 9, 0) @[DataMemory.scala 34:33]
    node _T_33 = bits(io_wdata, 31, 24) @[DataMemory.scala 34:60]
    node _GEN_6 = validif(_T_17, _T_20) @[DataMemory.scala 28:23 34:33]
    node _GEN_7 = validif(_T_17, clock) @[DataMemory.scala 28:23 34:33]
    node _GEN_8 = mux(_T_17, UInt<1>("h1"), UInt<1>("h0")) @[DataMemory.scala 15:16 28:23 34:33]
    node _GEN_9 = validif(_T_17, UInt<1>("h1")) @[DataMemory.scala 28:23 34:49]
    node _GEN_10 = validif(_T_17, _T_21) @[DataMemory.scala 28:23 34:49]
    node _GEN_11 = validif(_T_17, _T_24) @[DataMemory.scala 28:23 34:33]
    node _GEN_12 = validif(_T_17, _T_25) @[DataMemory.scala 28:23 34:49]
    node _GEN_13 = validif(_T_17, _T_28) @[DataMemory.scala 28:23 34:33]
    node _GEN_14 = validif(_T_17, _T_29) @[DataMemory.scala 28:23 34:49]
    node _GEN_15 = validif(_T_17, _T_32) @[DataMemory.scala 28:23 34:33]
    node _GEN_16 = validif(_T_17, _T_33) @[DataMemory.scala 28:23 34:49]
    node _GEN_17 = validif(_T_8, _T_11) @[DataMemory.scala 28:23 31:33]
    node _GEN_18 = validif(_T_8, clock) @[DataMemory.scala 28:23 31:33]
    node _GEN_19 = mux(_T_8, UInt<1>("h1"), UInt<1>("h0")) @[DataMemory.scala 15:16 28:23 31:33]
    node _GEN_20 = validif(_T_8, UInt<1>("h1")) @[DataMemory.scala 28:23 31:49]
    node _GEN_21 = validif(_T_8, _T_12) @[DataMemory.scala 28:23 31:49]
    node _GEN_22 = validif(_T_8, _T_15) @[DataMemory.scala 28:23 31:33]
    node _GEN_23 = validif(_T_8, _T_16) @[DataMemory.scala 28:23 31:49]
    node _GEN_24 = validif(eq(_T_8, UInt<1>("h0")), _GEN_6) @[DataMemory.scala 28:23]
    node _GEN_25 = validif(eq(_T_8, UInt<1>("h0")), _GEN_7) @[DataMemory.scala 28:23]
    node _GEN_26 = mux(_T_8, UInt<1>("h0"), _GEN_8) @[DataMemory.scala 15:16 28:23]
    node _GEN_27 = validif(eq(_T_8, UInt<1>("h0")), _GEN_9) @[DataMemory.scala 28:23]
    node _GEN_28 = validif(eq(_T_8, UInt<1>("h0")), _GEN_10) @[DataMemory.scala 28:23]
    node _GEN_29 = validif(eq(_T_8, UInt<1>("h0")), _GEN_11) @[DataMemory.scala 28:23]
    node _GEN_30 = validif(eq(_T_8, UInt<1>("h0")), _GEN_12) @[DataMemory.scala 28:23]
    node _GEN_31 = validif(eq(_T_8, UInt<1>("h0")), _GEN_13) @[DataMemory.scala 28:23]
    node _GEN_32 = validif(eq(_T_8, UInt<1>("h0")), _GEN_14) @[DataMemory.scala 28:23]
    node _GEN_33 = validif(eq(_T_8, UInt<1>("h0")), _GEN_15) @[DataMemory.scala 28:23]
    node _GEN_34 = validif(eq(_T_8, UInt<1>("h0")), _GEN_16) @[DataMemory.scala 28:23]
    node _GEN_35 = validif(_T_5, _T_6) @[DataMemory.scala 28:23 29:25]
    node _GEN_36 = validif(_T_5, clock) @[DataMemory.scala 28:23 29:25]
    node _GEN_37 = mux(_T_5, UInt<1>("h1"), UInt<1>("h0")) @[DataMemory.scala 15:16 28:23 29:25]
    node _GEN_38 = validif(_T_5, UInt<1>("h1")) @[DataMemory.scala 28:23 29:35]
    node _GEN_39 = validif(_T_5, _T_7) @[DataMemory.scala 28:23 29:35]
    node _GEN_40 = validif(eq(_T_5, UInt<1>("h0")), _GEN_17) @[DataMemory.scala 28:23]
    node _GEN_41 = validif(eq(_T_5, UInt<1>("h0")), _GEN_18) @[DataMemory.scala 28:23]
    node _GEN_42 = mux(_T_5, UInt<1>("h0"), _GEN_19) @[DataMemory.scala 15:16 28:23]
    node _GEN_43 = validif(eq(_T_5, UInt<1>("h0")), _GEN_20) @[DataMemory.scala 28:23]
    node _GEN_44 = validif(eq(_T_5, UInt<1>("h0")), _GEN_21) @[DataMemory.scala 28:23]
    node _GEN_45 = validif(eq(_T_5, UInt<1>("h0")), _GEN_22) @[DataMemory.scala 28:23]
    node _GEN_46 = validif(eq(_T_5, UInt<1>("h0")), _GEN_23) @[DataMemory.scala 28:23]
    node _GEN_47 = validif(eq(_T_5, UInt<1>("h0")), _GEN_24) @[DataMemory.scala 28:23]
    node _GEN_48 = validif(eq(_T_5, UInt<1>("h0")), _GEN_25) @[DataMemory.scala 28:23]
    node _GEN_49 = mux(_T_5, UInt<1>("h0"), _GEN_26) @[DataMemory.scala 15:16 28:23]
    node _GEN_50 = validif(eq(_T_5, UInt<1>("h0")), _GEN_27) @[DataMemory.scala 28:23]
    node _GEN_51 = validif(eq(_T_5, UInt<1>("h0")), _GEN_28) @[DataMemory.scala 28:23]
    node _GEN_52 = validif(eq(_T_5, UInt<1>("h0")), _GEN_29) @[DataMemory.scala 28:23]
    node _GEN_53 = validif(eq(_T_5, UInt<1>("h0")), _GEN_30) @[DataMemory.scala 28:23]
    node _GEN_54 = validif(eq(_T_5, UInt<1>("h0")), _GEN_31) @[DataMemory.scala 28:23]
    node _GEN_55 = validif(eq(_T_5, UInt<1>("h0")), _GEN_32) @[DataMemory.scala 28:23]
    node _GEN_56 = validif(eq(_T_5, UInt<1>("h0")), _GEN_33) @[DataMemory.scala 28:23]
    node _GEN_57 = validif(eq(_T_5, UInt<1>("h0")), _GEN_34) @[DataMemory.scala 28:23]
    node _GEN_58 = validif(io_memWrite, _GEN_35) @[DataMemory.scala 27:21]
    node _GEN_59 = validif(io_memWrite, _GEN_36) @[DataMemory.scala 27:21]
    node _GEN_60 = mux(io_memWrite, _GEN_37, UInt<1>("h0")) @[DataMemory.scala 15:16 27:21]
    node _GEN_61 = validif(io_memWrite, _GEN_38) @[DataMemory.scala 27:21]
    node _GEN_62 = validif(io_memWrite, _GEN_39) @[DataMemory.scala 27:21]
    node _GEN_63 = validif(io_memWrite, _GEN_40) @[DataMemory.scala 27:21]
    node _GEN_64 = validif(io_memWrite, _GEN_41) @[DataMemory.scala 27:21]
    node _GEN_65 = mux(io_memWrite, _GEN_42, UInt<1>("h0")) @[DataMemory.scala 15:16 27:21]
    node _GEN_66 = validif(io_memWrite, _GEN_43) @[DataMemory.scala 27:21]
    node _GEN_67 = validif(io_memWrite, _GEN_44) @[DataMemory.scala 27:21]
    node _GEN_68 = validif(io_memWrite, _GEN_45) @[DataMemory.scala 27:21]
    node _GEN_69 = validif(io_memWrite, _GEN_46) @[DataMemory.scala 27:21]
    node _GEN_70 = validif(io_memWrite, _GEN_47) @[DataMemory.scala 27:21]
    node _GEN_71 = validif(io_memWrite, _GEN_48) @[DataMemory.scala 27:21]
    node _GEN_72 = mux(io_memWrite, _GEN_49, UInt<1>("h0")) @[DataMemory.scala 15:16 27:21]
    node _GEN_73 = validif(io_memWrite, _GEN_50) @[DataMemory.scala 27:21]
    node _GEN_74 = validif(io_memWrite, _GEN_51) @[DataMemory.scala 27:21]
    node _GEN_75 = validif(io_memWrite, _GEN_52) @[DataMemory.scala 27:21]
    node _GEN_76 = validif(io_memWrite, _GEN_53) @[DataMemory.scala 27:21]
    node _GEN_77 = validif(io_memWrite, _GEN_54) @[DataMemory.scala 27:21]
    node _GEN_78 = validif(io_memWrite, _GEN_55) @[DataMemory.scala 27:21]
    node _GEN_79 = validif(io_memWrite, _GEN_56) @[DataMemory.scala 27:21]
    node _GEN_80 = validif(io_memWrite, _GEN_57) @[DataMemory.scala 27:21]
    io_rdata <= _GEN_5
    mem.b_0.addr <= _b_T_2 @[DataMemory.scala 16:35]
    mem.b_0.en <= UInt<1>("h1") @[DataMemory.scala 16:35]
    mem.b_0.clk <= clock @[DataMemory.scala 16:35]
    mem.b_1.addr <= _b_T_5 @[DataMemory.scala 16:35]
    mem.b_1.en <= UInt<1>("h1") @[DataMemory.scala 16:35]
    mem.b_1.clk <= clock @[DataMemory.scala 16:35]
    mem.b_2.addr <= _b_T_8 @[DataMemory.scala 16:35]
    mem.b_2.en <= UInt<1>("h1") @[DataMemory.scala 16:35]
    mem.b_2.clk <= clock @[DataMemory.scala 16:35]
    mem.b_3.addr <= _b_T_11 @[DataMemory.scala 16:35]
    mem.b_3.en <= UInt<1>("h1") @[DataMemory.scala 16:35]
    mem.b_3.clk <= clock @[DataMemory.scala 16:35]
    mem.MPORT.addr <= _GEN_58
    mem.MPORT.en <= _GEN_60
    mem.MPORT.clk <= _GEN_59
    mem.MPORT.data <= _GEN_62
    mem.MPORT.mask <= _GEN_61
    mem.MPORT_1.addr <= _GEN_63
    mem.MPORT_1.en <= _GEN_65
    mem.MPORT_1.clk <= _GEN_64
    mem.MPORT_1.data <= _GEN_67
    mem.MPORT_1.mask <= _GEN_66
    mem.MPORT_2.addr <= _GEN_68
    mem.MPORT_2.en <= _GEN_65
    mem.MPORT_2.clk <= _GEN_64
    mem.MPORT_2.data <= _GEN_69
    mem.MPORT_2.mask <= _GEN_66
    mem.MPORT_3.addr <= _GEN_70
    mem.MPORT_3.en <= _GEN_72
    mem.MPORT_3.clk <= _GEN_71
    mem.MPORT_3.data <= _GEN_74
    mem.MPORT_3.mask <= _GEN_73
    mem.MPORT_4.addr <= _GEN_75
    mem.MPORT_4.en <= _GEN_72
    mem.MPORT_4.clk <= _GEN_71
    mem.MPORT_4.data <= _GEN_76
    mem.MPORT_4.mask <= _GEN_73
    mem.MPORT_5.addr <= _GEN_77
    mem.MPORT_5.en <= _GEN_72
    mem.MPORT_5.clk <= _GEN_71
    mem.MPORT_5.data <= _GEN_78
    mem.MPORT_5.mask <= _GEN_73
    mem.MPORT_6.addr <= _GEN_79
    mem.MPORT_6.en <= _GEN_72
    mem.MPORT_6.clk <= _GEN_71
    mem.MPORT_6.data <= _GEN_80
    mem.MPORT_6.mask <= _GEN_73

  module RV32ICore :
    input clock : Clock
    input reset : UInt<1>
    output io_pc : UInt<32>
    output io_nextPc : UInt<32>
    output io_writeBack : UInt<32>
    output io_debugX1 : UInt<32>
    output io_debugX2 : UInt<32>
    output io_debugX3 : UInt<32>
    output io_debugX4 : UInt<32>
    output io_debugALU : UInt<32>
    output io_debugImm : UInt<32>

    inst instructionMemory of InstructionMemory @[RV32ICore.scala 24:33]
    inst datapath of Datapath @[RV32ICore.scala 25:24]
    inst dataMemory of DataMemory @[RV32ICore.scala 26:26]
    reg pcReg : UInt<32>, clock with :
      reset => (UInt<1>("h0"), pcReg) @[RV32ICore.scala 22:22]
    io_pc <= pcReg @[RV32ICore.scala 43:9]
    io_nextPc <= datapath.io_nextPc @[RV32ICore.scala 44:13]
    io_writeBack <= datapath.io_writeBack @[RV32ICore.scala 46:16]
    io_debugX1 <= datapath.io_debugX1 @[RV32ICore.scala 48:14]
    io_debugX2 <= datapath.io_debugX2 @[RV32ICore.scala 49:14]
    io_debugX3 <= datapath.io_debugX3 @[RV32ICore.scala 50:14]
    io_debugX4 <= datapath.io_debugX4 @[RV32ICore.scala 51:14]
    io_debugALU <= datapath.io_debugALU @[RV32ICore.scala 53:15]
    io_debugImm <= datapath.io_debugImm @[RV32ICore.scala 54:15]
    pcReg <= mux(reset, UInt<32>("h0"), datapath.io_nextPc) @[RV32ICore.scala 22:{22,22} 41:9]
    instructionMemory.clock <= clock
    instructionMemory.reset <= reset
    instructionMemory.io_addr <= pcReg @[RV32ICore.scala 28:29]
    datapath.clock <= clock
    datapath.reset <= reset
    datapath.io_instr <= instructionMemory.io_instr @[RV32ICore.scala 30:21]
    datapath.io_pc <= pcReg @[RV32ICore.scala 31:18]
    datapath.io_memRdata <= dataMemory.io_rdata @[RV32ICore.scala 39:24]
    dataMemory.clock <= clock
    dataMemory.reset <= reset
    dataMemory.io_addr <= datapath.io_memAddr @[RV32ICore.scala 33:22]
    dataMemory.io_wdata <= datapath.io_memWdata @[RV32ICore.scala 34:23]
    dataMemory.io_memRead <= datapath.io_memRead @[RV32ICore.scala 35:25]
    dataMemory.io_memWrite <= datapath.io_memWrite @[RV32ICore.scala 36:26]
    dataMemory.io_funct3 <= datapath.io_memFunct3 @[RV32ICore.scala 37:24]
