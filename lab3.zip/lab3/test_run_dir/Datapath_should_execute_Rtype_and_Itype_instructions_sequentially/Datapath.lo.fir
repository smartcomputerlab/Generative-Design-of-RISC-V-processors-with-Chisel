FIRRTL version 1.1.0
circuit Datapath :
  module Decoder :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    output io_rs1 : UInt<5>
    output io_rs2 : UInt<5>
    output io_rd : UInt<5>
    output io_aluOp : UInt<4>
    output io_aluSrc : UInt<1>
    output io_regWrite : UInt<1>
    output io_valid : UInt<1>

    node opcode = bits(io_instr, 6, 0) @[Decoder.scala 18:24]
    node funct3 = bits(io_instr, 14, 12) @[Decoder.scala 19:24]
    node funct7 = bits(io_instr, 31, 25) @[Decoder.scala 20:24]
    node funct = cat(funct7, funct3) @[Cat.scala 33:92]
    node _io_rs1_T = bits(io_instr, 19, 15) @[Decoder.scala 22:21]
    node _io_rs2_T = bits(io_instr, 24, 20) @[Decoder.scala 23:21]
    node _io_rd_T = bits(io_instr, 11, 7) @[Decoder.scala 24:21]
    node _T = eq(UInt<6>("h33"), opcode) @[Decoder.scala 28:18]
    node _T_1 = eq(UInt<1>("h0"), funct) @[Decoder.scala 30:21]
    node _T_2 = eq(UInt<9>("h100"), funct) @[Decoder.scala 30:21]
    node _T_3 = eq(UInt<1>("h1"), funct) @[Decoder.scala 30:21]
    node _T_4 = eq(UInt<2>("h2"), funct) @[Decoder.scala 30:21]
    node _T_5 = eq(UInt<2>("h3"), funct) @[Decoder.scala 30:21]
    node _T_6 = eq(UInt<3>("h4"), funct) @[Decoder.scala 30:21]
    node _T_7 = eq(UInt<3>("h5"), funct) @[Decoder.scala 30:21]
    node _T_8 = eq(UInt<9>("h105"), funct) @[Decoder.scala 30:21]
    node _T_9 = eq(UInt<3>("h6"), funct) @[Decoder.scala 30:21]
    node _T_10 = eq(UInt<3>("h7"), funct) @[Decoder.scala 30:21]
    node _GEN_0 = mux(_T_10, UInt<4>("h9"), UInt<4>("hf")) @[Decoder.scala 25:12 30:21 68:20]
    node _GEN_1 = mux(_T_10, UInt<1>("h1"), UInt<1>("h0")) @[Decoder.scala 27:12 30:21 69:20]
    node _GEN_2 = mux(_T_9, UInt<4>("h8"), _GEN_0) @[Decoder.scala 30:21 64:20]
    node _GEN_3 = mux(_T_9, UInt<1>("h1"), _GEN_1) @[Decoder.scala 30:21 65:20]
    node _GEN_4 = mux(_T_8, UInt<4>("h7"), _GEN_2) @[Decoder.scala 30:21 60:20]
    node _GEN_5 = mux(_T_8, UInt<1>("h1"), _GEN_3) @[Decoder.scala 30:21 61:20]
    node _GEN_6 = mux(_T_7, UInt<4>("h6"), _GEN_4) @[Decoder.scala 30:21 56:20]
    node _GEN_7 = mux(_T_7, UInt<1>("h1"), _GEN_5) @[Decoder.scala 30:21 57:20]
    node _GEN_8 = mux(_T_6, UInt<4>("h5"), _GEN_6) @[Decoder.scala 30:21 52:20]
    node _GEN_9 = mux(_T_6, UInt<1>("h1"), _GEN_7) @[Decoder.scala 30:21 53:20]
    node _GEN_10 = mux(_T_5, UInt<4>("h4"), _GEN_8) @[Decoder.scala 30:21 48:20]
    node _GEN_11 = mux(_T_5, UInt<1>("h1"), _GEN_9) @[Decoder.scala 30:21 49:20]
    node _GEN_12 = mux(_T_4, UInt<4>("h3"), _GEN_10) @[Decoder.scala 30:21 44:20]
    node _GEN_13 = mux(_T_4, UInt<1>("h1"), _GEN_11) @[Decoder.scala 30:21 45:20]
    node _GEN_14 = mux(_T_3, UInt<4>("h2"), _GEN_12) @[Decoder.scala 30:21 40:20]
    node _GEN_15 = mux(_T_3, UInt<1>("h1"), _GEN_13) @[Decoder.scala 30:21 41:20]
    node _GEN_16 = mux(_T_2, UInt<4>("h1"), _GEN_14) @[Decoder.scala 30:21 36:20]
    node _GEN_17 = mux(_T_2, UInt<1>("h1"), _GEN_15) @[Decoder.scala 30:21 37:20]
    node _GEN_18 = mux(_T_1, UInt<4>("h0"), _GEN_16) @[Decoder.scala 30:21 32:20]
    node _GEN_19 = mux(_T_1, UInt<1>("h1"), _GEN_17) @[Decoder.scala 30:21 33:20]
    node _T_11 = eq(UInt<5>("h13"), opcode) @[Decoder.scala 28:18]
    node _T_12 = eq(UInt<1>("h0"), funct3) @[Decoder.scala 75:22]
    node _T_13 = eq(UInt<2>("h2"), funct3) @[Decoder.scala 75:22]
    node _T_14 = eq(UInt<2>("h3"), funct3) @[Decoder.scala 75:22]
    node _T_15 = eq(UInt<3>("h4"), funct3) @[Decoder.scala 75:22]
    node _T_16 = eq(UInt<3>("h6"), funct3) @[Decoder.scala 75:22]
    node _T_17 = eq(UInt<3>("h7"), funct3) @[Decoder.scala 75:22]
    node _T_18 = eq(UInt<1>("h1"), funct3) @[Decoder.scala 75:22]
    node _T_19 = eq(funct7, UInt<1>("h0")) @[Decoder.scala 101:23]
    node _GEN_20 = mux(_T_19, UInt<4>("h2"), UInt<4>("hf")) @[Decoder.scala 101:41 102:22 25:12]
    node _GEN_21 = mux(_T_19, UInt<1>("h1"), UInt<1>("h0")) @[Decoder.scala 101:41 103:22 27:12]
    node _T_20 = eq(UInt<3>("h5"), funct3) @[Decoder.scala 75:22]
    node _T_21 = eq(funct7, UInt<1>("h0")) @[Decoder.scala 107:23]
    node _T_22 = eq(funct7, UInt<6>("h20")) @[Decoder.scala 110:29]
    node _GEN_22 = mux(_T_22, UInt<4>("h7"), UInt<4>("hf")) @[Decoder.scala 110:47 111:22 25:12]
    node _GEN_23 = mux(_T_22, UInt<1>("h1"), UInt<1>("h0")) @[Decoder.scala 110:47 112:22 27:12]
    node _GEN_24 = mux(_T_21, UInt<4>("h6"), _GEN_22) @[Decoder.scala 107:41 108:22]
    node _GEN_25 = mux(_T_21, UInt<1>("h1"), _GEN_23) @[Decoder.scala 107:41 109:22]
    node _GEN_26 = mux(_T_20, _GEN_24, UInt<4>("hf")) @[Decoder.scala 25:12 75:22]
    node _GEN_27 = mux(_T_20, _GEN_25, UInt<1>("h0")) @[Decoder.scala 27:12 75:22]
    node _GEN_28 = mux(_T_18, _GEN_20, _GEN_26) @[Decoder.scala 75:22]
    node _GEN_29 = mux(_T_18, _GEN_21, _GEN_27) @[Decoder.scala 75:22]
    node _GEN_30 = mux(_T_17, UInt<4>("h9"), _GEN_28) @[Decoder.scala 75:22 97:20]
    node _GEN_31 = mux(_T_17, UInt<1>("h1"), _GEN_29) @[Decoder.scala 75:22 98:20]
    node _GEN_32 = mux(_T_16, UInt<4>("h8"), _GEN_30) @[Decoder.scala 75:22 93:20]
    node _GEN_33 = mux(_T_16, UInt<1>("h1"), _GEN_31) @[Decoder.scala 75:22 94:20]
    node _GEN_34 = mux(_T_15, UInt<4>("h5"), _GEN_32) @[Decoder.scala 75:22 89:20]
    node _GEN_35 = mux(_T_15, UInt<1>("h1"), _GEN_33) @[Decoder.scala 75:22 90:20]
    node _GEN_36 = mux(_T_14, UInt<4>("h4"), _GEN_34) @[Decoder.scala 75:22 85:20]
    node _GEN_37 = mux(_T_14, UInt<1>("h1"), _GEN_35) @[Decoder.scala 75:22 86:20]
    node _GEN_38 = mux(_T_13, UInt<4>("h3"), _GEN_36) @[Decoder.scala 75:22 81:20]
    node _GEN_39 = mux(_T_13, UInt<1>("h1"), _GEN_37) @[Decoder.scala 75:22 82:20]
    node _GEN_40 = mux(_T_12, UInt<4>("h0"), _GEN_38) @[Decoder.scala 75:22 77:20]
    node _GEN_41 = mux(_T_12, UInt<1>("h1"), _GEN_39) @[Decoder.scala 75:22 78:20]
    node _GEN_42 = mux(_T_11, UInt<1>("h1"), UInt<1>("h0")) @[Decoder.scala 26:13 28:18 74:17]
    node _GEN_43 = mux(_T_11, _GEN_40, UInt<4>("hf")) @[Decoder.scala 25:12 28:18]
    node _GEN_44 = mux(_T_11, _GEN_41, UInt<1>("h0")) @[Decoder.scala 27:12 28:18]
    node _GEN_45 = mux(_T, _GEN_18, _GEN_43) @[Decoder.scala 28:18]
    node _GEN_46 = mux(_T, _GEN_19, _GEN_44) @[Decoder.scala 28:18]
    node _GEN_47 = mux(_T, UInt<1>("h0"), _GEN_42) @[Decoder.scala 26:13 28:18]
    io_rs1 <= _io_rs1_T @[Decoder.scala 22:10]
    io_rs2 <= _io_rs2_T @[Decoder.scala 23:10]
    io_rd <= _io_rd_T @[Decoder.scala 24:10]
    io_aluOp <= _GEN_45
    io_aluSrc <= _GEN_47
    io_regWrite <= io_valid @[Decoder.scala 118:15]
    io_valid <= _GEN_46

  module ImmediateGenerator :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    output io_imm : UInt<32>

    node imm12 = bits(io_instr, 31, 20) @[ImmediateGenerator.scala 11:23]
    node _io_imm_T = asSInt(imm12) @[ImmediateGenerator.scala 12:19]
    node _io_imm_T_1 = pad(_io_imm_T, 32) @[ImmediateGenerator.scala 12:29]
    node _io_imm_T_2 = asUInt(_io_imm_T_1) @[ImmediateGenerator.scala 12:38]
    io_imm <= _io_imm_T_2 @[ImmediateGenerator.scala 12:10]

  module RegisterFile :
    input clock : Clock
    input reset : UInt<1>
    input io_rs1 : UInt<5>
    input io_rs2 : UInt<5>
    input io_rd : UInt<5>
    input io_writeData : UInt<32>
    input io_writeEnable : UInt<1>
    output io_readData1 : UInt<32>
    output io_readData2 : UInt<32>
    output io_debugRead_0 : UInt<32>
    output io_debugRead_1 : UInt<32>
    output io_debugRead_2 : UInt<32>
    output io_debugRead_3 : UInt<32>
    output io_debugRead_4 : UInt<32>
    output io_debugRead_5 : UInt<32>
    output io_debugRead_6 : UInt<32>
    output io_debugRead_7 : UInt<32>
    output io_debugRead_8 : UInt<32>
    output io_debugRead_9 : UInt<32>
    output io_debugRead_10 : UInt<32>
    output io_debugRead_11 : UInt<32>
    output io_debugRead_12 : UInt<32>
    output io_debugRead_13 : UInt<32>
    output io_debugRead_14 : UInt<32>
    output io_debugRead_15 : UInt<32>
    output io_debugRead_16 : UInt<32>
    output io_debugRead_17 : UInt<32>
    output io_debugRead_18 : UInt<32>
    output io_debugRead_19 : UInt<32>
    output io_debugRead_20 : UInt<32>
    output io_debugRead_21 : UInt<32>
    output io_debugRead_22 : UInt<32>
    output io_debugRead_23 : UInt<32>
    output io_debugRead_24 : UInt<32>
    output io_debugRead_25 : UInt<32>
    output io_debugRead_26 : UInt<32>
    output io_debugRead_27 : UInt<32>
    output io_debugRead_28 : UInt<32>
    output io_debugRead_29 : UInt<32>
    output io_debugRead_30 : UInt<32>
    output io_debugRead_31 : UInt<32>

    reg regs_0 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_0) @[RegisterFile.scala 30:21]
    reg regs_1 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_1) @[RegisterFile.scala 30:21]
    reg regs_2 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_2) @[RegisterFile.scala 30:21]
    reg regs_3 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_3) @[RegisterFile.scala 30:21]
    reg regs_4 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_4) @[RegisterFile.scala 30:21]
    reg regs_5 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_5) @[RegisterFile.scala 30:21]
    reg regs_6 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_6) @[RegisterFile.scala 30:21]
    reg regs_7 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_7) @[RegisterFile.scala 30:21]
    reg regs_8 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_8) @[RegisterFile.scala 30:21]
    reg regs_9 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_9) @[RegisterFile.scala 30:21]
    reg regs_10 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_10) @[RegisterFile.scala 30:21]
    reg regs_11 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_11) @[RegisterFile.scala 30:21]
    reg regs_12 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_12) @[RegisterFile.scala 30:21]
    reg regs_13 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_13) @[RegisterFile.scala 30:21]
    reg regs_14 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_14) @[RegisterFile.scala 30:21]
    reg regs_15 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_15) @[RegisterFile.scala 30:21]
    reg regs_16 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_16) @[RegisterFile.scala 30:21]
    reg regs_17 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_17) @[RegisterFile.scala 30:21]
    reg regs_18 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_18) @[RegisterFile.scala 30:21]
    reg regs_19 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_19) @[RegisterFile.scala 30:21]
    reg regs_20 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_20) @[RegisterFile.scala 30:21]
    reg regs_21 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_21) @[RegisterFile.scala 30:21]
    reg regs_22 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_22) @[RegisterFile.scala 30:21]
    reg regs_23 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_23) @[RegisterFile.scala 30:21]
    reg regs_24 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_24) @[RegisterFile.scala 30:21]
    reg regs_25 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_25) @[RegisterFile.scala 30:21]
    reg regs_26 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_26) @[RegisterFile.scala 30:21]
    reg regs_27 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_27) @[RegisterFile.scala 30:21]
    reg regs_28 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_28) @[RegisterFile.scala 30:21]
    reg regs_29 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_29) @[RegisterFile.scala 30:21]
    reg regs_30 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_30) @[RegisterFile.scala 30:21]
    reg regs_31 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_31) @[RegisterFile.scala 30:21]
    node _io_readData1_T = eq(io_rs1, UInt<1>("h0")) @[RegisterFile.scala 32:12]
    node _GEN_0 = validif(eq(UInt<1>("h0"), io_rs1), regs_0) @[RegisterFile.scala 31:{22,22}]
    node _GEN_1 = mux(eq(UInt<1>("h1"), io_rs1), regs_1, _GEN_0) @[RegisterFile.scala 31:{22,22}]
    node _GEN_2 = mux(eq(UInt<2>("h2"), io_rs1), regs_2, _GEN_1) @[RegisterFile.scala 31:{22,22}]
    node _GEN_3 = mux(eq(UInt<2>("h3"), io_rs1), regs_3, _GEN_2) @[RegisterFile.scala 31:{22,22}]
    node _GEN_4 = mux(eq(UInt<3>("h4"), io_rs1), regs_4, _GEN_3) @[RegisterFile.scala 31:{22,22}]
    node _GEN_5 = mux(eq(UInt<3>("h5"), io_rs1), regs_5, _GEN_4) @[RegisterFile.scala 31:{22,22}]
    node _GEN_6 = mux(eq(UInt<3>("h6"), io_rs1), regs_6, _GEN_5) @[RegisterFile.scala 31:{22,22}]
    node _GEN_7 = mux(eq(UInt<3>("h7"), io_rs1), regs_7, _GEN_6) @[RegisterFile.scala 31:{22,22}]
    node _GEN_8 = mux(eq(UInt<4>("h8"), io_rs1), regs_8, _GEN_7) @[RegisterFile.scala 31:{22,22}]
    node _GEN_9 = mux(eq(UInt<4>("h9"), io_rs1), regs_9, _GEN_8) @[RegisterFile.scala 31:{22,22}]
    node _GEN_10 = mux(eq(UInt<4>("ha"), io_rs1), regs_10, _GEN_9) @[RegisterFile.scala 31:{22,22}]
    node _GEN_11 = mux(eq(UInt<4>("hb"), io_rs1), regs_11, _GEN_10) @[RegisterFile.scala 31:{22,22}]
    node _GEN_12 = mux(eq(UInt<4>("hc"), io_rs1), regs_12, _GEN_11) @[RegisterFile.scala 31:{22,22}]
    node _GEN_13 = mux(eq(UInt<4>("hd"), io_rs1), regs_13, _GEN_12) @[RegisterFile.scala 31:{22,22}]
    node _GEN_14 = mux(eq(UInt<4>("he"), io_rs1), regs_14, _GEN_13) @[RegisterFile.scala 31:{22,22}]
    node _GEN_15 = mux(eq(UInt<4>("hf"), io_rs1), regs_15, _GEN_14) @[RegisterFile.scala 31:{22,22}]
    node _GEN_16 = mux(eq(UInt<5>("h10"), io_rs1), regs_16, _GEN_15) @[RegisterFile.scala 31:{22,22}]
    node _GEN_17 = mux(eq(UInt<5>("h11"), io_rs1), regs_17, _GEN_16) @[RegisterFile.scala 31:{22,22}]
    node _GEN_18 = mux(eq(UInt<5>("h12"), io_rs1), regs_18, _GEN_17) @[RegisterFile.scala 31:{22,22}]
    node _GEN_19 = mux(eq(UInt<5>("h13"), io_rs1), regs_19, _GEN_18) @[RegisterFile.scala 31:{22,22}]
    node _GEN_20 = mux(eq(UInt<5>("h14"), io_rs1), regs_20, _GEN_19) @[RegisterFile.scala 31:{22,22}]
    node _GEN_21 = mux(eq(UInt<5>("h15"), io_rs1), regs_21, _GEN_20) @[RegisterFile.scala 31:{22,22}]
    node _GEN_22 = mux(eq(UInt<5>("h16"), io_rs1), regs_22, _GEN_21) @[RegisterFile.scala 31:{22,22}]
    node _GEN_23 = mux(eq(UInt<5>("h17"), io_rs1), regs_23, _GEN_22) @[RegisterFile.scala 31:{22,22}]
    node _GEN_24 = mux(eq(UInt<5>("h18"), io_rs1), regs_24, _GEN_23) @[RegisterFile.scala 31:{22,22}]
    node _GEN_25 = mux(eq(UInt<5>("h19"), io_rs1), regs_25, _GEN_24) @[RegisterFile.scala 31:{22,22}]
    node _GEN_26 = mux(eq(UInt<5>("h1a"), io_rs1), regs_26, _GEN_25) @[RegisterFile.scala 31:{22,22}]
    node _GEN_27 = mux(eq(UInt<5>("h1b"), io_rs1), regs_27, _GEN_26) @[RegisterFile.scala 31:{22,22}]
    node _GEN_28 = mux(eq(UInt<5>("h1c"), io_rs1), regs_28, _GEN_27) @[RegisterFile.scala 31:{22,22}]
    node _GEN_29 = mux(eq(UInt<5>("h1d"), io_rs1), regs_29, _GEN_28) @[RegisterFile.scala 31:{22,22}]
    node _GEN_30 = mux(eq(UInt<5>("h1e"), io_rs1), regs_30, _GEN_29) @[RegisterFile.scala 31:{22,22}]
    node _GEN_31 = mux(eq(UInt<5>("h1f"), io_rs1), regs_31, _GEN_30) @[RegisterFile.scala 31:{22,22}]
    node _regs_io_rs1 = _GEN_31 @[RegisterFile.scala 31:22]
    node _io_readData1_T_1 = mux(_io_readData1_T, UInt<1>("h0"), _regs_io_rs1) @[RegisterFile.scala 31:22]
    node _io_readData2_T = eq(io_rs2, UInt<1>("h0")) @[RegisterFile.scala 37:12]
    node _GEN_32 = validif(eq(UInt<1>("h0"), io_rs2), regs_0) @[RegisterFile.scala 36:{22,22}]
    node _GEN_33 = mux(eq(UInt<1>("h1"), io_rs2), regs_1, _GEN_32) @[RegisterFile.scala 36:{22,22}]
    node _GEN_34 = mux(eq(UInt<2>("h2"), io_rs2), regs_2, _GEN_33) @[RegisterFile.scala 36:{22,22}]
    node _GEN_35 = mux(eq(UInt<2>("h3"), io_rs2), regs_3, _GEN_34) @[RegisterFile.scala 36:{22,22}]
    node _GEN_36 = mux(eq(UInt<3>("h4"), io_rs2), regs_4, _GEN_35) @[RegisterFile.scala 36:{22,22}]
    node _GEN_37 = mux(eq(UInt<3>("h5"), io_rs2), regs_5, _GEN_36) @[RegisterFile.scala 36:{22,22}]
    node _GEN_38 = mux(eq(UInt<3>("h6"), io_rs2), regs_6, _GEN_37) @[RegisterFile.scala 36:{22,22}]
    node _GEN_39 = mux(eq(UInt<3>("h7"), io_rs2), regs_7, _GEN_38) @[RegisterFile.scala 36:{22,22}]
    node _GEN_40 = mux(eq(UInt<4>("h8"), io_rs2), regs_8, _GEN_39) @[RegisterFile.scala 36:{22,22}]
    node _GEN_41 = mux(eq(UInt<4>("h9"), io_rs2), regs_9, _GEN_40) @[RegisterFile.scala 36:{22,22}]
    node _GEN_42 = mux(eq(UInt<4>("ha"), io_rs2), regs_10, _GEN_41) @[RegisterFile.scala 36:{22,22}]
    node _GEN_43 = mux(eq(UInt<4>("hb"), io_rs2), regs_11, _GEN_42) @[RegisterFile.scala 36:{22,22}]
    node _GEN_44 = mux(eq(UInt<4>("hc"), io_rs2), regs_12, _GEN_43) @[RegisterFile.scala 36:{22,22}]
    node _GEN_45 = mux(eq(UInt<4>("hd"), io_rs2), regs_13, _GEN_44) @[RegisterFile.scala 36:{22,22}]
    node _GEN_46 = mux(eq(UInt<4>("he"), io_rs2), regs_14, _GEN_45) @[RegisterFile.scala 36:{22,22}]
    node _GEN_47 = mux(eq(UInt<4>("hf"), io_rs2), regs_15, _GEN_46) @[RegisterFile.scala 36:{22,22}]
    node _GEN_48 = mux(eq(UInt<5>("h10"), io_rs2), regs_16, _GEN_47) @[RegisterFile.scala 36:{22,22}]
    node _GEN_49 = mux(eq(UInt<5>("h11"), io_rs2), regs_17, _GEN_48) @[RegisterFile.scala 36:{22,22}]
    node _GEN_50 = mux(eq(UInt<5>("h12"), io_rs2), regs_18, _GEN_49) @[RegisterFile.scala 36:{22,22}]
    node _GEN_51 = mux(eq(UInt<5>("h13"), io_rs2), regs_19, _GEN_50) @[RegisterFile.scala 36:{22,22}]
    node _GEN_52 = mux(eq(UInt<5>("h14"), io_rs2), regs_20, _GEN_51) @[RegisterFile.scala 36:{22,22}]
    node _GEN_53 = mux(eq(UInt<5>("h15"), io_rs2), regs_21, _GEN_52) @[RegisterFile.scala 36:{22,22}]
    node _GEN_54 = mux(eq(UInt<5>("h16"), io_rs2), regs_22, _GEN_53) @[RegisterFile.scala 36:{22,22}]
    node _GEN_55 = mux(eq(UInt<5>("h17"), io_rs2), regs_23, _GEN_54) @[RegisterFile.scala 36:{22,22}]
    node _GEN_56 = mux(eq(UInt<5>("h18"), io_rs2), regs_24, _GEN_55) @[RegisterFile.scala 36:{22,22}]
    node _GEN_57 = mux(eq(UInt<5>("h19"), io_rs2), regs_25, _GEN_56) @[RegisterFile.scala 36:{22,22}]
    node _GEN_58 = mux(eq(UInt<5>("h1a"), io_rs2), regs_26, _GEN_57) @[RegisterFile.scala 36:{22,22}]
    node _GEN_59 = mux(eq(UInt<5>("h1b"), io_rs2), regs_27, _GEN_58) @[RegisterFile.scala 36:{22,22}]
    node _GEN_60 = mux(eq(UInt<5>("h1c"), io_rs2), regs_28, _GEN_59) @[RegisterFile.scala 36:{22,22}]
    node _GEN_61 = mux(eq(UInt<5>("h1d"), io_rs2), regs_29, _GEN_60) @[RegisterFile.scala 36:{22,22}]
    node _GEN_62 = mux(eq(UInt<5>("h1e"), io_rs2), regs_30, _GEN_61) @[RegisterFile.scala 36:{22,22}]
    node _GEN_63 = mux(eq(UInt<5>("h1f"), io_rs2), regs_31, _GEN_62) @[RegisterFile.scala 36:{22,22}]
    node _regs_io_rs2 = _GEN_63 @[RegisterFile.scala 36:22]
    node _io_readData2_T_1 = mux(_io_readData2_T, UInt<1>("h0"), _regs_io_rs2) @[RegisterFile.scala 36:22]
    node _T = neq(io_rd, UInt<1>("h0")) @[RegisterFile.scala 41:32]
    node _T_1 = and(io_writeEnable, _T) @[RegisterFile.scala 41:23]
    node _regs_io_rd = io_writeData @[RegisterFile.scala 42:{17,17}]
    node _GEN_64 = mux(eq(UInt<1>("h0"), io_rd), _regs_io_rd, regs_0) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_65 = mux(eq(UInt<1>("h1"), io_rd), _regs_io_rd, regs_1) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_66 = mux(eq(UInt<2>("h2"), io_rd), _regs_io_rd, regs_2) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_67 = mux(eq(UInt<2>("h3"), io_rd), _regs_io_rd, regs_3) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_68 = mux(eq(UInt<3>("h4"), io_rd), _regs_io_rd, regs_4) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_69 = mux(eq(UInt<3>("h5"), io_rd), _regs_io_rd, regs_5) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_70 = mux(eq(UInt<3>("h6"), io_rd), _regs_io_rd, regs_6) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_71 = mux(eq(UInt<3>("h7"), io_rd), _regs_io_rd, regs_7) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_72 = mux(eq(UInt<4>("h8"), io_rd), _regs_io_rd, regs_8) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_73 = mux(eq(UInt<4>("h9"), io_rd), _regs_io_rd, regs_9) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_74 = mux(eq(UInt<4>("ha"), io_rd), _regs_io_rd, regs_10) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_75 = mux(eq(UInt<4>("hb"), io_rd), _regs_io_rd, regs_11) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_76 = mux(eq(UInt<4>("hc"), io_rd), _regs_io_rd, regs_12) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_77 = mux(eq(UInt<4>("hd"), io_rd), _regs_io_rd, regs_13) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_78 = mux(eq(UInt<4>("he"), io_rd), _regs_io_rd, regs_14) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_79 = mux(eq(UInt<4>("hf"), io_rd), _regs_io_rd, regs_15) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_80 = mux(eq(UInt<5>("h10"), io_rd), _regs_io_rd, regs_16) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_81 = mux(eq(UInt<5>("h11"), io_rd), _regs_io_rd, regs_17) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_82 = mux(eq(UInt<5>("h12"), io_rd), _regs_io_rd, regs_18) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_83 = mux(eq(UInt<5>("h13"), io_rd), _regs_io_rd, regs_19) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_84 = mux(eq(UInt<5>("h14"), io_rd), _regs_io_rd, regs_20) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_85 = mux(eq(UInt<5>("h15"), io_rd), _regs_io_rd, regs_21) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_86 = mux(eq(UInt<5>("h16"), io_rd), _regs_io_rd, regs_22) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_87 = mux(eq(UInt<5>("h17"), io_rd), _regs_io_rd, regs_23) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_88 = mux(eq(UInt<5>("h18"), io_rd), _regs_io_rd, regs_24) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_89 = mux(eq(UInt<5>("h19"), io_rd), _regs_io_rd, regs_25) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_90 = mux(eq(UInt<5>("h1a"), io_rd), _regs_io_rd, regs_26) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_91 = mux(eq(UInt<5>("h1b"), io_rd), _regs_io_rd, regs_27) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_92 = mux(eq(UInt<5>("h1c"), io_rd), _regs_io_rd, regs_28) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_93 = mux(eq(UInt<5>("h1d"), io_rd), _regs_io_rd, regs_29) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_94 = mux(eq(UInt<5>("h1e"), io_rd), _regs_io_rd, regs_30) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_95 = mux(eq(UInt<5>("h1f"), io_rd), _regs_io_rd, regs_31) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_96 = mux(_T_1, _GEN_64, regs_0) @[RegisterFile.scala 30:21 41:41]
    node _GEN_97 = mux(_T_1, _GEN_65, regs_1) @[RegisterFile.scala 30:21 41:41]
    node _GEN_98 = mux(_T_1, _GEN_66, regs_2) @[RegisterFile.scala 30:21 41:41]
    node _GEN_99 = mux(_T_1, _GEN_67, regs_3) @[RegisterFile.scala 30:21 41:41]
    node _GEN_100 = mux(_T_1, _GEN_68, regs_4) @[RegisterFile.scala 30:21 41:41]
    node _GEN_101 = mux(_T_1, _GEN_69, regs_5) @[RegisterFile.scala 30:21 41:41]
    node _GEN_102 = mux(_T_1, _GEN_70, regs_6) @[RegisterFile.scala 30:21 41:41]
    node _GEN_103 = mux(_T_1, _GEN_71, regs_7) @[RegisterFile.scala 30:21 41:41]
    node _GEN_104 = mux(_T_1, _GEN_72, regs_8) @[RegisterFile.scala 30:21 41:41]
    node _GEN_105 = mux(_T_1, _GEN_73, regs_9) @[RegisterFile.scala 30:21 41:41]
    node _GEN_106 = mux(_T_1, _GEN_74, regs_10) @[RegisterFile.scala 30:21 41:41]
    node _GEN_107 = mux(_T_1, _GEN_75, regs_11) @[RegisterFile.scala 30:21 41:41]
    node _GEN_108 = mux(_T_1, _GEN_76, regs_12) @[RegisterFile.scala 30:21 41:41]
    node _GEN_109 = mux(_T_1, _GEN_77, regs_13) @[RegisterFile.scala 30:21 41:41]
    node _GEN_110 = mux(_T_1, _GEN_78, regs_14) @[RegisterFile.scala 30:21 41:41]
    node _GEN_111 = mux(_T_1, _GEN_79, regs_15) @[RegisterFile.scala 30:21 41:41]
    node _GEN_112 = mux(_T_1, _GEN_80, regs_16) @[RegisterFile.scala 30:21 41:41]
    node _GEN_113 = mux(_T_1, _GEN_81, regs_17) @[RegisterFile.scala 30:21 41:41]
    node _GEN_114 = mux(_T_1, _GEN_82, regs_18) @[RegisterFile.scala 30:21 41:41]
    node _GEN_115 = mux(_T_1, _GEN_83, regs_19) @[RegisterFile.scala 30:21 41:41]
    node _GEN_116 = mux(_T_1, _GEN_84, regs_20) @[RegisterFile.scala 30:21 41:41]
    node _GEN_117 = mux(_T_1, _GEN_85, regs_21) @[RegisterFile.scala 30:21 41:41]
    node _GEN_118 = mux(_T_1, _GEN_86, regs_22) @[RegisterFile.scala 30:21 41:41]
    node _GEN_119 = mux(_T_1, _GEN_87, regs_23) @[RegisterFile.scala 30:21 41:41]
    node _GEN_120 = mux(_T_1, _GEN_88, regs_24) @[RegisterFile.scala 30:21 41:41]
    node _GEN_121 = mux(_T_1, _GEN_89, regs_25) @[RegisterFile.scala 30:21 41:41]
    node _GEN_122 = mux(_T_1, _GEN_90, regs_26) @[RegisterFile.scala 30:21 41:41]
    node _GEN_123 = mux(_T_1, _GEN_91, regs_27) @[RegisterFile.scala 30:21 41:41]
    node _GEN_124 = mux(_T_1, _GEN_92, regs_28) @[RegisterFile.scala 30:21 41:41]
    node _GEN_125 = mux(_T_1, _GEN_93, regs_29) @[RegisterFile.scala 30:21 41:41]
    node _GEN_126 = mux(_T_1, _GEN_94, regs_30) @[RegisterFile.scala 30:21 41:41]
    node _GEN_127 = mux(_T_1, _GEN_95, regs_31) @[RegisterFile.scala 30:21 41:41]
    node _io_debugRead_0_T = eq(UInt<1>("h0"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_0_T_1 = mux(_io_debugRead_0_T, UInt<1>("h0"), regs_0) @[RegisterFile.scala 45:27]
    node _io_debugRead_1_T = eq(UInt<1>("h1"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_1_T_1 = mux(_io_debugRead_1_T, UInt<1>("h0"), regs_1) @[RegisterFile.scala 45:27]
    node _io_debugRead_2_T = eq(UInt<2>("h2"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_2_T_1 = mux(_io_debugRead_2_T, UInt<1>("h0"), regs_2) @[RegisterFile.scala 45:27]
    node _io_debugRead_3_T = eq(UInt<2>("h3"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_3_T_1 = mux(_io_debugRead_3_T, UInt<1>("h0"), regs_3) @[RegisterFile.scala 45:27]
    node _io_debugRead_4_T = eq(UInt<3>("h4"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_4_T_1 = mux(_io_debugRead_4_T, UInt<1>("h0"), regs_4) @[RegisterFile.scala 45:27]
    node _io_debugRead_5_T = eq(UInt<3>("h5"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_5_T_1 = mux(_io_debugRead_5_T, UInt<1>("h0"), regs_5) @[RegisterFile.scala 45:27]
    node _io_debugRead_6_T = eq(UInt<3>("h6"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_6_T_1 = mux(_io_debugRead_6_T, UInt<1>("h0"), regs_6) @[RegisterFile.scala 45:27]
    node _io_debugRead_7_T = eq(UInt<3>("h7"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_7_T_1 = mux(_io_debugRead_7_T, UInt<1>("h0"), regs_7) @[RegisterFile.scala 45:27]
    node _io_debugRead_8_T = eq(UInt<4>("h8"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_8_T_1 = mux(_io_debugRead_8_T, UInt<1>("h0"), regs_8) @[RegisterFile.scala 45:27]
    node _io_debugRead_9_T = eq(UInt<4>("h9"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_9_T_1 = mux(_io_debugRead_9_T, UInt<1>("h0"), regs_9) @[RegisterFile.scala 45:27]
    node _io_debugRead_10_T = eq(UInt<4>("ha"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_10_T_1 = mux(_io_debugRead_10_T, UInt<1>("h0"), regs_10) @[RegisterFile.scala 45:27]
    node _io_debugRead_11_T = eq(UInt<4>("hb"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_11_T_1 = mux(_io_debugRead_11_T, UInt<1>("h0"), regs_11) @[RegisterFile.scala 45:27]
    node _io_debugRead_12_T = eq(UInt<4>("hc"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_12_T_1 = mux(_io_debugRead_12_T, UInt<1>("h0"), regs_12) @[RegisterFile.scala 45:27]
    node _io_debugRead_13_T = eq(UInt<4>("hd"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_13_T_1 = mux(_io_debugRead_13_T, UInt<1>("h0"), regs_13) @[RegisterFile.scala 45:27]
    node _io_debugRead_14_T = eq(UInt<4>("he"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_14_T_1 = mux(_io_debugRead_14_T, UInt<1>("h0"), regs_14) @[RegisterFile.scala 45:27]
    node _io_debugRead_15_T = eq(UInt<4>("hf"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_15_T_1 = mux(_io_debugRead_15_T, UInt<1>("h0"), regs_15) @[RegisterFile.scala 45:27]
    node _io_debugRead_16_T = eq(UInt<5>("h10"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_16_T_1 = mux(_io_debugRead_16_T, UInt<1>("h0"), regs_16) @[RegisterFile.scala 45:27]
    node _io_debugRead_17_T = eq(UInt<5>("h11"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_17_T_1 = mux(_io_debugRead_17_T, UInt<1>("h0"), regs_17) @[RegisterFile.scala 45:27]
    node _io_debugRead_18_T = eq(UInt<5>("h12"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_18_T_1 = mux(_io_debugRead_18_T, UInt<1>("h0"), regs_18) @[RegisterFile.scala 45:27]
    node _io_debugRead_19_T = eq(UInt<5>("h13"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_19_T_1 = mux(_io_debugRead_19_T, UInt<1>("h0"), regs_19) @[RegisterFile.scala 45:27]
    node _io_debugRead_20_T = eq(UInt<5>("h14"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_20_T_1 = mux(_io_debugRead_20_T, UInt<1>("h0"), regs_20) @[RegisterFile.scala 45:27]
    node _io_debugRead_21_T = eq(UInt<5>("h15"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_21_T_1 = mux(_io_debugRead_21_T, UInt<1>("h0"), regs_21) @[RegisterFile.scala 45:27]
    node _io_debugRead_22_T = eq(UInt<5>("h16"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_22_T_1 = mux(_io_debugRead_22_T, UInt<1>("h0"), regs_22) @[RegisterFile.scala 45:27]
    node _io_debugRead_23_T = eq(UInt<5>("h17"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_23_T_1 = mux(_io_debugRead_23_T, UInt<1>("h0"), regs_23) @[RegisterFile.scala 45:27]
    node _io_debugRead_24_T = eq(UInt<5>("h18"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_24_T_1 = mux(_io_debugRead_24_T, UInt<1>("h0"), regs_24) @[RegisterFile.scala 45:27]
    node _io_debugRead_25_T = eq(UInt<5>("h19"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_25_T_1 = mux(_io_debugRead_25_T, UInt<1>("h0"), regs_25) @[RegisterFile.scala 45:27]
    node _io_debugRead_26_T = eq(UInt<5>("h1a"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_26_T_1 = mux(_io_debugRead_26_T, UInt<1>("h0"), regs_26) @[RegisterFile.scala 45:27]
    node _io_debugRead_27_T = eq(UInt<5>("h1b"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_27_T_1 = mux(_io_debugRead_27_T, UInt<1>("h0"), regs_27) @[RegisterFile.scala 45:27]
    node _io_debugRead_28_T = eq(UInt<5>("h1c"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_28_T_1 = mux(_io_debugRead_28_T, UInt<1>("h0"), regs_28) @[RegisterFile.scala 45:27]
    node _io_debugRead_29_T = eq(UInt<5>("h1d"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_29_T_1 = mux(_io_debugRead_29_T, UInt<1>("h0"), regs_29) @[RegisterFile.scala 45:27]
    node _io_debugRead_30_T = eq(UInt<5>("h1e"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_30_T_1 = mux(_io_debugRead_30_T, UInt<1>("h0"), regs_30) @[RegisterFile.scala 45:27]
    node _io_debugRead_31_T = eq(UInt<5>("h1f"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_31_T_1 = mux(_io_debugRead_31_T, UInt<1>("h0"), regs_31) @[RegisterFile.scala 45:27]
    node _regs_WIRE_0 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_1 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_2 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_3 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_4 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_5 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_6 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_7 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_8 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_9 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_10 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_11 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_12 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_13 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_14 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_15 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_16 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_17 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_18 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_19 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_20 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_21 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_22 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_23 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_24 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_25 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_26 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_27 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_28 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_29 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_30 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_31 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    io_readData1 <= _io_readData1_T_1 @[RegisterFile.scala 31:16]
    io_readData2 <= _io_readData2_T_1 @[RegisterFile.scala 36:16]
    io_debugRead_0 <= _io_debugRead_0_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_1 <= _io_debugRead_1_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_2 <= _io_debugRead_2_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_3 <= _io_debugRead_3_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_4 <= _io_debugRead_4_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_5 <= _io_debugRead_5_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_6 <= _io_debugRead_6_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_7 <= _io_debugRead_7_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_8 <= _io_debugRead_8_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_9 <= _io_debugRead_9_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_10 <= _io_debugRead_10_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_11 <= _io_debugRead_11_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_12 <= _io_debugRead_12_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_13 <= _io_debugRead_13_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_14 <= _io_debugRead_14_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_15 <= _io_debugRead_15_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_16 <= _io_debugRead_16_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_17 <= _io_debugRead_17_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_18 <= _io_debugRead_18_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_19 <= _io_debugRead_19_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_20 <= _io_debugRead_20_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_21 <= _io_debugRead_21_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_22 <= _io_debugRead_22_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_23 <= _io_debugRead_23_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_24 <= _io_debugRead_24_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_25 <= _io_debugRead_25_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_26 <= _io_debugRead_26_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_27 <= _io_debugRead_27_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_28 <= _io_debugRead_28_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_29 <= _io_debugRead_29_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_30 <= _io_debugRead_30_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_31 <= _io_debugRead_31_T_1 @[RegisterFile.scala 45:21]
    regs_0 <= mux(reset, _regs_WIRE_0, _GEN_96) @[RegisterFile.scala 30:{21,21}]
    regs_1 <= mux(reset, _regs_WIRE_1, _GEN_97) @[RegisterFile.scala 30:{21,21}]
    regs_2 <= mux(reset, _regs_WIRE_2, _GEN_98) @[RegisterFile.scala 30:{21,21}]
    regs_3 <= mux(reset, _regs_WIRE_3, _GEN_99) @[RegisterFile.scala 30:{21,21}]
    regs_4 <= mux(reset, _regs_WIRE_4, _GEN_100) @[RegisterFile.scala 30:{21,21}]
    regs_5 <= mux(reset, _regs_WIRE_5, _GEN_101) @[RegisterFile.scala 30:{21,21}]
    regs_6 <= mux(reset, _regs_WIRE_6, _GEN_102) @[RegisterFile.scala 30:{21,21}]
    regs_7 <= mux(reset, _regs_WIRE_7, _GEN_103) @[RegisterFile.scala 30:{21,21}]
    regs_8 <= mux(reset, _regs_WIRE_8, _GEN_104) @[RegisterFile.scala 30:{21,21}]
    regs_9 <= mux(reset, _regs_WIRE_9, _GEN_105) @[RegisterFile.scala 30:{21,21}]
    regs_10 <= mux(reset, _regs_WIRE_10, _GEN_106) @[RegisterFile.scala 30:{21,21}]
    regs_11 <= mux(reset, _regs_WIRE_11, _GEN_107) @[RegisterFile.scala 30:{21,21}]
    regs_12 <= mux(reset, _regs_WIRE_12, _GEN_108) @[RegisterFile.scala 30:{21,21}]
    regs_13 <= mux(reset, _regs_WIRE_13, _GEN_109) @[RegisterFile.scala 30:{21,21}]
    regs_14 <= mux(reset, _regs_WIRE_14, _GEN_110) @[RegisterFile.scala 30:{21,21}]
    regs_15 <= mux(reset, _regs_WIRE_15, _GEN_111) @[RegisterFile.scala 30:{21,21}]
    regs_16 <= mux(reset, _regs_WIRE_16, _GEN_112) @[RegisterFile.scala 30:{21,21}]
    regs_17 <= mux(reset, _regs_WIRE_17, _GEN_113) @[RegisterFile.scala 30:{21,21}]
    regs_18 <= mux(reset, _regs_WIRE_18, _GEN_114) @[RegisterFile.scala 30:{21,21}]
    regs_19 <= mux(reset, _regs_WIRE_19, _GEN_115) @[RegisterFile.scala 30:{21,21}]
    regs_20 <= mux(reset, _regs_WIRE_20, _GEN_116) @[RegisterFile.scala 30:{21,21}]
    regs_21 <= mux(reset, _regs_WIRE_21, _GEN_117) @[RegisterFile.scala 30:{21,21}]
    regs_22 <= mux(reset, _regs_WIRE_22, _GEN_118) @[RegisterFile.scala 30:{21,21}]
    regs_23 <= mux(reset, _regs_WIRE_23, _GEN_119) @[RegisterFile.scala 30:{21,21}]
    regs_24 <= mux(reset, _regs_WIRE_24, _GEN_120) @[RegisterFile.scala 30:{21,21}]
    regs_25 <= mux(reset, _regs_WIRE_25, _GEN_121) @[RegisterFile.scala 30:{21,21}]
    regs_26 <= mux(reset, _regs_WIRE_26, _GEN_122) @[RegisterFile.scala 30:{21,21}]
    regs_27 <= mux(reset, _regs_WIRE_27, _GEN_123) @[RegisterFile.scala 30:{21,21}]
    regs_28 <= mux(reset, _regs_WIRE_28, _GEN_124) @[RegisterFile.scala 30:{21,21}]
    regs_29 <= mux(reset, _regs_WIRE_29, _GEN_125) @[RegisterFile.scala 30:{21,21}]
    regs_30 <= mux(reset, _regs_WIRE_30, _GEN_126) @[RegisterFile.scala 30:{21,21}]
    regs_31 <= mux(reset, _regs_WIRE_31, _GEN_127) @[RegisterFile.scala 30:{21,21}]

  module ALU :
    input clock : Clock
    input reset : UInt<1>
    input io_a : UInt<32>
    input io_b : UInt<32>
    input io_op : UInt<4>
    output io_y : UInt<32>

    node shamt = bits(io_b, 4, 0) @[ALU.scala 32:19]
    node _io_y_T = add(io_a, io_b) @[ALU.scala 35:25]
    node _io_y_T_1 = tail(_io_y_T, 1) @[ALU.scala 35:25]
    node _io_y_T_2 = sub(io_a, io_b) @[ALU.scala 36:25]
    node _io_y_T_3 = tail(_io_y_T_2, 1) @[ALU.scala 36:25]
    node _io_y_T_4 = dshl(io_a, shamt) @[ALU.scala 37:25]
    node _io_y_T_5 = asSInt(io_a) @[ALU.scala 38:25]
    node _io_y_T_6 = asSInt(io_b) @[ALU.scala 38:39]
    node _io_y_T_7 = lt(_io_y_T_5, _io_y_T_6) @[ALU.scala 38:32]
    node _io_y_T_8 = lt(io_a, io_b) @[ALU.scala 39:25]
    node _io_y_T_9 = xor(io_a, io_b) @[ALU.scala 40:25]
    node _io_y_T_10 = dshr(io_a, shamt) @[ALU.scala 41:25]
    node _io_y_T_11 = asSInt(io_a) @[ALU.scala 42:25]
    node _io_y_T_12 = dshr(_io_y_T_11, shamt) @[ALU.scala 42:32]
    node _io_y_T_13 = asUInt(_io_y_T_12) @[ALU.scala 42:42]
    node _io_y_T_14 = or(io_a, io_b) @[ALU.scala 43:25]
    node _io_y_T_15 = and(io_a, io_b) @[ALU.scala 44:25]
    node _io_y_T_16 = eq(UInt<4>("h0"), io_op) @[Mux.scala 81:61]
    node _io_y_T_17 = mux(_io_y_T_16, _io_y_T_1, UInt<1>("h0")) @[Mux.scala 81:58]
    node _io_y_T_18 = eq(UInt<4>("h1"), io_op) @[Mux.scala 81:61]
    node _io_y_T_19 = mux(_io_y_T_18, _io_y_T_3, _io_y_T_17) @[Mux.scala 81:58]
    node _io_y_T_20 = eq(UInt<4>("h2"), io_op) @[Mux.scala 81:61]
    node _io_y_T_21 = mux(_io_y_T_20, _io_y_T_4, _io_y_T_19) @[Mux.scala 81:58]
    node _io_y_T_22 = eq(UInt<4>("h3"), io_op) @[Mux.scala 81:61]
    node _io_y_T_23 = mux(_io_y_T_22, _io_y_T_7, _io_y_T_21) @[Mux.scala 81:58]
    node _io_y_T_24 = eq(UInt<4>("h4"), io_op) @[Mux.scala 81:61]
    node _io_y_T_25 = mux(_io_y_T_24, _io_y_T_8, _io_y_T_23) @[Mux.scala 81:58]
    node _io_y_T_26 = eq(UInt<4>("h5"), io_op) @[Mux.scala 81:61]
    node _io_y_T_27 = mux(_io_y_T_26, _io_y_T_9, _io_y_T_25) @[Mux.scala 81:58]
    node _io_y_T_28 = eq(UInt<4>("h6"), io_op) @[Mux.scala 81:61]
    node _io_y_T_29 = mux(_io_y_T_28, _io_y_T_10, _io_y_T_27) @[Mux.scala 81:58]
    node _io_y_T_30 = eq(UInt<4>("h7"), io_op) @[Mux.scala 81:61]
    node _io_y_T_31 = mux(_io_y_T_30, _io_y_T_13, _io_y_T_29) @[Mux.scala 81:58]
    node _io_y_T_32 = eq(UInt<4>("h8"), io_op) @[Mux.scala 81:61]
    node _io_y_T_33 = mux(_io_y_T_32, _io_y_T_14, _io_y_T_31) @[Mux.scala 81:58]
    node _io_y_T_34 = eq(UInt<4>("h9"), io_op) @[Mux.scala 81:61]
    node _io_y_T_35 = mux(_io_y_T_34, _io_y_T_15, _io_y_T_33) @[Mux.scala 81:58]
    io_y <= bits(_io_y_T_35, 31, 0) @[ALU.scala 34:8]

  module Datapath :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    output io_writeBack : UInt<32>
    output io_debugX1 : UInt<32>
    output io_debugX2 : UInt<32>
    output io_debugX3 : UInt<32>
    output io_debugX4 : UInt<32>
    output io_debugALU : UInt<32>
    output io_debugImm : UInt<32>

    inst decoder of Decoder @[Datapath.scala 19:23]
    inst immGen of ImmediateGenerator @[Datapath.scala 20:23]
    inst regFile of RegisterFile @[Datapath.scala 21:23]
    inst alu of ALU @[Datapath.scala 22:23]
    node aluB = mux(decoder.io_aluSrc, immGen.io_imm, regFile.io_readData2) @[Datapath.scala 31:17]
    io_writeBack <= alu.io_y @[Datapath.scala 44:16]
    io_debugX1 <= regFile.io_debugRead_1 @[Datapath.scala 46:14]
    io_debugX2 <= regFile.io_debugRead_2 @[Datapath.scala 47:14]
    io_debugX3 <= regFile.io_debugRead_3 @[Datapath.scala 48:14]
    io_debugX4 <= regFile.io_debugRead_4 @[Datapath.scala 49:14]
    io_debugALU <= alu.io_y @[Datapath.scala 51:15]
    io_debugImm <= immGen.io_imm @[Datapath.scala 52:15]
    decoder.clock <= clock
    decoder.reset <= reset
    decoder.io_instr <= io_instr @[Datapath.scala 24:20]
    immGen.clock <= clock
    immGen.reset <= reset
    immGen.io_instr <= io_instr @[Datapath.scala 25:20]
    regFile.clock <= clock
    regFile.reset <= reset
    regFile.io_rs1 <= decoder.io_rs1 @[Datapath.scala 27:18]
    regFile.io_rs2 <= decoder.io_rs2 @[Datapath.scala 28:18]
    regFile.io_rd <= decoder.io_rd @[Datapath.scala 29:18]
    regFile.io_writeData <= alu.io_y @[Datapath.scala 41:26]
    regFile.io_writeEnable <= decoder.io_regWrite @[Datapath.scala 42:26]
    alu.clock <= clock
    alu.reset <= reset
    alu.io_a <= regFile.io_readData1 @[Datapath.scala 37:13]
    alu.io_b <= aluB @[Datapath.scala 38:13]
    alu.io_op <= decoder.io_aluOp @[Datapath.scala 39:13]
