FIRRTL version 1.1.0
circuit ImmediateGenerator :
  module ImmediateGenerator :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    output io_imm : UInt<32>

    node imm12 = bits(io_instr, 31, 20) @[ImmediateGenerator.scala 11:23]
    node _io_imm_T = asSInt(imm12) @[ImmediateGenerator.scala 12:19]
    node _io_imm_T_1 = pad(_io_imm_T, 32) @[ImmediateGenerator.scala 12:29]
    node _io_imm_T_2 = asUInt(_io_imm_T_1) @[ImmediateGenerator.scala 12:38]
    io_imm <= _io_imm_T_2 @[ImmediateGenerator.scala 12:10]
