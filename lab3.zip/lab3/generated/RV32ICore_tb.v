`timescale 1ns/1ps

module RV32ICore_tb;

    reg clock;
    reg reset;

    // Device Under Test
    RV32ICore dut (
        .clock(clock),
        .reset(reset)
    );

    // 100 MHz clock
    initial begin
        clock = 0;
        forever #5 clock = ~clock;
    end

    initial begin
        $readmemh("memory.hex", dut.instructionMemory.mem);
    end


    // Generate waveform
    initial begin
        $dumpfile("RV32ICore.vcd");
        $dumpvars(0, RV32ICore_tb);
    end

    // Simulation
    initial begin

        $display("=================================");
        $display("      RV32I Core Simulation");
        $display("=================================");

        reset = 1;

        // Hold reset for 2 cycles
        repeat (2)
            @(posedge clock);

        reset = 0;

        $display("[%0t] Reset released", $time);

        // Execute 100 cycles
        repeat (100)
            @(posedge clock);

        $display("[%0t] Simulation finished", $time);

        $finish;
    end

endmodule

