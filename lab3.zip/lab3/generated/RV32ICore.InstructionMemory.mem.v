module BindsTo_0_InstructionMemory(
  input         clock,
  input  [31:0] io_addr,
  output [31:0] io_instr
);

initial begin
  $readmemh("memory.hex", InstructionMemory.mem);
end
                      endmodule

bind InstructionMemory BindsTo_0_InstructionMemory BindsTo_0_InstructionMemory_Inst(.*);