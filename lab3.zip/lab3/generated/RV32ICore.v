module InstructionMemory(
  input         clock,
  input  [31:0] io_addr,
  output [31:0] io_instr
);
`ifdef RANDOMIZE_MEM_INIT
  reg [31:0] _RAND_0;
`endif // RANDOMIZE_MEM_INIT
  reg [31:0] mem [0:1023]; // @[InstructionMemory.scala 14:16]
  wire  mem_io_instr_MPORT_en; // @[InstructionMemory.scala 14:16]
  wire [9:0] mem_io_instr_MPORT_addr; // @[InstructionMemory.scala 14:16]
  wire [31:0] mem_io_instr_MPORT_data; // @[InstructionMemory.scala 14:16]
  wire [31:0] wordAddr = {{2'd0}, io_addr[31:2]}; // @[InstructionMemory.scala 18:26]
  assign mem_io_instr_MPORT_en = 1'h1;
  assign mem_io_instr_MPORT_addr = wordAddr[9:0];
  assign mem_io_instr_MPORT_data = mem[mem_io_instr_MPORT_addr]; // @[InstructionMemory.scala 14:16]
  assign io_instr = mem_io_instr_MPORT_data; // @[InstructionMemory.scala 20:12]
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_MEM_INIT
  _RAND_0 = {1{`RANDOM}};
  for (initvar = 0; initvar < 1024; initvar = initvar+1)
    mem[initvar] = _RAND_0[31:0];
`endif // RANDOMIZE_MEM_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module Decoder(
  input  [31:0] io_instr,
  output [4:0]  io_rs1,
  output [4:0]  io_rs2,
  output [4:0]  io_rd,
  output [2:0]  io_funct3
);
  assign io_rs1 = io_instr[19:15]; // @[Decoder.scala 37:24]
  assign io_rs2 = io_instr[24:20]; // @[Decoder.scala 38:24]
  assign io_rd = io_instr[11:7]; // @[Decoder.scala 39:24]
  assign io_funct3 = io_instr[14:12]; // @[Decoder.scala 34:24]
endmodule
module Control(
  input  [31:0] io_instr,
  output [3:0]  io_aluOp,
  output        io_aluSrc,
  output        io_regWrite,
  output        io_memRead,
  output        io_memWrite,
  output        io_memToReg,
  output        io_branch,
  output        io_jump,
  output        io_jalr
);
  wire [6:0] opcode = io_instr[6:0]; // @[Control.scala 22:24]
  wire [2:0] funct3 = io_instr[14:12]; // @[Control.scala 23:24]
  wire [6:0] funct7 = io_instr[31:25]; // @[Control.scala 24:24]
  wire  _io_aluOp_T = funct7 == 7'h20; // @[Control.scala 62:34]
  wire [3:0] _io_aluOp_T_1 = funct7 == 7'h20 ? 4'h1 : 4'h0; // @[Control.scala 62:26]
  wire [3:0] _io_aluOp_T_3 = _io_aluOp_T ? 4'h7 : 4'h6; // @[Control.scala 70:26]
  wire [3:0] _io_aluOp_T_5 = 3'h1 == funct3 ? 4'h2 : _io_aluOp_T_1; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_7 = 3'h2 == funct3 ? 4'h3 : _io_aluOp_T_5; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_9 = 3'h3 == funct3 ? 4'h4 : _io_aluOp_T_7; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_11 = 3'h4 == funct3 ? 4'h5 : _io_aluOp_T_9; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_13 = 3'h5 == funct3 ? _io_aluOp_T_3 : _io_aluOp_T_11; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_15 = 3'h6 == funct3 ? 4'h8 : _io_aluOp_T_13; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_17 = 3'h7 == funct3 ? 4'h9 : _io_aluOp_T_15; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_21 = 3'h1 == funct3 ? 4'h2 : 4'h0; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_23 = 3'h2 == funct3 ? 4'h3 : _io_aluOp_T_21; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_25 = 3'h3 == funct3 ? 4'h4 : _io_aluOp_T_23; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_27 = 3'h4 == funct3 ? 4'h5 : _io_aluOp_T_25; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_29 = 3'h5 == funct3 ? _io_aluOp_T_3 : _io_aluOp_T_27; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_31 = 3'h6 == funct3 ? 4'h8 : _io_aluOp_T_29; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_33 = 3'h7 == funct3 ? 4'h9 : _io_aluOp_T_31; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_35 = 3'h0 == funct3 ? 4'ha : 4'hf; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_37 = 3'h1 == funct3 ? 4'hb : _io_aluOp_T_35; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_39 = 3'h4 == funct3 ? 4'h3 : _io_aluOp_T_37; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_41 = 3'h5 == funct3 ? 4'h3 : _io_aluOp_T_39; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_43 = 3'h6 == funct3 ? 4'h4 : _io_aluOp_T_41; // @[Mux.scala 81:58]
  wire [3:0] _io_aluOp_T_45 = 3'h7 == funct3 ? 4'h4 : _io_aluOp_T_43; // @[Mux.scala 81:58]
  wire  _T_7 = funct3 == 3'h0; // @[Control.scala 164:19]
  wire [3:0] _GEN_1 = funct3 == 3'h0 ? 4'h0 : 4'hf; // @[Control.scala 164:33 169:21 38:15]
  wire [3:0] _GEN_3 = 7'h17 == opcode ? 4'h0 : 4'hf; // @[Control.scala 49:18 187:19 38:15]
  wire  _GEN_4 = 7'h37 == opcode | 7'h17 == opcode; // @[Control.scala 49:18 177:19]
  wire [3:0] _GEN_5 = 7'h37 == opcode ? 4'h0 : _GEN_3; // @[Control.scala 49:18 180:19]
  wire  _GEN_6 = 7'h67 == opcode ? _T_7 : _GEN_4; // @[Control.scala 49:18]
  wire [3:0] _GEN_8 = 7'h67 == opcode ? _GEN_1 : _GEN_5; // @[Control.scala 49:18]
  wire  _GEN_9 = 7'h6f == opcode | _GEN_6; // @[Control.scala 49:18 153:19]
  wire [3:0] _GEN_11 = 7'h6f == opcode ? 4'h0 : _GEN_8; // @[Control.scala 49:18 157:19]
  wire  _GEN_12 = 7'h6f == opcode ? 1'h0 : 7'h67 == opcode & _T_7; // @[Control.scala 46:15 49:18]
  wire [3:0] _GEN_15 = 7'h63 == opcode ? _io_aluOp_T_45 : _GEN_11; // @[Control.scala 135:16 49:18]
  wire  _GEN_16 = 7'h63 == opcode ? 1'h0 : 7'h6f == opcode; // @[Control.scala 45:15 49:18]
  wire  _GEN_17 = 7'h63 == opcode ? 1'h0 : _GEN_9; // @[Control.scala 40:15 49:18]
  wire  _GEN_18 = 7'h63 == opcode ? 1'h0 : _GEN_12; // @[Control.scala 46:15 49:18]
  wire  _GEN_20 = 7'h23 == opcode | _GEN_17; // @[Control.scala 49:18 123:19]
  wire [3:0] _GEN_21 = 7'h23 == opcode ? 4'h0 : _GEN_15; // @[Control.scala 49:18 124:19]
  wire  _GEN_23 = 7'h23 == opcode ? 1'h0 : 7'h63 == opcode; // @[Control.scala 44:15 49:18]
  wire  _GEN_24 = 7'h23 == opcode ? 1'h0 : _GEN_16; // @[Control.scala 45:15 49:18]
  wire  _GEN_25 = 7'h23 == opcode ? 1'h0 : _GEN_17; // @[Control.scala 40:15 49:18]
  wire  _GEN_26 = 7'h23 == opcode ? 1'h0 : _GEN_18; // @[Control.scala 46:15 49:18]
  wire  _GEN_28 = 7'h3 == opcode | _GEN_25; // @[Control.scala 49:18 111:19]
  wire  _GEN_29 = 7'h3 == opcode | _GEN_20; // @[Control.scala 49:18 112:19]
  wire [3:0] _GEN_30 = 7'h3 == opcode ? 4'h0 : _GEN_21; // @[Control.scala 49:18 113:19]
  wire  _GEN_32 = 7'h3 == opcode ? 1'h0 : 7'h23 == opcode; // @[Control.scala 42:15 49:18]
  wire  _GEN_33 = 7'h3 == opcode ? 1'h0 : _GEN_23; // @[Control.scala 44:15 49:18]
  wire  _GEN_34 = 7'h3 == opcode ? 1'h0 : _GEN_24; // @[Control.scala 45:15 49:18]
  wire  _GEN_35 = 7'h3 == opcode ? 1'h0 : _GEN_26; // @[Control.scala 46:15 49:18]
  wire  _GEN_37 = 7'h13 == opcode | _GEN_28; // @[Control.scala 49:18 84:19]
  wire  _GEN_38 = 7'h13 == opcode | _GEN_29; // @[Control.scala 49:18 85:19]
  wire [3:0] _GEN_39 = 7'h13 == opcode ? _io_aluOp_T_33 : _GEN_30; // @[Control.scala 49:18 87:16]
  wire  _GEN_40 = 7'h13 == opcode ? 1'h0 : 7'h3 == opcode; // @[Control.scala 41:15 49:18]
  wire  _GEN_41 = 7'h13 == opcode ? 1'h0 : _GEN_32; // @[Control.scala 42:15 49:18]
  wire  _GEN_42 = 7'h13 == opcode ? 1'h0 : _GEN_33; // @[Control.scala 44:15 49:18]
  wire  _GEN_43 = 7'h13 == opcode ? 1'h0 : _GEN_34; // @[Control.scala 45:15 49:18]
  wire  _GEN_44 = 7'h13 == opcode ? 1'h0 : _GEN_35; // @[Control.scala 46:15 49:18]
  assign io_aluOp = 7'h33 == opcode ? _io_aluOp_T_17 : _GEN_39; // @[Control.scala 49:18 58:16]
  assign io_aluSrc = 7'h33 == opcode ? 1'h0 : _GEN_38; // @[Control.scala 39:15 49:18]
  assign io_regWrite = 7'h33 == opcode | _GEN_37; // @[Control.scala 49:18 56:19]
  assign io_memRead = 7'h33 == opcode ? 1'h0 : _GEN_40; // @[Control.scala 41:15 49:18]
  assign io_memWrite = 7'h33 == opcode ? 1'h0 : _GEN_41; // @[Control.scala 42:15 49:18]
  assign io_memToReg = 7'h33 == opcode ? 1'h0 : _GEN_40; // @[Control.scala 41:15 49:18]
  assign io_branch = 7'h33 == opcode ? 1'h0 : _GEN_42; // @[Control.scala 44:15 49:18]
  assign io_jump = 7'h33 == opcode ? 1'h0 : _GEN_43; // @[Control.scala 45:15 49:18]
  assign io_jalr = 7'h33 == opcode ? 1'h0 : _GEN_44; // @[Control.scala 46:15 49:18]
endmodule
module ImmediateGenerator(
  input  [31:0] io_instr,
  output [31:0] io_imm
);
  wire [6:0] opcode = io_instr[6:0]; // @[ImmediateGenerator.scala 12:24]
  wire [19:0] _iImm_T_2 = io_instr[31] ? 20'hfffff : 20'h0; // @[Bitwise.scala 77:12]
  wire [31:0] iImm = {_iImm_T_2,io_instr[31:20]}; // @[Cat.scala 33:92]
  wire [31:0] sImm = {_iImm_T_2,io_instr[31:25],io_instr[11:7]}; // @[Cat.scala 33:92]
  wire [18:0] _bImm_T_2 = io_instr[31] ? 19'h7ffff : 19'h0; // @[Bitwise.scala 77:12]
  wire [31:0] bImm = {_bImm_T_2,io_instr[31],io_instr[7],io_instr[30:25],io_instr[11:8],1'h0}; // @[Cat.scala 33:92]
  wire [31:0] uImm = {io_instr[31:12],12'h0}; // @[Cat.scala 33:92]
  wire [10:0] _jImm_T_2 = io_instr[31] ? 11'h7ff : 11'h0; // @[Bitwise.scala 77:12]
  wire [31:0] jImm = {_jImm_T_2,io_instr[31],io_instr[19:12],io_instr[20],io_instr[30:21],1'h0}; // @[Cat.scala 33:92]
  wire [31:0] _GEN_0 = 7'h6f == opcode ? jImm : 32'h0; // @[ImmediateGenerator.scala 48:10 50:18 81:14]
  wire [31:0] _GEN_1 = 7'h17 == opcode ? uImm : _GEN_0; // @[ImmediateGenerator.scala 50:18 77:14]
  wire [31:0] _GEN_2 = 7'h37 == opcode ? uImm : _GEN_1; // @[ImmediateGenerator.scala 50:18 73:14]
  wire [31:0] _GEN_3 = 7'h63 == opcode ? bImm : _GEN_2; // @[ImmediateGenerator.scala 50:18 69:14]
  wire [31:0] _GEN_4 = 7'h23 == opcode ? sImm : _GEN_3; // @[ImmediateGenerator.scala 50:18 65:14]
  wire [31:0] _GEN_5 = 7'h67 == opcode ? iImm : _GEN_4; // @[ImmediateGenerator.scala 50:18 61:14]
  wire [31:0] _GEN_6 = 7'h13 == opcode ? iImm : _GEN_5; // @[ImmediateGenerator.scala 50:18 57:14]
  assign io_imm = 7'h3 == opcode ? iImm : _GEN_6; // @[ImmediateGenerator.scala 50:18 53:14]
endmodule
module RegisterFile(
  input         clock,
  input         reset,
  input  [4:0]  io_rs1,
  input  [4:0]  io_rs2,
  input  [4:0]  io_rd,
  input  [31:0] io_writeData,
  input         io_writeEnable,
  output [31:0] io_readData1,
  output [31:0] io_readData2,
  output [31:0] io_debugRead_1,
  output [31:0] io_debugRead_2,
  output [31:0] io_debugRead_3,
  output [31:0] io_debugRead_4
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
`endif // RANDOMIZE_REG_INIT
  reg [31:0] regs_0; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_1; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_2; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_3; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_4; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_5; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_6; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_7; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_8; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_9; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_10; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_11; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_12; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_13; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_14; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_15; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_16; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_17; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_18; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_19; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_20; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_21; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_22; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_23; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_24; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_25; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_26; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_27; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_28; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_29; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_30; // @[RegisterFile.scala 30:21]
  reg [31:0] regs_31; // @[RegisterFile.scala 30:21]
  wire  _io_readData1_T = io_rs1 == 5'h0; // @[RegisterFile.scala 32:12]
  wire [31:0] _GEN_1 = 5'h1 == io_rs1 ? regs_1 : regs_0; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_2 = 5'h2 == io_rs1 ? regs_2 : _GEN_1; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_3 = 5'h3 == io_rs1 ? regs_3 : _GEN_2; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_4 = 5'h4 == io_rs1 ? regs_4 : _GEN_3; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_5 = 5'h5 == io_rs1 ? regs_5 : _GEN_4; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_6 = 5'h6 == io_rs1 ? regs_6 : _GEN_5; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_7 = 5'h7 == io_rs1 ? regs_7 : _GEN_6; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_8 = 5'h8 == io_rs1 ? regs_8 : _GEN_7; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_9 = 5'h9 == io_rs1 ? regs_9 : _GEN_8; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_10 = 5'ha == io_rs1 ? regs_10 : _GEN_9; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_11 = 5'hb == io_rs1 ? regs_11 : _GEN_10; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_12 = 5'hc == io_rs1 ? regs_12 : _GEN_11; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_13 = 5'hd == io_rs1 ? regs_13 : _GEN_12; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_14 = 5'he == io_rs1 ? regs_14 : _GEN_13; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_15 = 5'hf == io_rs1 ? regs_15 : _GEN_14; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_16 = 5'h10 == io_rs1 ? regs_16 : _GEN_15; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_17 = 5'h11 == io_rs1 ? regs_17 : _GEN_16; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_18 = 5'h12 == io_rs1 ? regs_18 : _GEN_17; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_19 = 5'h13 == io_rs1 ? regs_19 : _GEN_18; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_20 = 5'h14 == io_rs1 ? regs_20 : _GEN_19; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_21 = 5'h15 == io_rs1 ? regs_21 : _GEN_20; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_22 = 5'h16 == io_rs1 ? regs_22 : _GEN_21; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_23 = 5'h17 == io_rs1 ? regs_23 : _GEN_22; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_24 = 5'h18 == io_rs1 ? regs_24 : _GEN_23; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_25 = 5'h19 == io_rs1 ? regs_25 : _GEN_24; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_26 = 5'h1a == io_rs1 ? regs_26 : _GEN_25; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_27 = 5'h1b == io_rs1 ? regs_27 : _GEN_26; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_28 = 5'h1c == io_rs1 ? regs_28 : _GEN_27; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_29 = 5'h1d == io_rs1 ? regs_29 : _GEN_28; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_30 = 5'h1e == io_rs1 ? regs_30 : _GEN_29; // @[RegisterFile.scala 31:{22,22}]
  wire [31:0] _GEN_31 = 5'h1f == io_rs1 ? regs_31 : _GEN_30; // @[RegisterFile.scala 31:{22,22}]
  wire  _io_readData2_T = io_rs2 == 5'h0; // @[RegisterFile.scala 37:12]
  wire [31:0] _GEN_33 = 5'h1 == io_rs2 ? regs_1 : regs_0; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_34 = 5'h2 == io_rs2 ? regs_2 : _GEN_33; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_35 = 5'h3 == io_rs2 ? regs_3 : _GEN_34; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_36 = 5'h4 == io_rs2 ? regs_4 : _GEN_35; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_37 = 5'h5 == io_rs2 ? regs_5 : _GEN_36; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_38 = 5'h6 == io_rs2 ? regs_6 : _GEN_37; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_39 = 5'h7 == io_rs2 ? regs_7 : _GEN_38; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_40 = 5'h8 == io_rs2 ? regs_8 : _GEN_39; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_41 = 5'h9 == io_rs2 ? regs_9 : _GEN_40; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_42 = 5'ha == io_rs2 ? regs_10 : _GEN_41; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_43 = 5'hb == io_rs2 ? regs_11 : _GEN_42; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_44 = 5'hc == io_rs2 ? regs_12 : _GEN_43; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_45 = 5'hd == io_rs2 ? regs_13 : _GEN_44; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_46 = 5'he == io_rs2 ? regs_14 : _GEN_45; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_47 = 5'hf == io_rs2 ? regs_15 : _GEN_46; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_48 = 5'h10 == io_rs2 ? regs_16 : _GEN_47; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_49 = 5'h11 == io_rs2 ? regs_17 : _GEN_48; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_50 = 5'h12 == io_rs2 ? regs_18 : _GEN_49; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_51 = 5'h13 == io_rs2 ? regs_19 : _GEN_50; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_52 = 5'h14 == io_rs2 ? regs_20 : _GEN_51; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_53 = 5'h15 == io_rs2 ? regs_21 : _GEN_52; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_54 = 5'h16 == io_rs2 ? regs_22 : _GEN_53; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_55 = 5'h17 == io_rs2 ? regs_23 : _GEN_54; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_56 = 5'h18 == io_rs2 ? regs_24 : _GEN_55; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_57 = 5'h19 == io_rs2 ? regs_25 : _GEN_56; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_58 = 5'h1a == io_rs2 ? regs_26 : _GEN_57; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_59 = 5'h1b == io_rs2 ? regs_27 : _GEN_58; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_60 = 5'h1c == io_rs2 ? regs_28 : _GEN_59; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_61 = 5'h1d == io_rs2 ? regs_29 : _GEN_60; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_62 = 5'h1e == io_rs2 ? regs_30 : _GEN_61; // @[RegisterFile.scala 36:{22,22}]
  wire [31:0] _GEN_63 = 5'h1f == io_rs2 ? regs_31 : _GEN_62; // @[RegisterFile.scala 36:{22,22}]
  assign io_readData1 = _io_readData1_T ? 32'h0 : _GEN_31; // @[RegisterFile.scala 31:22]
  assign io_readData2 = _io_readData2_T ? 32'h0 : _GEN_63; // @[RegisterFile.scala 36:22]
  assign io_debugRead_1 = regs_1; // @[RegisterFile.scala 45:27]
  assign io_debugRead_2 = regs_2; // @[RegisterFile.scala 45:27]
  assign io_debugRead_3 = regs_3; // @[RegisterFile.scala 45:27]
  assign io_debugRead_4 = regs_4; // @[RegisterFile.scala 45:27]
  always @(posedge clock) begin
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_0 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h0 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_0 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_1 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h1 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_1 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_2 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h2 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_2 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_3 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h3 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_3 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_4 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h4 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_4 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_5 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h5 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_5 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_6 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h6 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_6 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_7 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h7 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_7 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_8 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h8 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_8 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_9 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h9 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_9 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_10 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'ha == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_10 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_11 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'hb == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_11 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_12 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'hc == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_12 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_13 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'hd == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_13 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_14 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'he == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_14 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_15 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'hf == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_15 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_16 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h10 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_16 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_17 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h11 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_17 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_18 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h12 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_18 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_19 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h13 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_19 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_20 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h14 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_20 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_21 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h15 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_21 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_22 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h16 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_22 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_23 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h17 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_23 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_24 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h18 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_24 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_25 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h19 == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_25 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_26 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h1a == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_26 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_27 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h1b == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_27 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_28 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h1c == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_28 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_29 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h1d == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_29 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_30 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h1e == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_30 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 30:21]
      regs_31 <= 32'h0; // @[RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 41:41]
      if (5'h1f == io_rd) begin // @[RegisterFile.scala 42:17]
        regs_31 <= io_writeData; // @[RegisterFile.scala 42:17]
      end
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  regs_0 = _RAND_0[31:0];
  _RAND_1 = {1{`RANDOM}};
  regs_1 = _RAND_1[31:0];
  _RAND_2 = {1{`RANDOM}};
  regs_2 = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  regs_3 = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  regs_4 = _RAND_4[31:0];
  _RAND_5 = {1{`RANDOM}};
  regs_5 = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  regs_6 = _RAND_6[31:0];
  _RAND_7 = {1{`RANDOM}};
  regs_7 = _RAND_7[31:0];
  _RAND_8 = {1{`RANDOM}};
  regs_8 = _RAND_8[31:0];
  _RAND_9 = {1{`RANDOM}};
  regs_9 = _RAND_9[31:0];
  _RAND_10 = {1{`RANDOM}};
  regs_10 = _RAND_10[31:0];
  _RAND_11 = {1{`RANDOM}};
  regs_11 = _RAND_11[31:0];
  _RAND_12 = {1{`RANDOM}};
  regs_12 = _RAND_12[31:0];
  _RAND_13 = {1{`RANDOM}};
  regs_13 = _RAND_13[31:0];
  _RAND_14 = {1{`RANDOM}};
  regs_14 = _RAND_14[31:0];
  _RAND_15 = {1{`RANDOM}};
  regs_15 = _RAND_15[31:0];
  _RAND_16 = {1{`RANDOM}};
  regs_16 = _RAND_16[31:0];
  _RAND_17 = {1{`RANDOM}};
  regs_17 = _RAND_17[31:0];
  _RAND_18 = {1{`RANDOM}};
  regs_18 = _RAND_18[31:0];
  _RAND_19 = {1{`RANDOM}};
  regs_19 = _RAND_19[31:0];
  _RAND_20 = {1{`RANDOM}};
  regs_20 = _RAND_20[31:0];
  _RAND_21 = {1{`RANDOM}};
  regs_21 = _RAND_21[31:0];
  _RAND_22 = {1{`RANDOM}};
  regs_22 = _RAND_22[31:0];
  _RAND_23 = {1{`RANDOM}};
  regs_23 = _RAND_23[31:0];
  _RAND_24 = {1{`RANDOM}};
  regs_24 = _RAND_24[31:0];
  _RAND_25 = {1{`RANDOM}};
  regs_25 = _RAND_25[31:0];
  _RAND_26 = {1{`RANDOM}};
  regs_26 = _RAND_26[31:0];
  _RAND_27 = {1{`RANDOM}};
  regs_27 = _RAND_27[31:0];
  _RAND_28 = {1{`RANDOM}};
  regs_28 = _RAND_28[31:0];
  _RAND_29 = {1{`RANDOM}};
  regs_29 = _RAND_29[31:0];
  _RAND_30 = {1{`RANDOM}};
  regs_30 = _RAND_30[31:0];
  _RAND_31 = {1{`RANDOM}};
  regs_31 = _RAND_31[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module ALU(
  input  [31:0] io_a,
  input  [31:0] io_b,
  input  [3:0]  io_op,
  output [31:0] io_y
);
  wire [4:0] shamt = io_b[4:0]; // @[ALU.scala 15:19]
  wire  equal = io_a == io_b; // @[ALU.scala 20:23]
  wire  notEqual = io_a != io_b; // @[ALU.scala 21:23]
  wire [31:0] _io_y_T_1 = io_a + io_b; // @[ALU.scala 24:25]
  wire [31:0] _io_y_T_3 = io_a - io_b; // @[ALU.scala 25:25]
  wire [62:0] _GEN_0 = {{31'd0}, io_a}; // @[ALU.scala 26:25]
  wire [62:0] _io_y_T_4 = _GEN_0 << shamt; // @[ALU.scala 26:25]
  wire  _io_y_T_5 = $signed(io_a) < $signed(io_b); // @[ALU.scala 27:28]
  wire  _io_y_T_6 = io_a < io_b; // @[ALU.scala 28:25]
  wire [31:0] _io_y_T_7 = io_a ^ io_b; // @[ALU.scala 29:25]
  wire [31:0] _io_y_T_8 = io_a >> shamt; // @[ALU.scala 30:25]
  wire [31:0] _io_y_T_10 = $signed(io_a) >>> shamt; // @[ALU.scala 31:38]
  wire [31:0] _io_y_T_11 = io_a | io_b; // @[ALU.scala 32:25]
  wire [31:0] _io_y_T_12 = io_a & io_b; // @[ALU.scala 33:25]
  wire [31:0] _io_y_T_13 = equal ? 32'h1 : 32'h0; // @[ALU.scala 34:22]
  wire [31:0] _io_y_T_14 = notEqual ? 32'h1 : 32'h0; // @[ALU.scala 35:22]
  wire [31:0] _io_y_T_16 = 4'h0 == io_op ? _io_y_T_1 : 32'h0; // @[Mux.scala 81:58]
  wire [31:0] _io_y_T_18 = 4'h1 == io_op ? _io_y_T_3 : _io_y_T_16; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_20 = 4'h2 == io_op ? _io_y_T_4 : {{31'd0}, _io_y_T_18}; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_22 = 4'h3 == io_op ? {{62'd0}, _io_y_T_5} : _io_y_T_20; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_24 = 4'h4 == io_op ? {{62'd0}, _io_y_T_6} : _io_y_T_22; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_26 = 4'h5 == io_op ? {{31'd0}, _io_y_T_7} : _io_y_T_24; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_28 = 4'h6 == io_op ? {{31'd0}, _io_y_T_8} : _io_y_T_26; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_30 = 4'h7 == io_op ? {{31'd0}, _io_y_T_10} : _io_y_T_28; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_32 = 4'h8 == io_op ? {{31'd0}, _io_y_T_11} : _io_y_T_30; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_34 = 4'h9 == io_op ? {{31'd0}, _io_y_T_12} : _io_y_T_32; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_36 = 4'ha == io_op ? {{31'd0}, _io_y_T_13} : _io_y_T_34; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_38 = 4'hb == io_op ? {{31'd0}, _io_y_T_14} : _io_y_T_36; // @[Mux.scala 81:58]
  assign io_y = _io_y_T_38[31:0]; // @[ALU.scala 23:8]
endmodule
module PCUpdate(
  input  [31:0] io_pc,
  input  [31:0] io_rs1,
  input  [31:0] io_imm,
  input  [2:0]  io_funct3,
  input         io_branch,
  input         io_jump,
  input         io_jalr,
  input  [31:0] io_aluResult,
  output [31:0] io_nextPc
);
  wire [31:0] pcPlus4 = io_pc + 32'h4; // @[PCUpdate.scala 23:23]
  wire [31:0] branchTarget = io_pc + io_imm; // @[PCUpdate.scala 25:28]
  wire [31:0] _jalrTarget_T_1 = io_rs1 + io_imm; // @[PCUpdate.scala 29:28]
  wire [31:0] jalrTarget = _jalrTarget_T_1 & 32'hfffffffe; // @[PCUpdate.scala 29:38]
  wire  _branchTaken_T = io_aluResult == 32'h1; // @[PCUpdate.scala 36:37]
  wire  _branchTaken_T_3 = io_aluResult == 32'h0; // @[PCUpdate.scala 48:37]
  wire  _GEN_0 = 3'h7 == io_funct3 & _branchTaken_T_3; // @[PCUpdate.scala 34:24 56:21 31:32]
  wire  _GEN_1 = 3'h6 == io_funct3 ? _branchTaken_T : _GEN_0; // @[PCUpdate.scala 34:24 52:21]
  wire  _GEN_2 = 3'h5 == io_funct3 ? io_aluResult == 32'h0 : _GEN_1; // @[PCUpdate.scala 34:24 48:21]
  wire  _GEN_3 = 3'h4 == io_funct3 ? _branchTaken_T : _GEN_2; // @[PCUpdate.scala 34:24 44:21]
  wire  _GEN_4 = 3'h1 == io_funct3 ? _branchTaken_T : _GEN_3; // @[PCUpdate.scala 34:24 40:21]
  wire  _GEN_5 = 3'h0 == io_funct3 ? io_aluResult == 32'h1 : _GEN_4; // @[PCUpdate.scala 34:24 36:21]
  wire  branchTaken = io_branch & _GEN_5; // @[PCUpdate.scala 33:20 31:32]
  wire [31:0] _GEN_7 = branchTaken ? branchTarget : pcPlus4; // @[PCUpdate.scala 61:13 63:22 64:15]
  wire [31:0] _GEN_8 = io_jump ? branchTarget : _GEN_7; // @[PCUpdate.scala 67:18 68:15]
  assign io_nextPc = io_jalr ? jalrTarget : _GEN_8; // @[PCUpdate.scala 71:18 72:15]
endmodule
module Datapath(
  input         clock,
  input         reset,
  input  [31:0] io_instr,
  input  [31:0] io_pc,
  output [31:0] io_nextPc,
  output        io_memRead,
  output        io_memWrite,
  output [31:0] io_memAddr,
  output [31:0] io_memWdata,
  input  [31:0] io_memRdata,
  output [2:0]  io_memFunct3,
  output [31:0] io_writeBack,
  output [31:0] io_debugX1,
  output [31:0] io_debugX2,
  output [31:0] io_debugX3,
  output [31:0] io_debugX4,
  output [31:0] io_debugALU,
  output [31:0] io_debugImm
);
  wire [31:0] decoder_io_instr; // @[Datapath.scala 32:23]
  wire [4:0] decoder_io_rs1; // @[Datapath.scala 32:23]
  wire [4:0] decoder_io_rs2; // @[Datapath.scala 32:23]
  wire [4:0] decoder_io_rd; // @[Datapath.scala 32:23]
  wire [2:0] decoder_io_funct3; // @[Datapath.scala 32:23]
  wire [31:0] control_io_instr; // @[Datapath.scala 33:23]
  wire [3:0] control_io_aluOp; // @[Datapath.scala 33:23]
  wire  control_io_aluSrc; // @[Datapath.scala 33:23]
  wire  control_io_regWrite; // @[Datapath.scala 33:23]
  wire  control_io_memRead; // @[Datapath.scala 33:23]
  wire  control_io_memWrite; // @[Datapath.scala 33:23]
  wire  control_io_memToReg; // @[Datapath.scala 33:23]
  wire  control_io_branch; // @[Datapath.scala 33:23]
  wire  control_io_jump; // @[Datapath.scala 33:23]
  wire  control_io_jalr; // @[Datapath.scala 33:23]
  wire [31:0] immGen_io_instr; // @[Datapath.scala 34:23]
  wire [31:0] immGen_io_imm; // @[Datapath.scala 34:23]
  wire  regFile_clock; // @[Datapath.scala 35:23]
  wire  regFile_reset; // @[Datapath.scala 35:23]
  wire [4:0] regFile_io_rs1; // @[Datapath.scala 35:23]
  wire [4:0] regFile_io_rs2; // @[Datapath.scala 35:23]
  wire [4:0] regFile_io_rd; // @[Datapath.scala 35:23]
  wire [31:0] regFile_io_writeData; // @[Datapath.scala 35:23]
  wire  regFile_io_writeEnable; // @[Datapath.scala 35:23]
  wire [31:0] regFile_io_readData1; // @[Datapath.scala 35:23]
  wire [31:0] regFile_io_readData2; // @[Datapath.scala 35:23]
  wire [31:0] regFile_io_debugRead_1; // @[Datapath.scala 35:23]
  wire [31:0] regFile_io_debugRead_2; // @[Datapath.scala 35:23]
  wire [31:0] regFile_io_debugRead_3; // @[Datapath.scala 35:23]
  wire [31:0] regFile_io_debugRead_4; // @[Datapath.scala 35:23]
  wire [31:0] alu_io_a; // @[Datapath.scala 36:23]
  wire [31:0] alu_io_b; // @[Datapath.scala 36:23]
  wire [3:0] alu_io_op; // @[Datapath.scala 36:23]
  wire [31:0] alu_io_y; // @[Datapath.scala 36:23]
  wire [31:0] pcUpdate_io_pc; // @[Datapath.scala 37:24]
  wire [31:0] pcUpdate_io_rs1; // @[Datapath.scala 37:24]
  wire [31:0] pcUpdate_io_imm; // @[Datapath.scala 37:24]
  wire [2:0] pcUpdate_io_funct3; // @[Datapath.scala 37:24]
  wire  pcUpdate_io_branch; // @[Datapath.scala 37:24]
  wire  pcUpdate_io_jump; // @[Datapath.scala 37:24]
  wire  pcUpdate_io_jalr; // @[Datapath.scala 37:24]
  wire [31:0] pcUpdate_io_aluResult; // @[Datapath.scala 37:24]
  wire [31:0] pcUpdate_io_nextPc; // @[Datapath.scala 37:24]
  wire  _writeBackData_T = control_io_jump | control_io_jalr; // @[Datapath.scala 87:23]
  wire [31:0] _writeBackData_T_2 = io_pc + 32'h4; // @[Datapath.scala 88:13]
  wire [31:0] _writeBackData_T_3 = _writeBackData_T ? _writeBackData_T_2 : alu_io_y; // @[Datapath.scala 86:8]
  Decoder decoder ( // @[Datapath.scala 32:23]
    .io_instr(decoder_io_instr),
    .io_rs1(decoder_io_rs1),
    .io_rs2(decoder_io_rs2),
    .io_rd(decoder_io_rd),
    .io_funct3(decoder_io_funct3)
  );
  Control control ( // @[Datapath.scala 33:23]
    .io_instr(control_io_instr),
    .io_aluOp(control_io_aluOp),
    .io_aluSrc(control_io_aluSrc),
    .io_regWrite(control_io_regWrite),
    .io_memRead(control_io_memRead),
    .io_memWrite(control_io_memWrite),
    .io_memToReg(control_io_memToReg),
    .io_branch(control_io_branch),
    .io_jump(control_io_jump),
    .io_jalr(control_io_jalr)
  );
  ImmediateGenerator immGen ( // @[Datapath.scala 34:23]
    .io_instr(immGen_io_instr),
    .io_imm(immGen_io_imm)
  );
  RegisterFile regFile ( // @[Datapath.scala 35:23]
    .clock(regFile_clock),
    .reset(regFile_reset),
    .io_rs1(regFile_io_rs1),
    .io_rs2(regFile_io_rs2),
    .io_rd(regFile_io_rd),
    .io_writeData(regFile_io_writeData),
    .io_writeEnable(regFile_io_writeEnable),
    .io_readData1(regFile_io_readData1),
    .io_readData2(regFile_io_readData2),
    .io_debugRead_1(regFile_io_debugRead_1),
    .io_debugRead_2(regFile_io_debugRead_2),
    .io_debugRead_3(regFile_io_debugRead_3),
    .io_debugRead_4(regFile_io_debugRead_4)
  );
  ALU alu ( // @[Datapath.scala 36:23]
    .io_a(alu_io_a),
    .io_b(alu_io_b),
    .io_op(alu_io_op),
    .io_y(alu_io_y)
  );
  PCUpdate pcUpdate ( // @[Datapath.scala 37:24]
    .io_pc(pcUpdate_io_pc),
    .io_rs1(pcUpdate_io_rs1),
    .io_imm(pcUpdate_io_imm),
    .io_funct3(pcUpdate_io_funct3),
    .io_branch(pcUpdate_io_branch),
    .io_jump(pcUpdate_io_jump),
    .io_jalr(pcUpdate_io_jalr),
    .io_aluResult(pcUpdate_io_aluResult),
    .io_nextPc(pcUpdate_io_nextPc)
  );
  assign io_nextPc = pcUpdate_io_nextPc; // @[Datapath.scala 109:13]
  assign io_memRead = control_io_memRead; // @[Datapath.scala 73:16]
  assign io_memWrite = control_io_memWrite; // @[Datapath.scala 74:16]
  assign io_memAddr = alu_io_y; // @[Datapath.scala 75:16]
  assign io_memWdata = regFile_io_readData2; // @[Datapath.scala 76:16]
  assign io_memFunct3 = decoder_io_funct3; // @[Datapath.scala 77:16]
  assign io_writeBack = control_io_memToReg ? io_memRdata : _writeBackData_T_3; // @[Datapath.scala 83:26]
  assign io_debugX1 = regFile_io_debugRead_1; // @[Datapath.scala 117:14]
  assign io_debugX2 = regFile_io_debugRead_2; // @[Datapath.scala 118:14]
  assign io_debugX3 = regFile_io_debugRead_3; // @[Datapath.scala 119:14]
  assign io_debugX4 = regFile_io_debugRead_4; // @[Datapath.scala 120:14]
  assign io_debugALU = alu_io_y; // @[Datapath.scala 122:15]
  assign io_debugImm = immGen_io_imm; // @[Datapath.scala 123:15]
  assign decoder_io_instr = io_instr; // @[Datapath.scala 43:20]
  assign control_io_instr = io_instr; // @[Datapath.scala 44:20]
  assign immGen_io_instr = io_instr; // @[Datapath.scala 45:20]
  assign regFile_clock = clock;
  assign regFile_reset = reset;
  assign regFile_io_rs1 = decoder_io_rs1; // @[Datapath.scala 51:18]
  assign regFile_io_rs2 = decoder_io_rs2; // @[Datapath.scala 52:18]
  assign regFile_io_rd = decoder_io_rd; // @[Datapath.scala 53:18]
  assign regFile_io_writeData = control_io_memToReg ? io_memRdata : _writeBackData_T_3; // @[Datapath.scala 83:26]
  assign regFile_io_writeEnable = control_io_regWrite; // @[Datapath.scala 94:26]
  assign alu_io_a = regFile_io_readData1; // @[Datapath.scala 65:13]
  assign alu_io_b = control_io_aluSrc ? immGen_io_imm : regFile_io_readData2; // @[Datapath.scala 59:17]
  assign alu_io_op = control_io_aluOp; // @[Datapath.scala 67:13]
  assign pcUpdate_io_pc = io_pc; // @[Datapath.scala 100:25]
  assign pcUpdate_io_rs1 = regFile_io_readData1; // @[Datapath.scala 101:25]
  assign pcUpdate_io_imm = immGen_io_imm; // @[Datapath.scala 102:25]
  assign pcUpdate_io_funct3 = decoder_io_funct3; // @[Datapath.scala 103:25]
  assign pcUpdate_io_branch = control_io_branch; // @[Datapath.scala 104:25]
  assign pcUpdate_io_jump = control_io_jump; // @[Datapath.scala 105:25]
  assign pcUpdate_io_jalr = control_io_jalr; // @[Datapath.scala 106:25]
  assign pcUpdate_io_aluResult = alu_io_y; // @[Datapath.scala 107:25]
endmodule
module DataMemory(
  input         clock,
  input  [31:0] io_addr,
  input  [31:0] io_wdata,
  output [31:0] io_rdata,
  input         io_memRead,
  input         io_memWrite,
  input  [2:0]  io_funct3
);
`ifdef RANDOMIZE_MEM_INIT
  reg [31:0] _RAND_0;
`endif // RANDOMIZE_MEM_INIT
  reg [7:0] mem [0:1023]; // @[DataMemory.scala 18:16]
  wire  mem_byte0_en; // @[DataMemory.scala 18:16]
  wire [9:0] mem_byte0_addr; // @[DataMemory.scala 18:16]
  wire [7:0] mem_byte0_data; // @[DataMemory.scala 18:16]
  wire  mem_byte1_en; // @[DataMemory.scala 18:16]
  wire [9:0] mem_byte1_addr; // @[DataMemory.scala 18:16]
  wire [7:0] mem_byte1_data; // @[DataMemory.scala 18:16]
  wire  mem_byte2_en; // @[DataMemory.scala 18:16]
  wire [9:0] mem_byte2_addr; // @[DataMemory.scala 18:16]
  wire [7:0] mem_byte2_data; // @[DataMemory.scala 18:16]
  wire  mem_byte3_en; // @[DataMemory.scala 18:16]
  wire [9:0] mem_byte3_addr; // @[DataMemory.scala 18:16]
  wire [7:0] mem_byte3_data; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_1_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_1_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_1_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_1_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_2_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_2_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_2_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_2_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_3_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_3_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_3_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_3_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_4_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_4_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_4_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_4_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_5_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_5_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_5_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_5_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_6_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_6_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_6_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_6_en; // @[DataMemory.scala 18:16]
  wire [31:0] _byte1_T_1 = io_addr + 32'h1; // @[DataMemory.scala 21:27]
  wire [31:0] _byte2_T_1 = io_addr + 32'h2; // @[DataMemory.scala 22:27]
  wire [31:0] _byte3_T_1 = io_addr + 32'h3; // @[DataMemory.scala 23:27]
  wire [31:0] loadData = {mem_byte3_data,mem_byte2_data,mem_byte1_data,mem_byte0_data}; // @[Cat.scala 33:92]
  wire  _T = 3'h0 == io_funct3; // @[DataMemory.scala 30:23]
  wire [23:0] _io_rdata_T_2 = mem_byte0_data[7] ? 24'hffffff : 24'h0; // @[Bitwise.scala 77:12]
  wire [31:0] _io_rdata_T_3 = {_io_rdata_T_2,mem_byte0_data}; // @[Cat.scala 33:92]
  wire  _T_1 = 3'h1 == io_funct3; // @[DataMemory.scala 30:23]
  wire [15:0] _io_rdata_T_6 = mem_byte1_data[7] ? 16'hffff : 16'h0; // @[Bitwise.scala 77:12]
  wire [31:0] _io_rdata_T_7 = {_io_rdata_T_6,mem_byte1_data,mem_byte0_data}; // @[Cat.scala 33:92]
  wire  _T_2 = 3'h2 == io_funct3; // @[DataMemory.scala 30:23]
  wire [31:0] _io_rdata_T_8 = {24'h0,mem_byte0_data}; // @[Cat.scala 33:92]
  wire [31:0] _io_rdata_T_9 = {16'h0,mem_byte1_data,mem_byte0_data}; // @[Cat.scala 33:92]
  wire [31:0] _GEN_0 = 3'h5 == io_funct3 ? _io_rdata_T_9 : 32'h0; // @[DataMemory.scala 27:12 30:23 52:18]
  wire [31:0] _GEN_1 = 3'h4 == io_funct3 ? _io_rdata_T_8 : _GEN_0; // @[DataMemory.scala 30:23 48:18]
  wire [31:0] _GEN_2 = 3'h2 == io_funct3 ? loadData : _GEN_1; // @[DataMemory.scala 30:23 44:18]
  wire [31:0] _GEN_3 = 3'h1 == io_funct3 ? _io_rdata_T_7 : _GEN_2; // @[DataMemory.scala 30:23 36:18]
  wire [31:0] _GEN_4 = 3'h0 == io_funct3 ? _io_rdata_T_3 : _GEN_3; // @[DataMemory.scala 30:23 32:18]
  wire  _GEN_26 = _T_1 ? 1'h0 : _T_2; // @[DataMemory.scala 18:16 62:23]
  wire  _GEN_42 = _T ? 1'h0 : _T_1; // @[DataMemory.scala 18:16 62:23]
  wire  _GEN_49 = _T ? 1'h0 : _GEN_26; // @[DataMemory.scala 18:16 62:23]
  assign mem_byte0_en = 1'h1;
  assign mem_byte0_addr = io_addr[9:0];
  assign mem_byte0_data = mem[mem_byte0_addr]; // @[DataMemory.scala 18:16]
  assign mem_byte1_en = 1'h1;
  assign mem_byte1_addr = _byte1_T_1[9:0];
  assign mem_byte1_data = mem[mem_byte1_addr]; // @[DataMemory.scala 18:16]
  assign mem_byte2_en = 1'h1;
  assign mem_byte2_addr = _byte2_T_1[9:0];
  assign mem_byte2_data = mem[mem_byte2_addr]; // @[DataMemory.scala 18:16]
  assign mem_byte3_en = 1'h1;
  assign mem_byte3_addr = _byte3_T_1[9:0];
  assign mem_byte3_data = mem[mem_byte3_addr]; // @[DataMemory.scala 18:16]
  assign mem_MPORT_data = io_wdata[7:0];
  assign mem_MPORT_addr = io_addr[9:0];
  assign mem_MPORT_mask = 1'h1;
  assign mem_MPORT_en = io_memWrite & _T;
  assign mem_MPORT_1_data = io_wdata[7:0];
  assign mem_MPORT_1_addr = io_addr[9:0];
  assign mem_MPORT_1_mask = 1'h1;
  assign mem_MPORT_1_en = io_memWrite & _GEN_42;
  assign mem_MPORT_2_data = io_wdata[15:8];
  assign mem_MPORT_2_addr = _byte1_T_1[9:0];
  assign mem_MPORT_2_mask = 1'h1;
  assign mem_MPORT_2_en = io_memWrite & _GEN_42;
  assign mem_MPORT_3_data = io_wdata[7:0];
  assign mem_MPORT_3_addr = io_addr[9:0];
  assign mem_MPORT_3_mask = 1'h1;
  assign mem_MPORT_3_en = io_memWrite & _GEN_49;
  assign mem_MPORT_4_data = io_wdata[15:8];
  assign mem_MPORT_4_addr = _byte1_T_1[9:0];
  assign mem_MPORT_4_mask = 1'h1;
  assign mem_MPORT_4_en = io_memWrite & _GEN_49;
  assign mem_MPORT_5_data = io_wdata[23:16];
  assign mem_MPORT_5_addr = _byte2_T_1[9:0];
  assign mem_MPORT_5_mask = 1'h1;
  assign mem_MPORT_5_en = io_memWrite & _GEN_49;
  assign mem_MPORT_6_data = io_wdata[31:24];
  assign mem_MPORT_6_addr = _byte3_T_1[9:0];
  assign mem_MPORT_6_mask = 1'h1;
  assign mem_MPORT_6_en = io_memWrite & _GEN_49;
  assign io_rdata = io_memRead ? _GEN_4 : 32'h0; // @[DataMemory.scala 27:12 29:20]
  always @(posedge clock) begin
    if (mem_MPORT_en & mem_MPORT_mask) begin
      mem[mem_MPORT_addr] <= mem_MPORT_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_1_en & mem_MPORT_1_mask) begin
      mem[mem_MPORT_1_addr] <= mem_MPORT_1_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_2_en & mem_MPORT_2_mask) begin
      mem[mem_MPORT_2_addr] <= mem_MPORT_2_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_3_en & mem_MPORT_3_mask) begin
      mem[mem_MPORT_3_addr] <= mem_MPORT_3_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_4_en & mem_MPORT_4_mask) begin
      mem[mem_MPORT_4_addr] <= mem_MPORT_4_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_5_en & mem_MPORT_5_mask) begin
      mem[mem_MPORT_5_addr] <= mem_MPORT_5_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_6_en & mem_MPORT_6_mask) begin
      mem[mem_MPORT_6_addr] <= mem_MPORT_6_data; // @[DataMemory.scala 18:16]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_MEM_INIT
  _RAND_0 = {1{`RANDOM}};
  for (initvar = 0; initvar < 1024; initvar = initvar+1)
    mem[initvar] = _RAND_0[7:0];
`endif // RANDOMIZE_MEM_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module RV32ICore(
  input         clock,
  input         reset,
  output [31:0] io_pc,
  output [31:0] io_nextPc,
  output [31:0] io_writeBack,
  output [31:0] io_debugX1,
  output [31:0] io_debugX2,
  output [31:0] io_debugX3,
  output [31:0] io_debugX4,
  output [31:0] io_debugALU,
  output [31:0] io_debugImm
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
`endif // RANDOMIZE_REG_INIT
  wire  instructionMemory_clock; // @[RV32ICore.scala 24:33]
  wire [31:0] instructionMemory_io_addr; // @[RV32ICore.scala 24:33]
  wire [31:0] instructionMemory_io_instr; // @[RV32ICore.scala 24:33]
  wire  datapath_clock; // @[RV32ICore.scala 25:24]
  wire  datapath_reset; // @[RV32ICore.scala 25:24]
  wire [31:0] datapath_io_instr; // @[RV32ICore.scala 25:24]
  wire [31:0] datapath_io_pc; // @[RV32ICore.scala 25:24]
  wire [31:0] datapath_io_nextPc; // @[RV32ICore.scala 25:24]
  wire  datapath_io_memRead; // @[RV32ICore.scala 25:24]
  wire  datapath_io_memWrite; // @[RV32ICore.scala 25:24]
  wire [31:0] datapath_io_memAddr; // @[RV32ICore.scala 25:24]
  wire [31:0] datapath_io_memWdata; // @[RV32ICore.scala 25:24]
  wire [31:0] datapath_io_memRdata; // @[RV32ICore.scala 25:24]
  wire [2:0] datapath_io_memFunct3; // @[RV32ICore.scala 25:24]
  wire [31:0] datapath_io_writeBack; // @[RV32ICore.scala 25:24]
  wire [31:0] datapath_io_debugX1; // @[RV32ICore.scala 25:24]
  wire [31:0] datapath_io_debugX2; // @[RV32ICore.scala 25:24]
  wire [31:0] datapath_io_debugX3; // @[RV32ICore.scala 25:24]
  wire [31:0] datapath_io_debugX4; // @[RV32ICore.scala 25:24]
  wire [31:0] datapath_io_debugALU; // @[RV32ICore.scala 25:24]
  wire [31:0] datapath_io_debugImm; // @[RV32ICore.scala 25:24]
  wire  dataMemory_clock; // @[RV32ICore.scala 26:26]
  wire [31:0] dataMemory_io_addr; // @[RV32ICore.scala 26:26]
  wire [31:0] dataMemory_io_wdata; // @[RV32ICore.scala 26:26]
  wire [31:0] dataMemory_io_rdata; // @[RV32ICore.scala 26:26]
  wire  dataMemory_io_memRead; // @[RV32ICore.scala 26:26]
  wire  dataMemory_io_memWrite; // @[RV32ICore.scala 26:26]
  wire [2:0] dataMemory_io_funct3; // @[RV32ICore.scala 26:26]
  reg [31:0] pcReg; // @[RV32ICore.scala 22:22]
  InstructionMemory instructionMemory ( // @[RV32ICore.scala 24:33]
    .clock(instructionMemory_clock),
    .io_addr(instructionMemory_io_addr),
    .io_instr(instructionMemory_io_instr)
  );
  Datapath datapath ( // @[RV32ICore.scala 25:24]
    .clock(datapath_clock),
    .reset(datapath_reset),
    .io_instr(datapath_io_instr),
    .io_pc(datapath_io_pc),
    .io_nextPc(datapath_io_nextPc),
    .io_memRead(datapath_io_memRead),
    .io_memWrite(datapath_io_memWrite),
    .io_memAddr(datapath_io_memAddr),
    .io_memWdata(datapath_io_memWdata),
    .io_memRdata(datapath_io_memRdata),
    .io_memFunct3(datapath_io_memFunct3),
    .io_writeBack(datapath_io_writeBack),
    .io_debugX1(datapath_io_debugX1),
    .io_debugX2(datapath_io_debugX2),
    .io_debugX3(datapath_io_debugX3),
    .io_debugX4(datapath_io_debugX4),
    .io_debugALU(datapath_io_debugALU),
    .io_debugImm(datapath_io_debugImm)
  );
  DataMemory dataMemory ( // @[RV32ICore.scala 26:26]
    .clock(dataMemory_clock),
    .io_addr(dataMemory_io_addr),
    .io_wdata(dataMemory_io_wdata),
    .io_rdata(dataMemory_io_rdata),
    .io_memRead(dataMemory_io_memRead),
    .io_memWrite(dataMemory_io_memWrite),
    .io_funct3(dataMemory_io_funct3)
  );
  assign io_pc = pcReg; // @[RV32ICore.scala 43:9]
  assign io_nextPc = datapath_io_nextPc; // @[RV32ICore.scala 44:13]
  assign io_writeBack = datapath_io_writeBack; // @[RV32ICore.scala 46:16]
  assign io_debugX1 = datapath_io_debugX1; // @[RV32ICore.scala 48:14]
  assign io_debugX2 = datapath_io_debugX2; // @[RV32ICore.scala 49:14]
  assign io_debugX3 = datapath_io_debugX3; // @[RV32ICore.scala 50:14]
  assign io_debugX4 = datapath_io_debugX4; // @[RV32ICore.scala 51:14]
  assign io_debugALU = datapath_io_debugALU; // @[RV32ICore.scala 53:15]
  assign io_debugImm = datapath_io_debugImm; // @[RV32ICore.scala 54:15]
  assign instructionMemory_clock = clock;
  assign instructionMemory_io_addr = pcReg; // @[RV32ICore.scala 28:29]
  assign datapath_clock = clock;
  assign datapath_reset = reset;
  assign datapath_io_instr = instructionMemory_io_instr; // @[RV32ICore.scala 30:21]
  assign datapath_io_pc = pcReg; // @[RV32ICore.scala 31:18]
  assign datapath_io_memRdata = dataMemory_io_rdata; // @[RV32ICore.scala 39:24]
  assign dataMemory_clock = clock;
  assign dataMemory_io_addr = datapath_io_memAddr; // @[RV32ICore.scala 33:22]
  assign dataMemory_io_wdata = datapath_io_memWdata; // @[RV32ICore.scala 34:23]
  assign dataMemory_io_memRead = datapath_io_memRead; // @[RV32ICore.scala 35:25]
  assign dataMemory_io_memWrite = datapath_io_memWrite; // @[RV32ICore.scala 36:26]
  assign dataMemory_io_funct3 = datapath_io_memFunct3; // @[RV32ICore.scala 37:24]
  always @(posedge clock) begin
    if (reset) begin // @[RV32ICore.scala 22:22]
      pcReg <= 32'h0; // @[RV32ICore.scala 22:22]
    end else begin
      pcReg <= datapath_io_nextPc; // @[RV32ICore.scala 41:9]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  pcReg = _RAND_0[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
