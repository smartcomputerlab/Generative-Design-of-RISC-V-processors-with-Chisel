/home/bako/Book/lab3/generated/RV32ICore.InstructionMemory.mem.v
