package rv32i

import chisel3._
import chisel3.util._

class ImmediateGenerator(p: CoreParams) extends Module {
  val io = IO(new Bundle {
    val instr = Input(UInt(32.W))
    val imm   = Output(UInt(p.xlen.W))
  })

  val opcode = io.instr(6, 0)

  val iImm = Cat(
    Fill(20, io.instr(31)),
    io.instr(31, 20)
  )

  val sImm = Cat(
    Fill(20, io.instr(31)),
    io.instr(31, 25),
    io.instr(11, 7)
  )

  val bImm = Cat(
    Fill(19, io.instr(31)),
    io.instr(31),
    io.instr(7),
    io.instr(30, 25),
    io.instr(11, 8),
    0.U(1.W)
  )

  val uImm = Cat(
    io.instr(31, 12),
    0.U(12.W)
  )

  val jImm = Cat(
    Fill(11, io.instr(31)),
    io.instr(31),
    io.instr(19, 12),
    io.instr(20),
    io.instr(30, 21),
    0.U(1.W)
  )

  io.imm := 0.U

  switch(opcode) {

    is("b0000011".U) {
      io.imm := iImm
    }

    is("b0010011".U) {
      io.imm := iImm
    }

    is("b1100111".U) {
      io.imm := iImm
    }

    is("b0100011".U) {
      io.imm := sImm
    }

    is("b1100011".U) {
      io.imm := bImm
    }

    is("b0110111".U) {
      io.imm := uImm
    }

    is("b0010111".U) {
      io.imm := uImm
    }

    is("b1101111".U) {
      io.imm := jImm
    }
  }
}

