package rv32i

import chisel3._
import chisel3.util._

class PCUpdate(p: CoreParams) extends Module {

  val io = IO(new Bundle {
    val pc         = Input(UInt(p.xlen.W))
    val rs1        = Input(UInt(p.xlen.W))
    val imm        = Input(UInt(p.xlen.W))
    val funct3     = Input(UInt(3.W))

    val branch     = Input(Bool())
    val jump       = Input(Bool())
    val jalr       = Input(Bool())

    val aluResult  = Input(UInt(p.xlen.W))

    val nextPc     = Output(UInt(p.xlen.W))
  })

  val pcPlus4 = io.pc + 4.U

  val branchTarget = io.pc + io.imm

  val jalTarget = io.pc + io.imm

  val jalrTarget = (io.rs1 + io.imm) & (~1.U(p.xlen.W))

  val branchTaken = WireDefault(false.B)

  when (io.branch) {
    switch (io.funct3) {
      is("b000".U) {
        branchTaken := io.aluResult === 1.U
      }

      is("b001".U) {
        branchTaken := io.aluResult === 1.U
      }

      is("b100".U) {
        branchTaken := io.aluResult === 1.U
      }

      is("b101".U) {
        branchTaken := io.aluResult === 0.U
      }

      is("b110".U) {
        branchTaken := io.aluResult === 1.U
      }

      is("b111".U) {
        branchTaken := io.aluResult === 0.U
      }
    }
  }

  io.nextPc := pcPlus4

  when (branchTaken) {
    io.nextPc := branchTarget
  }

  when (io.jump) {
    io.nextPc := jalTarget
  }

  when (io.jalr) {
    io.nextPc := jalrTarget
  }
}

