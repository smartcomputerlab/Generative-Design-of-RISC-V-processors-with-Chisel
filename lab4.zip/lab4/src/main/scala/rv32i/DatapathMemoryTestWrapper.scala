package rv32i

import chisel3._

class DatapathMemoryTestWrapper(p: CoreParams) extends Module {

  val io = IO(new Bundle {
    val instr = Input(UInt(32.W))
    val pc    = Input(UInt(p.xlen.W))

    val nextPc = Output(UInt(p.xlen.W))

    val debugX1 = Output(UInt(p.xlen.W))
    val debugX2 = Output(UInt(p.xlen.W))
    val debugX3 = Output(UInt(p.xlen.W))
    val debugX4 = Output(UInt(p.xlen.W))

    val debugALU = Output(UInt(p.xlen.W))
    val debugImm = Output(UInt(p.xlen.W))
  })

  val datapath = Module(new Datapath(p))
  val memory   = Module(new DataMemory(p))

  datapath.io.instr := io.instr
  datapath.io.pc    := io.pc

  memory.io.addr     := datapath.io.memAddr
  memory.io.wdata    := datapath.io.memWdata
  memory.io.memRead  := datapath.io.memRead
  memory.io.memWrite := datapath.io.memWrite
  memory.io.funct3   := datapath.io.memFunct3

  datapath.io.memRdata := memory.io.rdata

  io.nextPc   := datapath.io.nextPc
  io.debugX1  := datapath.io.debugX1
  io.debugX2  := datapath.io.debugX2
  io.debugX3  := datapath.io.debugX3
  io.debugX4  := datapath.io.debugX4
  io.debugALU := datapath.io.debugALU
  io.debugImm := datapath.io.debugImm
}

