package rv32i

import chisel3._
import chisel3.util._

object ALUOp {
  val width = 5

  // RV32I operations
  val ADD  = 0.U(width.W)
  val SUB  = 1.U(width.W)
  val SLL  = 2.U(width.W)
  val SLT  = 3.U(width.W)
  val SLTU = 4.U(width.W)
  val XOR  = 5.U(width.W)
  val SRL  = 6.U(width.W)
  val SRA  = 7.U(width.W)
  val OR   = 8.U(width.W)
  val AND  = 9.U(width.W)

  // RV32M multiplication operations
  val MUL    = 10.U(width.W)
  val MULH   = 11.U(width.W)
  val MULHSU = 12.U(width.W)
  val MULHU  = 13.U(width.W)

  // Branch comparisons
  val EQ = 14.U(width.W)
  val NE = 15.U(width.W)

  // Invalid or unsupported operation
  val NOP = 31.U(width.W)
}


class ALU(p: CoreParams) extends Module {

  val io = IO(new Bundle {
    val a  = Input(UInt(p.xlen.W))
    val b  = Input(UInt(p.xlen.W))
    val op = Input(UInt(ALUOp.width.W))
    val y  = Output(UInt(p.xlen.W))
  })

  // ============================================================
  // Basic ALU operations
  // ============================================================

  val shamt = io.b(log2Ceil(p.xlen) - 1, 0)

  val signedA = io.a.asSInt
  val signedB = io.b.asSInt

  // ============================================================
  // Explicit 64-bit multiplication operands
  // ============================================================

  // Signed × signed
  val aSigned64 = Cat(
    Fill(32, io.a(31)),
    io.a
  ).asSInt

  val bSigned64 = Cat(
    Fill(32, io.b(31)),
    io.b
  ).asSInt

  // Unsigned × unsigned
  val aUnsigned64 = Cat(
    0.U(32.W),
    io.a
  )

  val bUnsigned64 = Cat(
    0.U(32.W),
    io.b
  )

  // Signed × unsigned.
  //
  // a is sign-extended and interpreted as signed.
  // b is zero-extended and interpreted as unsigned.
  //
  // Multiplication is performed using a 64-bit signed representation.
  val mulSS = aSigned64 * bSigned64

  val mulUU = aUnsigned64 * bUnsigned64

  val mulHSU = aSigned64 * bUnsigned64.asSInt

  // ============================================================
  // Extract RV32M results
  // ============================================================

  val mulLow   = mulSS(31, 0)
  val mulHighSS = mulSS(63, 32)
  val mulHighSU = mulHSU(63, 32)
  val mulHighUU = mulUU(63, 32)

  // ============================================================
  // Comparisons
  // ============================================================

  val equal    = io.a === io.b
  val notEqual = io.a =/= io.b

  // ============================================================
  // ALU result
  // ============================================================

  io.y := MuxLookup(io.op, 0.U, Seq(

    // RV32I
    ALUOp.ADD  -> (io.a + io.b),
    ALUOp.SUB  -> (io.a - io.b),
    ALUOp.SLL  -> (io.a << shamt),
    ALUOp.SLT  -> (signedA < signedB).asUInt,
    ALUOp.SLTU -> (io.a < io.b).asUInt,
    ALUOp.XOR  -> (io.a ^ io.b),
    ALUOp.SRL  -> (io.a >> shamt),
    ALUOp.SRA  -> (signedA >> shamt).asUInt,
    ALUOp.OR   -> (io.a | io.b),
    ALUOp.AND  -> (io.a & io.b),

    // RV32M
    ALUOp.MUL    -> mulLow,
    ALUOp.MULH   -> mulHighSS,
    ALUOp.MULHSU -> mulHighSU,
    ALUOp.MULHU  -> mulHighUU,

    // Branch comparisons
    ALUOp.EQ -> Mux(
      equal,
      1.U(p.xlen.W),
      0.U(p.xlen.W)
    ),

    ALUOp.NE -> Mux(
      notEqual,
      1.U(p.xlen.W),
      0.U(p.xlen.W)
    )
  ))
}

