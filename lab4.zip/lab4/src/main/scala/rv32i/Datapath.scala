package rv32i
import chisel3._
import chisel3.util._

class Datapath(p: CoreParams) extends Module {
  val io = IO(new Bundle {
    val instr = Input(UInt(32.W))
    val pc = Input(UInt(p.xlen.W))
    val nextPc = Output(UInt(p.xlen.W))

    val memRead = Output(Bool())
    val memWrite = Output(Bool())
    val memAddr = Output(UInt(p.xlen.W))
    val memWdata = Output(UInt(p.xlen.W))
    val memRdata = Input(UInt(p.xlen.W))
    val memFunct3 = Output(UInt(3.W))

    val writeBack = Output(UInt(p.xlen.W))
    val debugX1 = Output(UInt(p.xlen.W))
    val debugX2 = Output(UInt(p.xlen.W))
    val debugX3 = Output(UInt(p.xlen.W))
    val debugX4 = Output(UInt(p.xlen.W))
    val debugX5 = Output(UInt(p.xlen.W))
    val debugX6 = Output(UInt(p.xlen.W))
    val debugALU = Output(UInt(p.xlen.W))
    val debugImm = Output(UInt(p.xlen.W))
  })

  // Internal modules
  val decoder = Module(new Decoder)
  val control = Module(new Control)
  val immGen = Module(new ImmediateGenerator(p))
  val regFile = Module(new RegisterFile(p))
  val alu = Module(new ALU(p))
  val pcUpdate = Module(new PCUpdate(p))

  // Instruction decoding
  decoder.io.instr := io.instr
  immGen.io.instr := io.instr

  control.io.opcode := decoder.io.opcode
  control.io.funct3 := decoder.io.funct3
  control.io.funct7 := decoder.io.funct7

  // Register file
  regFile.io.rs1 := decoder.io.rs1
  regFile.io.rs2 := decoder.io.rs2
  regFile.io.rd := decoder.io.rd

  // ALU
  alu.io.a := regFile.io.readData1
  alu.io.b := Mux(
    control.io.aluSrc,
    immGen.io.imm,
    regFile.io.readData2
  )
  alu.io.op := control.io.aluOp

  // Data memory interface
  io.memRead := control.io.memRead
  io.memWrite := control.io.memWrite
  io.memAddr := alu.io.y
  io.memWdata := regFile.io.readData2
  io.memFunct3 := decoder.io.funct3

  // Write-back selection
  val wb = Mux(
    control.io.memToReg,
    io.memRdata,
    Mux(
      control.io.jump || control.io.jalr,
      io.pc + 4.U,
      alu.io.y
    )
  )

  regFile.io.writeData := wb
  regFile.io.writeEnable := control.io.regWrite

  // Program counter update
  pcUpdate.io.pc := io.pc
  pcUpdate.io.rs1 := regFile.io.readData1
  pcUpdate.io.imm := immGen.io.imm
  pcUpdate.io.funct3 := decoder.io.funct3
  pcUpdate.io.branch := control.io.branch
  pcUpdate.io.jump := control.io.jump
  pcUpdate.io.jalr := control.io.jalr
  pcUpdate.io.aluResult := alu.io.y

  io.nextPc := pcUpdate.io.nextPc

  // Write-back and debug outputs
  io.writeBack := wb
  io.debugX1 := regFile.io.debugRead(1)
  io.debugX2 := regFile.io.debugRead(2)
  io.debugX3 := regFile.io.debugRead(3)
  io.debugX4 := regFile.io.debugRead(4)
  io.debugX5 := regFile.io.debugRead(5)
  io.debugX6 := regFile.io.debugRead(6)
  io.debugALU := alu.io.y
  io.debugImm := immGen.io.imm
}

