package rv32i

import chisel3._

class RV32ICore(p: CoreParams) extends Module {

val io = IO(new Bundle {
// PC
val pc     = Output(UInt(p.xlen.W))
val nextPc = Output(UInt(p.xlen.W))

// Write-back
val writeBack = Output(UInt(p.xlen.W))

// Debug instruction
val debugInstr = Output(UInt(32.W))

// Debug registers
val debugX1 = Output(UInt(p.xlen.W))
val debugX2 = Output(UInt(p.xlen.W))
val debugX3 = Output(UInt(p.xlen.W))
val debugX4 = Output(UInt(p.xlen.W))
val debugX5 = Output(UInt(p.xlen.W))
val debugX6 = Output(UInt(p.xlen.W))

// Debug ALU / immediate
val debugALU = Output(UInt(p.xlen.W))
val debugImm = Output(UInt(p.xlen.W))

})

// ============================================================
// Program Counter
// ============================================================

val pcReg = RegInit(0.U(p.xlen.W))

// ============================================================
// Processor modules
// ============================================================

val instructionMemory = Module(new InstructionMemory(p))
val datapath          = Module(new Datapath(p))
val dataMemory        = Module(new DataMemory(p))

// ============================================================
// Instruction memory
// ============================================================

instructionMemory.io.addr := pcReg

datapath.io.instr := instructionMemory.io.instr
datapath.io.pc    := pcReg

// ============================================================
// Data memory
// ============================================================

dataMemory.io.addr     := datapath.io.memAddr
dataMemory.io.wdata    := datapath.io.memWdata
dataMemory.io.memRead  := datapath.io.memRead
dataMemory.io.memWrite := datapath.io.memWrite
dataMemory.io.funct3   := datapath.io.memFunct3

datapath.io.memRdata := dataMemory.io.rdata

// ============================================================
// PC register update
// ============================================================

pcReg := datapath.io.nextPc

// ============================================================
// Outputs
// ============================================================

io.pc        := pcReg
io.nextPc    := datapath.io.nextPc
io.writeBack := datapath.io.writeBack

// Debug instruction
io.debugInstr := instructionMemory.io.instr

// Debug registers
io.debugX1 := datapath.io.debugX1
io.debugX2 := datapath.io.debugX2
io.debugX3 := datapath.io.debugX3
io.debugX4 := datapath.io.debugX4
io.debugX5 := datapath.io.debugX5
io.debugX6 := datapath.io.debugX6

io.debugALU := datapath.io.debugALU
io.debugImm := datapath.io.debugImm
}

