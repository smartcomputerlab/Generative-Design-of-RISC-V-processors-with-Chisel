package rv32i

import chisel3._

class RV32IRICore(p: CoreParams) extends Module {

  val io = IO(new Bundle {
    val imemAddr = Output(UInt(p.xlen.W))
    val imemInst = Input(UInt(32.W))

    val debugPC = Output(UInt(p.xlen.W))
    val debugX1 = Output(UInt(p.xlen.W))
    val debugX2 = Output(UInt(p.xlen.W))
    val debugX3 = Output(UInt(p.xlen.W))
    val debugX4 = Output(UInt(p.xlen.W))
  })

  val pc = RegInit(0.U(p.xlen.W))

  val datapath = Module(new Datapath(p))

  datapath.io.instr := io.imemInst

  io.imemAddr := pc
  io.debugPC := pc

  io.debugX1 := datapath.io.debugX1
  io.debugX2 := datapath.io.debugX2
  io.debugX3 := datapath.io.debugX3
  io.debugX4 := datapath.io.debugX4

  pc := pc + 4.U
}

