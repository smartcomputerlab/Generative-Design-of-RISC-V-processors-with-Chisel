package rv32i

import chisel3._
import chisel3.util._

class DataMemory(params: CoreParams) extends Module {
  val io = IO(new Bundle {
    val addr  = Input(UInt(params.xlen.W))
    val wdata = Input(UInt(params.xlen.W))
    val rdata = Output(UInt(params.xlen.W))

    val memRead  = Input(Bool())
    val memWrite = Input(Bool())

    val funct3 = Input(UInt(3.W))
  })

  val mem = Mem(params.dataMemWords, UInt(8.W))

  val byte0 = mem(io.addr)
  val byte1 = mem(io.addr + 1.U)
  val byte2 = mem(io.addr + 2.U)
  val byte3 = mem(io.addr + 3.U)

  val loadData = Cat(byte3, byte2, byte1, byte0)

  io.rdata := 0.U

  when(io.memRead) {
    switch(io.funct3) {
      is("b000".U) { // LB
        io.rdata := Cat(Fill(24, byte0(7)), byte0)
      }

      is("b001".U) { // LH
        io.rdata := Cat(
          Fill(16, byte1(7)),
          byte1,
          byte0
        )
      }

      is("b010".U) { // LW
        io.rdata := loadData
      }

      is("b100".U) { // LBU
        io.rdata := Cat(0.U(24.W), byte0)
      }

      is("b101".U) { // LHU
        io.rdata := Cat(
          0.U(16.W),
          byte1,
          byte0
        )
      }
    }
  }

  when(io.memWrite) {
    switch(io.funct3) {
      is("b000".U) { // SB
        mem(io.addr) := io.wdata(7, 0)
      }

      is("b001".U) { // SH
        mem(io.addr)     := io.wdata(7, 0)
        mem(io.addr + 1.U) := io.wdata(15, 8)
      }

      is("b010".U) { // SW
        mem(io.addr)     := io.wdata(7, 0)
        mem(io.addr + 1.U) := io.wdata(15, 8)
        mem(io.addr + 2.U) := io.wdata(23, 16)
        mem(io.addr + 3.U) := io.wdata(31, 24)
      }
    }
  }
}

