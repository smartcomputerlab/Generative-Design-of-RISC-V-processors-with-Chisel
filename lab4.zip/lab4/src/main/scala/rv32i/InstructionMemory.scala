package rv32i

import chisel3._
import chisel3.util._
import chisel3.util.experimental.loadMemoryFromFileInline

class InstructionMemory(p: CoreParams) extends Module {

  val io = IO(new Bundle {
    val addr  = Input(UInt(p.xlen.W))
    val instr = Output(UInt(32.W))
  })

  // ============================================================
  // Instruction memory
  // ============================================================

  val mem = Mem(256, UInt(32.W))

  // Load instructions from memory.hex
  loadMemoryFromFileInline(
    mem,
    "memory.hex"
  )

  // Byte address -> word address
  val wordAddr = io.addr >> 2.U

  // Read instruction
  io.instr := Mux(
    wordAddr < 256.U,
    mem(wordAddr),
    0.U(32.W)
  )
}

