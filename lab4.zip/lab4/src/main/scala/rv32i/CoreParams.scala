package rv32i
case class CoreParams(
  xlen: Int = 32,
  numRegs: Int = 32,
  instrMemWords: Int = 1024,
  dataMemWords: Int = 1024
)

