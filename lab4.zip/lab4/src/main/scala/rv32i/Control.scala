package rv32i
import chisel3._
import chisel3.util._

class Control extends Module {
  val io = IO(new Bundle {
    val opcode   = Input(UInt(7.W))
    val funct3   = Input(UInt(3.W))
    val funct7   = Input(UInt(7.W))
    val valid    = Output(Bool())
    val aluOp    = Output(UInt(ALUOp.width.W))
    val aluSrc   = Output(Bool())
    val memRead  = Output(Bool())
    val memWrite = Output(Bool())
    val memToReg = Output(Bool())
    val regWrite = Output(Bool())
    val branch   = Output(Bool())
    val jump     = Output(Bool())
    val jalr     = Output(Bool())
  })

  val op = io.opcode
  val f3 = io.funct3
  val f7 = io.funct7

  // R-type and multiplication operations
  val rOp = MuxLookup(Cat(f7, f3), ALUOp.NOP, Seq(
    "b0000000000".U -> ALUOp.ADD,
    "b0100000000".U -> ALUOp.SUB,
    "b0000000001".U -> ALUOp.SLL,
    "b0000000010".U -> ALUOp.SLT,
    "b0000000011".U -> ALUOp.SLTU,
    "b0000000100".U -> ALUOp.XOR,
    "b0000000101".U -> ALUOp.SRL,
    "b0100000101".U -> ALUOp.SRA,
    "b0000000110".U -> ALUOp.OR,
    "b0000000111".U -> ALUOp.AND,
    "b0000001000".U -> ALUOp.MUL,
    "b0000001001".U -> ALUOp.MULH,
    "b0000001010".U -> ALUOp.MULHSU,
    "b0000001011".U -> ALUOp.MULHU
  ))

  // I-type operations
  val iOp = MuxLookup(f3, ALUOp.NOP, Seq(
    "b000".U -> ALUOp.ADD,
    "b010".U -> ALUOp.SLT,
    "b011".U -> ALUOp.SLTU,
    "b100".U -> ALUOp.XOR,
    "b110".U -> ALUOp.OR,
    "b111".U -> ALUOp.AND,
    "b001".U -> Mux(f7 === 0.U, ALUOp.SLL, ALUOp.NOP),
    "b101".U -> Mux(f7 === "b0100000".U, ALUOp.SRA,
                  Mux(f7 === 0.U, ALUOp.SRL, ALUOp.NOP))
  ))

  // Branch operations
  val bOp = MuxLookup(f3, ALUOp.NOP, Seq(
    "b000".U -> ALUOp.EQ,
    "b001".U -> ALUOp.NE,
    "b100".U -> ALUOp.SLT,
    "b101".U -> ALUOp.SLT,
    "b110".U -> ALUOp.SLTU,
    "b111".U -> ALUOp.SLTU
  ))

  // Default control signals
  io.valid := false.B
  io.aluOp := ALUOp.NOP
  io.aluSrc := false.B
  io.memRead := false.B
  io.memWrite := false.B
  io.memToReg := false.B
  io.regWrite := false.B
  io.branch := false.B
  io.jump := false.B
  io.jalr := false.B

  // Instruction control
  switch(op) {
    is("b0110011".U) {
      val validR = rOp =/= ALUOp.NOP
      io.aluOp := rOp
      io.valid := validR
      io.regWrite := validR
    }

    is("b0010011".U) {
      val validI = iOp =/= ALUOp.NOP
      io.aluOp := iOp
      io.aluSrc := true.B
      io.valid := validI
      io.regWrite := validI
    }

    is("b0000011".U) {
      io.valid := true.B
      io.aluOp := ALUOp.ADD
      io.aluSrc := true.B
      io.memRead := true.B
      io.memToReg := true.B
      io.regWrite := true.B
    }

    is("b0100011".U) {
      io.valid := true.B
      io.aluOp := ALUOp.ADD
      io.aluSrc := true.B
      io.memWrite := true.B
    }

    is("b1100011".U) {
      val validB = bOp =/= ALUOp.NOP
      io.aluOp := bOp
      io.valid := validB
      io.branch := validB
    }

    is("b1101111".U) {
      io.valid := true.B
      io.jump := true.B
      io.regWrite := true.B
    }

    is("b1100111".U) {
      io.valid := true.B
      io.jalr := true.B
      io.aluSrc := true.B
      io.aluOp := ALUOp.ADD
      io.regWrite := true.B
    }

    is("b0110111".U, "b0010111".U) {
      io.valid := true.B
      io.aluSrc := true.B
      io.aluOp := ALUOp.ADD
      io.regWrite := true.B
    }
  }
}

