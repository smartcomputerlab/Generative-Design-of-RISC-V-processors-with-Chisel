package rv32i

import chisel3.stage.ChiselStage

object GenerateRV32IRICore extends App {
  (new ChiselStage).emitVerilog(
    new RV32IRICore(CoreParams()),
    Array("--target-dir", "generated")
  )
}

