package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import chiseltest.simulator.VerilatorBackendAnnotation
import chiseltest.simulator.WriteVcdAnnotation

class ALUTest extends AnyFlatSpec with ChiselScalatestTester {

  behavior of "ALU"

  it should "execute MUL correctly with VCD enabled" in {

    test(new ALU(CoreParams()))
      .withAnnotations(
        Seq(
          VerilatorBackendAnnotation,
          WriteVcdAnnotation
        )
      ) { dut =>

        // MUL: 0xffffffff * 2 = 0xfffffffe (low 32 bits)
        dut.io.a.poke("hffffffff".U)
        dut.io.b.poke("h00000002".U)
        dut.io.op.poke(ALUOp.MUL)

        println("Testing MUL with VCD enabled...")

        dut.io.y.expect("hfffffffe".U)

        dut.clock.step()

        println(
          f"MUL result = 0x${dut.io.y.peek().litValue.toLong}%08x"
        )
      }
  }
}

