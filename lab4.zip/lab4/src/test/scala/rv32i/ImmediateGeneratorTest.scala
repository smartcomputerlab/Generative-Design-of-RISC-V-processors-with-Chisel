package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class ImmediateGeneratorTest
    extends AnyFlatSpec
    with ChiselScalatestTester {
  behavior of "ImmediateGenerator"
  it should "generate positive immediates" in {
    test(new ImmediateGenerator(CoreParams()))
      .withAnnotations(Seq(WriteVcdAnnotation)) { dut =>
      dut.io.instr.poke("h00500013".U)
      dut.io.imm.expect(5.U)
    }
  }
  it should "sign extend negative immediates" in {
    test(new ImmediateGenerator(CoreParams()))
      .withAnnotations(Seq(WriteVcdAnnotation)) { dut =>
      dut.io.instr.poke("hfff00013".U)
      dut.io.imm.expect("hffffffff".U)
    }
  }
}


