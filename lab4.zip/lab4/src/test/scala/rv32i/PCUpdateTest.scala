package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class PCUpdateTest extends AnyFlatSpec with ChiselScalatestTester {

behavior of "PCUpdate"

it should "handle sequential execution" in {
test(new PCUpdate(CoreParams())) { dut =>
  // Normal instruction: PC + 4
  dut.io.pc.poke("h00000000".U)
  dut.io.rs1.poke(0.U)
  dut.io.imm.poke(0.U)
  dut.io.funct3.poke(0.U)
  dut.io.branch.poke(false.B)
  dut.io.jump.poke(false.B)
  dut.io.jalr.poke(false.B)
  dut.io.aluResult.poke(0.U)

  dut.clock.step()

  dut.io.nextPc.expect("h00000004".U)
}
}

it should "calculate a taken BEQ target" in {
test(new PCUpdate(CoreParams())) { dut =>

  // BEQ x1, x2, +8
  // We don't need the actual register numbers here because
  // PCUpdate receives rs1/aluResult directly.
  dut.io.pc.poke("h00000010".U)
  dut.io.rs1.poke(5.U)
  dut.io.imm.poke("h00000008".U)
  dut.io.funct3.poke("b000".U) // BEQ
  dut.io.branch.poke(true.B)
  dut.io.jump.poke(false.B)
  dut.io.jalr.poke(false.B)

  // EQ result from the ALU
  dut.io.aluResult.poke(1.U)

  dut.clock.step()

  dut.io.nextPc.expect("h00000018".U)
}
}

it should "calculate a JAL target" in {
test(new PCUpdate(CoreParams())) { dut =>

  dut.io.pc.poke("h00000100".U)
  dut.io.rs1.poke(0.U)
  dut.io.imm.poke("h00000020".U)
  dut.io.funct3.poke(0.U)
  dut.io.branch.poke(false.B)
  dut.io.jump.poke(true.B)
  dut.io.jalr.poke(false.B)
  dut.io.aluResult.poke(0.U)

  dut.clock.step()

  dut.io.nextPc.expect("h00000120".U)
}

}

it should "calculate a JALR target" in {
test(new PCUpdate(CoreParams())) { dut =>

  // JALR target = (rs1 + imm) & ~1
  dut.io.pc.poke("h00000100".U)
  dut.io.rs1.poke("h00000201".U)
  dut.io.imm.poke("h00000010".U)
  dut.io.funct3.poke(0.U)
  dut.io.branch.poke(false.B)
  dut.io.jump.poke(false.B)
  dut.io.jalr.poke(true.B)
  dut.io.aluResult.poke(0.U)

  dut.clock.step()

  // 0x201 + 0x10 = 0x211, then clear bit 0
  dut.io.nextPc.expect("h00000210".U)
}
}
}

