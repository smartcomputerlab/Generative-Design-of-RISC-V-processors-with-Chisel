package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class ControlTest extends AnyFlatSpec with ChiselScalatestTester {

  behavior of "Control"

  it should "decode ADD instruction" in {
    test(new Control) { dut =>
      dut.io.opcode.poke("b0110011".U)
      dut.io.funct3.poke(0.U)
      dut.io.funct7.poke(0.U)

      dut.io.aluOp.expect(ALUOp.ADD)
      dut.io.valid.expect(true.B)
      dut.io.regWrite.expect(true.B)
    }
  }
}

