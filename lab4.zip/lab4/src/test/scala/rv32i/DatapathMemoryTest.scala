package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class DatapathMemoryTest extends AnyFlatSpec with ChiselScalatestTester {

  behavior of "Datapath and DataMemory"

  it should "execute sequential store and load tests" in {
    test(new DatapathMemoryTestWrapper(new CoreParams))
      .withAnnotations(Seq(WriteVcdAnnotation)) { dut =>

      dut.io.pc.poke(0.U)

      dut.io.instr.poke(RV32IEncoding.addi(1, 0, 100).U)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.addi(2, 0, 0x123).U)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.sw(2, 1, 0).U)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.lw(3, 1, 0).U)
      dut.clock.step()

      dut.io.debugX3.expect(0x123.U)

      dut.io.instr.poke(RV32IEncoding.addi(2, 0, 0x7f).U)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.sb(2, 1, 4).U)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.lb(3, 1, 4).U)
      dut.clock.step()

      dut.io.debugX3.expect(0x7f.U)

      dut.io.instr.poke(RV32IEncoding.addi(2, 0, 0x456).U)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.sh(2, 1, 8).U)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.lh(3, 1, 8).U)
      dut.clock.step()

      dut.io.debugX3.expect(0x456.U)

      dut.io.instr.poke(RV32IEncoding.addi(2, 0, 127).U)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.sb(2, 1, 12).U)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.lbu(3, 1, 12).U)
      dut.clock.step()

      dut.io.debugX3.expect(127.U)

      dut.io.instr.poke(RV32IEncoding.addi(2, 0, 0x7ff).U)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.sh(2, 1, 16).U)
      dut.clock.step()

      dut.io.instr.poke(RV32IEncoding.lhu(3, 1, 16).U)
      dut.clock.step()

      dut.io.debugX3.expect(0x7ff.U)

      dut.clock.step(2)
    }
  }
}

