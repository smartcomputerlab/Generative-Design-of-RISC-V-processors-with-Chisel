package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class RV32ICoreTest extends AnyFlatSpec with ChiselScalatestTester {

  behavior of "RV32ICore"

  it should "execute the program from memory.hex" in {

    test(new RV32ICore(CoreParams()))
      .withAnnotations(Seq(WriteVcdAnnotation)) { dut =>

      // Reset processor
      dut.reset.poke(true.B)
      dut.clock.step(2)
      dut.reset.poke(false.B)

      // Verify initial PC
      dut.io.pc.expect(0.U)

      println("\n===== RV32I Processor Simulation =====")

      // Execute 50 clock cycles
      for (cycle <- 0 until 50) {

        val pc     = dut.io.pc.peek().litValue
        val nextPc = dut.io.nextPc.peek().litValue
        val instr  = dut.io.debugInstr.peek().litValue

        val alu = dut.io.debugALU.peek().litValue
        val imm = dut.io.debugImm.peek().litValue
        val wb  = dut.io.writeBack.peek().litValue

        val x1 = dut.io.debugX1.peek().litValue
        val x2 = dut.io.debugX2.peek().litValue
        val x3 = dut.io.debugX3.peek().litValue
        val x4 = dut.io.debugX4.peek().litValue
        val x5 = dut.io.debugX5.peek().litValue
        val x6 = dut.io.debugX6.peek().litValue

        println(
          f"Cycle $cycle%2d | " +
          f"PC=0x$pc%08x | " +
          f"Instr=0x$instr%08x | " +
          f"NextPC=0x$nextPc%08x"
        )

        println(
          s"           ALU=$alu IMM=$imm WB=$wb"
        )

        println(
          s"           x1=$x1 x2=$x2 x3=$x3 " +
          s"x4=$x4 x5=$x5 x6=$x6"
        )

        // Advance processor
        dut.clock.step()

        // Verify PC update
        dut.io.pc.expect(nextPc.U)
      }

      println("\n===== Simulation Completed =====")
      println("VCD waveform generated.")
    }
  }
}

