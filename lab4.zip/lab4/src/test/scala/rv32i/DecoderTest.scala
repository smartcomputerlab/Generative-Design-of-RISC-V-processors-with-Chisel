package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class DecoderTest extends AnyFlatSpec with ChiselScalatestTester {

  behavior of "Decoder"

  def checkInstruction(
    dut: Decoder,
    instr: BigInt,
    opcode: Int,
    rd: Int,
    rs1: Int,
    rs2: Int,
    funct3: Int,
    funct7: Int
  ): Unit = {
    dut.io.instr.poke(instr.U)

    dut.io.opcode.expect(opcode.U)
    dut.io.rd.expect(rd.U)
    dut.io.rs1.expect(rs1.U)
    dut.io.rs2.expect(rs2.U)
    dut.io.funct3.expect(funct3.U)
    dut.io.funct7.expect(funct7.U)
  }

  it should "decode R-type instruction fields" in {
    test(new Decoder) { dut =>

      checkInstruction(
        dut, RV32IEncoding.add(1, 2, 3),
        0x33, 1, 2, 3, 0, 0
      )

      checkInstruction(
        dut, RV32IEncoding.sub(1, 2, 3),
        0x33, 1, 2, 3, 0, 0x20
      )

      checkInstruction(
        dut, RV32IEncoding.sll(1, 2, 3),
        0x33, 1, 2, 3, 1, 0
      )

      checkInstruction(
        dut, RV32IEncoding.slt(1, 2, 3),
        0x33, 1, 2, 3, 2, 0
      )

      checkInstruction(
        dut, RV32IEncoding.sltu(1, 2, 3),
        0x33, 1, 2, 3, 3, 0
      )

      checkInstruction(
        dut, RV32IEncoding.xor(1, 2, 3),
        0x33, 1, 2, 3, 4, 0
      )

      checkInstruction(
        dut, RV32IEncoding.srl(1, 2, 3),
        0x33, 1, 2, 3, 5, 0
      )

      checkInstruction(
        dut, RV32IEncoding.sra(1, 2, 3),
        0x33, 1, 2, 3, 5, 0x20
      )

      checkInstruction(
        dut, RV32IEncoding.or(1, 2, 3),
        0x33, 1, 2, 3, 6, 0
      )

      checkInstruction(
        dut, RV32IEncoding.and(1, 2, 3),
        0x33, 1, 2, 3, 7, 0
      )
    }
  }

  it should "decode I-type instruction fields" in {
    test(new Decoder) { dut =>

      checkInstruction(
        dut, RV32IEncoding.addi(1, 2, 10),
        0x13, 1, 2, 10, 0, 0
      )

      checkInstruction(
        dut, RV32IEncoding.andi(1, 2, 15),
        0x13, 1, 2, 15, 7, 0
      )

      checkInstruction(
        dut, RV32IEncoding.ori(1, 2, 5),
        0x13, 1, 2, 5, 6, 0
      )
    }
  }
}

