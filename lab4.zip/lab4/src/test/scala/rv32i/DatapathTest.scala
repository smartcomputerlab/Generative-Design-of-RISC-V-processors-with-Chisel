package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class DatapathTest
    extends AnyFlatSpec
    with ChiselScalatestTester {

  behavior of "Datapath"

  it should "execute R-type and I-type instructions sequentially" in {

    test(new Datapath(CoreParams()))
      .withAnnotations(Seq(WriteVcdAnnotation)) { dut =>

      dut.io.instr.poke(
        RV32IEncoding.addi(1, 0, 10).U
      )
      dut.clock.step()
      dut.io.debugX1.expect(10.U)

      dut.io.instr.poke(
        RV32IEncoding.addi(2, 0, 3).U
      )
      dut.clock.step()
      dut.io.debugX2.expect(3.U)

      dut.io.instr.poke(
        RV32IEncoding.add(3, 1, 2).U
      )
      dut.clock.step()
      dut.io.debugX3.expect(13.U)

      dut.io.instr.poke(
        RV32IEncoding.sub(4, 1, 2).U
      )
      dut.clock.step()
      dut.io.debugX4.expect(7.U)

      dut.io.instr.poke(
        RV32IEncoding.addi(3, 1, 5).U
      )
      dut.clock.step()
      dut.io.debugX3.expect(15.U)

      dut.io.instr.poke(
        RV32IEncoding.andi(4, 1, 3).U
      )
      dut.clock.step()
      dut.io.debugX4.expect(2.U)

      dut.io.instr.poke(
        RV32IEncoding.ori(3, 2, 8).U
      )
      dut.clock.step()
      dut.io.debugX3.expect(11.U)

      dut.io.instr.poke(
        RV32IEncoding.xori(4, 1, 3).U
      )
      dut.clock.step()
      dut.io.debugX4.expect(9.U)
    }
  }
}

