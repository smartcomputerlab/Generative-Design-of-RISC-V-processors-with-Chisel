package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class InstructionMemoryTest extends AnyFlatSpec with ChiselScalatestTester {

behavior of "InstructionMemory"

it should "fetch instructions sequentially" in {
test(new InstructionMemory(CoreParams())) { dut =>

  // Address 0 -> ADDI x1, x0, -1
  dut.io.addr.poke(0.U)
  dut.clock.step()
  dut.io.instr.expect("hfff00093".U)

  // Address 4 -> ADDI x2, x0, 2
  dut.io.addr.poke(4.U)
  dut.clock.step()
  dut.io.instr.expect("h00200113".U)

  // Address 8 -> MUL x3, x1, x2
  dut.io.addr.poke(8.U)
  dut.clock.step()
  dut.io.instr.expect("h022081b3".U)

  // Address 12 -> MULH x4, x1, x2
  dut.io.addr.poke(12.U)
  dut.clock.step()
  dut.io.instr.expect("h02209233".U)

  // Address 16 -> MULHSU x5, x1, x2
  dut.io.addr.poke(16.U)
  dut.clock.step()
  dut.io.instr.expect("h0220a2b3".U)

  // Address 20 -> MULHU x6, x1, x2
  dut.io.addr.poke(20.U)
  dut.clock.step()
  dut.io.instr.expect("h0220b333".U)

  // Address 24 -> JAL x0, 0
  dut.io.addr.poke(24.U)
  dut.clock.step()
  dut.io.instr.expect("h0000006f".U)
}
}
}

