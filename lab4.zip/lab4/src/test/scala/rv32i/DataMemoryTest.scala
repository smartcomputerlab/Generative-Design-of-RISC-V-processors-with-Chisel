package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class DataMemoryTest extends AnyFlatSpec with ChiselScalatestTester {

behavior of "DataMemory"

it should "store and load a word" in {
test(new DataMemory(CoreParams())) { dut =>

  // Store 0x12345678 at address 0
  dut.io.addr.poke(0.U)
  dut.io.wdata.poke("h12345678".U)
  dut.io.funct3.poke("b010".U) // SW
  dut.io.memRead.poke(false.B)
  dut.io.memWrite.poke(true.B)

  dut.clock.step()

  // Load the word back
  dut.io.addr.poke(0.U)
  dut.io.funct3.poke("b010".U) // LW
  dut.io.memRead.poke(true.B)
  dut.io.memWrite.poke(false.B)

  dut.io.rdata.expect("h12345678".U)
}
}

it should "store and load halfwords" in {
test(new DataMemory(CoreParams())) { dut =>

  // Store 0x1234 at address 4
  dut.io.addr.poke(4.U)
  dut.io.wdata.poke("h00001234".U)
  dut.io.funct3.poke("b001".U) // SH
  dut.io.memRead.poke(false.B)
  dut.io.memWrite.poke(true.B)

  dut.clock.step()

  // Signed halfword load
  dut.io.addr.poke(4.U)
  dut.io.funct3.poke("b001".U) // LH
  dut.io.memRead.poke(true.B)
  dut.io.memWrite.poke(false.B)

  dut.io.rdata.expect("h00001234".U)

  // Unsigned halfword load
  dut.io.funct3.poke("b101".U) // LHU
  dut.io.rdata.expect("h00001234".U)
}
}

it should "store and load bytes" in {
test(new DataMemory(CoreParams())) { dut =>

  // Store 0x80 at address 8
  dut.io.addr.poke(8.U)
  dut.io.wdata.poke("h00000080".U)
  dut.io.funct3.poke("b000".U) // SB
  dut.io.memRead.poke(false.B)
  dut.io.memWrite.poke(true.B)

  dut.clock.step()

  // Signed byte load: 0x80 -> 0xffffff80
  dut.io.addr.poke(8.U)
  dut.io.funct3.poke("b000".U) // LB
  dut.io.memRead.poke(true.B)
  dut.io.memWrite.poke(false.B)

  dut.io.rdata.expect("hffffff80".U)

  // Unsigned byte load: 0x80 -> 0x00000080
  dut.io.funct3.poke("b100".U) // LBU
  dut.io.rdata.expect("h00000080".U)
}
}
}

