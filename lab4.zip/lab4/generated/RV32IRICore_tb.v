`timescale 1ns/1ps

module RV32IRICore_tb;

  reg         clock = 0;
  reg         reset = 1;

  wire [31:0] io_imemAddr;
  reg  [31:0] io_imemInst;

  wire [31:0] io_debugPC;
  wire [31:0] io_debugX1;
  wire [31:0] io_debugX2;
  wire [31:0] io_debugX3;
  wire [31:0] io_debugX4;

  reg [31:0] mem [0:1023];

  RV32IRICore dut (
    .clock(clock),
    .reset(reset),
    .io_imemAddr(io_imemAddr),
    .io_imemInst(io_imemInst),
    .io_debugPC(io_debugPC),
    .io_debugX1(io_debugX1),
    .io_debugX2(io_debugX2),
    .io_debugX3(io_debugX3),
    .io_debugX4(io_debugX4)
  );

  always #5 clock = ~clock;

  always @(*) begin
    io_imemInst = mem[io_imemAddr[31:2]];
  end

  initial begin
    $readmemh("memory.hex", mem);

    $dumpfile("RV32IRICore.vcd");
    $dumpvars(0, RV32IRICore_tb);

    #20;
    reset = 0;

    #200;

    $finish;
  end

endmodule

