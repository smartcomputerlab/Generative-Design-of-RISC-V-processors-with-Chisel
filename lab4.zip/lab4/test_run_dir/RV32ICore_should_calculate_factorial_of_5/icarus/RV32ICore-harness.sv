module testbench;
  reg clock = 0;
  reg[0:0] reset = 0;
  wire[31:0] io_pc;
  wire[31:0] io_nextPc;
  wire[31:0] io_writeBack;
  wire[31:0] io_debugInstr;
  wire[31:0] io_debugX1;
  wire[31:0] io_debugX2;
  wire[31:0] io_debugX3;
  wire[31:0] io_debugX4;
  wire[31:0] io_debugX5;
  wire[31:0] io_debugX6;
  wire[31:0] io_debugALU;
  wire[31:0] io_debugImm;
  initial begin
    #`CLOCK_PERIOD; // Delay first clock edge to avoid race condition with randomization
    forever begin
      #`CLOCK_PERIOD clock = ~clock;
    end
  end
  reg [4095:0] dumpfile = 0;
  reg dumpon = 0;

  /*** DUT instantiation ***/
  RV32ICore RV32ICore(
    .clock(clock),
    .reset(reset),
    .io_pc(io_pc),
    .io_nextPc(io_nextPc),
    .io_writeBack(io_writeBack),
    .io_debugInstr(io_debugInstr),
    .io_debugX1(io_debugX1),
    .io_debugX2(io_debugX2),
    .io_debugX3(io_debugX3),
    .io_debugX4(io_debugX4),
    .io_debugX5(io_debugX5),
    .io_debugX6(io_debugX6),
    .io_debugALU(io_debugALU),
    .io_debugImm(io_debugImm)  );

  initial begin
    $init_ins(reset);
    $init_outs(io_pc, io_nextPc, io_writeBack, io_debugInstr, io_debugX1, io_debugX2, io_debugX3, io_debugX4, io_debugX5, io_debugX6, io_debugALU, io_debugImm);
    $init_sigs(RV32ICore);
    /*** Enable VCD dump ***/
    if ($value$plusargs("dumpfile=%s", dumpfile)) begin
      $dumpfile(dumpfile);
      $dumpvars(0, RV32ICore);
      /* exclude the startup from the wave dump */
      $dumpoff;
    end
  end

  always @(negedge clock)  begin
    if (dumpfile && !dumpon) begin
      dumpon = 1;
      $dumpon;
    end
    $tick();
    $dumpflush;
  end

endmodule
