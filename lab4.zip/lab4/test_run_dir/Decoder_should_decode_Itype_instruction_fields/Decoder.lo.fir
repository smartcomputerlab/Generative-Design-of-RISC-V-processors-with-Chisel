FIRRTL version 1.1.0
circuit Decoder :
  module Decoder :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    output io_opcode : UInt<7>
    output io_rs1 : UInt<5>
    output io_rs2 : UInt<5>
    output io_rd : UInt<5>
    output io_funct3 : UInt<3>
    output io_funct7 : UInt<7>

    node _io_opcode_T = bits(io_instr, 6, 0) @[Decoder.scala 15:24]
    node _io_rd_T = bits(io_instr, 11, 7) @[Decoder.scala 16:24]
    node _io_funct3_T = bits(io_instr, 14, 12) @[Decoder.scala 17:24]
    node _io_rs1_T = bits(io_instr, 19, 15) @[Decoder.scala 18:24]
    node _io_rs2_T = bits(io_instr, 24, 20) @[Decoder.scala 19:24]
    node _io_funct7_T = bits(io_instr, 31, 25) @[Decoder.scala 20:24]
    io_opcode <= _io_opcode_T @[Decoder.scala 15:13]
    io_rs1 <= _io_rs1_T @[Decoder.scala 18:13]
    io_rs2 <= _io_rs2_T @[Decoder.scala 19:13]
    io_rd <= _io_rd_T @[Decoder.scala 16:13]
    io_funct3 <= _io_funct3_T @[Decoder.scala 17:13]
    io_funct7 <= _io_funct7_T @[Decoder.scala 20:13]
