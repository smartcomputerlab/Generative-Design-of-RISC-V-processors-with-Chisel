`timescale 1ns/1ps

module RV32IRCore_tb;
  reg clock = 1'b0;
  reg reset = 1'b1;

  wire [31:0] debugPC;
  wire [31:0] debugX1;
  wire [31:0] debugX2;
  wire [31:0] debugX3;
  wire [31:0] debugX4;

  integer errors = 0;
  integer pc;

  // DUT: generate RV32ITestWrapper with memory.hex and initialRegs
  // x0=0, x1=10, x2=3, x3..x31=0 during Chisel elaboration.
  RV32ITestWrapper dut (
    .clock(clock),
    .reset(reset),
    .io_debugPC(debugPC),
    .io_debugX1(debugX1),
    .io_debugX2(debugX2),
    .io_debugX3(debugX3),
    .io_debugX4(debugX4)
  );

  // 100 MHz clock (10 ns period)
  always #5 clock = ~clock;

  task automatic check_value;
    input [255:0] label;
    input [31:0] actual;
    input [31:0] expected;
    begin
      if (actual !== expected) begin
        $display("FAIL %0s: expected=%0d, got=%0d at %0t", label, expected, actual, $time);
        errors = errors + 1;
      end else begin
        $display("PASS %0s: %0d", label, actual);
      end
    end
  endtask

  task automatic step_clock;
    begin
      @(posedge clock);
      #1; // Sample after nonblocking sequential updates
    end
  endtask

  initial begin
    $dumpfile("RV32IRCore.vcd");
    $dumpvars(0, RV32IRCore_tb);

    // Reset is assumed active-high and synchronous.
    repeat (5) @(negedge clock);
    reset = 1'b0;
    #1;

    check_value("Initial PC", debugPC, 32'd0);

    // ADD x3, x1, x2 => 10 + 3 = 13
    step_clock();
    check_value("PC after ADD", debugPC, 32'd4);
    check_value("ADD result x3", debugX3, 32'd13);

    // SUB x4, x1, x2 => 10 - 3 = 7
    step_clock();
    check_value("PC after SUB", debugPC, 32'd8);
    check_value("SUB result x4", debugX4, 32'd7);

    // Remaining 8 instructions: verify PC progression
    for (pc = 12; pc <= 40; pc = pc + 4) begin
      step_clock();
      check_value("PC", debugPC, pc);
    end

    if (errors == 0) begin
      $display("PASS: all RV32IRCoreTest checks passed");
    end else begin
      $display("FAIL: %0d checks failed", errors);
      $fatal(1, "RV32IRCore test failed");
    end
    $finish;
  end
endmodule

