FIRRTL version 1.1.0
circuit Decoder :
  module Decoder :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    output io_rs1 : UInt<5>
    output io_rs2 : UInt<5>
    output io_rd : UInt<5>
    output io_aluOp : UInt<4>
    output io_aluSrc : UInt<1>
    output io_regWrite : UInt<1>
    output io_valid : UInt<1>

    node opcode = bits(io_instr, 6, 0) @[Decoder.scala 26:24]
    node funct3 = bits(io_instr, 14, 12) @[Decoder.scala 27:24]
    node funct7 = bits(io_instr, 31, 25) @[Decoder.scala 28:24]
    node _io_rs1_T = bits(io_instr, 19, 15) @[Decoder.scala 30:21]
    node _io_rs2_T = bits(io_instr, 24, 20) @[Decoder.scala 31:21]
    node _io_rd_T = bits(io_instr, 11, 7) @[Decoder.scala 32:21]
    node _T = eq(opcode, UInt<6>("h33")) @[Decoder.scala 51:15]
    node _io_aluOp_T = cat(funct7, funct3) @[Cat.scala 33:92]
    node _io_aluOp_T_1 = eq(UInt<1>("h0"), _io_aluOp_T) @[Mux.scala 81:61]
    node _io_aluOp_T_2 = mux(_io_aluOp_T_1, UInt<4>("h0"), UInt<4>("hf")) @[Mux.scala 81:58]
    node _io_aluOp_T_3 = eq(UInt<9>("h100"), _io_aluOp_T) @[Mux.scala 81:61]
    node _io_aluOp_T_4 = mux(_io_aluOp_T_3, UInt<4>("h1"), _io_aluOp_T_2) @[Mux.scala 81:58]
    node _io_aluOp_T_5 = eq(UInt<1>("h1"), _io_aluOp_T) @[Mux.scala 81:61]
    node _io_aluOp_T_6 = mux(_io_aluOp_T_5, UInt<4>("h2"), _io_aluOp_T_4) @[Mux.scala 81:58]
    node _io_aluOp_T_7 = eq(UInt<2>("h2"), _io_aluOp_T) @[Mux.scala 81:61]
    node _io_aluOp_T_8 = mux(_io_aluOp_T_7, UInt<4>("h3"), _io_aluOp_T_6) @[Mux.scala 81:58]
    node _io_aluOp_T_9 = eq(UInt<2>("h3"), _io_aluOp_T) @[Mux.scala 81:61]
    node _io_aluOp_T_10 = mux(_io_aluOp_T_9, UInt<4>("h4"), _io_aluOp_T_8) @[Mux.scala 81:58]
    node _io_aluOp_T_11 = eq(UInt<3>("h4"), _io_aluOp_T) @[Mux.scala 81:61]
    node _io_aluOp_T_12 = mux(_io_aluOp_T_11, UInt<4>("h5"), _io_aluOp_T_10) @[Mux.scala 81:58]
    node _io_aluOp_T_13 = eq(UInt<3>("h5"), _io_aluOp_T) @[Mux.scala 81:61]
    node _io_aluOp_T_14 = mux(_io_aluOp_T_13, UInt<4>("h6"), _io_aluOp_T_12) @[Mux.scala 81:58]
    node _io_aluOp_T_15 = eq(UInt<9>("h105"), _io_aluOp_T) @[Mux.scala 81:61]
    node _io_aluOp_T_16 = mux(_io_aluOp_T_15, UInt<4>("h7"), _io_aluOp_T_14) @[Mux.scala 81:58]
    node _io_aluOp_T_17 = eq(UInt<3>("h6"), _io_aluOp_T) @[Mux.scala 81:61]
    node _io_aluOp_T_18 = mux(_io_aluOp_T_17, UInt<4>("h8"), _io_aluOp_T_16) @[Mux.scala 81:58]
    node _io_aluOp_T_19 = eq(UInt<3>("h7"), _io_aluOp_T) @[Mux.scala 81:61]
    node _io_aluOp_T_20 = mux(_io_aluOp_T_19, UInt<4>("h9"), _io_aluOp_T_18) @[Mux.scala 81:58]
    node _io_valid_T = neq(io_aluOp, UInt<4>("hf")) @[Decoder.scala 75:26]
    node _GEN_0 = mux(_T, _io_aluOp_T_20, UInt<4>("hf")) @[Decoder.scala 38:13 51:33 53:14]
    node _GEN_1 = mux(_T, _io_valid_T, UInt<1>("h0")) @[Decoder.scala 40:13 51:33 75:14]
    node _T_1 = eq(opcode, UInt<5>("h13")) @[Decoder.scala 87:15]
    node _io_aluOp_T_21 = eq(funct7, UInt<1>("h0")) @[Decoder.scala 117:18]
    node _io_aluOp_T_22 = mux(_io_aluOp_T_21, UInt<4>("h2"), UInt<4>("hf")) @[Decoder.scala 116:24]
    node _io_aluOp_T_23 = eq(funct7, UInt<1>("h0")) @[Decoder.scala 124:18]
    node _io_aluOp_T_24 = eq(funct7, UInt<6>("h20")) @[Decoder.scala 128:20]
    node _io_aluOp_T_25 = mux(_io_aluOp_T_24, UInt<4>("h7"), UInt<4>("hf")) @[Decoder.scala 127:14]
    node _io_aluOp_T_26 = mux(_io_aluOp_T_23, UInt<4>("h6"), _io_aluOp_T_25) @[Decoder.scala 123:24]
    node _io_aluOp_T_27 = eq(UInt<2>("h2"), funct3) @[Mux.scala 81:61]
    node _io_aluOp_T_28 = mux(_io_aluOp_T_27, UInt<4>("h3"), UInt<4>("h0")) @[Mux.scala 81:58]
    node _io_aluOp_T_29 = eq(UInt<2>("h3"), funct3) @[Mux.scala 81:61]
    node _io_aluOp_T_30 = mux(_io_aluOp_T_29, UInt<4>("h4"), _io_aluOp_T_28) @[Mux.scala 81:58]
    node _io_aluOp_T_31 = eq(UInt<3>("h4"), funct3) @[Mux.scala 81:61]
    node _io_aluOp_T_32 = mux(_io_aluOp_T_31, UInt<4>("h5"), _io_aluOp_T_30) @[Mux.scala 81:58]
    node _io_aluOp_T_33 = eq(UInt<3>("h6"), funct3) @[Mux.scala 81:61]
    node _io_aluOp_T_34 = mux(_io_aluOp_T_33, UInt<4>("h8"), _io_aluOp_T_32) @[Mux.scala 81:58]
    node _io_aluOp_T_35 = eq(UInt<3>("h7"), funct3) @[Mux.scala 81:61]
    node _io_aluOp_T_36 = mux(_io_aluOp_T_35, UInt<4>("h9"), _io_aluOp_T_34) @[Mux.scala 81:58]
    node _io_aluOp_T_37 = eq(UInt<1>("h1"), funct3) @[Mux.scala 81:61]
    node _io_aluOp_T_38 = mux(_io_aluOp_T_37, _io_aluOp_T_22, _io_aluOp_T_36) @[Mux.scala 81:58]
    node _io_aluOp_T_39 = eq(UInt<3>("h5"), funct3) @[Mux.scala 81:61]
    node _io_aluOp_T_40 = mux(_io_aluOp_T_39, _io_aluOp_T_26, _io_aluOp_T_38) @[Mux.scala 81:58]
    node _io_valid_T_1 = neq(io_aluOp, UInt<4>("hf")) @[Decoder.scala 136:26]
    node _GEN_2 = mux(_T_1, UInt<1>("h1"), UInt<1>("h0")) @[Decoder.scala 39:13 87:33 90:15]
    node _GEN_3 = mux(_T_1, _io_aluOp_T_40, _GEN_0) @[Decoder.scala 87:33 92:14]
    node _GEN_4 = mux(_T_1, _io_valid_T_1, _GEN_1) @[Decoder.scala 136:14 87:33]
    io_rs1 <= _io_rs1_T @[Decoder.scala 30:10]
    io_rs2 <= _io_rs2_T @[Decoder.scala 31:10]
    io_rd <= _io_rd_T @[Decoder.scala 32:10]
    io_aluOp <= _GEN_3
    io_aluSrc <= _GEN_2
    io_regWrite <= io_valid @[Decoder.scala 143:15]
    io_valid <= _GEN_4
