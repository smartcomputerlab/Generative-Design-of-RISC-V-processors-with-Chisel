FIRRTL version 1.1.0
circuit ALU :
  module ALU :
    input clock : Clock
    input reset : UInt<1>
    input io_a : UInt<32>
    input io_b : UInt<32>
    input io_op : UInt<4>
    output io_y : UInt<32>

    node shamt = bits(io_b, 4, 0) @[ALU.scala 27:19]
    node _io_y_T = add(io_a, io_b) @[ALU.scala 29:25]
    node _io_y_T_1 = tail(_io_y_T, 1) @[ALU.scala 29:25]
    node _io_y_T_2 = sub(io_a, io_b) @[ALU.scala 30:25]
    node _io_y_T_3 = tail(_io_y_T_2, 1) @[ALU.scala 30:25]
    node _io_y_T_4 = dshl(io_a, shamt) @[ALU.scala 31:25]
    node _io_y_T_5 = asSInt(io_a) @[ALU.scala 32:25]
    node _io_y_T_6 = asSInt(io_b) @[ALU.scala 32:39]
    node _io_y_T_7 = lt(_io_y_T_5, _io_y_T_6) @[ALU.scala 32:32]
    node _io_y_T_8 = lt(io_a, io_b) @[ALU.scala 33:25]
    node _io_y_T_9 = xor(io_a, io_b) @[ALU.scala 34:25]
    node _io_y_T_10 = dshr(io_a, shamt) @[ALU.scala 35:25]
    node _io_y_T_11 = asSInt(io_a) @[ALU.scala 36:25]
    node _io_y_T_12 = dshr(_io_y_T_11, shamt) @[ALU.scala 36:32]
    node _io_y_T_13 = asUInt(_io_y_T_12) @[ALU.scala 36:42]
    node _io_y_T_14 = or(io_a, io_b) @[ALU.scala 37:25]
    node _io_y_T_15 = and(io_a, io_b) @[ALU.scala 38:25]
    node _io_y_T_16 = eq(UInt<4>("h0"), io_op) @[Mux.scala 81:61]
    node _io_y_T_17 = mux(_io_y_T_16, _io_y_T_1, UInt<1>("h0")) @[Mux.scala 81:58]
    node _io_y_T_18 = eq(UInt<4>("h1"), io_op) @[Mux.scala 81:61]
    node _io_y_T_19 = mux(_io_y_T_18, _io_y_T_3, _io_y_T_17) @[Mux.scala 81:58]
    node _io_y_T_20 = eq(UInt<4>("h2"), io_op) @[Mux.scala 81:61]
    node _io_y_T_21 = mux(_io_y_T_20, _io_y_T_4, _io_y_T_19) @[Mux.scala 81:58]
    node _io_y_T_22 = eq(UInt<4>("h3"), io_op) @[Mux.scala 81:61]
    node _io_y_T_23 = mux(_io_y_T_22, _io_y_T_7, _io_y_T_21) @[Mux.scala 81:58]
    node _io_y_T_24 = eq(UInt<4>("h4"), io_op) @[Mux.scala 81:61]
    node _io_y_T_25 = mux(_io_y_T_24, _io_y_T_8, _io_y_T_23) @[Mux.scala 81:58]
    node _io_y_T_26 = eq(UInt<4>("h5"), io_op) @[Mux.scala 81:61]
    node _io_y_T_27 = mux(_io_y_T_26, _io_y_T_9, _io_y_T_25) @[Mux.scala 81:58]
    node _io_y_T_28 = eq(UInt<4>("h6"), io_op) @[Mux.scala 81:61]
    node _io_y_T_29 = mux(_io_y_T_28, _io_y_T_10, _io_y_T_27) @[Mux.scala 81:58]
    node _io_y_T_30 = eq(UInt<4>("h7"), io_op) @[Mux.scala 81:61]
    node _io_y_T_31 = mux(_io_y_T_30, _io_y_T_13, _io_y_T_29) @[Mux.scala 81:58]
    node _io_y_T_32 = eq(UInt<4>("h8"), io_op) @[Mux.scala 81:61]
    node _io_y_T_33 = mux(_io_y_T_32, _io_y_T_14, _io_y_T_31) @[Mux.scala 81:58]
    node _io_y_T_34 = eq(UInt<4>("h9"), io_op) @[Mux.scala 81:61]
    node _io_y_T_35 = mux(_io_y_T_34, _io_y_T_15, _io_y_T_33) @[Mux.scala 81:58]
    io_y <= bits(_io_y_T_35, 31, 0) @[ALU.scala 28:8]
