FIRRTL version 1.1.0
circuit Decoder :
  module Decoder :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    output io_rs1 : UInt<5>
    output io_rs2 : UInt<5>
    output io_rd : UInt<5>
    output io_aluOp : UInt<4>
    output io_regWrite : UInt<1>
    output io_valid : UInt<1>

    node opcode = bits(io_instr, 6, 0) @[Decoder.scala 15:24]
    node funct3 = bits(io_instr, 14, 12) @[Decoder.scala 16:24]
    node funct7 = bits(io_instr, 31, 25) @[Decoder.scala 17:24]
    node funct = cat(funct7, funct3) @[Cat.scala 33:92]
    node _io_rs1_T = bits(io_instr, 19, 15) @[Decoder.scala 19:21]
    node _io_rs2_T = bits(io_instr, 24, 20) @[Decoder.scala 20:21]
    node _io_rd_T = bits(io_instr, 11, 7) @[Decoder.scala 21:21]
    node _T = eq(opcode, UInt<6>("h33")) @[Decoder.scala 24:16]
    node _T_1 = eq(UInt<1>("h0"), funct) @[Decoder.scala 25:20]
    node _T_2 = eq(UInt<9>("h100"), funct) @[Decoder.scala 25:20]
    node _T_3 = eq(UInt<1>("h1"), funct) @[Decoder.scala 25:20]
    node _T_4 = eq(UInt<2>("h2"), funct) @[Decoder.scala 25:20]
    node _T_5 = eq(UInt<2>("h3"), funct) @[Decoder.scala 25:20]
    node _T_6 = eq(UInt<3>("h4"), funct) @[Decoder.scala 25:20]
    node _T_7 = eq(UInt<3>("h5"), funct) @[Decoder.scala 25:20]
    node _T_8 = eq(UInt<9>("h105"), funct) @[Decoder.scala 25:20]
    node _T_9 = eq(UInt<3>("h6"), funct) @[Decoder.scala 25:20]
    node _T_10 = eq(UInt<3>("h7"), funct) @[Decoder.scala 25:20]
    node _GEN_0 = mux(_T_10, UInt<4>("h9"), UInt<4>("hf")) @[Decoder.scala 22:12 25:20 35:39]
    node _GEN_1 = mux(_T_10, UInt<1>("h1"), UInt<1>("h0")) @[Decoder.scala 23:12 25:20 35:63]
    node _GEN_2 = mux(_T_9, UInt<4>("h8"), _GEN_0) @[Decoder.scala 25:20 34:39]
    node _GEN_3 = mux(_T_9, UInt<1>("h1"), _GEN_1) @[Decoder.scala 25:20 34:63]
    node _GEN_4 = mux(_T_8, UInt<4>("h7"), _GEN_2) @[Decoder.scala 25:20 33:39]
    node _GEN_5 = mux(_T_8, UInt<1>("h1"), _GEN_3) @[Decoder.scala 25:20 33:63]
    node _GEN_6 = mux(_T_7, UInt<4>("h6"), _GEN_4) @[Decoder.scala 25:20 32:39]
    node _GEN_7 = mux(_T_7, UInt<1>("h1"), _GEN_5) @[Decoder.scala 25:20 32:63]
    node _GEN_8 = mux(_T_6, UInt<4>("h5"), _GEN_6) @[Decoder.scala 25:20 31:39]
    node _GEN_9 = mux(_T_6, UInt<1>("h1"), _GEN_7) @[Decoder.scala 25:20 31:63]
    node _GEN_10 = mux(_T_5, UInt<4>("h4"), _GEN_8) @[Decoder.scala 25:20 30:39]
    node _GEN_11 = mux(_T_5, UInt<1>("h1"), _GEN_9) @[Decoder.scala 25:20 30:63]
    node _GEN_12 = mux(_T_4, UInt<4>("h3"), _GEN_10) @[Decoder.scala 25:20 29:39]
    node _GEN_13 = mux(_T_4, UInt<1>("h1"), _GEN_11) @[Decoder.scala 25:20 29:63]
    node _GEN_14 = mux(_T_3, UInt<4>("h2"), _GEN_12) @[Decoder.scala 25:20 28:39]
    node _GEN_15 = mux(_T_3, UInt<1>("h1"), _GEN_13) @[Decoder.scala 25:20 28:63]
    node _GEN_16 = mux(_T_2, UInt<4>("h1"), _GEN_14) @[Decoder.scala 25:20 27:39]
    node _GEN_17 = mux(_T_2, UInt<1>("h1"), _GEN_15) @[Decoder.scala 25:20 27:63]
    node _GEN_18 = mux(_T_1, UInt<4>("h0"), _GEN_16) @[Decoder.scala 25:20 26:39]
    node _GEN_19 = mux(_T_1, UInt<1>("h1"), _GEN_17) @[Decoder.scala 25:20 26:63]
    node _GEN_20 = mux(_T, _GEN_18, UInt<4>("hf")) @[Decoder.scala 22:12 24:34]
    node _GEN_21 = mux(_T, _GEN_19, UInt<1>("h0")) @[Decoder.scala 23:12 24:34]
    io_rs1 <= _io_rs1_T @[Decoder.scala 19:10]
    io_rs2 <= _io_rs2_T @[Decoder.scala 20:10]
    io_rd <= _io_rd_T @[Decoder.scala 21:10]
    io_aluOp <= _GEN_20
    io_regWrite <= io_valid @[Decoder.scala 38:15]
    io_valid <= _GEN_21
