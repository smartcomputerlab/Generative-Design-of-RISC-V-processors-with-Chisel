package rv32i

import chisel3._
import chisel3.util._

class Datapath(p: CoreParams) extends Module {

  val io = IO(new Bundle {

    // ============================================================
    // Inputs from IF/EX pipeline register
    // ============================================================

    // True when the IF/EX pipeline register contains
    // a real instruction.
    val valid = Input(Bool())

    val instr = Input(UInt(32.W))
    val pc    = Input(UInt(p.xlen.W))

    // PC calculated by the instruction in Stage 2
    val nextPc = Output(UInt(p.xlen.W))

    // ============================================================
    // Data memory interface
    // ============================================================

    val memRead   = Output(Bool())
    val memWrite  = Output(Bool())
    val memAddr   = Output(UInt(p.xlen.W))
    val memWdata  = Output(UInt(p.xlen.W))
    val memRdata  = Input(UInt(p.xlen.W))
    val memFunct3 = Output(UInt(3.W))

    // ============================================================
    // Write-back
    // ============================================================

    val writeBack = Output(UInt(p.xlen.W))

    // ============================================================
    // Debug register outputs
    // ============================================================

    val debugX1 = Output(UInt(p.xlen.W))
    val debugX2 = Output(UInt(p.xlen.W))
    val debugX3 = Output(UInt(p.xlen.W))
    val debugX4 = Output(UInt(p.xlen.W))
    val debugX5 = Output(UInt(p.xlen.W))
    val debugX6 = Output(UInt(p.xlen.W))

    // Debug ALU / immediate
    val debugALU = Output(UInt(p.xlen.W))
    val debugImm = Output(UInt(p.xlen.W))
  })

  // ============================================================
  // STAGE 2 MODULES
  //
  // The IF stage is implemented in RV32ICore.scala.
  //
  // This Datapath contains:
  //
  //   Decode
  //      |
  //      v
  //   Register File
  //      |
  //      v
  //   ALU / RV32M
  //      |
  //      v
  //   Data Memory interface
  //      |
  //      v
  //   Write Back
  //
  // PCUpdate also resolves branches / jumps in this stage.
  // ============================================================

  val decoder  = Module(new Decoder)
  val control  = Module(new Control)
  val immGen   = Module(new ImmediateGenerator(p))
  val regFile  = Module(new RegisterFile(p))
  val alu      = Module(new ALU(p))
  val pcUpdate = Module(new PCUpdate(p))

  // ============================================================
  // 1. INSTRUCTION DECODING
  // ============================================================
  //
  // io.instr is no longer the instruction directly coming from
  // InstructionMemory.
  //
  // It is the instruction stored in the IF/EX pipeline register.
  // ============================================================

  decoder.io.instr := io.instr
  control.io.instr := io.instr
  immGen.io.instr  := io.instr

  // ============================================================
  // 2. REGISTER FILE
  // ============================================================

  regFile.io.rs1 := decoder.io.rs1
  regFile.io.rs2 := decoder.io.rs2
  regFile.io.rd  := decoder.io.rd

  val rs1Data = regFile.io.readData1
  val rs2Data = regFile.io.readData2

  // ============================================================
  // 3. ALU INPUT B MULTIPLEXER
  // ============================================================
  //
  // R-type / RV32M:
  //
  //     ALU B = rs2
  //
  // I-type / load / store:
  //
  //     ALU B = immediate
  // ============================================================

  val aluB = Mux(
    control.io.aluSrc,
    immGen.io.imm,
    rs2Data
  )

  // ============================================================
  // 4. ALU / RV32M EXECUTION
  // ============================================================

  alu.io.a  := rs1Data
  alu.io.b  := aluB
  alu.io.op := control.io.aluOp

  // ============================================================
  // 5. DATA MEMORY INTERFACE
  // ============================================================
  //
  // Memory belongs logically to Stage 2.
  //
  // An invalid pipeline entry MUST NOT modify memory.
  // Therefore memWrite is qualified by io.valid.
  //
  // We also qualify memRead so bubbles don't generate meaningful
  // memory operations.
  // ============================================================

  io.memRead :=
    control.io.memRead && io.valid

  io.memWrite :=
    control.io.memWrite && io.valid

  io.memAddr := alu.io.y

  // Store data comes from rs2.
  io.memWdata := rs2Data

  io.memFunct3 := decoder.io.funct3

  // ============================================================
  // 6. WRITE-BACK MULTIPLEXER
  // ============================================================
  //
  //                    +----------------+
  // ALU result -------->|                |
  // Memory data ------->|   WB MUX       |----> Register File
  // PC + 4 ------------>|                |
  //                    +----------------+
  //
  // LOAD:
  //     writeBackData = memory data
  //
  // JAL / JALR:
  //     writeBackData = PC + 4
  //
  // ALU / MUL / DIV / REM:
  //     writeBackData = ALU result
  // ============================================================

  val writeBackData = Mux(
    control.io.memToReg,
    io.memRdata,
    Mux(
      control.io.jump || control.io.jalr,
      io.pc + 4.U,
      alu.io.y
    )
  )

  regFile.io.writeData := writeBackData

  // ============================================================
  // PIPELINE VALID CONTROL
  // ============================================================
  //
  // This is one of the most important changes from the
  // single-cycle datapath.
  //
  // A bubble or flushed instruction must NEVER write a register.
  // ============================================================

  regFile.io.writeEnable :=
    control.io.regWrite && io.valid

  // ============================================================
  // 7. PC UPDATE / BRANCH / JUMP RESOLUTION
  // ============================================================
  //
  // Branches and jumps are resolved in Stage 2.
  //
  // For an invalid pipeline entry, branch/jump controls are
  // forced low so a bubble cannot redirect the fetch PC.
  // ============================================================

  pcUpdate.io.pc := io.pc

  pcUpdate.io.rs1 := rs1Data

  pcUpdate.io.imm := immGen.io.imm

  pcUpdate.io.funct3 := decoder.io.funct3

  pcUpdate.io.branch :=
    control.io.branch && io.valid

  pcUpdate.io.jump :=
    control.io.jump && io.valid

  pcUpdate.io.jalr :=
    control.io.jalr && io.valid

  pcUpdate.io.aluResult := alu.io.y

  // ============================================================
  // NEXT PC
  // ============================================================
  //
  // If the IF/EX entry is invalid, simply report PC + 4.
  //
  // RV32ICore will use this value to determine whether the
  // instruction in Stage 2 redirected execution.
  // ============================================================

  io.nextPc := Mux(
    io.valid,
    pcUpdate.io.nextPc,
    io.pc + 4.U
  )

  // ============================================================
  // 8. OUTPUTS
  // ============================================================

  io.writeBack := Mux(
    io.valid,
    writeBackData,
    0.U
  )

  // ============================================================
  // DEBUG OUTPUTS
  // ============================================================

  io.debugX1 := regFile.io.debugRead(1)
  io.debugX2 := regFile.io.debugRead(2)
  io.debugX3 := regFile.io.debugRead(3)
  io.debugX4 := regFile.io.debugRead(4)
  io.debugX5 := regFile.io.debugRead(5)
  io.debugX6 := regFile.io.debugRead(6)

  io.debugALU := alu.io.y
  io.debugImm := immGen.io.imm
}

