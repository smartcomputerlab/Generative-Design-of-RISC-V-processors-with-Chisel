package rv32i

import chisel3._

class RV32IMCore(p: CoreParams) extends Module {

  val io = IO(new Bundle {

    // ==========================================================
    // PC
    // ==========================================================

    val pc     = Output(UInt(p.xlen.W))
    val nextPc = Output(UInt(p.xlen.W))

    // ==========================================================
    // Write-back
    // ==========================================================

    val writeBack = Output(UInt(p.xlen.W))

    // ==========================================================
    // Debug instruction
    // ==========================================================

    val debugInstr = Output(UInt(32.W))

    // ==========================================================
    // Debug registers
    // ==========================================================

    val debugX1 = Output(UInt(p.xlen.W))
    val debugX2 = Output(UInt(p.xlen.W))
    val debugX3 = Output(UInt(p.xlen.W))
    val debugX4 = Output(UInt(p.xlen.W))
    val debugX5 = Output(UInt(p.xlen.W))
    val debugX6 = Output(UInt(p.xlen.W))

    // ==========================================================
    // Debug ALU / immediate
    // ==========================================================

    val debugALU = Output(UInt(p.xlen.W))
    val debugImm = Output(UInt(p.xlen.W))

    // ==========================================================
    // Pipeline debug
    // ==========================================================

    val debugFetchPC = Output(UInt(p.xlen.W))
    val debugExecPC  = Output(UInt(p.xlen.W))

    val debugValid = Output(Bool())
    val debugFlush = Output(Bool())
  })

  // ============================================================
  // Processor modules
  // ============================================================

  val instructionMemory = Module(new InstructionMemory(p))
  val datapath          = Module(new Datapath(p))
  val dataMemory        = Module(new DataMemory(p))

  // ============================================================
  // STAGE 1
  //
  // Instruction Fetch
  //
  //              +-------------------+
  // PC --------->| InstructionMemory |
  //              +---------+---------+
  //                        |
  //                        | instruction
  //                        v
  //                   IF/EX register
  //
  // ============================================================


  // ============================================================
  // Program Counter
  // ============================================================

  val pcReg = RegInit(0.U(p.xlen.W))

  // Instruction memory is addressed by the FETCH PC.

  instructionMemory.io.addr := pcReg

  val fetchedInstr = instructionMemory.io.instr

  // Normal sequential fetch address.

  val sequentialPC = pcReg + 4.U


  // ============================================================
  // IF/EX PIPELINE REGISTER
  // ============================================================
  //
  // This is the pipeline boundary between:
  //
  //        Stage 1: IF
  //
  // and
  //
  //        Stage 2: EX/MEM/WB
  //
  // Information that must cross the boundary:
  //
  //        valid
  //        PC
  //        instruction
  //
  // ============================================================

  val ifexValid = RegInit(false.B)

  val ifexPC =
    RegInit(0.U(p.xlen.W))

  // RISC-V NOP:
  //
  //     addi x0, x0, 0
  //
  // Encoding:
  //
  //     0x00000013

  val NOP =
    "h00000013".U(32.W)

  val ifexInstr =
    RegInit(NOP)


  // ============================================================
  // STAGE 2
  //
  // Execute / Memory / Write-back
  // ============================================================
  //
  // IMPORTANT:
  //
  // Datapath no longer receives the instruction directly from
  // InstructionMemory.
  //
  // It receives the registered instruction and PC from IF/EX.
  //
  // ============================================================

  datapath.io.valid := ifexValid

  datapath.io.instr := ifexInstr

  datapath.io.pc := ifexPC


  // ============================================================
  // DATA MEMORY
  // ============================================================
  //
  // Data memory belongs to Stage 2.
  //
  // Datapath already qualifies memRead/memWrite using ifexValid.
  //
  // ============================================================

  dataMemory.io.addr :=
    datapath.io.memAddr

  dataMemory.io.wdata :=
    datapath.io.memWdata

  dataMemory.io.memRead :=
    datapath.io.memRead

  dataMemory.io.memWrite :=
    datapath.io.memWrite

  dataMemory.io.funct3 :=
    datapath.io.memFunct3

  datapath.io.memRdata :=
    dataMemory.io.rdata


  // ============================================================
  // BRANCH / JUMP REDIRECTION
  // ============================================================
  //
  // Stage 2 calculates nextPc.
  //
  // For an ordinary instruction:
  //
  //        nextPc = ifexPC + 4
  //
  // For:
  //
  //        taken branch
  //        JAL
  //        JALR
  //
  // nextPc is different from ifexPC + 4.
  //
  // Therefore we can detect a control-flow redirect by comparing
  // these two addresses.
  //
  // ============================================================

  val stage2SequentialPC =
    ifexPC + 4.U

  val redirect =
    ifexValid &&
    (datapath.io.nextPc =/= stage2SequentialPC)


  // ============================================================
  // FETCH PC UPDATE
  // ============================================================
  //
  // Normal execution:
  //
  //       PC <- PC + 4
  //
  // Taken branch / JAL / JALR:
  //
  //       PC <- Stage-2 target
  //
  // ============================================================

  when(redirect) {

    // Branch / jump target calculated by Stage 2.

    pcReg := datapath.io.nextPc

  }.otherwise {

    // Continue fetching sequentially.

    pcReg := sequentialPC
  }


  // ============================================================
  // IF/EX PIPELINE REGISTER UPDATE
  // ============================================================
  //
  // Normally:
  //
  //     IF instruction --> IF/EX
  //
  // But when Stage 2 redirects the PC, the instruction currently
  // being fetched belongs to the WRONG execution path.
  //
  // It must therefore be flushed.
  //
  // ============================================================

  when(redirect) {

    // ----------------------------------------------------------
    // FLUSH
    // ----------------------------------------------------------
    //
    // Convert the incorrectly fetched instruction into a bubble.
    //
    // ifexValid = false guarantees that:
    //
    //     no register write occurs
    //     no memory write occurs
    //     no branch/jump occurs
    //
    // ----------------------------------------------------------

    ifexValid := false.B

    ifexInstr := NOP

    ifexPC := 0.U

  }.otherwise {

    // ----------------------------------------------------------
    // NORMAL PIPELINE ADVANCE
    // ----------------------------------------------------------

    ifexValid := true.B

    ifexInstr := fetchedInstr

    ifexPC := pcReg
  }


  // ============================================================
  // TOP-LEVEL OUTPUTS
  // ============================================================

  // Current FETCH-stage PC.

  io.pc := pcReg


  // PC that will be used next.

  io.nextPc := Mux(
    redirect,
    datapath.io.nextPc,
    sequentialPC
  )


  // Stage-2 write-back value.

  io.writeBack := Mux(
    ifexValid,
    datapath.io.writeBack,
    0.U
  )


  // ============================================================
  // DEBUG INSTRUCTION
  // ============================================================
  //
  // Show the instruction currently executing in Stage 2 rather
  // than the instruction currently being fetched.
  //
  // This makes waveform/debug output much easier to understand.
  //
  // ============================================================

  io.debugInstr := ifexInstr


  // ============================================================
  // DEBUG REGISTERS
  // ============================================================

  io.debugX1 := datapath.io.debugX1
  io.debugX2 := datapath.io.debugX2
  io.debugX3 := datapath.io.debugX3
  io.debugX4 := datapath.io.debugX4
  io.debugX5 := datapath.io.debugX5
  io.debugX6 := datapath.io.debugX6


  // ============================================================
  // DEBUG ALU / IMMEDIATE
  // ============================================================

  io.debugALU := datapath.io.debugALU

  io.debugImm := datapath.io.debugImm


  // ============================================================
  // PIPELINE DEBUG
  // ============================================================

  // Stage 1 PC

  io.debugFetchPC := pcReg

  // Stage 2 PC

  io.debugExecPC := ifexPC

  // Is Stage 2 executing a real instruction?

  io.debugValid := ifexValid

  // Did Stage 2 cause a pipeline flush?

  io.debugFlush := redirect
}

