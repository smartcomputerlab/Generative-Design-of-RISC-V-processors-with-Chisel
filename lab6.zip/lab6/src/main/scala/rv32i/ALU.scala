package rv32i

import chisel3._
import chisel3.util._

object ALUOp {
  val width = 5

  // ============================================================
  // RV32I ALU operations
  // ============================================================
  val ADD  = 0.U(width.W)
  val SUB  = 1.U(width.W)
  val SLL  = 2.U(width.W)
  val SLT  = 3.U(width.W)
  val SLTU = 4.U(width.W)
  val XOR  = 5.U(width.W)
  val SRL  = 6.U(width.W)
  val SRA  = 7.U(width.W)
  val OR   = 8.U(width.W)
  val AND  = 9.U(width.W)

  // ============================================================
  // RV32M multiplication operations
  // ============================================================
  val MUL    = 10.U(width.W)
  val MULH   = 11.U(width.W)
  val MULHSU = 12.U(width.W)
  val MULHU  = 13.U(width.W)

  // ============================================================
  // Branch comparisons
  //
  // Keep these at their original values for compatibility.
  // ============================================================
  val EQ = 14.U(width.W)
  val NE = 15.U(width.W)

  // ============================================================
  // RV32M division / remainder operations
  // ============================================================
  val DIV  = 16.U(width.W)
  val DIVU = 17.U(width.W)
  val REM  = 18.U(width.W)
  val REMU = 19.U(width.W)

  // No separate NOP encoding
  val NOP = ADD
}

class ALU(p: CoreParams) extends Module {

  val io = IO(new Bundle {
    val a  = Input(UInt(p.xlen.W))
    val b  = Input(UInt(p.xlen.W))
    val op = Input(UInt(ALUOp.width.W))
    val y  = Output(UInt(p.xlen.W))
  })

  // ============================================================
  // Shift amount
  // ============================================================

  val shamt = io.b(log2Ceil(p.xlen) - 1, 0)

  // ============================================================
  // Signed operands
  // ============================================================

  val signedA = io.a.asSInt
  val signedB = io.b.asSInt

  // ============================================================
  // 64-bit multiplication operands
  // ============================================================

  val aSigned64 =
    Cat(Fill(32, io.a(31)), io.a).asSInt

  val bSigned64 =
    Cat(Fill(32, io.b(31)), io.b).asSInt

  val aUnsigned64 =
    Cat(0.U(32.W), io.a)

  val bUnsigned64 =
    Cat(0.U(32.W), io.b)

  // ============================================================
  // Multiplication
  // ============================================================

  val mulSS  = aSigned64 * bSigned64
  val mulUU  = aUnsigned64 * bUnsigned64
  val mulHSU = aSigned64 * bUnsigned64.asSInt

  val mulLow =
    mulSS(31, 0)

  val mulHighSS =
    mulSS(63, 32)

  val mulHighSU =
    mulHSU(63, 32)

  val mulHighUU =
    mulUU(63, 32)

  // ============================================================
  // Division / remainder
  //
  // RISC-V RV32M semantics:
  //
  // DIV:
  //   divide signed rs1 by signed rs2
  //
  // DIVU:
  //   divide unsigned rs1 by unsigned rs2
  //
  // REM:
  //   signed remainder
  //
  // REMU:
  //   unsigned remainder
  //
  // Divide by zero:
  //   DIV / DIVU -> 0xffffffff
  //   REM / REMU -> rs1
  //
  // Signed overflow:
  //   0x80000000 / 0xffffffff
  //       -> 0x80000000
  //
  //   0x80000000 % 0xffffffff
  //       -> 0
  // ============================================================

  val minInt  = "h80000000".U(32.W)
  val minusOne = "hffffffff".U(32.W)

  // ------------------------------------------------------------
  // DIV
  // ------------------------------------------------------------

  val divResult = Wire(UInt(p.xlen.W))

  when (io.b === 0.U) {
    // RISC-V: division by zero
    divResult := "hffffffff".U(32.W)
  } .elsewhen (
    (io.a === minInt) &&
    (io.b === minusOne)
  ) {
    // RISC-V signed division overflow
    divResult := minInt
  } .otherwise {
    divResult := (signedA / signedB).asUInt
  }

  // ------------------------------------------------------------
  // DIVU
  // ------------------------------------------------------------

  val divuResult = Wire(UInt(p.xlen.W))

  when (io.b === 0.U) {
    // RISC-V: unsigned division by zero
    divuResult := "hffffffff".U(32.W)
  } .otherwise {
    divuResult := io.a / io.b
  }

  // ------------------------------------------------------------
  // REM
  // ------------------------------------------------------------

  val remResult = Wire(UInt(p.xlen.W))

  when (io.b === 0.U) {
    // RISC-V: remainder by zero = rs1
    remResult := io.a
  } .elsewhen (
    (io.a === minInt) &&
    (io.b === minusOne)
  ) {
    // RISC-V signed overflow remainder
    remResult := 0.U
  } .otherwise {
    remResult := (signedA % signedB).asUInt
  }

  // ------------------------------------------------------------
  // REMU
  // ------------------------------------------------------------

  val remuResult = Wire(UInt(p.xlen.W))

  when (io.b === 0.U) {
    // RISC-V: unsigned remainder by zero = rs1
    remuResult := io.a
  } .otherwise {
    remuResult := io.a % io.b
  }

  // ============================================================
  // Branch comparisons
  // ============================================================

  val equal =
    io.a === io.b

  val notEqual =
    io.a =/= io.b

  // ============================================================
  // ALU operation selection
  // ============================================================

  io.y := MuxLookup(
    io.op,
    0.U(p.xlen.W),
    Seq(

      // --------------------------------------------------------
      // RV32I
      // --------------------------------------------------------

      ALUOp.ADD ->
        (io.a + io.b),

      ALUOp.SUB ->
        (io.a - io.b),

      ALUOp.SLL ->
        (io.a << shamt),

      ALUOp.SLT ->
        Mux(
          signedA < signedB,
          1.U(p.xlen.W),
          0.U(p.xlen.W)
        ),

      ALUOp.SLTU ->
        Mux(
          io.a < io.b,
          1.U(p.xlen.W),
          0.U(p.xlen.W)
        ),

      ALUOp.XOR ->
        (io.a ^ io.b),

      ALUOp.SRL ->
        (io.a >> shamt),

      ALUOp.SRA ->
        (signedA >> shamt).asUInt,

      ALUOp.OR ->
        (io.a | io.b),

      ALUOp.AND ->
        (io.a & io.b),

      // --------------------------------------------------------
      // RV32M multiplication
      // --------------------------------------------------------

      ALUOp.MUL ->
        mulLow,

      ALUOp.MULH ->
        mulHighSS,

      ALUOp.MULHSU ->
        mulHighSU,

      ALUOp.MULHU ->
        mulHighUU,

      // --------------------------------------------------------
      // Branch comparisons
      // --------------------------------------------------------

      ALUOp.EQ ->
        Mux(
          equal,
          1.U(p.xlen.W),
          0.U(p.xlen.W)
        ),

      ALUOp.NE ->
        Mux(
          notEqual,
          1.U(p.xlen.W),
          0.U(p.xlen.W)
        ),

      // --------------------------------------------------------
      // RV32M division / remainder
      // --------------------------------------------------------

      ALUOp.DIV ->
        divResult,

      ALUOp.DIVU ->
        divuResult,

      ALUOp.REM ->
        remResult,

      ALUOp.REMU ->
        remuResult
    )
  )
}

