package rv32i

import chisel3._
import chisel3.util._

class Decoder extends Module {

  val io = IO(new Bundle {
    val instr = Input(UInt(32.W))

    val rs1 = Output(UInt(5.W))
    val rs2 = Output(UInt(5.W))
    val rd  = Output(UInt(5.W))

    val funct3 = Output(UInt(3.W))
    val funct7 = Output(UInt(7.W))

    // Control signals expected by DecoderTest
    val aluSrc   = Output(Bool())
    val regWrite = Output(Bool())
    val valid    = Output(Bool())

    // ALU operation
    val aluOp = Output(UInt(ALUOp.width.W))
  })

  // ------------------------------------------------------------
  // Instruction fields
  // ------------------------------------------------------------

  val opcode = io.instr(6, 0)
  val funct3 = io.instr(14, 12)
  val funct7 = io.instr(31, 25)

  io.rs1    := io.instr(19, 15)
  io.rs2    := io.instr(24, 20)
  io.rd     := io.instr(11, 7)

  io.funct3 := funct3
  io.funct7 := funct7

  // ------------------------------------------------------------
  // Opcodes
  // ------------------------------------------------------------

  val R_TYPE = "b0110011".U
  val I_TYPE = "b0010011".U
  val LOAD   = "b0000011".U
  val STORE  = "b0100011".U
  val BRANCH = "b1100011".U
  val JAL    = "b1101111".U
  val JALR   = "b1100111".U
  val LUI    = "b0110111".U
  val AUIPC  = "b0010111".U

  // ------------------------------------------------------------
  // Defaults
  // ------------------------------------------------------------

  io.valid    := false.B
  io.aluSrc   := false.B
  io.regWrite := false.B

  // NOP is an alias for ADD in ALU.scala.
  // This is safe because the decoder only needs a defined
  // default ALU operation for instructions which don't use it.
  io.aluOp := ALUOp.NOP

  // ------------------------------------------------------------
  // Decode
  // ------------------------------------------------------------

  switch(opcode) {

    // ==========================================================
    // R-TYPE
    // ==========================================================

    is(R_TYPE) {
      io.valid    := true.B
      io.aluSrc   := false.B
      io.regWrite := true.B

      switch(funct3) {

        // ADD / SUB / MUL
        is("b000".U) {
          when(funct7 === "b0000001".U) {
            io.aluOp := ALUOp.MUL
          }.elsewhen(funct7 === "b0100000".U) {
            io.aluOp := ALUOp.SUB
          }.otherwise {
            io.aluOp := ALUOp.ADD
          }
        }

        // SLL / MULH
        is("b001".U) {
          when(funct7 === "b0000001".U) {
            io.aluOp := ALUOp.MULH
          }.otherwise {
            io.aluOp := ALUOp.SLL
          }
        }

        // SLT / MULHSU
        is("b010".U) {
          when(funct7 === "b0000001".U) {
            io.aluOp := ALUOp.MULHSU
          }.otherwise {
            io.aluOp := ALUOp.SLT
          }
        }

        // SLTU / MULHU
        is("b011".U) {
          when(funct7 === "b0000001".U) {
            io.aluOp := ALUOp.MULHU
          }.otherwise {
            io.aluOp := ALUOp.SLTU
          }
        }

        // XOR
        is("b100".U) {
          io.aluOp := ALUOp.XOR
        }

        // SRL / SRA
        is("b101".U) {
          when(funct7 === "b0100000".U) {
            io.aluOp := ALUOp.SRA
          }.otherwise {
            io.aluOp := ALUOp.SRL
          }
        }

        // OR
        is("b110".U) {
          io.aluOp := ALUOp.OR
        }

        // AND
        is("b111".U) {
          io.aluOp := ALUOp.AND
        }
      }
    }

    // ==========================================================
    // I-TYPE ALU
    // ==========================================================

    is(I_TYPE) {
      io.valid    := true.B
      io.aluSrc   := true.B
      io.regWrite := true.B

      switch(funct3) {

        // ADDI
        is("b000".U) {
          io.aluOp := ALUOp.ADD
        }

        // SLLI
        is("b001".U) {
          io.aluOp := ALUOp.SLL
        }

        // SLTI
        is("b010".U) {
          io.aluOp := ALUOp.SLT
        }

        // SLTIU
        is("b011".U) {
          io.aluOp := ALUOp.SLTU
        }

        // XORI
        is("b100".U) {
          io.aluOp := ALUOp.XOR
        }

        // SRLI / SRAI
        is("b101".U) {
          when(funct7 === "b0100000".U) {
            io.aluOp := ALUOp.SRA
          }.otherwise {
            io.aluOp := ALUOp.SRL
          }
        }

        // ORI
        is("b110".U) {
          io.aluOp := ALUOp.OR
        }

        // ANDI
        is("b111".U) {
          io.aluOp := ALUOp.AND
        }
      }
    }

    // ==========================================================
    // LOAD
    // ==========================================================

    is(LOAD) {
      io.valid    := true.B
      io.aluSrc   := true.B
      io.regWrite := true.B
      io.aluOp    := ALUOp.ADD
    }

    // ==========================================================
    // STORE
    // ==========================================================

    is(STORE) {
      io.valid    := true.B
      io.aluSrc   := true.B
      io.regWrite := false.B
      io.aluOp    := ALUOp.ADD
    }

    // ==========================================================
    // BRANCH
    // ==========================================================

    is(BRANCH) {
      io.valid    := true.B
      io.aluSrc   := false.B
      io.regWrite := false.B

      switch(funct3) {

        // BEQ
        is("b000".U) {
          io.aluOp := ALUOp.EQ
        }

        // BNE
        is("b001".U) {
          io.aluOp := ALUOp.NE
        }

        // BLT
        is("b100".U) {
          io.aluOp := ALUOp.SLT
        }

        // BGE
        is("b101".U) {
          io.aluOp := ALUOp.SLT
        }

        // BLTU
        is("b110".U) {
          io.aluOp := ALUOp.SLTU
        }

        // BGEU
        is("b111".U) {
          io.aluOp := ALUOp.SLTU
        }
      }
    }

    // ==========================================================
    // JAL
    // ==========================================================

    is(JAL) {
      io.valid    := true.B
      io.aluSrc   := false.B
      io.regWrite := true.B
      io.aluOp    := ALUOp.NOP
    }

    // ==========================================================
    // JALR
    // ==========================================================

    is(JALR) {
      io.valid    := true.B
      io.aluSrc   := true.B
      io.regWrite := true.B
      io.aluOp    := ALUOp.ADD
    }

    // ==========================================================
    // LUI
    // ==========================================================

    is(LUI) {
      io.valid    := true.B
      io.aluSrc   := true.B
      io.regWrite := true.B
      io.aluOp    := ALUOp.ADD
    }

    // ==========================================================
    // AUIPC
    // ==========================================================

    is(AUIPC) {
      io.valid    := true.B
      io.aluSrc   := true.B
      io.regWrite := true.B
      io.aluOp    := ALUOp.ADD
    }
  }
}
