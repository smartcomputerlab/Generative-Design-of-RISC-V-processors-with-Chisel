package rv32i

import chisel3._
import chisel3.util._

class Control extends Module {
  val io = IO(new Bundle {
    val instr = Input(UInt(32.W))

    val valid    = Output(Bool())

    val aluOp    = Output(UInt(ALUOp.width.W))
    val aluSrc   = Output(Bool())

    val memRead  = Output(Bool())
    val memWrite = Output(Bool())
    val memToReg = Output(Bool())

    val regWrite = Output(Bool())

    val branch   = Output(Bool())
    val jump     = Output(Bool())
    val jalr     = Output(Bool())
  })

  val opcode = io.instr(6, 0)
  val funct3 = io.instr(14, 12)
  val funct7 = io.instr(31, 25)

  // Opcodes
  val R_TYPE = "b0110011".U
  val I_TYPE = "b0010011".U
  val LOAD   = "b0000011".U
  val STORE  = "b0100011".U
  val BRANCH = "b1100011".U
  val JAL    = "b1101111".U
  val JALR   = "b1100111".U
  val LUI    = "b0110111".U
  val AUIPC  = "b0010111".U

  // Defaults
  io.valid    := false.B
  io.aluOp    := ALUOp.NOP
  io.aluSrc   := false.B

  io.memRead  := false.B
  io.memWrite := false.B
  io.memToReg := false.B

  io.regWrite := false.B

  io.branch   := false.B
  io.jump     := false.B
  io.jalr     := false.B

  switch(opcode) {

    // ============================================================
    // R-TYPE
    // ============================================================
    is(R_TYPE) {
      io.valid    := true.B
      io.aluSrc   := false.B
      io.regWrite := true.B

      switch(funct3) {

        // --------------------------------------------------------
        // ADD / SUB / MUL
        // --------------------------------------------------------
        is("b000".U) {
          when(funct7 === "b0000001".U) {
            io.aluOp := ALUOp.MUL
          }.elsewhen(funct7 === "b0100000".U) {
            io.aluOp := ALUOp.SUB
          }.otherwise {
            io.aluOp := ALUOp.ADD
          }
        }

        // --------------------------------------------------------
        // SLL / MULH
        // --------------------------------------------------------
        is("b001".U) {
          when(funct7 === "b0000001".U) {
            io.aluOp := ALUOp.MULH
          }.otherwise {
            io.aluOp := ALUOp.SLL
          }
        }

        // --------------------------------------------------------
        // SLT / MULHSU
        // --------------------------------------------------------
        is("b010".U) {
          when(funct7 === "b0000001".U) {
            io.aluOp := ALUOp.MULHSU
          }.otherwise {
            io.aluOp := ALUOp.SLT
          }
        }

        // --------------------------------------------------------
        // SLTU / MULHU
        // --------------------------------------------------------
        is("b011".U) {
          when(funct7 === "b0000001".U) {
            io.aluOp := ALUOp.MULHU
          }.otherwise {
            io.aluOp := ALUOp.SLTU
          }
        }

        // --------------------------------------------------------
        // XOR / DIV
        // --------------------------------------------------------
        is("b100".U) {
          when(funct7 === "b0000001".U) {
            io.aluOp := ALUOp.DIV
          }.otherwise {
            io.aluOp := ALUOp.XOR
          }
        }

        // --------------------------------------------------------
        // SRL / SRA / DIVU
        // --------------------------------------------------------
        is("b101".U) {
          when(funct7 === "b0000001".U) {
            io.aluOp := ALUOp.DIVU
          }.elsewhen(funct7 === "b0100000".U) {
            io.aluOp := ALUOp.SRA
          }.otherwise {
            io.aluOp := ALUOp.SRL
          }
        }

        // --------------------------------------------------------
        // OR / REM
        // --------------------------------------------------------
        is("b110".U) {
          when(funct7 === "b0000001".U) {
            io.aluOp := ALUOp.REM
          }.otherwise {
            io.aluOp := ALUOp.OR
          }
        }

        // --------------------------------------------------------
        // AND / REMU
        // --------------------------------------------------------
        is("b111".U) {
          when(funct7 === "b0000001".U) {
            io.aluOp := ALUOp.REMU
          }.otherwise {
            io.aluOp := ALUOp.AND
          }
        }
      }
    }

    // ============================================================
    // I-TYPE ALU
    // ============================================================
    is(I_TYPE) {
      io.valid    := true.B
      io.aluSrc   := true.B
      io.regWrite := true.B

      switch(funct3) {
        is("b000".U) {
          io.aluOp := ALUOp.ADD
        }

        is("b010".U) {
          io.aluOp := ALUOp.SLT
        }

        is("b011".U) {
          io.aluOp := ALUOp.SLTU
        }

        is("b100".U) {
          io.aluOp := ALUOp.XOR
        }

        is("b110".U) {
          io.aluOp := ALUOp.OR
        }

        is("b111".U) {
          io.aluOp := ALUOp.AND
        }

        is("b001".U) {
          io.aluOp := ALUOp.SLL
        }

        is("b101".U) {
          when(funct7 === "b0100000".U) {
            io.aluOp := ALUOp.SRA
          }.otherwise {
            io.aluOp := ALUOp.SRL
          }
        }
      }
    }

    // ============================================================
    // LOAD
    // ============================================================
    is(LOAD) {
      io.valid    := true.B
      io.aluSrc   := true.B
      io.aluOp    := ALUOp.ADD
      io.memRead  := true.B
      io.memToReg := true.B
      io.regWrite := true.B
    }

    // ============================================================
    // STORE
    // ============================================================
    is(STORE) {
      io.valid    := true.B
      io.aluSrc   := true.B
      io.aluOp    := ALUOp.ADD
      io.memWrite := true.B
    }

    // ============================================================
    // BRANCH
    // ============================================================
    is(BRANCH) {
      io.valid  := true.B
      io.branch := true.B
      io.aluSrc := false.B

      switch(funct3) {
        is("b000".U) {
          io.aluOp := ALUOp.EQ
        }

        is("b001".U) {
          io.aluOp := ALUOp.NE
        }

        is("b100".U) {
          io.aluOp := ALUOp.SLT
        }

        is("b101".U) {
          io.aluOp := ALUOp.SLT
        }

        is("b110".U) {
          io.aluOp := ALUOp.SLTU
        }

        is("b111".U) {
          io.aluOp := ALUOp.SLTU
        }
      }
    }

    // ============================================================
    // JAL
    // ============================================================
    is(JAL) {
      io.valid    := true.B
      io.jump     := true.B
      io.regWrite := true.B
    }

    // ============================================================
    // JALR
    // ============================================================
    is(JALR) {
      io.valid    := true.B
      io.jalr     := true.B
      io.regWrite := true.B
      io.aluSrc   := true.B
      io.aluOp    := ALUOp.ADD
    }

    // ============================================================
    // LUI
    // ============================================================
    is(LUI) {
      io.valid    := true.B
      io.aluSrc   := true.B
      io.aluOp    := ALUOp.ADD
      io.regWrite := true.B
    }

    // ============================================================
    // AUIPC
    // ============================================================
    is(AUIPC) {
      io.valid    := true.B
      io.aluSrc   := true.B
      io.aluOp    := ALUOp.ADD
      io.regWrite := true.B
    }
  }
}

