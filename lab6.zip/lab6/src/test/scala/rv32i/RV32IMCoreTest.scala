package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class RV32IMCoreTest extends AnyFlatSpec with ChiselScalatestTester {

  behavior of "RV32ICore 2-Stage Pipeline"

  it should "calculate factorial of 5 using RV32IM MUL" in {

    test(new RV32IMCore(CoreParams()))
      .withAnnotations(Seq(WriteVcdAnnotation)) { dut =>

      // ========================================================
      // Reset
      // ========================================================

      dut.reset.poke(true.B)
      dut.clock.step(2)
      dut.reset.poke(false.B)

      println()
      println("============================================================")
      println(" RV32IM 2-STAGE PIPELINE - FACTORIAL(5)")
      println("============================================================")
      println(
        "Cycle | FetchPC   | ExecPC    | Valid | Flush | " +
        "Instr      | x1 | x2  | ALU"
      )
      println(
        "------------------------------------------------------------"
      )

      // ========================================================
      // Execute program
      // ========================================================

      for (cycle <- 0 until 50) {

        val fetchPC =
          dut.io.debugFetchPC.peek().litValue

        val execPC =
          dut.io.debugExecPC.peek().litValue

        val instr =
          dut.io.debugInstr.peek().litValue

        val valid =
          dut.io.debugValid.peek().litToBoolean

        val flush =
          dut.io.debugFlush.peek().litToBoolean

        val x1 =
          dut.io.debugX1.peek().litValue

        val x2 =
          dut.io.debugX2.peek().litValue

        val alu =
          dut.io.debugALU.peek().litValue

        println(
          f"$cycle%5d | " +
          f"0x$fetchPC%08x | " +
          f"0x$execPC%08x | " +
          f"$valid%5s | " +
          f"$flush%5s | " +
          f"0x$instr%08x | " +
          f"$x1%2d | " +
          f"$x2%3d | " +
          f"0x$alu%08x"
        )

        dut.clock.step()
      }

      // ========================================================
      // Final result
      // ========================================================

      println()
      println("============================================================")
      println(" FINAL RESULTS")
      println("============================================================")

      println(
        s"x1 = ${dut.io.debugX1.peek().litValue} (expected 0)"
      )

      println(
        s"x2 = ${dut.io.debugX2.peek().litValue} (expected 120)"
      )

      // ========================================================
      // Assertions
      // ========================================================

      dut.io.debugX1.expect(
        0.U,
        "Loop counter x1 should be zero"
      )

      dut.io.debugX2.expect(
        120.U,
        "Factorial failed: expected 5! = 120"
      )

      println()
      println("FACTORIAL(5) PASSED")
      println("============================================================")
    }
  }
}

