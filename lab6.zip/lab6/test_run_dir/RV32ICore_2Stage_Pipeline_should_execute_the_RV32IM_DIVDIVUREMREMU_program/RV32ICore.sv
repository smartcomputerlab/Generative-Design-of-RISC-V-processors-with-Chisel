module InstructionMemory(
  input         clock,
  input  [31:0] io_addr,
  output [31:0] io_instr
);
  reg [31:0] mem [0:255]; // @[InstructionMemory.scala 18:16]
  wire  mem_io_instr_MPORT_en; // @[InstructionMemory.scala 18:16]
  wire [7:0] mem_io_instr_MPORT_addr; // @[InstructionMemory.scala 18:16]
  wire [31:0] mem_io_instr_MPORT_data; // @[InstructionMemory.scala 18:16]
  wire [31:0] wordAddr = {{2'd0}, io_addr[31:2]}; // @[InstructionMemory.scala 27:26]
  wire  _io_instr_T = wordAddr < 32'h100; // @[InstructionMemory.scala 31:14]
  assign mem_io_instr_MPORT_en = 1'h1;
  assign mem_io_instr_MPORT_addr = wordAddr[7:0];
  assign mem_io_instr_MPORT_data = mem[mem_io_instr_MPORT_addr]; // @[InstructionMemory.scala 18:16]
  assign io_instr = _io_instr_T ? mem_io_instr_MPORT_data : 32'h0; // @[InstructionMemory.scala 30:18]
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
  integer initvar;
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
  `endif // RANDOMIZE
  $readmemh("memory.hex", mem);
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module Decoder(
  input  [31:0] io_instr,
  output [4:0]  io_rs1,
  output [4:0]  io_rs2,
  output [4:0]  io_rd,
  output [2:0]  io_funct3
);
  assign io_rs1 = io_instr[19:15]; // @[Decoder.scala 35:24]
  assign io_rs2 = io_instr[24:20]; // @[Decoder.scala 36:24]
  assign io_rd = io_instr[11:7]; // @[Decoder.scala 37:24]
  assign io_funct3 = io_instr[14:12]; // @[Decoder.scala 32:24]
endmodule
module Control(
  input  [31:0] io_instr,
  output [4:0]  io_aluOp,
  output        io_aluSrc,
  output        io_memRead,
  output        io_memWrite,
  output        io_memToReg,
  output        io_regWrite,
  output        io_branch,
  output        io_jump,
  output        io_jalr
);
  wire [6:0] opcode = io_instr[6:0]; // @[Control.scala 26:24]
  wire [2:0] funct3 = io_instr[14:12]; // @[Control.scala 27:24]
  wire [6:0] funct7 = io_instr[31:25]; // @[Control.scala 28:24]
  wire  _T_1 = 3'h0 == funct3; // @[Control.scala 66:22]
  wire  _T_2 = funct7 == 7'h1; // @[Control.scala 72:23]
  wire  _T_3 = funct7 == 7'h20; // @[Control.scala 74:29]
  wire [4:0] _GEN_0 = funct7 == 7'h20 ? 5'h1 : 5'h0; // @[Control.scala 74:47 75:22 77:22]
  wire [4:0] _GEN_1 = funct7 == 7'h1 ? 5'ha : _GEN_0; // @[Control.scala 72:41 73:22]
  wire  _T_4 = 3'h1 == funct3; // @[Control.scala 66:22]
  wire [4:0] _GEN_2 = _T_2 ? 5'hb : 5'h2; // @[Control.scala 85:41 86:22 88:22]
  wire  _T_6 = 3'h2 == funct3; // @[Control.scala 66:22]
  wire [4:0] _GEN_3 = _T_2 ? 5'hc : 5'h3; // @[Control.scala 96:41 97:22 99:22]
  wire  _T_8 = 3'h3 == funct3; // @[Control.scala 66:22]
  wire [4:0] _GEN_4 = _T_2 ? 5'hd : 5'h4; // @[Control.scala 107:41 108:22 110:22]
  wire  _T_10 = 3'h4 == funct3; // @[Control.scala 66:22]
  wire [4:0] _GEN_5 = _T_2 ? 5'h10 : 5'h5; // @[Control.scala 118:41 119:22 121:22]
  wire  _T_12 = 3'h5 == funct3; // @[Control.scala 66:22]
  wire [4:0] _GEN_6 = _T_3 ? 5'h7 : 5'h6; // @[Control.scala 131:47 132:22 134:22]
  wire [4:0] _GEN_7 = _T_2 ? 5'h11 : _GEN_6; // @[Control.scala 129:41 130:22]
  wire  _T_15 = 3'h6 == funct3; // @[Control.scala 66:22]
  wire [4:0] _GEN_8 = _T_2 ? 5'h12 : 5'h8; // @[Control.scala 142:41 143:22 145:22]
  wire  _T_17 = 3'h7 == funct3; // @[Control.scala 66:22]
  wire [4:0] _GEN_9 = _T_2 ? 5'h13 : 5'h9; // @[Control.scala 153:41 154:22 156:22]
  wire [4:0] _GEN_10 = 3'h7 == funct3 ? _GEN_9 : 5'h0; // @[Control.scala 43:15 66:22]
  wire [4:0] _GEN_11 = 3'h6 == funct3 ? _GEN_8 : _GEN_10; // @[Control.scala 66:22]
  wire [4:0] _GEN_12 = 3'h5 == funct3 ? _GEN_7 : _GEN_11; // @[Control.scala 66:22]
  wire [4:0] _GEN_13 = 3'h4 == funct3 ? _GEN_5 : _GEN_12; // @[Control.scala 66:22]
  wire [4:0] _GEN_14 = 3'h3 == funct3 ? _GEN_4 : _GEN_13; // @[Control.scala 66:22]
  wire [4:0] _GEN_15 = 3'h2 == funct3 ? _GEN_3 : _GEN_14; // @[Control.scala 66:22]
  wire [4:0] _GEN_16 = 3'h1 == funct3 ? _GEN_2 : _GEN_15; // @[Control.scala 66:22]
  wire [4:0] _GEN_17 = 3'h0 == funct3 ? _GEN_1 : _GEN_16; // @[Control.scala 66:22]
  wire [4:0] _GEN_19 = _T_12 ? _GEN_6 : 5'h0; // @[Control.scala 170:22 43:15]
  wire [4:0] _GEN_20 = _T_4 ? 5'h2 : _GEN_19; // @[Control.scala 170:22 196:20]
  wire [4:0] _GEN_21 = _T_17 ? 5'h9 : _GEN_20; // @[Control.scala 170:22 192:20]
  wire [4:0] _GEN_22 = _T_15 ? 5'h8 : _GEN_21; // @[Control.scala 170:22 188:20]
  wire [4:0] _GEN_23 = _T_10 ? 5'h5 : _GEN_22; // @[Control.scala 170:22 184:20]
  wire [4:0] _GEN_24 = _T_8 ? 5'h4 : _GEN_23; // @[Control.scala 170:22 180:20]
  wire [4:0] _GEN_25 = _T_6 ? 5'h3 : _GEN_24; // @[Control.scala 170:22 176:20]
  wire [4:0] _GEN_26 = _T_1 ? 5'h0 : _GEN_25; // @[Control.scala 170:22 172:20]
  wire [4:0] _GEN_27 = _T_17 ? 5'h4 : 5'h0; // @[Control.scala 239:22 261:20 43:15]
  wire [4:0] _GEN_28 = _T_15 ? 5'h4 : _GEN_27; // @[Control.scala 239:22 257:20]
  wire [4:0] _GEN_29 = _T_12 ? 5'h3 : _GEN_28; // @[Control.scala 239:22 253:20]
  wire [4:0] _GEN_30 = _T_10 ? 5'h3 : _GEN_29; // @[Control.scala 239:22 249:20]
  wire [4:0] _GEN_31 = _T_4 ? 5'hf : _GEN_30; // @[Control.scala 239:22 245:20]
  wire [4:0] _GEN_32 = _T_1 ? 5'he : _GEN_31; // @[Control.scala 239:22 241:20]
  wire  _GEN_35 = 7'h37 == opcode | 7'h17 == opcode; // @[Control.scala 56:18 290:19]
  wire  _GEN_37 = 7'h67 == opcode | _GEN_35; // @[Control.scala 56:18 279:19]
  wire  _GEN_40 = 7'h6f == opcode | _GEN_37; // @[Control.scala 56:18 270:19]
  wire  _GEN_42 = 7'h6f == opcode ? 1'h0 : 7'h67 == opcode; // @[Control.scala 54:15 56:18]
  wire  _GEN_43 = 7'h6f == opcode ? 1'h0 : _GEN_37; // @[Control.scala 44:15 56:18]
  wire  _GEN_47 = 7'h63 == opcode ? 1'h0 : _GEN_43; // @[Control.scala 237:17 56:18]
  wire [4:0] _GEN_48 = 7'h63 == opcode ? _GEN_32 : 5'h0; // @[Control.scala 56:18]
  wire  _GEN_49 = 7'h63 == opcode ? 1'h0 : 7'h6f == opcode; // @[Control.scala 53:15 56:18]
  wire  _GEN_50 = 7'h63 == opcode ? 1'h0 : _GEN_40; // @[Control.scala 50:15 56:18]
  wire  _GEN_51 = 7'h63 == opcode ? 1'h0 : _GEN_42; // @[Control.scala 54:15 56:18]
  wire  _GEN_53 = 7'h23 == opcode | _GEN_47; // @[Control.scala 56:18 226:19]
  wire [4:0] _GEN_54 = 7'h23 == opcode ? 5'h0 : _GEN_48; // @[Control.scala 56:18 227:19]
  wire  _GEN_56 = 7'h23 == opcode ? 1'h0 : 7'h63 == opcode; // @[Control.scala 52:15 56:18]
  wire  _GEN_57 = 7'h23 == opcode ? 1'h0 : _GEN_49; // @[Control.scala 53:15 56:18]
  wire  _GEN_58 = 7'h23 == opcode ? 1'h0 : _GEN_50; // @[Control.scala 50:15 56:18]
  wire  _GEN_59 = 7'h23 == opcode ? 1'h0 : _GEN_51; // @[Control.scala 54:15 56:18]
  wire  _GEN_61 = 7'h3 == opcode | _GEN_53; // @[Control.scala 56:18 214:19]
  wire [4:0] _GEN_62 = 7'h3 == opcode ? 5'h0 : _GEN_54; // @[Control.scala 56:18 215:19]
  wire  _GEN_64 = 7'h3 == opcode | _GEN_58; // @[Control.scala 56:18 218:19]
  wire  _GEN_65 = 7'h3 == opcode ? 1'h0 : 7'h23 == opcode; // @[Control.scala 47:15 56:18]
  wire  _GEN_66 = 7'h3 == opcode ? 1'h0 : _GEN_56; // @[Control.scala 52:15 56:18]
  wire  _GEN_67 = 7'h3 == opcode ? 1'h0 : _GEN_57; // @[Control.scala 53:15 56:18]
  wire  _GEN_68 = 7'h3 == opcode ? 1'h0 : _GEN_59; // @[Control.scala 54:15 56:18]
  wire  _GEN_70 = 7'h13 == opcode | _GEN_61; // @[Control.scala 56:18 167:19]
  wire  _GEN_71 = 7'h13 == opcode | _GEN_64; // @[Control.scala 56:18 168:19]
  wire [4:0] _GEN_72 = 7'h13 == opcode ? _GEN_26 : _GEN_62; // @[Control.scala 56:18]
  wire  _GEN_73 = 7'h13 == opcode ? 1'h0 : 7'h3 == opcode; // @[Control.scala 46:15 56:18]
  wire  _GEN_74 = 7'h13 == opcode ? 1'h0 : _GEN_65; // @[Control.scala 47:15 56:18]
  wire  _GEN_75 = 7'h13 == opcode ? 1'h0 : _GEN_66; // @[Control.scala 52:15 56:18]
  wire  _GEN_76 = 7'h13 == opcode ? 1'h0 : _GEN_67; // @[Control.scala 53:15 56:18]
  wire  _GEN_77 = 7'h13 == opcode ? 1'h0 : _GEN_68; // @[Control.scala 54:15 56:18]
  assign io_aluOp = 7'h33 == opcode ? _GEN_17 : _GEN_72; // @[Control.scala 56:18]
  assign io_aluSrc = 7'h33 == opcode ? 1'h0 : _GEN_70; // @[Control.scala 56:18 63:19]
  assign io_memRead = 7'h33 == opcode ? 1'h0 : _GEN_73; // @[Control.scala 46:15 56:18]
  assign io_memWrite = 7'h33 == opcode ? 1'h0 : _GEN_74; // @[Control.scala 47:15 56:18]
  assign io_memToReg = 7'h33 == opcode ? 1'h0 : _GEN_73; // @[Control.scala 46:15 56:18]
  assign io_regWrite = 7'h33 == opcode | _GEN_71; // @[Control.scala 56:18 64:19]
  assign io_branch = 7'h33 == opcode ? 1'h0 : _GEN_75; // @[Control.scala 52:15 56:18]
  assign io_jump = 7'h33 == opcode ? 1'h0 : _GEN_76; // @[Control.scala 53:15 56:18]
  assign io_jalr = 7'h33 == opcode ? 1'h0 : _GEN_77; // @[Control.scala 54:15 56:18]
endmodule
module ImmediateGenerator(
  input  [31:0] io_instr,
  output [31:0] io_imm
);
  wire [6:0] opcode = io_instr[6:0]; // @[ImmediateGenerator.scala 12:24]
  wire [19:0] _iImm_T_2 = io_instr[31] ? 20'hfffff : 20'h0; // @[Bitwise.scala 77:12]
  wire [31:0] iImm = {_iImm_T_2,io_instr[31:20]}; // @[Cat.scala 33:92]
  wire [31:0] sImm = {_iImm_T_2,io_instr[31:25],io_instr[11:7]}; // @[Cat.scala 33:92]
  wire [18:0] _bImm_T_2 = io_instr[31] ? 19'h7ffff : 19'h0; // @[Bitwise.scala 77:12]
  wire [31:0] bImm = {_bImm_T_2,io_instr[31],io_instr[7],io_instr[30:25],io_instr[11:8],1'h0}; // @[Cat.scala 33:92]
  wire [31:0] uImm = {io_instr[31:12],12'h0}; // @[Cat.scala 33:92]
  wire [10:0] _jImm_T_2 = io_instr[31] ? 11'h7ff : 11'h0; // @[Bitwise.scala 77:12]
  wire [31:0] jImm = {_jImm_T_2,io_instr[31],io_instr[19:12],io_instr[20],io_instr[30:21],1'h0}; // @[Cat.scala 33:92]
  wire [31:0] _GEN_0 = 7'h6f == opcode ? jImm : 32'h0; // @[ImmediateGenerator.scala 48:10 50:18 81:14]
  wire [31:0] _GEN_1 = 7'h17 == opcode ? uImm : _GEN_0; // @[ImmediateGenerator.scala 50:18 77:14]
  wire [31:0] _GEN_2 = 7'h37 == opcode ? uImm : _GEN_1; // @[ImmediateGenerator.scala 50:18 73:14]
  wire [31:0] _GEN_3 = 7'h63 == opcode ? bImm : _GEN_2; // @[ImmediateGenerator.scala 50:18 69:14]
  wire [31:0] _GEN_4 = 7'h23 == opcode ? sImm : _GEN_3; // @[ImmediateGenerator.scala 50:18 65:14]
  wire [31:0] _GEN_5 = 7'h67 == opcode ? iImm : _GEN_4; // @[ImmediateGenerator.scala 50:18 61:14]
  wire [31:0] _GEN_6 = 7'h13 == opcode ? iImm : _GEN_5; // @[ImmediateGenerator.scala 50:18 57:14]
  assign io_imm = 7'h3 == opcode ? iImm : _GEN_6; // @[ImmediateGenerator.scala 50:18 53:14]
endmodule
module RegisterFile(
  input         clock,
  input         reset,
  input  [4:0]  io_rs1,
  input  [4:0]  io_rs2,
  input  [4:0]  io_rd,
  input  [31:0] io_writeData,
  input         io_writeEnable,
  output [31:0] io_readData1,
  output [31:0] io_readData2,
  output [31:0] io_debugRead_1,
  output [31:0] io_debugRead_2,
  output [31:0] io_debugRead_3,
  output [31:0] io_debugRead_4,
  output [31:0] io_debugRead_5,
  output [31:0] io_debugRead_6
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
`endif // RANDOMIZE_REG_INIT
  reg [31:0] regs_0; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_1; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_2; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_3; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_4; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_5; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_6; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_7; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_8; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_9; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_10; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_11; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_12; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_13; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_14; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_15; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_16; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_17; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_18; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_19; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_20; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_21; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_22; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_23; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_24; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_25; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_26; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_27; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_28; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_29; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_30; // @[RegisterFile.scala 43:21]
  reg [31:0] regs_31; // @[RegisterFile.scala 43:21]
  wire  _io_readData1_T = io_rs1 == 5'h0; // @[RegisterFile.scala 56:12]
  wire [31:0] _GEN_1 = 5'h1 == io_rs1 ? regs_1 : regs_0; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_2 = 5'h2 == io_rs1 ? regs_2 : _GEN_1; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_3 = 5'h3 == io_rs1 ? regs_3 : _GEN_2; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_4 = 5'h4 == io_rs1 ? regs_4 : _GEN_3; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_5 = 5'h5 == io_rs1 ? regs_5 : _GEN_4; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_6 = 5'h6 == io_rs1 ? regs_6 : _GEN_5; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_7 = 5'h7 == io_rs1 ? regs_7 : _GEN_6; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_8 = 5'h8 == io_rs1 ? regs_8 : _GEN_7; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_9 = 5'h9 == io_rs1 ? regs_9 : _GEN_8; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_10 = 5'ha == io_rs1 ? regs_10 : _GEN_9; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_11 = 5'hb == io_rs1 ? regs_11 : _GEN_10; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_12 = 5'hc == io_rs1 ? regs_12 : _GEN_11; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_13 = 5'hd == io_rs1 ? regs_13 : _GEN_12; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_14 = 5'he == io_rs1 ? regs_14 : _GEN_13; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_15 = 5'hf == io_rs1 ? regs_15 : _GEN_14; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_16 = 5'h10 == io_rs1 ? regs_16 : _GEN_15; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_17 = 5'h11 == io_rs1 ? regs_17 : _GEN_16; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_18 = 5'h12 == io_rs1 ? regs_18 : _GEN_17; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_19 = 5'h13 == io_rs1 ? regs_19 : _GEN_18; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_20 = 5'h14 == io_rs1 ? regs_20 : _GEN_19; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_21 = 5'h15 == io_rs1 ? regs_21 : _GEN_20; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_22 = 5'h16 == io_rs1 ? regs_22 : _GEN_21; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_23 = 5'h17 == io_rs1 ? regs_23 : _GEN_22; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_24 = 5'h18 == io_rs1 ? regs_24 : _GEN_23; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_25 = 5'h19 == io_rs1 ? regs_25 : _GEN_24; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_26 = 5'h1a == io_rs1 ? regs_26 : _GEN_25; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_27 = 5'h1b == io_rs1 ? regs_27 : _GEN_26; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_28 = 5'h1c == io_rs1 ? regs_28 : _GEN_27; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_29 = 5'h1d == io_rs1 ? regs_29 : _GEN_28; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_30 = 5'h1e == io_rs1 ? regs_30 : _GEN_29; // @[RegisterFile.scala 55:{22,22}]
  wire [31:0] _GEN_31 = 5'h1f == io_rs1 ? regs_31 : _GEN_30; // @[RegisterFile.scala 55:{22,22}]
  wire  _io_readData2_T = io_rs2 == 5'h0; // @[RegisterFile.scala 66:12]
  wire [31:0] _GEN_33 = 5'h1 == io_rs2 ? regs_1 : regs_0; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_34 = 5'h2 == io_rs2 ? regs_2 : _GEN_33; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_35 = 5'h3 == io_rs2 ? regs_3 : _GEN_34; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_36 = 5'h4 == io_rs2 ? regs_4 : _GEN_35; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_37 = 5'h5 == io_rs2 ? regs_5 : _GEN_36; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_38 = 5'h6 == io_rs2 ? regs_6 : _GEN_37; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_39 = 5'h7 == io_rs2 ? regs_7 : _GEN_38; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_40 = 5'h8 == io_rs2 ? regs_8 : _GEN_39; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_41 = 5'h9 == io_rs2 ? regs_9 : _GEN_40; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_42 = 5'ha == io_rs2 ? regs_10 : _GEN_41; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_43 = 5'hb == io_rs2 ? regs_11 : _GEN_42; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_44 = 5'hc == io_rs2 ? regs_12 : _GEN_43; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_45 = 5'hd == io_rs2 ? regs_13 : _GEN_44; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_46 = 5'he == io_rs2 ? regs_14 : _GEN_45; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_47 = 5'hf == io_rs2 ? regs_15 : _GEN_46; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_48 = 5'h10 == io_rs2 ? regs_16 : _GEN_47; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_49 = 5'h11 == io_rs2 ? regs_17 : _GEN_48; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_50 = 5'h12 == io_rs2 ? regs_18 : _GEN_49; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_51 = 5'h13 == io_rs2 ? regs_19 : _GEN_50; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_52 = 5'h14 == io_rs2 ? regs_20 : _GEN_51; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_53 = 5'h15 == io_rs2 ? regs_21 : _GEN_52; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_54 = 5'h16 == io_rs2 ? regs_22 : _GEN_53; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_55 = 5'h17 == io_rs2 ? regs_23 : _GEN_54; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_56 = 5'h18 == io_rs2 ? regs_24 : _GEN_55; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_57 = 5'h19 == io_rs2 ? regs_25 : _GEN_56; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_58 = 5'h1a == io_rs2 ? regs_26 : _GEN_57; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_59 = 5'h1b == io_rs2 ? regs_27 : _GEN_58; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_60 = 5'h1c == io_rs2 ? regs_28 : _GEN_59; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_61 = 5'h1d == io_rs2 ? regs_29 : _GEN_60; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_62 = 5'h1e == io_rs2 ? regs_30 : _GEN_61; // @[RegisterFile.scala 65:{22,22}]
  wire [31:0] _GEN_63 = 5'h1f == io_rs2 ? regs_31 : _GEN_62; // @[RegisterFile.scala 65:{22,22}]
  assign io_readData1 = _io_readData1_T ? 32'h0 : _GEN_31; // @[RegisterFile.scala 55:22]
  assign io_readData2 = _io_readData2_T ? 32'h0 : _GEN_63; // @[RegisterFile.scala 65:22]
  assign io_debugRead_1 = regs_1; // @[RegisterFile.scala 90:27]
  assign io_debugRead_2 = regs_2; // @[RegisterFile.scala 90:27]
  assign io_debugRead_3 = regs_3; // @[RegisterFile.scala 90:27]
  assign io_debugRead_4 = regs_4; // @[RegisterFile.scala 90:27]
  assign io_debugRead_5 = regs_5; // @[RegisterFile.scala 90:27]
  assign io_debugRead_6 = regs_6; // @[RegisterFile.scala 90:27]
  always @(posedge clock) begin
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_0 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h0 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_0 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_1 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h1 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_1 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_2 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h2 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_2 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_3 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h3 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_3 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_4 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h4 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_4 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_5 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h5 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_5 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_6 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h6 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_6 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_7 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h7 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_7 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_8 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h8 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_8 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_9 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h9 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_9 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_10 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'ha == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_10 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_11 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'hb == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_11 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_12 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'hc == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_12 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_13 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'hd == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_13 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_14 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'he == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_14 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_15 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'hf == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_15 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_16 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h10 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_16 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_17 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h11 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_17 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_18 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h12 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_18 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_19 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h13 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_19 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_20 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h14 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_20 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_21 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h15 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_21 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_22 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h16 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_22 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_23 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h17 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_23 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_24 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h18 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_24 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_25 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h19 == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_25 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_26 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h1a == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_26 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_27 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h1b == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_27 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_28 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h1c == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_28 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_29 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h1d == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_29 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_30 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h1e == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_30 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 43:21]
      regs_31 <= 32'h0; // @[RegisterFile.scala 43:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 80:43]
      if (5'h1f == io_rd) begin // @[RegisterFile.scala 81:17]
        regs_31 <= io_writeData; // @[RegisterFile.scala 81:17]
      end
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  regs_0 = _RAND_0[31:0];
  _RAND_1 = {1{`RANDOM}};
  regs_1 = _RAND_1[31:0];
  _RAND_2 = {1{`RANDOM}};
  regs_2 = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  regs_3 = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  regs_4 = _RAND_4[31:0];
  _RAND_5 = {1{`RANDOM}};
  regs_5 = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  regs_6 = _RAND_6[31:0];
  _RAND_7 = {1{`RANDOM}};
  regs_7 = _RAND_7[31:0];
  _RAND_8 = {1{`RANDOM}};
  regs_8 = _RAND_8[31:0];
  _RAND_9 = {1{`RANDOM}};
  regs_9 = _RAND_9[31:0];
  _RAND_10 = {1{`RANDOM}};
  regs_10 = _RAND_10[31:0];
  _RAND_11 = {1{`RANDOM}};
  regs_11 = _RAND_11[31:0];
  _RAND_12 = {1{`RANDOM}};
  regs_12 = _RAND_12[31:0];
  _RAND_13 = {1{`RANDOM}};
  regs_13 = _RAND_13[31:0];
  _RAND_14 = {1{`RANDOM}};
  regs_14 = _RAND_14[31:0];
  _RAND_15 = {1{`RANDOM}};
  regs_15 = _RAND_15[31:0];
  _RAND_16 = {1{`RANDOM}};
  regs_16 = _RAND_16[31:0];
  _RAND_17 = {1{`RANDOM}};
  regs_17 = _RAND_17[31:0];
  _RAND_18 = {1{`RANDOM}};
  regs_18 = _RAND_18[31:0];
  _RAND_19 = {1{`RANDOM}};
  regs_19 = _RAND_19[31:0];
  _RAND_20 = {1{`RANDOM}};
  regs_20 = _RAND_20[31:0];
  _RAND_21 = {1{`RANDOM}};
  regs_21 = _RAND_21[31:0];
  _RAND_22 = {1{`RANDOM}};
  regs_22 = _RAND_22[31:0];
  _RAND_23 = {1{`RANDOM}};
  regs_23 = _RAND_23[31:0];
  _RAND_24 = {1{`RANDOM}};
  regs_24 = _RAND_24[31:0];
  _RAND_25 = {1{`RANDOM}};
  regs_25 = _RAND_25[31:0];
  _RAND_26 = {1{`RANDOM}};
  regs_26 = _RAND_26[31:0];
  _RAND_27 = {1{`RANDOM}};
  regs_27 = _RAND_27[31:0];
  _RAND_28 = {1{`RANDOM}};
  regs_28 = _RAND_28[31:0];
  _RAND_29 = {1{`RANDOM}};
  regs_29 = _RAND_29[31:0];
  _RAND_30 = {1{`RANDOM}};
  regs_30 = _RAND_30[31:0];
  _RAND_31 = {1{`RANDOM}};
  regs_31 = _RAND_31[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module ALU(
  input  [31:0] io_a,
  input  [31:0] io_b,
  input  [4:0]  io_op,
  output [31:0] io_y
);
  wire [4:0] shamt = io_b[4:0]; // @[ALU.scala 64:19]
  wire [31:0] _aSigned64_T_2 = io_a[31] ? 32'hffffffff : 32'h0; // @[Bitwise.scala 77:12]
  wire [63:0] aSigned64 = {_aSigned64_T_2,io_a}; // @[ALU.scala 78:35]
  wire [31:0] _bSigned64_T_2 = io_b[31] ? 32'hffffffff : 32'h0; // @[Bitwise.scala 77:12]
  wire [63:0] bSigned64 = {_bSigned64_T_2,io_b}; // @[ALU.scala 81:35]
  wire [63:0] aUnsigned64 = {32'h0,io_a}; // @[Cat.scala 33:92]
  wire [63:0] bUnsigned64 = {32'h0,io_b}; // @[Cat.scala 33:92]
  wire [127:0] mulSS = $signed(aSigned64) * $signed(bSigned64); // @[ALU.scala 93:26]
  wire [127:0] mulUU = aUnsigned64 * bUnsigned64; // @[ALU.scala 94:28]
  wire [63:0] _mulHSU_T = {32'h0,io_b}; // @[ALU.scala 95:40]
  wire [127:0] mulHSU = $signed(aSigned64) * $signed(_mulHSU_T); // @[ALU.scala 95:26]
  wire [31:0] mulLow = mulSS[31:0]; // @[ALU.scala 98:10]
  wire [31:0] mulHighSS = mulSS[63:32]; // @[ALU.scala 101:10]
  wire [31:0] mulHighSU = mulHSU[63:32]; // @[ALU.scala 104:11]
  wire [31:0] mulHighUU = mulUU[63:32]; // @[ALU.scala 107:10]
  wire  _T = io_b == 32'h0; // @[ALU.scala 147:14]
  wire  _T_2 = io_b == 32'hffffffff; // @[ALU.scala 152:11]
  wire  _T_3 = io_a == 32'h80000000 & _T_2; // @[ALU.scala 151:23]
  wire [32:0] _divResult_T_1 = $signed(io_a) / $signed(io_b); // @[ALU.scala 157:38]
  wire [32:0] _GEN_0 = _T_3 ? 33'h80000000 : _divResult_T_1; // @[ALU.scala 153:5 155:15 157:15]
  wire [32:0] _GEN_1 = io_b == 32'h0 ? 33'hffffffff : _GEN_0; // @[ALU.scala 147:23 149:15]
  wire [31:0] _divuResult_T = io_a / io_b; // @[ALU.scala 170:24]
  wire [31:0] divuResult = _T ? 32'hffffffff : _divuResult_T; // @[ALU.scala 166:23 168:16 170:16]
  wire [31:0] _remResult_T_1 = $signed(io_a) % $signed(io_b); // @[ALU.scala 189:38]
  wire [31:0] _GEN_3 = _T_3 ? 32'h0 : _remResult_T_1; // @[ALU.scala 185:5 187:15 189:15]
  wire [31:0] remResult = _T ? io_a : _GEN_3; // @[ALU.scala 179:23 181:15]
  wire [31:0] _remuResult_T = io_a % io_b; // @[ALU.scala 202:24]
  wire [31:0] remuResult = _T ? io_a : _remuResult_T; // @[ALU.scala 198:23 200:16 202:16]
  wire  equal = io_a == io_b; // @[ALU.scala 210:10]
  wire  notEqual = io_a != io_b; // @[ALU.scala 213:10]
  wire [31:0] _io_y_T_1 = io_a + io_b; // @[ALU.scala 229:15]
  wire [31:0] _io_y_T_3 = io_a - io_b; // @[ALU.scala 232:15]
  wire [62:0] _GEN_2 = {{31'd0}, io_a}; // @[ALU.scala 235:15]
  wire [62:0] _io_y_T_4 = _GEN_2 << shamt; // @[ALU.scala 235:15]
  wire  _io_y_T_5 = $signed(io_a) < $signed(io_b); // @[ALU.scala 239:19]
  wire [31:0] _io_y_T_6 = _io_y_T_5 ? 32'h1 : 32'h0; // @[ALU.scala 238:12]
  wire  _io_y_T_7 = io_a < io_b; // @[ALU.scala 246:16]
  wire [31:0] _io_y_T_8 = _io_y_T_7 ? 32'h1 : 32'h0; // @[ALU.scala 245:12]
  wire [31:0] _io_y_T_9 = io_a ^ io_b; // @[ALU.scala 252:15]
  wire [31:0] _io_y_T_10 = io_a >> shamt; // @[ALU.scala 255:15]
  wire [31:0] _io_y_T_12 = $signed(io_a) >>> shamt; // @[ALU.scala 258:28]
  wire [31:0] _io_y_T_13 = io_a | io_b; // @[ALU.scala 261:15]
  wire [31:0] _io_y_T_14 = io_a & io_b; // @[ALU.scala 264:15]
  wire [31:0] _io_y_T_15 = equal ? 32'h1 : 32'h0; // @[ALU.scala 287:12]
  wire [31:0] _io_y_T_16 = notEqual ? 32'h1 : 32'h0; // @[ALU.scala 294:12]
  wire [31:0] _io_y_T_18 = 5'h0 == io_op ? _io_y_T_1 : 32'h0; // @[Mux.scala 81:58]
  wire [31:0] _io_y_T_20 = 5'h1 == io_op ? _io_y_T_3 : _io_y_T_18; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_22 = 5'h2 == io_op ? _io_y_T_4 : {{31'd0}, _io_y_T_20}; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_24 = 5'h3 == io_op ? {{31'd0}, _io_y_T_6} : _io_y_T_22; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_26 = 5'h4 == io_op ? {{31'd0}, _io_y_T_8} : _io_y_T_24; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_28 = 5'h5 == io_op ? {{31'd0}, _io_y_T_9} : _io_y_T_26; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_30 = 5'h6 == io_op ? {{31'd0}, _io_y_T_10} : _io_y_T_28; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_32 = 5'h7 == io_op ? {{31'd0}, _io_y_T_12} : _io_y_T_30; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_34 = 5'h8 == io_op ? {{31'd0}, _io_y_T_13} : _io_y_T_32; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_36 = 5'h9 == io_op ? {{31'd0}, _io_y_T_14} : _io_y_T_34; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_38 = 5'ha == io_op ? {{31'd0}, mulLow} : _io_y_T_36; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_40 = 5'hb == io_op ? {{31'd0}, mulHighSS} : _io_y_T_38; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_42 = 5'hc == io_op ? {{31'd0}, mulHighSU} : _io_y_T_40; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_44 = 5'hd == io_op ? {{31'd0}, mulHighUU} : _io_y_T_42; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_46 = 5'he == io_op ? {{31'd0}, _io_y_T_15} : _io_y_T_44; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_48 = 5'hf == io_op ? {{31'd0}, _io_y_T_16} : _io_y_T_46; // @[Mux.scala 81:58]
  wire [31:0] divResult = _GEN_1[31:0]; // @[ALU.scala 145:23]
  wire [62:0] _io_y_T_50 = 5'h10 == io_op ? {{31'd0}, divResult} : _io_y_T_48; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_52 = 5'h11 == io_op ? {{31'd0}, divuResult} : _io_y_T_50; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_54 = 5'h12 == io_op ? {{31'd0}, remResult} : _io_y_T_52; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_56 = 5'h13 == io_op ? {{31'd0}, remuResult} : _io_y_T_54; // @[Mux.scala 81:58]
  assign io_y = _io_y_T_56[31:0]; // @[ALU.scala 219:8]
endmodule
module PCUpdate(
  input  [31:0] io_pc,
  input  [31:0] io_rs1,
  input  [31:0] io_imm,
  input  [2:0]  io_funct3,
  input         io_branch,
  input         io_jump,
  input         io_jalr,
  input  [31:0] io_aluResult,
  output [31:0] io_nextPc
);
  wire [31:0] pcPlus4 = io_pc + 32'h4; // @[PCUpdate.scala 23:23]
  wire [31:0] branchTarget = io_pc + io_imm; // @[PCUpdate.scala 25:28]
  wire [31:0] _jalrTarget_T_1 = io_rs1 + io_imm; // @[PCUpdate.scala 29:28]
  wire [31:0] jalrTarget = _jalrTarget_T_1 & 32'hfffffffe; // @[PCUpdate.scala 29:38]
  wire  _branchTaken_T = io_aluResult == 32'h1; // @[PCUpdate.scala 36:37]
  wire  _branchTaken_T_3 = io_aluResult == 32'h0; // @[PCUpdate.scala 48:37]
  wire  _GEN_0 = 3'h7 == io_funct3 & _branchTaken_T_3; // @[PCUpdate.scala 34:24 56:21 31:32]
  wire  _GEN_1 = 3'h6 == io_funct3 ? _branchTaken_T : _GEN_0; // @[PCUpdate.scala 34:24 52:21]
  wire  _GEN_2 = 3'h5 == io_funct3 ? io_aluResult == 32'h0 : _GEN_1; // @[PCUpdate.scala 34:24 48:21]
  wire  _GEN_3 = 3'h4 == io_funct3 ? _branchTaken_T : _GEN_2; // @[PCUpdate.scala 34:24 44:21]
  wire  _GEN_4 = 3'h1 == io_funct3 ? _branchTaken_T : _GEN_3; // @[PCUpdate.scala 34:24 40:21]
  wire  _GEN_5 = 3'h0 == io_funct3 ? io_aluResult == 32'h1 : _GEN_4; // @[PCUpdate.scala 34:24 36:21]
  wire  branchTaken = io_branch & _GEN_5; // @[PCUpdate.scala 33:20 31:32]
  wire [31:0] _GEN_7 = branchTaken ? branchTarget : pcPlus4; // @[PCUpdate.scala 61:13 63:22 64:15]
  wire [31:0] _GEN_8 = io_jump ? branchTarget : _GEN_7; // @[PCUpdate.scala 67:18 68:15]
  assign io_nextPc = io_jalr ? jalrTarget : _GEN_8; // @[PCUpdate.scala 71:18 72:15]
endmodule
module Datapath(
  input         clock,
  input         reset,
  input         io_valid,
  input  [31:0] io_instr,
  input  [31:0] io_pc,
  output [31:0] io_nextPc,
  output        io_memRead,
  output        io_memWrite,
  output [31:0] io_memAddr,
  output [31:0] io_memWdata,
  input  [31:0] io_memRdata,
  output [2:0]  io_memFunct3,
  output [31:0] io_writeBack,
  output [31:0] io_debugX1,
  output [31:0] io_debugX2,
  output [31:0] io_debugX3,
  output [31:0] io_debugX4,
  output [31:0] io_debugX5,
  output [31:0] io_debugX6,
  output [31:0] io_debugALU,
  output [31:0] io_debugImm
);
  wire [31:0] decoder_io_instr; // @[Datapath.scala 81:24]
  wire [4:0] decoder_io_rs1; // @[Datapath.scala 81:24]
  wire [4:0] decoder_io_rs2; // @[Datapath.scala 81:24]
  wire [4:0] decoder_io_rd; // @[Datapath.scala 81:24]
  wire [2:0] decoder_io_funct3; // @[Datapath.scala 81:24]
  wire [31:0] control_io_instr; // @[Datapath.scala 82:24]
  wire [4:0] control_io_aluOp; // @[Datapath.scala 82:24]
  wire  control_io_aluSrc; // @[Datapath.scala 82:24]
  wire  control_io_memRead; // @[Datapath.scala 82:24]
  wire  control_io_memWrite; // @[Datapath.scala 82:24]
  wire  control_io_memToReg; // @[Datapath.scala 82:24]
  wire  control_io_regWrite; // @[Datapath.scala 82:24]
  wire  control_io_branch; // @[Datapath.scala 82:24]
  wire  control_io_jump; // @[Datapath.scala 82:24]
  wire  control_io_jalr; // @[Datapath.scala 82:24]
  wire [31:0] immGen_io_instr; // @[Datapath.scala 83:24]
  wire [31:0] immGen_io_imm; // @[Datapath.scala 83:24]
  wire  regFile_clock; // @[Datapath.scala 84:24]
  wire  regFile_reset; // @[Datapath.scala 84:24]
  wire [4:0] regFile_io_rs1; // @[Datapath.scala 84:24]
  wire [4:0] regFile_io_rs2; // @[Datapath.scala 84:24]
  wire [4:0] regFile_io_rd; // @[Datapath.scala 84:24]
  wire [31:0] regFile_io_writeData; // @[Datapath.scala 84:24]
  wire  regFile_io_writeEnable; // @[Datapath.scala 84:24]
  wire [31:0] regFile_io_readData1; // @[Datapath.scala 84:24]
  wire [31:0] regFile_io_readData2; // @[Datapath.scala 84:24]
  wire [31:0] regFile_io_debugRead_1; // @[Datapath.scala 84:24]
  wire [31:0] regFile_io_debugRead_2; // @[Datapath.scala 84:24]
  wire [31:0] regFile_io_debugRead_3; // @[Datapath.scala 84:24]
  wire [31:0] regFile_io_debugRead_4; // @[Datapath.scala 84:24]
  wire [31:0] regFile_io_debugRead_5; // @[Datapath.scala 84:24]
  wire [31:0] regFile_io_debugRead_6; // @[Datapath.scala 84:24]
  wire [31:0] alu_io_a; // @[Datapath.scala 85:24]
  wire [31:0] alu_io_b; // @[Datapath.scala 85:24]
  wire [4:0] alu_io_op; // @[Datapath.scala 85:24]
  wire [31:0] alu_io_y; // @[Datapath.scala 85:24]
  wire [31:0] pcUpdate_io_pc; // @[Datapath.scala 86:24]
  wire [31:0] pcUpdate_io_rs1; // @[Datapath.scala 86:24]
  wire [31:0] pcUpdate_io_imm; // @[Datapath.scala 86:24]
  wire [2:0] pcUpdate_io_funct3; // @[Datapath.scala 86:24]
  wire  pcUpdate_io_branch; // @[Datapath.scala 86:24]
  wire  pcUpdate_io_jump; // @[Datapath.scala 86:24]
  wire  pcUpdate_io_jalr; // @[Datapath.scala 86:24]
  wire [31:0] pcUpdate_io_aluResult; // @[Datapath.scala 86:24]
  wire [31:0] pcUpdate_io_nextPc; // @[Datapath.scala 86:24]
  wire  _writeBackData_T = control_io_jump | control_io_jalr; // @[Datapath.scala 190:23]
  wire [31:0] _writeBackData_T_2 = io_pc + 32'h4; // @[Datapath.scala 191:13]
  wire [31:0] _writeBackData_T_3 = _writeBackData_T ? _writeBackData_T_2 : alu_io_y; // @[Datapath.scala 189:8]
  wire [31:0] writeBackData = control_io_memToReg ? io_memRdata : _writeBackData_T_3; // @[Datapath.scala 186:26]
  Decoder decoder ( // @[Datapath.scala 81:24]
    .io_instr(decoder_io_instr),
    .io_rs1(decoder_io_rs1),
    .io_rs2(decoder_io_rs2),
    .io_rd(decoder_io_rd),
    .io_funct3(decoder_io_funct3)
  );
  Control control ( // @[Datapath.scala 82:24]
    .io_instr(control_io_instr),
    .io_aluOp(control_io_aluOp),
    .io_aluSrc(control_io_aluSrc),
    .io_memRead(control_io_memRead),
    .io_memWrite(control_io_memWrite),
    .io_memToReg(control_io_memToReg),
    .io_regWrite(control_io_regWrite),
    .io_branch(control_io_branch),
    .io_jump(control_io_jump),
    .io_jalr(control_io_jalr)
  );
  ImmediateGenerator immGen ( // @[Datapath.scala 83:24]
    .io_instr(immGen_io_instr),
    .io_imm(immGen_io_imm)
  );
  RegisterFile regFile ( // @[Datapath.scala 84:24]
    .clock(regFile_clock),
    .reset(regFile_reset),
    .io_rs1(regFile_io_rs1),
    .io_rs2(regFile_io_rs2),
    .io_rd(regFile_io_rd),
    .io_writeData(regFile_io_writeData),
    .io_writeEnable(regFile_io_writeEnable),
    .io_readData1(regFile_io_readData1),
    .io_readData2(regFile_io_readData2),
    .io_debugRead_1(regFile_io_debugRead_1),
    .io_debugRead_2(regFile_io_debugRead_2),
    .io_debugRead_3(regFile_io_debugRead_3),
    .io_debugRead_4(regFile_io_debugRead_4),
    .io_debugRead_5(regFile_io_debugRead_5),
    .io_debugRead_6(regFile_io_debugRead_6)
  );
  ALU alu ( // @[Datapath.scala 85:24]
    .io_a(alu_io_a),
    .io_b(alu_io_b),
    .io_op(alu_io_op),
    .io_y(alu_io_y)
  );
  PCUpdate pcUpdate ( // @[Datapath.scala 86:24]
    .io_pc(pcUpdate_io_pc),
    .io_rs1(pcUpdate_io_rs1),
    .io_imm(pcUpdate_io_imm),
    .io_funct3(pcUpdate_io_funct3),
    .io_branch(pcUpdate_io_branch),
    .io_jump(pcUpdate_io_jump),
    .io_jalr(pcUpdate_io_jalr),
    .io_aluResult(pcUpdate_io_aluResult),
    .io_nextPc(pcUpdate_io_nextPc)
  );
  assign io_nextPc = io_valid ? pcUpdate_io_nextPc : _writeBackData_T_2; // @[Datapath.scala 250:19]
  assign io_memRead = control_io_memRead & io_valid; // @[Datapath.scala 154:24]
  assign io_memWrite = control_io_memWrite & io_valid; // @[Datapath.scala 157:25]
  assign io_memAddr = alu_io_y; // @[Datapath.scala 159:14]
  assign io_memWdata = regFile_io_readData2; // @[Datapath.scala 162:15]
  assign io_memFunct3 = decoder_io_funct3; // @[Datapath.scala 164:16]
  assign io_writeBack = io_valid ? writeBackData : 32'h0; // @[Datapath.scala 260:22]
  assign io_debugX1 = regFile_io_debugRead_1; // @[Datapath.scala 270:14]
  assign io_debugX2 = regFile_io_debugRead_2; // @[Datapath.scala 271:14]
  assign io_debugX3 = regFile_io_debugRead_3; // @[Datapath.scala 272:14]
  assign io_debugX4 = regFile_io_debugRead_4; // @[Datapath.scala 273:14]
  assign io_debugX5 = regFile_io_debugRead_5; // @[Datapath.scala 274:14]
  assign io_debugX6 = regFile_io_debugRead_6; // @[Datapath.scala 275:14]
  assign io_debugALU = alu_io_y; // @[Datapath.scala 277:15]
  assign io_debugImm = immGen_io_imm; // @[Datapath.scala 278:15]
  assign decoder_io_instr = io_instr; // @[Datapath.scala 98:20]
  assign control_io_instr = io_instr; // @[Datapath.scala 99:20]
  assign immGen_io_instr = io_instr; // @[Datapath.scala 100:20]
  assign regFile_clock = clock;
  assign regFile_reset = reset;
  assign regFile_io_rs1 = decoder_io_rs1; // @[Datapath.scala 106:18]
  assign regFile_io_rs2 = decoder_io_rs2; // @[Datapath.scala 107:18]
  assign regFile_io_rd = decoder_io_rd; // @[Datapath.scala 108:18]
  assign regFile_io_writeData = control_io_memToReg ? io_memRdata : _writeBackData_T_3; // @[Datapath.scala 186:26]
  assign regFile_io_writeEnable = control_io_regWrite & io_valid; // @[Datapath.scala 209:25]
  assign alu_io_a = regFile_io_readData1; // @[Datapath.scala 136:13]
  assign alu_io_b = control_io_aluSrc ? immGen_io_imm : regFile_io_readData2; // @[Datapath.scala 126:17]
  assign alu_io_op = control_io_aluOp; // @[Datapath.scala 138:13]
  assign pcUpdate_io_pc = io_pc; // @[Datapath.scala 221:18]
  assign pcUpdate_io_rs1 = regFile_io_readData1; // @[Datapath.scala 223:19]
  assign pcUpdate_io_imm = immGen_io_imm; // @[Datapath.scala 225:19]
  assign pcUpdate_io_funct3 = decoder_io_funct3; // @[Datapath.scala 227:22]
  assign pcUpdate_io_branch = control_io_branch & io_valid; // @[Datapath.scala 230:23]
  assign pcUpdate_io_jump = control_io_jump & io_valid; // @[Datapath.scala 233:21]
  assign pcUpdate_io_jalr = control_io_jalr & io_valid; // @[Datapath.scala 236:21]
  assign pcUpdate_io_aluResult = alu_io_y; // @[Datapath.scala 238:25]
endmodule
module DataMemory(
  input         clock,
  input  [31:0] io_addr,
  input  [31:0] io_wdata,
  output [31:0] io_rdata,
  input         io_memRead,
  input         io_memWrite,
  input  [2:0]  io_funct3
);
`ifdef RANDOMIZE_MEM_INIT
  reg [31:0] _RAND_0;
`endif // RANDOMIZE_MEM_INIT
  reg [7:0] mem [0:1023]; // @[DataMemory.scala 18:16]
  wire  mem_byte0_en; // @[DataMemory.scala 18:16]
  wire [9:0] mem_byte0_addr; // @[DataMemory.scala 18:16]
  wire [7:0] mem_byte0_data; // @[DataMemory.scala 18:16]
  wire  mem_byte1_en; // @[DataMemory.scala 18:16]
  wire [9:0] mem_byte1_addr; // @[DataMemory.scala 18:16]
  wire [7:0] mem_byte1_data; // @[DataMemory.scala 18:16]
  wire  mem_byte2_en; // @[DataMemory.scala 18:16]
  wire [9:0] mem_byte2_addr; // @[DataMemory.scala 18:16]
  wire [7:0] mem_byte2_data; // @[DataMemory.scala 18:16]
  wire  mem_byte3_en; // @[DataMemory.scala 18:16]
  wire [9:0] mem_byte3_addr; // @[DataMemory.scala 18:16]
  wire [7:0] mem_byte3_data; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_1_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_1_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_1_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_1_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_2_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_2_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_2_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_2_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_3_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_3_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_3_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_3_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_4_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_4_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_4_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_4_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_5_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_5_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_5_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_5_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_6_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_6_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_6_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_6_en; // @[DataMemory.scala 18:16]
  wire [31:0] _byte1_T_1 = io_addr + 32'h1; // @[DataMemory.scala 21:27]
  wire [31:0] _byte2_T_1 = io_addr + 32'h2; // @[DataMemory.scala 22:27]
  wire [31:0] _byte3_T_1 = io_addr + 32'h3; // @[DataMemory.scala 23:27]
  wire [31:0] loadData = {mem_byte3_data,mem_byte2_data,mem_byte1_data,mem_byte0_data}; // @[Cat.scala 33:92]
  wire  _T = 3'h0 == io_funct3; // @[DataMemory.scala 30:23]
  wire [23:0] _io_rdata_T_2 = mem_byte0_data[7] ? 24'hffffff : 24'h0; // @[Bitwise.scala 77:12]
  wire [31:0] _io_rdata_T_3 = {_io_rdata_T_2,mem_byte0_data}; // @[Cat.scala 33:92]
  wire  _T_1 = 3'h1 == io_funct3; // @[DataMemory.scala 30:23]
  wire [15:0] _io_rdata_T_6 = mem_byte1_data[7] ? 16'hffff : 16'h0; // @[Bitwise.scala 77:12]
  wire [31:0] _io_rdata_T_7 = {_io_rdata_T_6,mem_byte1_data,mem_byte0_data}; // @[Cat.scala 33:92]
  wire  _T_2 = 3'h2 == io_funct3; // @[DataMemory.scala 30:23]
  wire [31:0] _io_rdata_T_8 = {24'h0,mem_byte0_data}; // @[Cat.scala 33:92]
  wire [31:0] _io_rdata_T_9 = {16'h0,mem_byte1_data,mem_byte0_data}; // @[Cat.scala 33:92]
  wire [31:0] _GEN_0 = 3'h5 == io_funct3 ? _io_rdata_T_9 : 32'h0; // @[DataMemory.scala 27:12 30:23 52:18]
  wire [31:0] _GEN_1 = 3'h4 == io_funct3 ? _io_rdata_T_8 : _GEN_0; // @[DataMemory.scala 30:23 48:18]
  wire [31:0] _GEN_2 = 3'h2 == io_funct3 ? loadData : _GEN_1; // @[DataMemory.scala 30:23 44:18]
  wire [31:0] _GEN_3 = 3'h1 == io_funct3 ? _io_rdata_T_7 : _GEN_2; // @[DataMemory.scala 30:23 36:18]
  wire [31:0] _GEN_4 = 3'h0 == io_funct3 ? _io_rdata_T_3 : _GEN_3; // @[DataMemory.scala 30:23 32:18]
  wire  _GEN_26 = _T_1 ? 1'h0 : _T_2; // @[DataMemory.scala 18:16 62:23]
  wire  _GEN_42 = _T ? 1'h0 : _T_1; // @[DataMemory.scala 18:16 62:23]
  wire  _GEN_49 = _T ? 1'h0 : _GEN_26; // @[DataMemory.scala 18:16 62:23]
  assign mem_byte0_en = 1'h1;
  assign mem_byte0_addr = io_addr[9:0];
  assign mem_byte0_data = mem[mem_byte0_addr]; // @[DataMemory.scala 18:16]
  assign mem_byte1_en = 1'h1;
  assign mem_byte1_addr = _byte1_T_1[9:0];
  assign mem_byte1_data = mem[mem_byte1_addr]; // @[DataMemory.scala 18:16]
  assign mem_byte2_en = 1'h1;
  assign mem_byte2_addr = _byte2_T_1[9:0];
  assign mem_byte2_data = mem[mem_byte2_addr]; // @[DataMemory.scala 18:16]
  assign mem_byte3_en = 1'h1;
  assign mem_byte3_addr = _byte3_T_1[9:0];
  assign mem_byte3_data = mem[mem_byte3_addr]; // @[DataMemory.scala 18:16]
  assign mem_MPORT_data = io_wdata[7:0];
  assign mem_MPORT_addr = io_addr[9:0];
  assign mem_MPORT_mask = 1'h1;
  assign mem_MPORT_en = io_memWrite & _T;
  assign mem_MPORT_1_data = io_wdata[7:0];
  assign mem_MPORT_1_addr = io_addr[9:0];
  assign mem_MPORT_1_mask = 1'h1;
  assign mem_MPORT_1_en = io_memWrite & _GEN_42;
  assign mem_MPORT_2_data = io_wdata[15:8];
  assign mem_MPORT_2_addr = _byte1_T_1[9:0];
  assign mem_MPORT_2_mask = 1'h1;
  assign mem_MPORT_2_en = io_memWrite & _GEN_42;
  assign mem_MPORT_3_data = io_wdata[7:0];
  assign mem_MPORT_3_addr = io_addr[9:0];
  assign mem_MPORT_3_mask = 1'h1;
  assign mem_MPORT_3_en = io_memWrite & _GEN_49;
  assign mem_MPORT_4_data = io_wdata[15:8];
  assign mem_MPORT_4_addr = _byte1_T_1[9:0];
  assign mem_MPORT_4_mask = 1'h1;
  assign mem_MPORT_4_en = io_memWrite & _GEN_49;
  assign mem_MPORT_5_data = io_wdata[23:16];
  assign mem_MPORT_5_addr = _byte2_T_1[9:0];
  assign mem_MPORT_5_mask = 1'h1;
  assign mem_MPORT_5_en = io_memWrite & _GEN_49;
  assign mem_MPORT_6_data = io_wdata[31:24];
  assign mem_MPORT_6_addr = _byte3_T_1[9:0];
  assign mem_MPORT_6_mask = 1'h1;
  assign mem_MPORT_6_en = io_memWrite & _GEN_49;
  assign io_rdata = io_memRead ? _GEN_4 : 32'h0; // @[DataMemory.scala 27:12 29:20]
  always @(posedge clock) begin
    if (mem_MPORT_en & mem_MPORT_mask) begin
      mem[mem_MPORT_addr] <= mem_MPORT_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_1_en & mem_MPORT_1_mask) begin
      mem[mem_MPORT_1_addr] <= mem_MPORT_1_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_2_en & mem_MPORT_2_mask) begin
      mem[mem_MPORT_2_addr] <= mem_MPORT_2_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_3_en & mem_MPORT_3_mask) begin
      mem[mem_MPORT_3_addr] <= mem_MPORT_3_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_4_en & mem_MPORT_4_mask) begin
      mem[mem_MPORT_4_addr] <= mem_MPORT_4_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_5_en & mem_MPORT_5_mask) begin
      mem[mem_MPORT_5_addr] <= mem_MPORT_5_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_6_en & mem_MPORT_6_mask) begin
      mem[mem_MPORT_6_addr] <= mem_MPORT_6_data; // @[DataMemory.scala 18:16]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_MEM_INIT
  _RAND_0 = {1{`RANDOM}};
  for (initvar = 0; initvar < 1024; initvar = initvar+1)
    mem[initvar] = _RAND_0[7:0];
`endif // RANDOMIZE_MEM_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module RV32ICore(
  input         clock,
  input         reset,
  output [31:0] io_pc,
  output [31:0] io_nextPc,
  output [31:0] io_writeBack,
  output [31:0] io_debugInstr,
  output [31:0] io_debugX1,
  output [31:0] io_debugX2,
  output [31:0] io_debugX3,
  output [31:0] io_debugX4,
  output [31:0] io_debugX5,
  output [31:0] io_debugX6,
  output [31:0] io_debugALU,
  output [31:0] io_debugImm,
  output [31:0] io_debugFetchPC,
  output [31:0] io_debugExecPC,
  output        io_debugValid,
  output        io_debugFlush
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
`endif // RANDOMIZE_REG_INIT
  wire  instructionMemory_clock; // @[RV32ICore.scala 61:33]
  wire [31:0] instructionMemory_io_addr; // @[RV32ICore.scala 61:33]
  wire [31:0] instructionMemory_io_instr; // @[RV32ICore.scala 61:33]
  wire  datapath_clock; // @[RV32ICore.scala 62:33]
  wire  datapath_reset; // @[RV32ICore.scala 62:33]
  wire  datapath_io_valid; // @[RV32ICore.scala 62:33]
  wire [31:0] datapath_io_instr; // @[RV32ICore.scala 62:33]
  wire [31:0] datapath_io_pc; // @[RV32ICore.scala 62:33]
  wire [31:0] datapath_io_nextPc; // @[RV32ICore.scala 62:33]
  wire  datapath_io_memRead; // @[RV32ICore.scala 62:33]
  wire  datapath_io_memWrite; // @[RV32ICore.scala 62:33]
  wire [31:0] datapath_io_memAddr; // @[RV32ICore.scala 62:33]
  wire [31:0] datapath_io_memWdata; // @[RV32ICore.scala 62:33]
  wire [31:0] datapath_io_memRdata; // @[RV32ICore.scala 62:33]
  wire [2:0] datapath_io_memFunct3; // @[RV32ICore.scala 62:33]
  wire [31:0] datapath_io_writeBack; // @[RV32ICore.scala 62:33]
  wire [31:0] datapath_io_debugX1; // @[RV32ICore.scala 62:33]
  wire [31:0] datapath_io_debugX2; // @[RV32ICore.scala 62:33]
  wire [31:0] datapath_io_debugX3; // @[RV32ICore.scala 62:33]
  wire [31:0] datapath_io_debugX4; // @[RV32ICore.scala 62:33]
  wire [31:0] datapath_io_debugX5; // @[RV32ICore.scala 62:33]
  wire [31:0] datapath_io_debugX6; // @[RV32ICore.scala 62:33]
  wire [31:0] datapath_io_debugALU; // @[RV32ICore.scala 62:33]
  wire [31:0] datapath_io_debugImm; // @[RV32ICore.scala 62:33]
  wire  dataMemory_clock; // @[RV32ICore.scala 63:33]
  wire [31:0] dataMemory_io_addr; // @[RV32ICore.scala 63:33]
  wire [31:0] dataMemory_io_wdata; // @[RV32ICore.scala 63:33]
  wire [31:0] dataMemory_io_rdata; // @[RV32ICore.scala 63:33]
  wire  dataMemory_io_memRead; // @[RV32ICore.scala 63:33]
  wire  dataMemory_io_memWrite; // @[RV32ICore.scala 63:33]
  wire [2:0] dataMemory_io_funct3; // @[RV32ICore.scala 63:33]
  reg [31:0] pcReg; // @[RV32ICore.scala 85:22]
  wire [31:0] sequentialPC = pcReg + 32'h4; // @[RV32ICore.scala 95:28]
  reg  ifexValid; // @[RV32ICore.scala 118:26]
  reg [31:0] ifexPC; // @[RV32ICore.scala 121:12]
  reg [31:0] ifexInstr; // @[RV32ICore.scala 135:12]
  wire [31:0] stage2SequentialPC = ifexPC + 32'h4; // @[RV32ICore.scala 213:12]
  wire  _redirect_T = datapath_io_nextPc != stage2SequentialPC; // @[RV32ICore.scala 217:25]
  wire  redirect = ifexValid & _redirect_T; // @[RV32ICore.scala 216:15]
  InstructionMemory instructionMemory ( // @[RV32ICore.scala 61:33]
    .clock(instructionMemory_clock),
    .io_addr(instructionMemory_io_addr),
    .io_instr(instructionMemory_io_instr)
  );
  Datapath datapath ( // @[RV32ICore.scala 62:33]
    .clock(datapath_clock),
    .reset(datapath_reset),
    .io_valid(datapath_io_valid),
    .io_instr(datapath_io_instr),
    .io_pc(datapath_io_pc),
    .io_nextPc(datapath_io_nextPc),
    .io_memRead(datapath_io_memRead),
    .io_memWrite(datapath_io_memWrite),
    .io_memAddr(datapath_io_memAddr),
    .io_memWdata(datapath_io_memWdata),
    .io_memRdata(datapath_io_memRdata),
    .io_memFunct3(datapath_io_memFunct3),
    .io_writeBack(datapath_io_writeBack),
    .io_debugX1(datapath_io_debugX1),
    .io_debugX2(datapath_io_debugX2),
    .io_debugX3(datapath_io_debugX3),
    .io_debugX4(datapath_io_debugX4),
    .io_debugX5(datapath_io_debugX5),
    .io_debugX6(datapath_io_debugX6),
    .io_debugALU(datapath_io_debugALU),
    .io_debugImm(datapath_io_debugImm)
  );
  DataMemory dataMemory ( // @[RV32ICore.scala 63:33]
    .clock(dataMemory_clock),
    .io_addr(dataMemory_io_addr),
    .io_wdata(dataMemory_io_wdata),
    .io_rdata(dataMemory_io_rdata),
    .io_memRead(dataMemory_io_memRead),
    .io_memWrite(dataMemory_io_memWrite),
    .io_funct3(dataMemory_io_funct3)
  );
  assign io_pc = pcReg; // @[RV32ICore.scala 305:9]
  assign io_nextPc = redirect ? datapath_io_nextPc : sequentialPC; // @[RV32ICore.scala 310:19]
  assign io_writeBack = ifexValid ? datapath_io_writeBack : 32'h0; // @[RV32ICore.scala 319:22]
  assign io_debugInstr = ifexInstr; // @[RV32ICore.scala 337:17]
  assign io_debugX1 = datapath_io_debugX1; // @[RV32ICore.scala 344:14]
  assign io_debugX2 = datapath_io_debugX2; // @[RV32ICore.scala 345:14]
  assign io_debugX3 = datapath_io_debugX3; // @[RV32ICore.scala 346:14]
  assign io_debugX4 = datapath_io_debugX4; // @[RV32ICore.scala 347:14]
  assign io_debugX5 = datapath_io_debugX5; // @[RV32ICore.scala 348:14]
  assign io_debugX6 = datapath_io_debugX6; // @[RV32ICore.scala 349:14]
  assign io_debugALU = datapath_io_debugALU; // @[RV32ICore.scala 356:15]
  assign io_debugImm = datapath_io_debugImm; // @[RV32ICore.scala 358:15]
  assign io_debugFetchPC = pcReg; // @[RV32ICore.scala 367:19]
  assign io_debugExecPC = ifexPC; // @[RV32ICore.scala 371:18]
  assign io_debugValid = ifexValid; // @[RV32ICore.scala 375:17]
  assign io_debugFlush = ifexValid & _redirect_T; // @[RV32ICore.scala 216:15]
  assign instructionMemory_clock = clock;
  assign instructionMemory_io_addr = pcReg; // @[RV32ICore.scala 89:29]
  assign datapath_clock = clock;
  assign datapath_reset = reset;
  assign datapath_io_valid = ifexValid; // @[RV32ICore.scala 153:21]
  assign datapath_io_instr = ifexInstr; // @[RV32ICore.scala 155:21]
  assign datapath_io_pc = ifexPC; // @[RV32ICore.scala 157:18]
  assign datapath_io_memRdata = dataMemory_io_rdata; // @[RV32ICore.scala 185:24]
  assign dataMemory_clock = clock;
  assign dataMemory_io_addr = datapath_io_memAddr; // @[RV32ICore.scala 170:22]
  assign dataMemory_io_wdata = datapath_io_memWdata; // @[RV32ICore.scala 173:23]
  assign dataMemory_io_memRead = datapath_io_memRead; // @[RV32ICore.scala 176:25]
  assign dataMemory_io_memWrite = datapath_io_memWrite; // @[RV32ICore.scala 179:26]
  assign dataMemory_io_funct3 = datapath_io_memFunct3; // @[RV32ICore.scala 182:24]
  always @(posedge clock) begin
    if (reset) begin // @[RV32ICore.scala 85:22]
      pcReg <= 32'h0; // @[RV32ICore.scala 85:22]
    end else if (redirect) begin // @[RV32ICore.scala 234:18]
      pcReg <= datapath_io_nextPc; // @[RV32ICore.scala 238:11]
    end else begin
      pcReg <= sequentialPC; // @[RV32ICore.scala 244:11]
    end
    if (reset) begin // @[RV32ICore.scala 118:26]
      ifexValid <= 1'h0; // @[RV32ICore.scala 118:26]
    end else if (redirect) begin // @[RV32ICore.scala 263:18]
      ifexValid <= 1'h0; // @[RV32ICore.scala 279:15]
    end else begin
      ifexValid <= 1'h1; // @[RV32ICore.scala 291:15]
    end
    if (reset) begin // @[RV32ICore.scala 121:12]
      ifexPC <= 32'h0; // @[RV32ICore.scala 121:12]
    end else if (redirect) begin // @[RV32ICore.scala 263:18]
      ifexPC <= 32'h0; // @[RV32ICore.scala 283:12]
    end else begin
      ifexPC <= pcReg; // @[RV32ICore.scala 295:12]
    end
    if (reset) begin // @[RV32ICore.scala 135:12]
      ifexInstr <= 32'h13; // @[RV32ICore.scala 135:12]
    end else if (redirect) begin // @[RV32ICore.scala 263:18]
      ifexInstr <= 32'h13; // @[RV32ICore.scala 281:15]
    end else begin
      ifexInstr <= instructionMemory_io_instr; // @[RV32ICore.scala 293:15]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  pcReg = _RAND_0[31:0];
  _RAND_1 = {1{`RANDOM}};
  ifexValid = _RAND_1[0:0];
  _RAND_2 = {1{`RANDOM}};
  ifexPC = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  ifexInstr = _RAND_3[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
