// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VRV32ICore.h for the primary calling header

#include "VRV32ICore__pch.h"
#include "VRV32ICore___024root.h"

VL_ATTR_COLD void VRV32ICore___024root___eval_static(VRV32ICore___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root___eval_static\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

VL_ATTR_COLD void VRV32ICore___024root___eval_initial__TOP(VRV32ICore___024root* vlSelf);
VL_ATTR_COLD void VRV32ICore___024root____Vm_traceActivitySetAll(VRV32ICore___024root* vlSelf);

VL_ATTR_COLD void VRV32ICore___024root___eval_initial(VRV32ICore___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root___eval_initial\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    VRV32ICore___024root___eval_initial__TOP(vlSelf);
    VRV32ICore___024root____Vm_traceActivitySetAll(vlSelf);
    vlSelfRef.__Vtrigprevexpr___TOP__clock__0 = vlSelfRef.clock;
}

VL_ATTR_COLD void VRV32ICore___024root___eval_initial__TOP(VRV32ICore___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root___eval_initial__TOP\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    VlWide<3>/*95:0*/ __Vtemp_1;
    // Body
    __Vtemp_1[0U] = 0x2e686578U;
    __Vtemp_1[1U] = 0x6d6f7279U;
    __Vtemp_1[2U] = 0x6d65U;
    VL_READMEM_N(true, 32, 256, 0, VL_CVT_PACK_STR_NW(3, __Vtemp_1)
                 ,  &(vlSelfRef.RV32ICore__DOT__instructionMemory__DOT__mem)
                 , 0, ~0ULL);
}

VL_ATTR_COLD void VRV32ICore___024root___eval_final(VRV32ICore___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root___eval_final\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
VL_ATTR_COLD void VRV32ICore___024root___dump_triggers__stl(VRV32ICore___024root* vlSelf);
#endif  // VL_DEBUG
VL_ATTR_COLD bool VRV32ICore___024root___eval_phase__stl(VRV32ICore___024root* vlSelf);

VL_ATTR_COLD void VRV32ICore___024root___eval_settle(VRV32ICore___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root___eval_settle\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ __VstlIterCount;
    CData/*0:0*/ __VstlContinue;
    // Body
    __VstlIterCount = 0U;
    vlSelfRef.__VstlFirstIteration = 1U;
    __VstlContinue = 1U;
    while (__VstlContinue) {
        if (VL_UNLIKELY((0x64U < __VstlIterCount))) {
#ifdef VL_DEBUG
            VRV32ICore___024root___dump_triggers__stl(vlSelf);
#endif
            VL_FATAL_MT("RV32ICore.sv", 1131, "", "Settle region did not converge.");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        __VstlContinue = 0U;
        if (VRV32ICore___024root___eval_phase__stl(vlSelf)) {
            __VstlContinue = 1U;
        }
        vlSelfRef.__VstlFirstIteration = 0U;
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void VRV32ICore___024root___dump_triggers__stl(VRV32ICore___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root___dump_triggers__stl\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VstlTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VstlTriggered.word(0U))) {
        VL_DBG_MSGF("         'stl' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void VRV32ICore___024root___stl_sequent__TOP__0(VRV32ICore___024root* vlSelf);

VL_ATTR_COLD void VRV32ICore___024root___eval_stl(VRV32ICore___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root___eval_stl\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VstlTriggered.word(0U))) {
        VRV32ICore___024root___stl_sequent__TOP__0(vlSelf);
        VRV32ICore___024root____Vm_traceActivitySetAll(vlSelf);
    }
}

VL_ATTR_COLD void VRV32ICore___024root___stl_sequent__TOP__0(VRV32ICore___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root___stl_sequent__TOP__0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*4:0*/ RV32ICore__DOT__datapath__DOT__control__DOT___GEN_15;
    RV32ICore__DOT__datapath__DOT__control__DOT___GEN_15 = 0;
    IData/*31:0*/ RV32ICore__DOT__datapath__DOT__immGen__DOT___GEN_4;
    RV32ICore__DOT__datapath__DOT__immGen__DOT___GEN_4 = 0;
    IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_13;
    RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_13 = 0;
    IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_26;
    RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_26 = 0;
    IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_31;
    RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_31 = 0;
    IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_45;
    RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_45 = 0;
    IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_58;
    RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_58 = 0;
    QData/*62:0*/ RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_38;
    RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_38 = 0;
    VlWide<4>/*127:0*/ __Vtemp_1;
    VlWide<4>/*127:0*/ __Vtemp_2;
    VlWide<4>/*127:0*/ __Vtemp_3;
    VlWide<4>/*127:0*/ __Vtemp_4;
    VlWide<4>/*127:0*/ __Vtemp_5;
    VlWide<4>/*127:0*/ __Vtemp_6;
    VlWide<4>/*127:0*/ __Vtemp_7;
    VlWide<4>/*127:0*/ __Vtemp_8;
    // Body
    vlSelfRef.io_pc = vlSelfRef.RV32ICore__DOT__pcReg;
    vlSelfRef.io_debugInstr = vlSelfRef.RV32ICore__DOT__ifexInstr;
    vlSelfRef.io_debugX1 = vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_1;
    vlSelfRef.io_debugX2 = vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_2;
    vlSelfRef.io_debugX3 = vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_3;
    vlSelfRef.io_debugX4 = vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_4;
    vlSelfRef.io_debugX5 = vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_5;
    vlSelfRef.io_debugX6 = vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_6;
    vlSelfRef.io_debugFetchPC = vlSelfRef.RV32ICore__DOT__pcReg;
    vlSelfRef.io_debugExecPC = vlSelfRef.RV32ICore__DOT__ifexPC;
    vlSelfRef.io_debugValid = vlSelfRef.RV32ICore__DOT__ifexValid;
    vlSelfRef.RV32ICore__DOT__sequentialPC = ((IData)(4U) 
                                              + vlSelfRef.RV32ICore__DOT__pcReg);
    vlSelfRef.RV32ICore__DOT__datapath_io_memWrite 
        = (((0x33U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
            & ((0x13U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
               & ((3U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                  & (0x23U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr))))) 
           & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid));
    vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_memRead 
        = ((0x33U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
           & ((0x13U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
              & (3U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr))));
    vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jalr 
        = ((0x33U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
           & ((0x13U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
              & ((3U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                 & ((0x23U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                    & ((0x63U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                       & ((0x6fU != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                          & (0x67U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr))))))));
    vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jump 
        = ((0x33U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
           & ((0x13U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
              & ((3U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                 & ((0x23U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                    & ((0x63U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                       & (0x6fU == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)))))));
    RV32ICore__DOT__datapath__DOT__control__DOT___GEN_15 
        = ((2U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                         >> 0xcU))) ? ((1U == (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                               >> 0x19U))
                                        ? 0xcU : 3U)
            : ((3U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                             >> 0xcU))) ? ((1U == (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                   >> 0x19U))
                                            ? 0xdU : 4U)
                : ((4U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                 >> 0xcU))) ? ((1U 
                                                == 
                                                (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                 >> 0x19U))
                                                ? 0x10U
                                                : 5U)
                    : ((5U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                     >> 0xcU))) ? (
                                                   (1U 
                                                    == 
                                                    (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                     >> 0x19U))
                                                    ? 0x11U
                                                    : 
                                                   ((0x20U 
                                                     == 
                                                     (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                      >> 0x19U))
                                                     ? 7U
                                                     : 6U))
                        : ((6U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                         >> 0xcU)))
                            ? ((1U == (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                       >> 0x19U)) ? 0x12U
                                : 8U) : ((7U == (7U 
                                                 & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                    >> 0xcU)))
                                          ? ((1U == 
                                              (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                               >> 0x19U))
                                              ? 0x13U
                                              : 9U)
                                          : 0U))))));
    vlSelfRef.RV32ICore__DOT__datapath__DOT__control__DOT___GEN_37 
        = ((0x67U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
           | ((0x37U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
              | (0x17U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr))));
    RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_45 
        = ((0xdU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                              >> 0x14U))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_13
            : ((0xcU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                  >> 0x14U))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_12
                : ((0xbU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                      >> 0x14U))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_11
                    : ((0xaU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                          >> 0x14U)))
                        ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_10
                        : ((9U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                            >> 0x14U)))
                            ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_9
                            : ((8U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                >> 0x14U)))
                                ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_8
                                : ((7U == (0x1fU & 
                                           (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                            >> 0x14U)))
                                    ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_7
                                    : ((6U == (0x1fU 
                                               & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                  >> 0x14U)))
                                        ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_6
                                        : ((5U == (0x1fU 
                                                   & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                      >> 0x14U)))
                                            ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_5
                                            : ((4U 
                                                == 
                                                (0x1fU 
                                                 & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                    >> 0x14U)))
                                                ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_4
                                                : (
                                                   (3U 
                                                    == 
                                                    (0x1fU 
                                                     & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                        >> 0x14U)))
                                                    ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_3
                                                    : 
                                                   ((2U 
                                                     == 
                                                     (0x1fU 
                                                      & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                         >> 0x14U)))
                                                     ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_2
                                                     : 
                                                    ((1U 
                                                      == 
                                                      (0x1fU 
                                                       & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                          >> 0x14U)))
                                                      ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_1
                                                      : vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_0)))))))))))));
    vlSelfRef.RV32ICore__DOT__datapath__DOT__immGen__DOT__iImm 
        = ((((vlSelfRef.RV32ICore__DOT__ifexInstr >> 0x1fU)
              ? 0xfffffU : 0U) << 0xcU) | (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                           >> 0x14U));
    RV32ICore__DOT__datapath__DOT__immGen__DOT___GEN_4 
        = ((0x23U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr))
            ? ((((vlSelfRef.RV32ICore__DOT__ifexInstr 
                  >> 0x1fU) ? 0xfffffU : 0U) << 0xcU) 
               | ((0xfe0U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                             >> 0x14U)) | (0x1fU & 
                                           (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                            >> 7U))))
            : ((0x63U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr))
                ? ((((vlSelfRef.RV32ICore__DOT__ifexInstr 
                      >> 0x1fU) ? 0x7ffffU : 0U) << 0xdU) 
                   | (((0x1000U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                   >> 0x13U)) | (0x800U 
                                                 & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                    << 4U))) 
                      | ((0x7e0U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                    >> 0x14U)) | (0x1eU 
                                                  & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                     >> 7U)))))
                : ((0x37U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr))
                    ? (0xfffff000U & vlSelfRef.RV32ICore__DOT__ifexInstr)
                    : ((0x17U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr))
                        ? (0xfffff000U & vlSelfRef.RV32ICore__DOT__ifexInstr)
                        : ((0x6fU == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr))
                            ? (((((vlSelfRef.RV32ICore__DOT__ifexInstr 
                                   >> 0x1fU) ? 0x7ffU
                                   : 0U) << 0x15U) 
                                | (0x100000U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                >> 0xbU))) 
                               | (((0xff000U & vlSelfRef.RV32ICore__DOT__ifexInstr) 
                                   | (0x800U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                >> 9U))) 
                                  | (0x7feU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                               >> 0x14U))))
                            : 0U)))));
    RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_13 
        = ((0xdU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                              >> 0xfU))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_13
            : ((0xcU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                  >> 0xfU))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_12
                : ((0xbU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                      >> 0xfU))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_11
                    : ((0xaU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                          >> 0xfU)))
                        ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_10
                        : ((9U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                            >> 0xfU)))
                            ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_9
                            : ((8U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                >> 0xfU)))
                                ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_8
                                : ((7U == (0x1fU & 
                                           (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                            >> 0xfU)))
                                    ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_7
                                    : ((6U == (0x1fU 
                                               & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                  >> 0xfU)))
                                        ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_6
                                        : ((5U == (0x1fU 
                                                   & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                      >> 0xfU)))
                                            ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_5
                                            : ((4U 
                                                == 
                                                (0x1fU 
                                                 & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                    >> 0xfU)))
                                                ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_4
                                                : (
                                                   (3U 
                                                    == 
                                                    (0x1fU 
                                                     & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                        >> 0xfU)))
                                                    ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_3
                                                    : 
                                                   ((2U 
                                                     == 
                                                     (0x1fU 
                                                      & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                         >> 0xfU)))
                                                     ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_2
                                                     : 
                                                    ((1U 
                                                      == 
                                                      (0x1fU 
                                                       & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                          >> 0xfU)))
                                                      ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_1
                                                      : vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_0)))))))))))));
    vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem_MPORT_1_en 
        = ((IData)(vlSelfRef.RV32ICore__DOT__datapath_io_memWrite) 
           & (IData)(((0x1000U == (0x7000U & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                      & (0U != (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                      >> 0xcU))))));
    vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem_MPORT_3_en 
        = ((IData)(vlSelfRef.RV32ICore__DOT__datapath_io_memWrite) 
           & ((0U != (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                            >> 0xcU))) & (IData)(((0x2000U 
                                                   == 
                                                   (0x7000U 
                                                    & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                                  & (1U 
                                                     != 
                                                     (7U 
                                                      & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                         >> 0xcU)))))));
    vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp 
        = ((0x33U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr))
            ? ((0U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                             >> 0xcU))) ? ((1U == (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                   >> 0x19U))
                                            ? 0xaU : 
                                           ((0x20U 
                                             == (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                 >> 0x19U))
                                             ? 1U : 0U))
                : ((1U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                 >> 0xcU))) ? ((1U 
                                                == 
                                                (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                 >> 0x19U))
                                                ? 0xbU
                                                : 2U)
                    : (IData)(RV32ICore__DOT__datapath__DOT__control__DOT___GEN_15)))
            : ((0x13U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr))
                ? ((0U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                 >> 0xcU))) ? 0U : 
                   ((2U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                  >> 0xcU))) ? 3U : 
                    ((3U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                   >> 0xcU))) ? 4U : 
                     ((4U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                    >> 0xcU))) ? 5U
                       : ((6U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                        >> 0xcU))) ? 8U
                           : ((7U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                            >> 0xcU)))
                               ? 9U : ((1U == (7U & 
                                               (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                >> 0xcU)))
                                        ? 2U : ((5U 
                                                 == 
                                                 (7U 
                                                  & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                     >> 0xcU)))
                                                 ? 
                                                ((0x20U 
                                                  == 
                                                  (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                   >> 0x19U))
                                                  ? 7U
                                                  : 6U)
                                                 : 0U))))))))
                : ((3U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr))
                    ? 0U : ((0x23U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr))
                             ? 0U : ((0x63U == (0x7fU 
                                                & vlSelfRef.RV32ICore__DOT__ifexInstr))
                                      ? ((0U == (7U 
                                                 & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                    >> 0xcU)))
                                          ? 0xeU : 
                                         ((1U == (7U 
                                                  & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                     >> 0xcU)))
                                           ? 0xfU : 
                                          ((4U == (7U 
                                                   & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                      >> 0xcU)))
                                            ? 3U : 
                                           ((5U == 
                                             (7U & 
                                              (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                               >> 0xcU)))
                                             ? 3U : 
                                            ((6U == 
                                              (7U & 
                                               (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                >> 0xcU)))
                                              ? 4U : 
                                             ((7U == 
                                               (7U 
                                                & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                   >> 0xcU)))
                                               ? 4U
                                               : 0U))))))
                                      : 0U)))));
    vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_writeEnable 
        = (((0x33U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
            | ((0x13U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
               | ((3U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                  | ((0x23U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                     & ((0x63U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                        & ((0x6fU == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                           | (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control__DOT___GEN_37))))))) 
           & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid));
    RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_58 
        = ((0x1aU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                               >> 0x14U))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_26
            : ((0x19U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                   >> 0x14U))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_25
                : ((0x18U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                       >> 0x14U))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_24
                    : ((0x17U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                           >> 0x14U)))
                        ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_23
                        : ((0x16U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                               >> 0x14U)))
                            ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_22
                            : ((0x15U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                   >> 0x14U)))
                                ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_21
                                : ((0x14U == (0x1fU 
                                              & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                 >> 0x14U)))
                                    ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_20
                                    : ((0x13U == (0x1fU 
                                                  & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                     >> 0x14U)))
                                        ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_19
                                        : ((0x12U == 
                                            (0x1fU 
                                             & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                >> 0x14U)))
                                            ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_18
                                            : ((0x11U 
                                                == 
                                                (0x1fU 
                                                 & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                    >> 0x14U)))
                                                ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_17
                                                : (
                                                   (0x10U 
                                                    == 
                                                    (0x1fU 
                                                     & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                        >> 0x14U)))
                                                    ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_16
                                                    : 
                                                   ((0xfU 
                                                     == 
                                                     (0x1fU 
                                                      & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                         >> 0x14U)))
                                                     ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_15
                                                     : 
                                                    ((0xeU 
                                                      == 
                                                      (0x1fU 
                                                       & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                          >> 0x14U)))
                                                      ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_14
                                                      : RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_45)))))))))))));
    vlSelfRef.RV32ICore__DOT__datapath__DOT__immGen_io_imm 
        = ((3U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr))
            ? vlSelfRef.RV32ICore__DOT__datapath__DOT__immGen__DOT__iImm
            : ((0x13U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr))
                ? vlSelfRef.RV32ICore__DOT__datapath__DOT__immGen__DOT__iImm
                : ((0x67U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr))
                    ? vlSelfRef.RV32ICore__DOT__datapath__DOT__immGen__DOT__iImm
                    : RV32ICore__DOT__datapath__DOT__immGen__DOT___GEN_4)));
    RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_26 
        = ((0x1aU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                               >> 0xfU))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_26
            : ((0x19U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                   >> 0xfU))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_25
                : ((0x18U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                       >> 0xfU))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_24
                    : ((0x17U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                           >> 0xfU)))
                        ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_23
                        : ((0x16U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                               >> 0xfU)))
                            ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_22
                            : ((0x15U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                   >> 0xfU)))
                                ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_21
                                : ((0x14U == (0x1fU 
                                              & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                 >> 0xfU)))
                                    ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_20
                                    : ((0x13U == (0x1fU 
                                                  & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                     >> 0xfU)))
                                        ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_19
                                        : ((0x12U == 
                                            (0x1fU 
                                             & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                >> 0xfU)))
                                            ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_18
                                            : ((0x11U 
                                                == 
                                                (0x1fU 
                                                 & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                    >> 0xfU)))
                                                ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_17
                                                : (
                                                   (0x10U 
                                                    == 
                                                    (0x1fU 
                                                     & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                        >> 0xfU)))
                                                    ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_16
                                                    : 
                                                   ((0xfU 
                                                     == 
                                                     (0x1fU 
                                                      & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                         >> 0xfU)))
                                                     ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_15
                                                     : 
                                                    ((0xeU 
                                                      == 
                                                      (0x1fU 
                                                       & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                          >> 0xfU)))
                                                      ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_14
                                                      : RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_13)))))))))))));
    vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_63 
        = ((0x1fU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                               >> 0x14U))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_31
            : ((0x1eU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                   >> 0x14U))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_30
                : ((0x1dU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                       >> 0x14U))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_29
                    : ((0x1cU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                           >> 0x14U)))
                        ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_28
                        : ((0x1bU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                               >> 0x14U)))
                            ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_27
                            : RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_58)))));
    vlSelfRef.io_debugImm = vlSelfRef.RV32ICore__DOT__datapath__DOT__immGen_io_imm;
    vlSelfRef.RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTarget 
        = (vlSelfRef.RV32ICore__DOT__datapath__DOT__immGen_io_imm 
           + vlSelfRef.RV32ICore__DOT__ifexPC);
    RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_31 
        = ((0x1fU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                               >> 0xfU))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_31
            : ((0x1eU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                   >> 0xfU))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_30
                : ((0x1dU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                       >> 0xfU))) ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_29
                    : ((0x1cU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                           >> 0xfU)))
                        ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_28
                        : ((0x1bU == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                               >> 0xfU)))
                            ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_27
                            : RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_26)))));
    if ((0U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                         >> 0x14U)))) {
        vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem_MPORT_data = 0U;
        vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem_MPORT_2_data = 0U;
    } else {
        vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem_MPORT_data 
            = (0xffU & vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_63);
        vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem_MPORT_2_data 
            = (0xffU & (vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_63 
                        >> 8U));
    }
    vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b 
        = (((0x33U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
            & ((0x13U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
               | ((3U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                  | ((0x23U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                     | ((0x63U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                        & ((0x6fU != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                           & (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control__DOT___GEN_37)))))))
            ? vlSelfRef.RV32ICore__DOT__datapath__DOT__immGen_io_imm
            : ((0U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                >> 0x14U))) ? 0U : vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_63));
    vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1 
        = ((0U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                            >> 0xfU))) ? 0U : RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_31);
    vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___T_3 
        = ((0x80000000U == vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1) 
           & (0xffffffffU == vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b));
    vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___divResult_T_1 
        = (0x1ffffffffULL & VL_DIVS_QQQ(33, (0x1ffffffffULL 
                                             & VL_EXTENDS_QI(33,32, vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1)), 
                                        (0x1ffffffffULL 
                                         & VL_EXTENDS_QI(33,32, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b))));
    vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__aSigned64 
        = (((QData)((IData)((((0U != (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                               >> 0xfU))) 
                              & (RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_31 
                                 >> 0x1fU)) ? 0xffffffffU
                              : 0U))) << 0x20U) | (QData)((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1)));
    VL_EXTENDS_WQ(128,64, __Vtemp_1, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__aSigned64);
    VL_EXTENDS_WQ(128,64, __Vtemp_2, (((QData)((IData)(
                                                       ((vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b 
                                                         >> 0x1fU)
                                                         ? 0xffffffffU
                                                         : 0U))) 
                                       << 0x20U) | (QData)((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b))));
    VL_MULS_WWW(128, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__mulSS, __Vtemp_1, __Vtemp_2);
    RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_38 
        = (0x7fffffffffffffffULL & ((0xaU == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                                     ? (QData)((IData)(
                                                       vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__mulSS[0U]))
                                     : ((9U == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                                         ? (QData)((IData)(
                                                           (vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1 
                                                            & vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)))
                                         : ((8U == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                                             ? (QData)((IData)(
                                                               (vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1 
                                                                | vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)))
                                             : ((7U 
                                                 == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                                                 ? (QData)((IData)(
                                                                   VL_SHIFTRS_III(32,32,5, vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1, 
                                                                                (0x1fU 
                                                                                & vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b))))
                                                 : 
                                                ((6U 
                                                  == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                                                  ? (QData)((IData)(
                                                                    (vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1 
                                                                     >> 
                                                                     (0x1fU 
                                                                      & vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b))))
                                                  : 
                                                 ((5U 
                                                   == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                                                   ? (QData)((IData)(
                                                                     (vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1 
                                                                      ^ vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)))
                                                   : 
                                                  ((4U 
                                                    == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                                                    ? (QData)((IData)(
                                                                      ((vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1 
                                                                        < vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                                                                        ? 1U
                                                                        : 0U)))
                                                    : 
                                                   ((3U 
                                                     == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                                                     ? (QData)((IData)(
                                                                       (VL_LTS_III(32, vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                                                                         ? 1U
                                                                         : 0U)))
                                                     : 
                                                    ((2U 
                                                      == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                                                      ? 
                                                     ((QData)((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1)) 
                                                      << 
                                                      (0x1fU 
                                                       & vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b))
                                                      : (QData)((IData)(
                                                                        ((1U 
                                                                          == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                                                                          ? 
                                                                         (vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1 
                                                                          - vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                                                                          : 
                                                                         ((0U 
                                                                           == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                                                                           ? 
                                                                          (vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1 
                                                                           + vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                                                                           : 0U))))))))))))));
    __Vtemp_3[0U] = vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1;
    __Vtemp_3[1U] = 0U;
    __Vtemp_3[2U] = 0U;
    __Vtemp_3[3U] = 0U;
    __Vtemp_4[0U] = vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b;
    __Vtemp_4[1U] = 0U;
    __Vtemp_4[2U] = 0U;
    __Vtemp_4[3U] = 0U;
    VL_MUL_W(4, __Vtemp_5, __Vtemp_3, __Vtemp_4);
    VL_EXTENDS_WQ(128,64, __Vtemp_6, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__aSigned64);
    VL_EXTENDS_WQ(128,64, __Vtemp_7, (QData)((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)));
    VL_MULS_WWW(128, __Vtemp_8, __Vtemp_6, __Vtemp_7);
    vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56 
        = ((0x13U == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
            ? (QData)((IData)(((0U == vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                                ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1
                                : VL_MODDIV_III(32, vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b))))
            : ((0x12U == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                ? (QData)((IData)(((0U == vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                                    ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1
                                    : ((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___T_3)
                                        ? 0U : VL_MODDIVS_III(32, vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)))))
                : ((0x11U == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                    ? (QData)((IData)(((0U == vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                                        ? 0xffffffffU
                                        : VL_DIV_III(32, vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b))))
                    : ((0x10U == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                        ? (QData)((IData)(((0U == vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                                            ? 0xffffffffU
                                            : ((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___T_3)
                                                ? 0x80000000U
                                                : (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___divResult_T_1)))))
                        : ((0xfU == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                            ? (QData)((IData)(((vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1 
                                                != vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                                                ? 1U
                                                : 0U)))
                            : ((0xeU == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                                ? (QData)((IData)((
                                                   (vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1 
                                                    == vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                                                    ? 1U
                                                    : 0U)))
                                : ((0xdU == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                                    ? (QData)((IData)(
                                                      __Vtemp_5[1U]))
                                    : ((0xcU == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                                        ? (QData)((IData)(
                                                          __Vtemp_8[1U]))
                                        : ((0xbU == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp))
                                            ? (QData)((IData)(
                                                              vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__mulSS[1U]))
                                            : RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_38)))))))));
    vlSelfRef.io_debugALU = (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56);
    vlSelfRef.RV32ICore__DOT__dataMemory__DOT____VdfgRegularize_heafa0826_0_1 
        = ((vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
            [(0x3ffU & ((IData)(1U) + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))] 
            << 8U) | vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
           [(0x3ffU & (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))]);
    vlSelfRef.RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTaken 
        = ((((0x33U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
             & ((0x13U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                & ((3U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                   & ((0x23U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                      & (0x63U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)))))) 
            & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid)) 
           & ((0U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                            >> 0xcU))) ? (1U == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))
               : ((1U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                >> 0xcU))) ? (1U == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))
                   : ((4U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                    >> 0xcU))) ? (1U 
                                                  == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))
                       : ((5U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                        >> 0xcU))) ? 
                          (0U == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))
                           : ((6U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                            >> 0xcU)))
                               ? (1U == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))
                               : ((7U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                >> 0xcU))) 
                                  & (0U == (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))))))));
    vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_writeData 
        = ((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_memRead)
            ? (((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_memRead) 
                & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid))
                ? ((0U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                 >> 0xcU))) ? ((((0x80U 
                                                  & vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                                  [
                                                  (0x3ffU 
                                                   & (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))])
                                                  ? 0xffffffU
                                                  : 0U) 
                                                << 8U) 
                                               | vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                               [(0x3ffU 
                                                 & (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))])
                    : ((1U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                     >> 0xcU))) ? (
                                                   (((0x80U 
                                                      & vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                                      [
                                                      (0x3ffU 
                                                       & ((IData)(1U) 
                                                          + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))])
                                                      ? 0xffffU
                                                      : 0U) 
                                                    << 0x10U) 
                                                   | (IData)(vlSelfRef.RV32ICore__DOT__dataMemory__DOT____VdfgRegularize_heafa0826_0_1))
                        : ((2U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                         >> 0xcU)))
                            ? ((vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                [(0x3ffU & ((IData)(3U) 
                                            + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))] 
                                << 0x18U) | ((vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                              [(0x3ffU 
                                                & ((IData)(2U) 
                                                   + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))] 
                                              << 0x10U) 
                                             | (IData)(vlSelfRef.RV32ICore__DOT__dataMemory__DOT____VdfgRegularize_heafa0826_0_1)))
                            : ((4U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                             >> 0xcU)))
                                ? vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                               [(0x3ffU & (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))]
                                : ((5U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                 >> 0xcU)))
                                    ? (IData)(vlSelfRef.RV32ICore__DOT__dataMemory__DOT____VdfgRegularize_heafa0826_0_1)
                                    : 0U))))) : 0U)
            : (((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jalr) 
                | (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jump))
                ? ((IData)(4U) + vlSelfRef.RV32ICore__DOT__ifexPC)
                : (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)));
    if (vlSelfRef.RV32ICore__DOT__ifexValid) {
        vlSelfRef.RV32ICore__DOT__datapath_io_nextPc 
            = (((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jalr) 
                & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid))
                ? (0xfffffffeU & (vlSelfRef.RV32ICore__DOT__datapath__DOT__immGen_io_imm 
                                  + vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1))
                : (((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jump) 
                    & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid))
                    ? vlSelfRef.RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTarget
                    : ((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTaken)
                        ? vlSelfRef.RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTarget
                        : ((IData)(4U) + vlSelfRef.RV32ICore__DOT__ifexPC))));
        vlSelfRef.io_writeBack = ((IData)(vlSelfRef.RV32ICore__DOT__ifexValid)
                                   ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_writeData
                                   : 0U);
        vlSelfRef.io_debugFlush = (vlSelfRef.RV32ICore__DOT__datapath_io_nextPc 
                                   != ((IData)(4U) 
                                       + vlSelfRef.RV32ICore__DOT__ifexPC));
    } else {
        vlSelfRef.RV32ICore__DOT__datapath_io_nextPc 
            = ((IData)(4U) + vlSelfRef.RV32ICore__DOT__ifexPC);
        vlSelfRef.io_writeBack = 0U;
        vlSelfRef.io_debugFlush = 0U;
    }
    vlSelfRef.io_nextPc = ((IData)(vlSelfRef.io_debugFlush)
                            ? vlSelfRef.RV32ICore__DOT__datapath_io_nextPc
                            : ((IData)(4U) + vlSelfRef.RV32ICore__DOT__pcReg));
}

VL_ATTR_COLD void VRV32ICore___024root___eval_triggers__stl(VRV32ICore___024root* vlSelf);

VL_ATTR_COLD bool VRV32ICore___024root___eval_phase__stl(VRV32ICore___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root___eval_phase__stl\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VstlExecute;
    // Body
    VRV32ICore___024root___eval_triggers__stl(vlSelf);
    __VstlExecute = vlSelfRef.__VstlTriggered.any();
    if (__VstlExecute) {
        VRV32ICore___024root___eval_stl(vlSelf);
    }
    return (__VstlExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void VRV32ICore___024root___dump_triggers__act(VRV32ICore___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root___dump_triggers__act\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VactTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 0 is active: @(posedge clock)\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void VRV32ICore___024root___dump_triggers__nba(VRV32ICore___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root___dump_triggers__nba\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VnbaTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 0 is active: @(posedge clock)\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void VRV32ICore___024root____Vm_traceActivitySetAll(VRV32ICore___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root____Vm_traceActivitySetAll\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vm_traceActivity[0U] = 1U;
    vlSelfRef.__Vm_traceActivity[1U] = 1U;
}

VL_ATTR_COLD void VRV32ICore___024root___ctor_var_reset(VRV32ICore___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root___ctor_var_reset\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelf->clock = VL_RAND_RESET_I(1);
    vlSelf->reset = VL_RAND_RESET_I(1);
    vlSelf->io_pc = VL_RAND_RESET_I(32);
    vlSelf->io_nextPc = VL_RAND_RESET_I(32);
    vlSelf->io_writeBack = VL_RAND_RESET_I(32);
    vlSelf->io_debugInstr = VL_RAND_RESET_I(32);
    vlSelf->io_debugX1 = VL_RAND_RESET_I(32);
    vlSelf->io_debugX2 = VL_RAND_RESET_I(32);
    vlSelf->io_debugX3 = VL_RAND_RESET_I(32);
    vlSelf->io_debugX4 = VL_RAND_RESET_I(32);
    vlSelf->io_debugX5 = VL_RAND_RESET_I(32);
    vlSelf->io_debugX6 = VL_RAND_RESET_I(32);
    vlSelf->io_debugALU = VL_RAND_RESET_I(32);
    vlSelf->io_debugImm = VL_RAND_RESET_I(32);
    vlSelf->io_debugFetchPC = VL_RAND_RESET_I(32);
    vlSelf->io_debugExecPC = VL_RAND_RESET_I(32);
    vlSelf->io_debugValid = VL_RAND_RESET_I(1);
    vlSelf->io_debugFlush = VL_RAND_RESET_I(1);
    vlSelf->RV32ICore__DOT__datapath_io_nextPc = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath_io_memWrite = VL_RAND_RESET_I(1);
    vlSelf->RV32ICore__DOT__pcReg = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__sequentialPC = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__ifexValid = VL_RAND_RESET_I(1);
    vlSelf->RV32ICore__DOT__ifexPC = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__ifexInstr = VL_RAND_RESET_I(32);
    for (int __Vi0 = 0; __Vi0 < 256; ++__Vi0) {
        vlSelf->RV32ICore__DOT__instructionMemory__DOT__mem[__Vi0] = VL_RAND_RESET_I(32);
    }
    vlSelf->RV32ICore__DOT__instructionMemory__DOT__initvar = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__control_io_aluOp = VL_RAND_RESET_I(5);
    vlSelf->RV32ICore__DOT__datapath__DOT__control_io_memRead = VL_RAND_RESET_I(1);
    vlSelf->RV32ICore__DOT__datapath__DOT__control_io_jump = VL_RAND_RESET_I(1);
    vlSelf->RV32ICore__DOT__datapath__DOT__control_io_jalr = VL_RAND_RESET_I(1);
    vlSelf->RV32ICore__DOT__datapath__DOT__immGen_io_imm = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile_io_writeData = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile_io_writeEnable = VL_RAND_RESET_I(1);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile_io_readData1 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__alu_io_b = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__control__DOT___GEN_37 = VL_RAND_RESET_I(1);
    vlSelf->RV32ICore__DOT__datapath__DOT__immGen__DOT__iImm = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_0 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_1 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_2 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_3 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_4 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_5 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_6 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_7 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_8 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_9 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_10 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_11 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_12 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_13 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_14 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_15 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_16 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_17 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_18 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_19 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_20 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_21 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_22 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_23 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_24 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_25 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_26 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_27 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_28 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_29 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_30 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_31 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_63 = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__alu__DOT__aSigned64 = VL_RAND_RESET_Q(64);
    VL_RAND_RESET_W(128, vlSelf->RV32ICore__DOT__datapath__DOT__alu__DOT__mulSS);
    vlSelf->RV32ICore__DOT__datapath__DOT__alu__DOT___T_3 = VL_RAND_RESET_I(1);
    vlSelf->RV32ICore__DOT__datapath__DOT__alu__DOT___divResult_T_1 = VL_RAND_RESET_Q(33);
    vlSelf->RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56 = VL_RAND_RESET_Q(63);
    vlSelf->RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTarget = VL_RAND_RESET_I(32);
    vlSelf->RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTaken = VL_RAND_RESET_I(1);
    for (int __Vi0 = 0; __Vi0 < 1024; ++__Vi0) {
        vlSelf->RV32ICore__DOT__dataMemory__DOT__mem[__Vi0] = VL_RAND_RESET_I(8);
    }
    vlSelf->RV32ICore__DOT__dataMemory__DOT__mem_MPORT_data = VL_RAND_RESET_I(8);
    vlSelf->RV32ICore__DOT__dataMemory__DOT__mem_MPORT_1_en = VL_RAND_RESET_I(1);
    vlSelf->RV32ICore__DOT__dataMemory__DOT__mem_MPORT_2_data = VL_RAND_RESET_I(8);
    vlSelf->RV32ICore__DOT__dataMemory__DOT__mem_MPORT_3_en = VL_RAND_RESET_I(1);
    vlSelf->RV32ICore__DOT__dataMemory__DOT____VdfgRegularize_heafa0826_0_1 = VL_RAND_RESET_I(16);
    vlSelf->__Vtrigprevexpr___TOP__clock__0 = VL_RAND_RESET_I(1);
    for (int __Vi0 = 0; __Vi0 < 2; ++__Vi0) {
        vlSelf->__Vm_traceActivity[__Vi0] = 0;
    }
}

VL_ATTR_COLD void VRV32ICore___024root___configure_coverage(VRV32ICore___024root* vlSelf, bool first) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root___configure_coverage\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    (void)first;  // Prevent unused variable warning
}
