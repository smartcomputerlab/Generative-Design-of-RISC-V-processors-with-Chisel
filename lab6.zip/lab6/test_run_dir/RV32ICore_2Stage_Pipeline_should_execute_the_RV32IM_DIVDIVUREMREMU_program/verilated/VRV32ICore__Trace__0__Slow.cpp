// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "VRV32ICore__Syms.h"


VL_ATTR_COLD void VRV32ICore___024root__trace_init_sub__TOP__0(VRV32ICore___024root* vlSelf, VerilatedVcd* tracep) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root__trace_init_sub__TOP__0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBit(c+128,0,"clock",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+129,0,"reset",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+130,0,"io_pc",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+131,0,"io_nextPc",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+132,0,"io_writeBack",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+133,0,"io_debugInstr",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+134,0,"io_debugX1",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+135,0,"io_debugX2",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+136,0,"io_debugX3",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+137,0,"io_debugX4",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+138,0,"io_debugX5",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+139,0,"io_debugX6",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+140,0,"io_debugALU",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+141,0,"io_debugImm",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+142,0,"io_debugFetchPC",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+143,0,"io_debugExecPC",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+144,0,"io_debugValid",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+145,0,"io_debugFlush",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->pushPrefix("RV32ICore", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+128,0,"clock",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+129,0,"reset",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+130,0,"io_pc",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+131,0,"io_nextPc",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+132,0,"io_writeBack",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+133,0,"io_debugInstr",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+134,0,"io_debugX1",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+135,0,"io_debugX2",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+136,0,"io_debugX3",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+137,0,"io_debugX4",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+138,0,"io_debugX5",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+139,0,"io_debugX6",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+140,0,"io_debugALU",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+141,0,"io_debugImm",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+142,0,"io_debugFetchPC",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+143,0,"io_debugExecPC",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+144,0,"io_debugValid",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+145,0,"io_debugFlush",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+128,0,"instructionMemory_clock",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+1,0,"instructionMemory_io_addr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+2,0,"instructionMemory_io_instr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+128,0,"datapath_clock",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+129,0,"datapath_reset",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+3,0,"datapath_io_valid",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+4,0,"datapath_io_instr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+5,0,"datapath_io_pc",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+6,0,"datapath_io_nextPc",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+7,0,"datapath_io_memRead",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+8,0,"datapath_io_memWrite",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+9,0,"datapath_io_memAddr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+10,0,"datapath_io_memWdata",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+11,0,"datapath_io_memRdata",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+12,0,"datapath_io_memFunct3",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+13,0,"datapath_io_writeBack",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+14,0,"datapath_io_debugX1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+15,0,"datapath_io_debugX2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+16,0,"datapath_io_debugX3",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+17,0,"datapath_io_debugX4",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+18,0,"datapath_io_debugX5",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+19,0,"datapath_io_debugX6",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+9,0,"datapath_io_debugALU",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+20,0,"datapath_io_debugImm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+128,0,"dataMemory_clock",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+9,0,"dataMemory_io_addr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+10,0,"dataMemory_io_wdata",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+11,0,"dataMemory_io_rdata",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+7,0,"dataMemory_io_memRead",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+8,0,"dataMemory_io_memWrite",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+12,0,"dataMemory_io_funct3",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+1,0,"pcReg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+21,0,"sequentialPC",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+3,0,"ifexValid",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+5,0,"ifexPC",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+4,0,"ifexInstr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+22,0,"stage2SequentialPC",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+145,0,"redirect",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->pushPrefix("dataMemory", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+128,0,"clock",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+9,0,"io_addr",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+10,0,"io_wdata",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+11,0,"io_rdata",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+7,0,"io_memRead",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+8,0,"io_memWrite",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+12,0,"io_funct3",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+146,0,"mem_byte0_en",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+23,0,"mem_byte0_addr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 9,0);
    tracep->declBus(c+24,0,"mem_byte0_data",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBit(c+146,0,"mem_byte1_en",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+25,0,"mem_byte1_addr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 9,0);
    tracep->declBus(c+26,0,"mem_byte1_data",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBit(c+146,0,"mem_byte2_en",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+27,0,"mem_byte2_addr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 9,0);
    tracep->declBus(c+28,0,"mem_byte2_data",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBit(c+146,0,"mem_byte3_en",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+29,0,"mem_byte3_addr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 9,0);
    tracep->declBus(c+30,0,"mem_byte3_data",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+31,0,"mem_MPORT_data",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+23,0,"mem_MPORT_addr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 9,0);
    tracep->declBit(c+146,0,"mem_MPORT_mask",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+32,0,"mem_MPORT_en",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+31,0,"mem_MPORT_1_data",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+23,0,"mem_MPORT_1_addr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 9,0);
    tracep->declBit(c+146,0,"mem_MPORT_1_mask",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+33,0,"mem_MPORT_1_en",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+34,0,"mem_MPORT_2_data",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+25,0,"mem_MPORT_2_addr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 9,0);
    tracep->declBit(c+146,0,"mem_MPORT_2_mask",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+33,0,"mem_MPORT_2_en",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+31,0,"mem_MPORT_3_data",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+23,0,"mem_MPORT_3_addr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 9,0);
    tracep->declBit(c+146,0,"mem_MPORT_3_mask",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+35,0,"mem_MPORT_3_en",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+34,0,"mem_MPORT_4_data",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+25,0,"mem_MPORT_4_addr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 9,0);
    tracep->declBit(c+146,0,"mem_MPORT_4_mask",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+35,0,"mem_MPORT_4_en",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+36,0,"mem_MPORT_5_data",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+27,0,"mem_MPORT_5_addr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 9,0);
    tracep->declBit(c+146,0,"mem_MPORT_5_mask",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+35,0,"mem_MPORT_5_en",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+37,0,"mem_MPORT_6_data",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+29,0,"mem_MPORT_6_addr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 9,0);
    tracep->declBit(c+146,0,"mem_MPORT_6_mask",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+35,0,"mem_MPORT_6_en",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+38,0,"loadData",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->popPrefix();
    tracep->pushPrefix("datapath", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+128,0,"clock",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+129,0,"reset",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+3,0,"io_valid",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+4,0,"io_instr",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+5,0,"io_pc",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+6,0,"io_nextPc",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+7,0,"io_memRead",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+8,0,"io_memWrite",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+9,0,"io_memAddr",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+10,0,"io_memWdata",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+11,0,"io_memRdata",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+12,0,"io_memFunct3",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+13,0,"io_writeBack",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+14,0,"io_debugX1",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+15,0,"io_debugX2",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+16,0,"io_debugX3",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+17,0,"io_debugX4",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+18,0,"io_debugX5",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+19,0,"io_debugX6",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+9,0,"io_debugALU",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+20,0,"io_debugImm",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+4,0,"decoder_io_instr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+39,0,"decoder_io_rs1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+40,0,"decoder_io_rs2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+41,0,"decoder_io_rd",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+12,0,"decoder_io_funct3",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+4,0,"control_io_instr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+42,0,"control_io_aluOp",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBit(c+43,0,"control_io_aluSrc",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+44,0,"control_io_memRead",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+45,0,"control_io_memWrite",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+44,0,"control_io_memToReg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+46,0,"control_io_regWrite",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+47,0,"control_io_branch",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+48,0,"control_io_jump",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+49,0,"control_io_jalr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+4,0,"immGen_io_instr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+20,0,"immGen_io_imm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+128,0,"regFile_clock",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+129,0,"regFile_reset",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+39,0,"regFile_io_rs1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+40,0,"regFile_io_rs2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+41,0,"regFile_io_rd",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+50,0,"regFile_io_writeData",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+51,0,"regFile_io_writeEnable",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+52,0,"regFile_io_readData1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+10,0,"regFile_io_readData2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+14,0,"regFile_io_debugRead_1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+15,0,"regFile_io_debugRead_2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+16,0,"regFile_io_debugRead_3",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+17,0,"regFile_io_debugRead_4",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+18,0,"regFile_io_debugRead_5",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+19,0,"regFile_io_debugRead_6",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+52,0,"alu_io_a",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+53,0,"alu_io_b",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+42,0,"alu_io_op",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+9,0,"alu_io_y",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+5,0,"pcUpdate_io_pc",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+52,0,"pcUpdate_io_rs1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+20,0,"pcUpdate_io_imm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+12,0,"pcUpdate_io_funct3",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+54,0,"pcUpdate_io_branch",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+55,0,"pcUpdate_io_jump",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+56,0,"pcUpdate_io_jalr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+9,0,"pcUpdate_io_aluResult",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+57,0,"pcUpdate_io_nextPc",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+50,0,"writeBackData",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->pushPrefix("alu", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+52,0,"io_a",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+53,0,"io_b",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+42,0,"io_op",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+9,0,"io_y",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+58,0,"shamt",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declQuad(c+59,0,"aSigned64",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 63,0);
    tracep->declQuad(c+61,0,"bSigned64",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 63,0);
    tracep->declQuad(c+63,0,"aUnsigned64",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 63,0);
    tracep->declQuad(c+65,0,"bUnsigned64",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 63,0);
    tracep->declArray(c+67,0,"mulSS",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 127,0);
    tracep->declArray(c+71,0,"mulUU",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 127,0);
    tracep->declArray(c+75,0,"mulHSU",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 127,0);
    tracep->declBus(c+79,0,"mulLow",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+80,0,"mulHighSS",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+81,0,"mulHighSU",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+82,0,"mulHighUU",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+83,0,"divuResult",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+84,0,"remResult",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+85,0,"remuResult",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+86,0,"equal",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+87,0,"notEqual",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+88,0,"divResult",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->popPrefix();
    tracep->pushPrefix("control", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+4,0,"io_instr",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+42,0,"io_aluOp",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBit(c+43,0,"io_aluSrc",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+44,0,"io_memRead",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+45,0,"io_memWrite",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+44,0,"io_memToReg",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+46,0,"io_regWrite",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+47,0,"io_branch",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+48,0,"io_jump",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+49,0,"io_jalr",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+89,0,"opcode",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 6,0);
    tracep->declBus(c+12,0,"funct3",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+90,0,"funct7",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 6,0);
    tracep->popPrefix();
    tracep->pushPrefix("decoder", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+4,0,"io_instr",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+39,0,"io_rs1",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+40,0,"io_rs2",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+41,0,"io_rd",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+12,0,"io_funct3",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->popPrefix();
    tracep->pushPrefix("immGen", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+4,0,"io_instr",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+20,0,"io_imm",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+89,0,"opcode",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 6,0);
    tracep->declBus(c+91,0,"iImm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+92,0,"sImm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+93,0,"bImm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+94,0,"uImm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+95,0,"jImm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->popPrefix();
    tracep->pushPrefix("pcUpdate", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+5,0,"io_pc",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+52,0,"io_rs1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+20,0,"io_imm",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+12,0,"io_funct3",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+54,0,"io_branch",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+55,0,"io_jump",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+56,0,"io_jalr",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+9,0,"io_aluResult",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+57,0,"io_nextPc",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+22,0,"pcPlus4",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+96,0,"branchTarget",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+97,0,"jalrTarget",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+98,0,"branchTaken",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->popPrefix();
    tracep->pushPrefix("regFile", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+128,0,"clock",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+129,0,"reset",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+39,0,"io_rs1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+40,0,"io_rs2",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+41,0,"io_rd",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+50,0,"io_writeData",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+51,0,"io_writeEnable",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+52,0,"io_readData1",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+10,0,"io_readData2",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+14,0,"io_debugRead_1",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+15,0,"io_debugRead_2",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+16,0,"io_debugRead_3",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+17,0,"io_debugRead_4",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+18,0,"io_debugRead_5",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+19,0,"io_debugRead_6",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+99,0,"regs_0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+14,0,"regs_1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+15,0,"regs_2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+16,0,"regs_3",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+17,0,"regs_4",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+18,0,"regs_5",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+19,0,"regs_6",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+100,0,"regs_7",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+101,0,"regs_8",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+102,0,"regs_9",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+103,0,"regs_10",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+104,0,"regs_11",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+105,0,"regs_12",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+106,0,"regs_13",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+107,0,"regs_14",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+108,0,"regs_15",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+109,0,"regs_16",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+110,0,"regs_17",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+111,0,"regs_18",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+112,0,"regs_19",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+113,0,"regs_20",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+114,0,"regs_21",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+115,0,"regs_22",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+116,0,"regs_23",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+117,0,"regs_24",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+118,0,"regs_25",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+119,0,"regs_26",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+120,0,"regs_27",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+121,0,"regs_28",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+122,0,"regs_29",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+123,0,"regs_30",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+124,0,"regs_31",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->popPrefix();
    tracep->popPrefix();
    tracep->pushPrefix("instructionMemory", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+128,0,"clock",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+1,0,"io_addr",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+2,0,"io_instr",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+146,0,"mem_io_instr_MPORT_en",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+125,0,"mem_io_instr_MPORT_addr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+126,0,"mem_io_instr_MPORT_data",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+127,0,"wordAddr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+147,0,"initvar",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::INTEGER, false,-1, 31,0);
    tracep->popPrefix();
    tracep->popPrefix();
}

VL_ATTR_COLD void VRV32ICore___024root__trace_init_top(VRV32ICore___024root* vlSelf, VerilatedVcd* tracep) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root__trace_init_top\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    VRV32ICore___024root__trace_init_sub__TOP__0(vlSelf, tracep);
}

VL_ATTR_COLD void VRV32ICore___024root__trace_const_0(void* voidSelf, VerilatedVcd::Buffer* bufp);
VL_ATTR_COLD void VRV32ICore___024root__trace_full_0(void* voidSelf, VerilatedVcd::Buffer* bufp);
void VRV32ICore___024root__trace_chg_0(void* voidSelf, VerilatedVcd::Buffer* bufp);
void VRV32ICore___024root__trace_cleanup(void* voidSelf, VerilatedVcd* /*unused*/);

VL_ATTR_COLD void VRV32ICore___024root__trace_register(VRV32ICore___024root* vlSelf, VerilatedVcd* tracep) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root__trace_register\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    tracep->addConstCb(&VRV32ICore___024root__trace_const_0, 0U, vlSelf);
    tracep->addFullCb(&VRV32ICore___024root__trace_full_0, 0U, vlSelf);
    tracep->addChgCb(&VRV32ICore___024root__trace_chg_0, 0U, vlSelf);
    tracep->addCleanupCb(&VRV32ICore___024root__trace_cleanup, vlSelf);
}

VL_ATTR_COLD void VRV32ICore___024root__trace_const_0_sub_0(VRV32ICore___024root* vlSelf, VerilatedVcd::Buffer* bufp);

VL_ATTR_COLD void VRV32ICore___024root__trace_const_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root__trace_const_0\n"); );
    // Init
    VRV32ICore___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<VRV32ICore___024root*>(voidSelf);
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    VRV32ICore___024root__trace_const_0_sub_0((&vlSymsp->TOP), bufp);
}

VL_ATTR_COLD void VRV32ICore___024root__trace_const_0_sub_0(VRV32ICore___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root__trace_const_0_sub_0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode);
    // Body
    bufp->fullBit(oldp+146,(1U));
    bufp->fullIData(oldp+147,(vlSelfRef.RV32ICore__DOT__instructionMemory__DOT__initvar),32);
}

VL_ATTR_COLD void VRV32ICore___024root__trace_full_0_sub_0(VRV32ICore___024root* vlSelf, VerilatedVcd::Buffer* bufp);

VL_ATTR_COLD void VRV32ICore___024root__trace_full_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root__trace_full_0\n"); );
    // Init
    VRV32ICore___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<VRV32ICore___024root*>(voidSelf);
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    VRV32ICore___024root__trace_full_0_sub_0((&vlSymsp->TOP), bufp);
}

VL_ATTR_COLD void VRV32ICore___024root__trace_full_0_sub_0(VRV32ICore___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root__trace_full_0_sub_0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode);
    VlWide<4>/*127:0*/ __Vtemp_1;
    VlWide<4>/*127:0*/ __Vtemp_2;
    VlWide<4>/*127:0*/ __Vtemp_3;
    VlWide<4>/*127:0*/ __Vtemp_4;
    VlWide<4>/*127:0*/ __Vtemp_5;
    VlWide<4>/*127:0*/ __Vtemp_6;
    VlWide<4>/*127:0*/ __Vtemp_7;
    VlWide<4>/*127:0*/ __Vtemp_8;
    VlWide<4>/*127:0*/ __Vtemp_9;
    VlWide<4>/*127:0*/ __Vtemp_10;
    VlWide<4>/*127:0*/ __Vtemp_11;
    VlWide<4>/*127:0*/ __Vtemp_12;
    // Body
    bufp->fullIData(oldp+1,(vlSelfRef.RV32ICore__DOT__pcReg),32);
    bufp->fullIData(oldp+2,(((0x100U > VL_SHIFTR_III(32,32,32, vlSelfRef.RV32ICore__DOT__pcReg, 2U))
                              ? vlSelfRef.RV32ICore__DOT__instructionMemory__DOT__mem
                             [(0xffU & (vlSelfRef.RV32ICore__DOT__pcReg 
                                        >> 2U))] : 0U)),32);
    bufp->fullBit(oldp+3,(vlSelfRef.RV32ICore__DOT__ifexValid));
    bufp->fullIData(oldp+4,(vlSelfRef.RV32ICore__DOT__ifexInstr),32);
    bufp->fullIData(oldp+5,(vlSelfRef.RV32ICore__DOT__ifexPC),32);
    bufp->fullIData(oldp+6,(vlSelfRef.RV32ICore__DOT__datapath_io_nextPc),32);
    bufp->fullBit(oldp+7,(((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_memRead) 
                           & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid))));
    bufp->fullBit(oldp+8,(vlSelfRef.RV32ICore__DOT__datapath_io_memWrite));
    bufp->fullIData(oldp+9,((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)),32);
    bufp->fullIData(oldp+10,(((0U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                               >> 0x14U)))
                               ? 0U : vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_63)),32);
    bufp->fullIData(oldp+11,((((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_memRead) 
                               & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid))
                               ? ((0U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                >> 0xcU)))
                                   ? ((((0x80U & vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                         [(0x3ffU & (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))])
                                         ? 0xffffffU
                                         : 0U) << 8U) 
                                      | vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                      [(0x3ffU & (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))])
                                   : ((1U == (7U & 
                                              (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                               >> 0xcU)))
                                       ? ((((0x80U 
                                             & vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                             [(0x3ffU 
                                               & ((IData)(1U) 
                                                  + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))])
                                             ? 0xffffU
                                             : 0U) 
                                           << 0x10U) 
                                          | (IData)(vlSelfRef.RV32ICore__DOT__dataMemory__DOT____VdfgRegularize_heafa0826_0_1))
                                       : ((2U == (7U 
                                                  & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                     >> 0xcU)))
                                           ? ((vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                               [(0x3ffU 
                                                 & ((IData)(3U) 
                                                    + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))] 
                                               << 0x18U) 
                                              | ((vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                                  [
                                                  (0x3ffU 
                                                   & ((IData)(2U) 
                                                      + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))] 
                                                  << 0x10U) 
                                                 | (IData)(vlSelfRef.RV32ICore__DOT__dataMemory__DOT____VdfgRegularize_heafa0826_0_1)))
                                           : ((4U == 
                                               (7U 
                                                & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                   >> 0xcU)))
                                               ? vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                              [(0x3ffU 
                                                & (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))]
                                               : ((5U 
                                                   == 
                                                   (7U 
                                                    & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                       >> 0xcU)))
                                                   ? (IData)(vlSelfRef.RV32ICore__DOT__dataMemory__DOT____VdfgRegularize_heafa0826_0_1)
                                                   : 0U)))))
                               : 0U)),32);
    bufp->fullCData(oldp+12,((7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                    >> 0xcU))),3);
    bufp->fullIData(oldp+13,(((IData)(vlSelfRef.RV32ICore__DOT__ifexValid)
                               ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_writeData
                               : 0U)),32);
    bufp->fullIData(oldp+14,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_1),32);
    bufp->fullIData(oldp+15,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_2),32);
    bufp->fullIData(oldp+16,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_3),32);
    bufp->fullIData(oldp+17,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_4),32);
    bufp->fullIData(oldp+18,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_5),32);
    bufp->fullIData(oldp+19,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_6),32);
    bufp->fullIData(oldp+20,(vlSelfRef.RV32ICore__DOT__datapath__DOT__immGen_io_imm),32);
    bufp->fullIData(oldp+21,(((IData)(4U) + vlSelfRef.RV32ICore__DOT__pcReg)),32);
    bufp->fullIData(oldp+22,(((IData)(4U) + vlSelfRef.RV32ICore__DOT__ifexPC)),32);
    bufp->fullSData(oldp+23,((0x3ffU & (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))),10);
    bufp->fullCData(oldp+24,(vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                             [(0x3ffU & (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))]),8);
    bufp->fullSData(oldp+25,((0x3ffU & ((IData)(1U) 
                                        + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))),10);
    bufp->fullCData(oldp+26,(vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                             [(0x3ffU & ((IData)(1U) 
                                         + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))]),8);
    bufp->fullSData(oldp+27,((0x3ffU & ((IData)(2U) 
                                        + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))),10);
    bufp->fullCData(oldp+28,(vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                             [(0x3ffU & ((IData)(2U) 
                                         + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))]),8);
    bufp->fullSData(oldp+29,((0x3ffU & ((IData)(3U) 
                                        + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))),10);
    bufp->fullCData(oldp+30,(vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                             [(0x3ffU & ((IData)(3U) 
                                         + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))]),8);
    bufp->fullCData(oldp+31,(vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem_MPORT_data),8);
    bufp->fullBit(oldp+32,(((IData)(vlSelfRef.RV32ICore__DOT__datapath_io_memWrite) 
                            & (0U == (0x7000U & vlSelfRef.RV32ICore__DOT__ifexInstr)))));
    bufp->fullBit(oldp+33,(vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem_MPORT_1_en));
    bufp->fullCData(oldp+34,(vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem_MPORT_2_data),8);
    bufp->fullBit(oldp+35,(vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem_MPORT_3_en));
    bufp->fullCData(oldp+36,(((0U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                               >> 0x14U)))
                               ? 0U : (0xffU & (vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_63 
                                                >> 0x10U)))),8);
    bufp->fullCData(oldp+37,(((0U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                               >> 0x14U)))
                               ? 0U : (vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_63 
                                       >> 0x18U))),8);
    bufp->fullIData(oldp+38,(((vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                               [(0x3ffU & ((IData)(3U) 
                                           + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))] 
                               << 0x18U) | ((vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                             [(0x3ffU 
                                               & ((IData)(2U) 
                                                  + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))] 
                                             << 0x10U) 
                                            | (IData)(vlSelfRef.RV32ICore__DOT__dataMemory__DOT____VdfgRegularize_heafa0826_0_1)))),32);
    bufp->fullCData(oldp+39,((0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                       >> 0xfU))),5);
    bufp->fullCData(oldp+40,((0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                       >> 0x14U))),5);
    bufp->fullCData(oldp+41,((0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                       >> 7U))),5);
    bufp->fullCData(oldp+42,(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp),5);
    bufp->fullBit(oldp+43,(((0x33U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                            & ((0x13U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                               | ((3U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                  | ((0x23U == (0x7fU 
                                                & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                     | ((0x63U != (0x7fU 
                                                   & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                        & ((0x6fU != 
                                            (0x7fU 
                                             & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                           & (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control__DOT___GEN_37)))))))));
    bufp->fullBit(oldp+44,(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_memRead));
    bufp->fullBit(oldp+45,(((0x33U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                            & ((0x13U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                               & ((3U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                  & (0x23U == (0x7fU 
                                               & vlSelfRef.RV32ICore__DOT__ifexInstr)))))));
    bufp->fullBit(oldp+46,(((0x33U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                            | ((0x13U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                               | ((3U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                  | ((0x23U != (0x7fU 
                                                & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                     & ((0x63U != (0x7fU 
                                                   & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                        & ((0x6fU == 
                                            (0x7fU 
                                             & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                           | (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control__DOT___GEN_37)))))))));
    bufp->fullBit(oldp+47,(((0x33U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                            & ((0x13U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                               & ((3U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                  & ((0x23U != (0x7fU 
                                                & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                     & (0x63U == (0x7fU 
                                                  & vlSelfRef.RV32ICore__DOT__ifexInstr))))))));
    bufp->fullBit(oldp+48,(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jump));
    bufp->fullBit(oldp+49,(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jalr));
    bufp->fullIData(oldp+50,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_writeData),32);
    bufp->fullBit(oldp+51,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_writeEnable));
    bufp->fullIData(oldp+52,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1),32);
    bufp->fullIData(oldp+53,(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b),32);
    bufp->fullBit(oldp+54,((((0x33U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                             & ((0x13U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                & ((3U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                   & ((0x23U != (0x7fU 
                                                 & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                      & (0x63U == (0x7fU 
                                                   & vlSelfRef.RV32ICore__DOT__ifexInstr)))))) 
                            & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid))));
    bufp->fullBit(oldp+55,(((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jump) 
                            & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid))));
    bufp->fullBit(oldp+56,(((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jalr) 
                            & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid))));
    bufp->fullIData(oldp+57,((((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jalr) 
                               & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid))
                               ? (0xfffffffeU & (vlSelfRef.RV32ICore__DOT__datapath__DOT__immGen_io_imm 
                                                 + vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1))
                               : (((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jump) 
                                   & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid))
                                   ? vlSelfRef.RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTarget
                                   : ((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTaken)
                                       ? vlSelfRef.RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTarget
                                       : ((IData)(4U) 
                                          + vlSelfRef.RV32ICore__DOT__ifexPC))))),32);
    bufp->fullCData(oldp+58,((0x1fU & vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)),5);
    bufp->fullQData(oldp+59,(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__aSigned64),64);
    bufp->fullQData(oldp+61,((((QData)((IData)(((vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b 
                                                 >> 0x1fU)
                                                 ? 0xffffffffU
                                                 : 0U))) 
                               << 0x20U) | (QData)((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)))),64);
    bufp->fullQData(oldp+63,((QData)((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1))),64);
    bufp->fullQData(oldp+65,((QData)((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b))),64);
    bufp->fullWData(oldp+67,(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__mulSS),128);
    __Vtemp_1[0U] = vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1;
    __Vtemp_1[1U] = 0U;
    __Vtemp_1[2U] = 0U;
    __Vtemp_1[3U] = 0U;
    __Vtemp_2[0U] = vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b;
    __Vtemp_2[1U] = 0U;
    __Vtemp_2[2U] = 0U;
    __Vtemp_2[3U] = 0U;
    VL_MUL_W(4, __Vtemp_3, __Vtemp_1, __Vtemp_2);
    bufp->fullWData(oldp+71,(__Vtemp_3),128);
    VL_EXTENDS_WQ(128,64, __Vtemp_4, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__aSigned64);
    VL_EXTENDS_WQ(128,64, __Vtemp_5, (QData)((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)));
    VL_MULS_WWW(128, __Vtemp_6, __Vtemp_4, __Vtemp_5);
    bufp->fullWData(oldp+75,(__Vtemp_6),128);
    bufp->fullIData(oldp+79,(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__mulSS[0U]),32);
    bufp->fullIData(oldp+80,(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__mulSS[1U]),32);
    VL_EXTENDS_WQ(128,64, __Vtemp_7, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__aSigned64);
    VL_EXTENDS_WQ(128,64, __Vtemp_8, (QData)((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)));
    VL_MULS_WWW(128, __Vtemp_9, __Vtemp_7, __Vtemp_8);
    bufp->fullIData(oldp+81,(__Vtemp_9[1U]),32);
    __Vtemp_10[0U] = vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1;
    __Vtemp_10[1U] = 0U;
    __Vtemp_10[2U] = 0U;
    __Vtemp_10[3U] = 0U;
    __Vtemp_11[0U] = vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b;
    __Vtemp_11[1U] = 0U;
    __Vtemp_11[2U] = 0U;
    __Vtemp_11[3U] = 0U;
    VL_MUL_W(4, __Vtemp_12, __Vtemp_10, __Vtemp_11);
    bufp->fullIData(oldp+82,(__Vtemp_12[1U]),32);
    bufp->fullIData(oldp+83,(((0U == vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                               ? 0xffffffffU : VL_DIV_III(32, vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b))),32);
    bufp->fullIData(oldp+84,(((0U == vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                               ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1
                               : ((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___T_3)
                                   ? 0U : VL_MODDIVS_III(32, vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)))),32);
    bufp->fullIData(oldp+85,(((0U == vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                               ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1
                               : VL_MODDIV_III(32, vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b))),32);
    bufp->fullBit(oldp+86,((vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1 
                            == vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)));
    bufp->fullBit(oldp+87,((vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1 
                            != vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)));
    bufp->fullIData(oldp+88,(((0U == vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                               ? 0xffffffffU : ((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___T_3)
                                                 ? 0x80000000U
                                                 : (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___divResult_T_1)))),32);
    bufp->fullCData(oldp+89,((0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)),7);
    bufp->fullCData(oldp+90,((vlSelfRef.RV32ICore__DOT__ifexInstr 
                              >> 0x19U)),7);
    bufp->fullIData(oldp+91,(vlSelfRef.RV32ICore__DOT__datapath__DOT__immGen__DOT__iImm),32);
    bufp->fullIData(oldp+92,(((((vlSelfRef.RV32ICore__DOT__ifexInstr 
                                 >> 0x1fU) ? 0xfffffU
                                 : 0U) << 0xcU) | (
                                                   (0xfe0U 
                                                    & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                       >> 0x14U)) 
                                                   | (0x1fU 
                                                      & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                         >> 7U))))),32);
    bufp->fullIData(oldp+93,(((((vlSelfRef.RV32ICore__DOT__ifexInstr 
                                 >> 0x1fU) ? 0x7ffffU
                                 : 0U) << 0xdU) | (
                                                   ((0x1000U 
                                                     & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                        >> 0x13U)) 
                                                    | (0x800U 
                                                       & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                          << 4U))) 
                                                   | ((0x7e0U 
                                                       & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                          >> 0x14U)) 
                                                      | (0x1eU 
                                                         & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                            >> 7U)))))),32);
    bufp->fullIData(oldp+94,((0xfffff000U & vlSelfRef.RV32ICore__DOT__ifexInstr)),32);
    bufp->fullIData(oldp+95,((((((vlSelfRef.RV32ICore__DOT__ifexInstr 
                                  >> 0x1fU) ? 0x7ffU
                                  : 0U) << 0x15U) | 
                               (0x100000U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                             >> 0xbU))) 
                              | (((0xff000U & vlSelfRef.RV32ICore__DOT__ifexInstr) 
                                  | (0x800U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                               >> 9U))) 
                                 | (0x7feU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                              >> 0x14U))))),32);
    bufp->fullIData(oldp+96,(vlSelfRef.RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTarget),32);
    bufp->fullIData(oldp+97,((0xfffffffeU & (vlSelfRef.RV32ICore__DOT__datapath__DOT__immGen_io_imm 
                                             + vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1))),32);
    bufp->fullBit(oldp+98,(vlSelfRef.RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTaken));
    bufp->fullIData(oldp+99,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_0),32);
    bufp->fullIData(oldp+100,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_7),32);
    bufp->fullIData(oldp+101,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_8),32);
    bufp->fullIData(oldp+102,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_9),32);
    bufp->fullIData(oldp+103,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_10),32);
    bufp->fullIData(oldp+104,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_11),32);
    bufp->fullIData(oldp+105,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_12),32);
    bufp->fullIData(oldp+106,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_13),32);
    bufp->fullIData(oldp+107,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_14),32);
    bufp->fullIData(oldp+108,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_15),32);
    bufp->fullIData(oldp+109,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_16),32);
    bufp->fullIData(oldp+110,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_17),32);
    bufp->fullIData(oldp+111,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_18),32);
    bufp->fullIData(oldp+112,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_19),32);
    bufp->fullIData(oldp+113,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_20),32);
    bufp->fullIData(oldp+114,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_21),32);
    bufp->fullIData(oldp+115,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_22),32);
    bufp->fullIData(oldp+116,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_23),32);
    bufp->fullIData(oldp+117,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_24),32);
    bufp->fullIData(oldp+118,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_25),32);
    bufp->fullIData(oldp+119,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_26),32);
    bufp->fullIData(oldp+120,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_27),32);
    bufp->fullIData(oldp+121,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_28),32);
    bufp->fullIData(oldp+122,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_29),32);
    bufp->fullIData(oldp+123,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_30),32);
    bufp->fullIData(oldp+124,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_31),32);
    bufp->fullCData(oldp+125,((0xffU & (vlSelfRef.RV32ICore__DOT__pcReg 
                                        >> 2U))),8);
    bufp->fullIData(oldp+126,(vlSelfRef.RV32ICore__DOT__instructionMemory__DOT__mem
                              [(0xffU & (vlSelfRef.RV32ICore__DOT__pcReg 
                                         >> 2U))]),32);
    bufp->fullIData(oldp+127,(VL_SHIFTR_III(32,32,32, vlSelfRef.RV32ICore__DOT__pcReg, 2U)),32);
    bufp->fullBit(oldp+128,(vlSelfRef.clock));
    bufp->fullBit(oldp+129,(vlSelfRef.reset));
    bufp->fullIData(oldp+130,(vlSelfRef.io_pc),32);
    bufp->fullIData(oldp+131,(vlSelfRef.io_nextPc),32);
    bufp->fullIData(oldp+132,(vlSelfRef.io_writeBack),32);
    bufp->fullIData(oldp+133,(vlSelfRef.io_debugInstr),32);
    bufp->fullIData(oldp+134,(vlSelfRef.io_debugX1),32);
    bufp->fullIData(oldp+135,(vlSelfRef.io_debugX2),32);
    bufp->fullIData(oldp+136,(vlSelfRef.io_debugX3),32);
    bufp->fullIData(oldp+137,(vlSelfRef.io_debugX4),32);
    bufp->fullIData(oldp+138,(vlSelfRef.io_debugX5),32);
    bufp->fullIData(oldp+139,(vlSelfRef.io_debugX6),32);
    bufp->fullIData(oldp+140,(vlSelfRef.io_debugALU),32);
    bufp->fullIData(oldp+141,(vlSelfRef.io_debugImm),32);
    bufp->fullIData(oldp+142,(vlSelfRef.io_debugFetchPC),32);
    bufp->fullIData(oldp+143,(vlSelfRef.io_debugExecPC),32);
    bufp->fullBit(oldp+144,(vlSelfRef.io_debugValid));
    bufp->fullBit(oldp+145,(vlSelfRef.io_debugFlush));
}
