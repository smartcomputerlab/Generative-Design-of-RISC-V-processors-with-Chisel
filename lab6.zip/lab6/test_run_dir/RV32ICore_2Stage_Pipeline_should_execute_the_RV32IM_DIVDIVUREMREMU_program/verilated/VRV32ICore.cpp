// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Model implementation (design independent parts)

#include "VRV32ICore__pch.h"
#include "verilated_vcd_c.h"

//============================================================
// Constructors

VRV32ICore::VRV32ICore(VerilatedContext* _vcontextp__, const char* _vcname__)
    : VerilatedModel{*_vcontextp__}
    , vlSymsp{new VRV32ICore__Syms(contextp(), _vcname__, this)}
    , clock{vlSymsp->TOP.clock}
    , reset{vlSymsp->TOP.reset}
    , io_debugValid{vlSymsp->TOP.io_debugValid}
    , io_debugFlush{vlSymsp->TOP.io_debugFlush}
    , io_pc{vlSymsp->TOP.io_pc}
    , io_nextPc{vlSymsp->TOP.io_nextPc}
    , io_writeBack{vlSymsp->TOP.io_writeBack}
    , io_debugInstr{vlSymsp->TOP.io_debugInstr}
    , io_debugX1{vlSymsp->TOP.io_debugX1}
    , io_debugX2{vlSymsp->TOP.io_debugX2}
    , io_debugX3{vlSymsp->TOP.io_debugX3}
    , io_debugX4{vlSymsp->TOP.io_debugX4}
    , io_debugX5{vlSymsp->TOP.io_debugX5}
    , io_debugX6{vlSymsp->TOP.io_debugX6}
    , io_debugALU{vlSymsp->TOP.io_debugALU}
    , io_debugImm{vlSymsp->TOP.io_debugImm}
    , io_debugFetchPC{vlSymsp->TOP.io_debugFetchPC}
    , io_debugExecPC{vlSymsp->TOP.io_debugExecPC}
    , rootp{&(vlSymsp->TOP)}
{
    // Register model with the context
    contextp()->addModel(this);
    contextp()->traceBaseModelCbAdd(
        [this](VerilatedTraceBaseC* tfp, int levels, int options) { traceBaseModel(tfp, levels, options); });
}

VRV32ICore::VRV32ICore(const char* _vcname__)
    : VRV32ICore(Verilated::threadContextp(), _vcname__)
{
}

//============================================================
// Destructor

VRV32ICore::~VRV32ICore() {
    delete vlSymsp;
}

//============================================================
// Evaluation function

#ifdef VL_DEBUG
void VRV32ICore___024root___eval_debug_assertions(VRV32ICore___024root* vlSelf);
#endif  // VL_DEBUG
void VRV32ICore___024root___eval_static(VRV32ICore___024root* vlSelf);
void VRV32ICore___024root___eval_initial(VRV32ICore___024root* vlSelf);
void VRV32ICore___024root___eval_settle(VRV32ICore___024root* vlSelf);
void VRV32ICore___024root___eval(VRV32ICore___024root* vlSelf);

void VRV32ICore::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate VRV32ICore::eval_step\n"); );
#ifdef VL_DEBUG
    // Debug assertions
    VRV32ICore___024root___eval_debug_assertions(&(vlSymsp->TOP));
#endif  // VL_DEBUG
    vlSymsp->__Vm_activity = true;
    vlSymsp->__Vm_deleter.deleteAll();
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) {
        vlSymsp->__Vm_didInit = true;
        VL_DEBUG_IF(VL_DBG_MSGF("+ Initial\n"););
        VRV32ICore___024root___eval_static(&(vlSymsp->TOP));
        VRV32ICore___024root___eval_initial(&(vlSymsp->TOP));
        VRV32ICore___024root___eval_settle(&(vlSymsp->TOP));
    }
    VL_DEBUG_IF(VL_DBG_MSGF("+ Eval\n"););
    VRV32ICore___024root___eval(&(vlSymsp->TOP));
    // Evaluate cleanup
    Verilated::endOfEval(vlSymsp->__Vm_evalMsgQp);
}

//============================================================
// Events and timing
bool VRV32ICore::eventsPending() { return false; }

uint64_t VRV32ICore::nextTimeSlot() {
    VL_FATAL_MT(__FILE__, __LINE__, "", "No delays in the design");
    return 0;
}

//============================================================
// Utilities

const char* VRV32ICore::name() const {
    return vlSymsp->name();
}

//============================================================
// Invoke final blocks

void VRV32ICore___024root___eval_final(VRV32ICore___024root* vlSelf);

VL_ATTR_COLD void VRV32ICore::final() {
    VRV32ICore___024root___eval_final(&(vlSymsp->TOP));
}

//============================================================
// Implementations of abstract methods from VerilatedModel

const char* VRV32ICore::hierName() const { return vlSymsp->name(); }
const char* VRV32ICore::modelName() const { return "VRV32ICore"; }
unsigned VRV32ICore::threads() const { return 1; }
void VRV32ICore::prepareClone() const { contextp()->prepareClone(); }
void VRV32ICore::atClone() const {
    contextp()->threadPoolpOnClone();
}
std::unique_ptr<VerilatedTraceConfig> VRV32ICore::traceConfig() const {
    return std::unique_ptr<VerilatedTraceConfig>{new VerilatedTraceConfig{false, false, false}};
};

//============================================================
// Trace configuration

void VRV32ICore___024root__trace_decl_types(VerilatedVcd* tracep);

void VRV32ICore___024root__trace_init_top(VRV32ICore___024root* vlSelf, VerilatedVcd* tracep);

VL_ATTR_COLD static void trace_init(void* voidSelf, VerilatedVcd* tracep, uint32_t code) {
    // Callback from tracep->open()
    VRV32ICore___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<VRV32ICore___024root*>(voidSelf);
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    if (!vlSymsp->_vm_contextp__->calcUnusedSigs()) {
        VL_FATAL_MT(__FILE__, __LINE__, __FILE__,
            "Turning on wave traces requires Verilated::traceEverOn(true) call before time 0.");
    }
    vlSymsp->__Vm_baseCode = code;
    tracep->pushPrefix(std::string{vlSymsp->name()}, VerilatedTracePrefixType::SCOPE_MODULE);
    VRV32ICore___024root__trace_decl_types(tracep);
    VRV32ICore___024root__trace_init_top(vlSelf, tracep);
    tracep->popPrefix();
}

VL_ATTR_COLD void VRV32ICore___024root__trace_register(VRV32ICore___024root* vlSelf, VerilatedVcd* tracep);

VL_ATTR_COLD void VRV32ICore::traceBaseModel(VerilatedTraceBaseC* tfp, int levels, int options) {
    (void)levels; (void)options;
    VerilatedVcdC* const stfp = dynamic_cast<VerilatedVcdC*>(tfp);
    if (VL_UNLIKELY(!stfp)) {
        vl_fatal(__FILE__, __LINE__, __FILE__,"'VRV32ICore::trace()' called on non-VerilatedVcdC object;"
            " use --trace-fst with VerilatedFst object, and --trace with VerilatedVcd object");
    }
    stfp->spTrace()->addModel(this);
    stfp->spTrace()->addInitCb(&trace_init, &(vlSymsp->TOP));
    VRV32ICore___024root__trace_register(&(vlSymsp->TOP), stfp->spTrace());
}
