// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing declarations
#include "verilated_vcd_c.h"


void VRV32ICore___024root__traceDeclTypesSub0(VerilatedVcd* tracep) {
}

void VRV32ICore___024root__trace_decl_types(VerilatedVcd* tracep) {
    VRV32ICore___024root__traceDeclTypesSub0(tracep);
}
