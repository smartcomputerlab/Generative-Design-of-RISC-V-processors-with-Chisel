// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VRV32ICore.h for the primary calling header

#include "VRV32ICore__pch.h"
#include "VRV32ICore__Syms.h"
#include "VRV32ICore___024root.h"

#ifdef VL_DEBUG
VL_ATTR_COLD void VRV32ICore___024root___dump_triggers__act(VRV32ICore___024root* vlSelf);
#endif  // VL_DEBUG

void VRV32ICore___024root___eval_triggers__act(VRV32ICore___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root___eval_triggers__act\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VactTriggered.set(0U, ((IData)(vlSelfRef.clock) 
                                       & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__clock__0))));
    vlSelfRef.__Vtrigprevexpr___TOP__clock__0 = vlSelfRef.clock;
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        VRV32ICore___024root___dump_triggers__act(vlSelf);
    }
#endif
}
