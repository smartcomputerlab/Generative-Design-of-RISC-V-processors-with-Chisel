// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table internal header
//
// Internal details; most calling programs do not need this header,
// unless using verilator public meta comments.

#ifndef VERILATED_VRV32ICORE__SYMS_H_
#define VERILATED_VRV32ICORE__SYMS_H_  // guard

#include "verilated.h"

// INCLUDE MODEL CLASS

#include "VRV32ICore.h"

// INCLUDE MODULE CLASSES
#include "VRV32ICore___024root.h"

// SYMS CLASS (contains all model state)
class alignas(VL_CACHE_LINE_BYTES)VRV32ICore__Syms final : public VerilatedSyms {
  public:
    // INTERNAL STATE
    VRV32ICore* const __Vm_modelp;
    bool __Vm_activity = false;  ///< Used by trace routines to determine change occurred
    uint32_t __Vm_baseCode = 0;  ///< Used by trace routines when tracing multiple models
    VlDeleter __Vm_deleter;
    bool __Vm_didInit = false;

    // MODULE INSTANCE STATE
    VRV32ICore___024root           TOP;

    // CONSTRUCTORS
    VRV32ICore__Syms(VerilatedContext* contextp, const char* namep, VRV32ICore* modelp);
    ~VRV32ICore__Syms();

    // METHODS
    const char* name() { return TOP.name(); }
};

#endif  // guard
