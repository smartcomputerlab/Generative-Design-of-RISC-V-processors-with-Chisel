verilated.o: /usr/share/verilator/include/verilated.cpp VRV32ICore.h \
 /usr/share/verilator/include/verilated.h \
 /usr/share/verilator/include/verilatedos.h \
 /usr/share/verilator/include/verilated_config.h \
 /usr/share/verilator/include/verilated_types.h \
 /usr/share/verilator/include/verilated_funcs.h \
 /usr/share/verilator/include/verilated_cov.h \
 /usr/share/verilator/include/verilated.h \
 /usr/share/verilator/include/verilated_imp.h \
 /usr/share/verilator/include/verilated_syms.h \
 /usr/share/verilator/include/verilated_sym_props.h \
 /usr/share/verilator/include/verilated_threads.h \
 /usr/share/verilator/include/verilated_trace.h \
 /usr/share/verilator/include/verilatedos_c.h
