verilated_cov.o: /usr/share/verilator/include/verilated_cov.cpp \
 VRV32ICore.h /usr/share/verilator/include/verilated.h \
 /usr/share/verilator/include/verilatedos.h \
 /usr/share/verilator/include/verilated_config.h \
 /usr/share/verilator/include/verilated_types.h \
 /usr/share/verilator/include/verilated_funcs.h \
 /usr/share/verilator/include/verilated_cov.h \
 /usr/share/verilator/include/verilated.h \
 /usr/share/verilator/include/verilated_cov.h \
 /usr/share/verilator/include/verilated_cov_key.h
