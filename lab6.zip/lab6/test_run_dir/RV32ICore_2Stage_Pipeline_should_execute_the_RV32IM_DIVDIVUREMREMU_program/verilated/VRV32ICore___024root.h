// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See VRV32ICore.h for the primary calling header

#ifndef VERILATED_VRV32ICORE___024ROOT_H_
#define VERILATED_VRV32ICORE___024ROOT_H_  // guard

#include "verilated.h"
#include "verilated_cov.h"


class VRV32ICore__Syms;

class alignas(VL_CACHE_LINE_BYTES) VRV32ICore___024root final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        VL_IN8(clock,0,0);
        VL_IN8(reset,0,0);
        VL_OUT8(io_debugValid,0,0);
        VL_OUT8(io_debugFlush,0,0);
        CData/*0:0*/ RV32ICore__DOT__datapath_io_memWrite;
        CData/*0:0*/ RV32ICore__DOT__ifexValid;
        CData/*4:0*/ RV32ICore__DOT__datapath__DOT__control_io_aluOp;
        CData/*0:0*/ RV32ICore__DOT__datapath__DOT__control_io_memRead;
        CData/*0:0*/ RV32ICore__DOT__datapath__DOT__control_io_jump;
        CData/*0:0*/ RV32ICore__DOT__datapath__DOT__control_io_jalr;
        CData/*0:0*/ RV32ICore__DOT__datapath__DOT__regFile_io_writeEnable;
        CData/*0:0*/ RV32ICore__DOT__datapath__DOT__control__DOT___GEN_37;
        CData/*0:0*/ RV32ICore__DOT__datapath__DOT__alu__DOT___T_3;
        CData/*0:0*/ RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTaken;
        CData/*7:0*/ RV32ICore__DOT__dataMemory__DOT__mem_MPORT_data;
        CData/*0:0*/ RV32ICore__DOT__dataMemory__DOT__mem_MPORT_1_en;
        CData/*7:0*/ RV32ICore__DOT__dataMemory__DOT__mem_MPORT_2_data;
        CData/*0:0*/ RV32ICore__DOT__dataMemory__DOT__mem_MPORT_3_en;
        CData/*0:0*/ __VstlFirstIteration;
        CData/*0:0*/ __Vtrigprevexpr___TOP__clock__0;
        CData/*0:0*/ __VactContinue;
        SData/*15:0*/ RV32ICore__DOT__dataMemory__DOT____VdfgRegularize_heafa0826_0_1;
        VL_OUT(io_pc,31,0);
        VL_OUT(io_nextPc,31,0);
        VL_OUT(io_writeBack,31,0);
        VL_OUT(io_debugInstr,31,0);
        VL_OUT(io_debugX1,31,0);
        VL_OUT(io_debugX2,31,0);
        VL_OUT(io_debugX3,31,0);
        VL_OUT(io_debugX4,31,0);
        VL_OUT(io_debugX5,31,0);
        VL_OUT(io_debugX6,31,0);
        VL_OUT(io_debugALU,31,0);
        VL_OUT(io_debugImm,31,0);
        VL_OUT(io_debugFetchPC,31,0);
        VL_OUT(io_debugExecPC,31,0);
        IData/*31:0*/ RV32ICore__DOT__datapath_io_nextPc;
        IData/*31:0*/ RV32ICore__DOT__pcReg;
        IData/*31:0*/ RV32ICore__DOT__sequentialPC;
        IData/*31:0*/ RV32ICore__DOT__ifexPC;
        IData/*31:0*/ RV32ICore__DOT__ifexInstr;
        IData/*31:0*/ RV32ICore__DOT__instructionMemory__DOT__initvar;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__immGen_io_imm;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile_io_writeData;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile_io_readData1;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__alu_io_b;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__immGen__DOT__iImm;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_0;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_1;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_2;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_3;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_4;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_5;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_6;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_7;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_8;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_9;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_10;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_11;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_12;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_13;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_14;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_15;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_16;
    };
    struct {
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_17;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_18;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_19;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_20;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_21;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_22;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_23;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_24;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_25;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_26;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_27;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_28;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_29;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_30;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_31;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_63;
        VlWide<4>/*127:0*/ RV32ICore__DOT__datapath__DOT__alu__DOT__mulSS;
        IData/*31:0*/ RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTarget;
        IData/*31:0*/ __VactIterCount;
        QData/*63:0*/ RV32ICore__DOT__datapath__DOT__alu__DOT__aSigned64;
        QData/*32:0*/ RV32ICore__DOT__datapath__DOT__alu__DOT___divResult_T_1;
        QData/*62:0*/ RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56;
        VlUnpacked<IData/*31:0*/, 256> RV32ICore__DOT__instructionMemory__DOT__mem;
        VlUnpacked<CData/*7:0*/, 1024> RV32ICore__DOT__dataMemory__DOT__mem;
        VlUnpacked<CData/*0:0*/, 2> __Vm_traceActivity;
    };
    VlTriggerVec<1> __VstlTriggered;
    VlTriggerVec<1> __VactTriggered;
    VlTriggerVec<1> __VnbaTriggered;

    // INTERNAL VARIABLES
    VRV32ICore__Syms* const vlSymsp;

    // CONSTRUCTORS
    VRV32ICore___024root(VRV32ICore__Syms* symsp, const char* v__name);
    ~VRV32ICore___024root();
    VL_UNCOPYABLE(VRV32ICore___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
    void __vlCoverInsert(uint32_t* countp, bool enable, const char* filenamep, int lineno, int column,
        const char* hierp, const char* pagep, const char* commentp, const char* linescovp);
};


#endif  // guard
