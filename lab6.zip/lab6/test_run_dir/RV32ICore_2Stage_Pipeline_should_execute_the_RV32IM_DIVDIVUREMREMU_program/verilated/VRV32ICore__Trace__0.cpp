// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "VRV32ICore__Syms.h"


void VRV32ICore___024root__trace_chg_0_sub_0(VRV32ICore___024root* vlSelf, VerilatedVcd::Buffer* bufp);

void VRV32ICore___024root__trace_chg_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root__trace_chg_0\n"); );
    // Init
    VRV32ICore___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<VRV32ICore___024root*>(voidSelf);
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    if (VL_UNLIKELY(!vlSymsp->__Vm_activity)) return;
    // Body
    VRV32ICore___024root__trace_chg_0_sub_0((&vlSymsp->TOP), bufp);
}

void VRV32ICore___024root__trace_chg_0_sub_0(VRV32ICore___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    (void)vlSelf;  // Prevent unused variable warning
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root__trace_chg_0_sub_0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode + 1);
    VlWide<4>/*127:0*/ __Vtemp_1;
    VlWide<4>/*127:0*/ __Vtemp_2;
    VlWide<4>/*127:0*/ __Vtemp_3;
    VlWide<4>/*127:0*/ __Vtemp_4;
    VlWide<4>/*127:0*/ __Vtemp_5;
    VlWide<4>/*127:0*/ __Vtemp_6;
    VlWide<4>/*127:0*/ __Vtemp_7;
    VlWide<4>/*127:0*/ __Vtemp_8;
    VlWide<4>/*127:0*/ __Vtemp_9;
    VlWide<4>/*127:0*/ __Vtemp_10;
    VlWide<4>/*127:0*/ __Vtemp_11;
    VlWide<4>/*127:0*/ __Vtemp_12;
    // Body
    if (VL_UNLIKELY(vlSelfRef.__Vm_traceActivity[1U])) {
        bufp->chgIData(oldp+0,(vlSelfRef.RV32ICore__DOT__pcReg),32);
        bufp->chgIData(oldp+1,(((0x100U > VL_SHIFTR_III(32,32,32, vlSelfRef.RV32ICore__DOT__pcReg, 2U))
                                 ? vlSelfRef.RV32ICore__DOT__instructionMemory__DOT__mem
                                [(0xffU & (vlSelfRef.RV32ICore__DOT__pcReg 
                                           >> 2U))]
                                 : 0U)),32);
        bufp->chgBit(oldp+2,(vlSelfRef.RV32ICore__DOT__ifexValid));
        bufp->chgIData(oldp+3,(vlSelfRef.RV32ICore__DOT__ifexInstr),32);
        bufp->chgIData(oldp+4,(vlSelfRef.RV32ICore__DOT__ifexPC),32);
        bufp->chgIData(oldp+5,(vlSelfRef.RV32ICore__DOT__datapath_io_nextPc),32);
        bufp->chgBit(oldp+6,(((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_memRead) 
                              & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid))));
        bufp->chgBit(oldp+7,(vlSelfRef.RV32ICore__DOT__datapath_io_memWrite));
        bufp->chgIData(oldp+8,((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)),32);
        bufp->chgIData(oldp+9,(((0U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                 >> 0x14U)))
                                 ? 0U : vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_63)),32);
        bufp->chgIData(oldp+10,((((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_memRead) 
                                  & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid))
                                  ? ((0U == (7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                   >> 0xcU)))
                                      ? ((((0x80U & 
                                            vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                            [(0x3ffU 
                                              & (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))])
                                            ? 0xffffffU
                                            : 0U) << 8U) 
                                         | vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                         [(0x3ffU & (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))])
                                      : ((1U == (7U 
                                                 & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                    >> 0xcU)))
                                          ? ((((0x80U 
                                                & vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                                [(0x3ffU 
                                                  & ((IData)(1U) 
                                                     + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))])
                                                ? 0xffffU
                                                : 0U) 
                                              << 0x10U) 
                                             | (IData)(vlSelfRef.RV32ICore__DOT__dataMemory__DOT____VdfgRegularize_heafa0826_0_1))
                                          : ((2U == 
                                              (7U & 
                                               (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                >> 0xcU)))
                                              ? ((vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                                  [
                                                  (0x3ffU 
                                                   & ((IData)(3U) 
                                                      + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))] 
                                                  << 0x18U) 
                                                 | ((vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                                     [
                                                     (0x3ffU 
                                                      & ((IData)(2U) 
                                                         + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))] 
                                                     << 0x10U) 
                                                    | (IData)(vlSelfRef.RV32ICore__DOT__dataMemory__DOT____VdfgRegularize_heafa0826_0_1)))
                                              : ((4U 
                                                  == 
                                                  (7U 
                                                   & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                      >> 0xcU)))
                                                  ? 
                                                 vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                                 [(0x3ffU 
                                                   & (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))]
                                                  : 
                                                 ((5U 
                                                   == 
                                                   (7U 
                                                    & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                       >> 0xcU)))
                                                   ? (IData)(vlSelfRef.RV32ICore__DOT__dataMemory__DOT____VdfgRegularize_heafa0826_0_1)
                                                   : 0U)))))
                                  : 0U)),32);
        bufp->chgCData(oldp+11,((7U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                       >> 0xcU))),3);
        bufp->chgIData(oldp+12,(((IData)(vlSelfRef.RV32ICore__DOT__ifexValid)
                                  ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_writeData
                                  : 0U)),32);
        bufp->chgIData(oldp+13,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_1),32);
        bufp->chgIData(oldp+14,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_2),32);
        bufp->chgIData(oldp+15,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_3),32);
        bufp->chgIData(oldp+16,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_4),32);
        bufp->chgIData(oldp+17,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_5),32);
        bufp->chgIData(oldp+18,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_6),32);
        bufp->chgIData(oldp+19,(vlSelfRef.RV32ICore__DOT__datapath__DOT__immGen_io_imm),32);
        bufp->chgIData(oldp+20,(((IData)(4U) + vlSelfRef.RV32ICore__DOT__pcReg)),32);
        bufp->chgIData(oldp+21,(((IData)(4U) + vlSelfRef.RV32ICore__DOT__ifexPC)),32);
        bufp->chgSData(oldp+22,((0x3ffU & (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))),10);
        bufp->chgCData(oldp+23,(vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                [(0x3ffU & (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56))]),8);
        bufp->chgSData(oldp+24,((0x3ffU & ((IData)(1U) 
                                           + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))),10);
        bufp->chgCData(oldp+25,(vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                [(0x3ffU & ((IData)(1U) 
                                            + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))]),8);
        bufp->chgSData(oldp+26,((0x3ffU & ((IData)(2U) 
                                           + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))),10);
        bufp->chgCData(oldp+27,(vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                [(0x3ffU & ((IData)(2U) 
                                            + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))]),8);
        bufp->chgSData(oldp+28,((0x3ffU & ((IData)(3U) 
                                           + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))),10);
        bufp->chgCData(oldp+29,(vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                [(0x3ffU & ((IData)(3U) 
                                            + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))]),8);
        bufp->chgCData(oldp+30,(vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem_MPORT_data),8);
        bufp->chgBit(oldp+31,(((IData)(vlSelfRef.RV32ICore__DOT__datapath_io_memWrite) 
                               & (0U == (0x7000U & vlSelfRef.RV32ICore__DOT__ifexInstr)))));
        bufp->chgBit(oldp+32,(vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem_MPORT_1_en));
        bufp->chgCData(oldp+33,(vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem_MPORT_2_data),8);
        bufp->chgBit(oldp+34,(vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem_MPORT_3_en));
        bufp->chgCData(oldp+35,(((0U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                  >> 0x14U)))
                                  ? 0U : (0xffU & (vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_63 
                                                   >> 0x10U)))),8);
        bufp->chgCData(oldp+36,(((0U == (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                  >> 0x14U)))
                                  ? 0U : (vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT___GEN_63 
                                          >> 0x18U))),8);
        bufp->chgIData(oldp+37,(((vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                  [(0x3ffU & ((IData)(3U) 
                                              + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))] 
                                  << 0x18U) | ((vlSelfRef.RV32ICore__DOT__dataMemory__DOT__mem
                                                [(0x3ffU 
                                                  & ((IData)(2U) 
                                                     + (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___io_y_T_56)))] 
                                                << 0x10U) 
                                               | (IData)(vlSelfRef.RV32ICore__DOT__dataMemory__DOT____VdfgRegularize_heafa0826_0_1)))),32);
        bufp->chgCData(oldp+38,((0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                          >> 0xfU))),5);
        bufp->chgCData(oldp+39,((0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                          >> 0x14U))),5);
        bufp->chgCData(oldp+40,((0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                          >> 7U))),5);
        bufp->chgCData(oldp+41,(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_aluOp),5);
        bufp->chgBit(oldp+42,(((0x33U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                               & ((0x13U == (0x7fU 
                                             & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                  | ((3U == (0x7fU 
                                             & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                     | ((0x23U == (0x7fU 
                                                   & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                        | ((0x63U != 
                                            (0x7fU 
                                             & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                           & ((0x6fU 
                                               != (0x7fU 
                                                   & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                              & (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control__DOT___GEN_37)))))))));
        bufp->chgBit(oldp+43,(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_memRead));
        bufp->chgBit(oldp+44,(((0x33U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                               & ((0x13U != (0x7fU 
                                             & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                  & ((3U != (0x7fU 
                                             & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                     & (0x23U == (0x7fU 
                                                  & vlSelfRef.RV32ICore__DOT__ifexInstr)))))));
        bufp->chgBit(oldp+45,(((0x33U == (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                               | ((0x13U == (0x7fU 
                                             & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                  | ((3U == (0x7fU 
                                             & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                     | ((0x23U != (0x7fU 
                                                   & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                        & ((0x63U != 
                                            (0x7fU 
                                             & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                           & ((0x6fU 
                                               == (0x7fU 
                                                   & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                              | (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control__DOT___GEN_37)))))))));
        bufp->chgBit(oldp+46,(((0x33U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                               & ((0x13U != (0x7fU 
                                             & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                  & ((3U != (0x7fU 
                                             & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                     & ((0x23U != (0x7fU 
                                                   & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                        & (0x63U == 
                                           (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr))))))));
        bufp->chgBit(oldp+47,(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jump));
        bufp->chgBit(oldp+48,(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jalr));
        bufp->chgIData(oldp+49,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_writeData),32);
        bufp->chgBit(oldp+50,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_writeEnable));
        bufp->chgIData(oldp+51,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1),32);
        bufp->chgIData(oldp+52,(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b),32);
        bufp->chgBit(oldp+53,((((0x33U != (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                & ((0x13U != (0x7fU 
                                              & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                   & ((3U != (0x7fU 
                                              & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                      & ((0x23U != 
                                          (0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)) 
                                         & (0x63U == 
                                            (0x7fU 
                                             & vlSelfRef.RV32ICore__DOT__ifexInstr)))))) 
                               & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid))));
        bufp->chgBit(oldp+54,(((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jump) 
                               & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid))));
        bufp->chgBit(oldp+55,(((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jalr) 
                               & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid))));
        bufp->chgIData(oldp+56,((((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jalr) 
                                  & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid))
                                  ? (0xfffffffeU & 
                                     (vlSelfRef.RV32ICore__DOT__datapath__DOT__immGen_io_imm 
                                      + vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1))
                                  : (((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__control_io_jump) 
                                      & (IData)(vlSelfRef.RV32ICore__DOT__ifexValid))
                                      ? vlSelfRef.RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTarget
                                      : ((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTaken)
                                          ? vlSelfRef.RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTarget
                                          : ((IData)(4U) 
                                             + vlSelfRef.RV32ICore__DOT__ifexPC))))),32);
        bufp->chgCData(oldp+57,((0x1fU & vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)),5);
        bufp->chgQData(oldp+58,(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__aSigned64),64);
        bufp->chgQData(oldp+60,((((QData)((IData)((
                                                   (vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b 
                                                    >> 0x1fU)
                                                    ? 0xffffffffU
                                                    : 0U))) 
                                  << 0x20U) | (QData)((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)))),64);
        bufp->chgQData(oldp+62,((QData)((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1))),64);
        bufp->chgQData(oldp+64,((QData)((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b))),64);
        bufp->chgWData(oldp+66,(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__mulSS),128);
        __Vtemp_1[0U] = vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1;
        __Vtemp_1[1U] = 0U;
        __Vtemp_1[2U] = 0U;
        __Vtemp_1[3U] = 0U;
        __Vtemp_2[0U] = vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b;
        __Vtemp_2[1U] = 0U;
        __Vtemp_2[2U] = 0U;
        __Vtemp_2[3U] = 0U;
        VL_MUL_W(4, __Vtemp_3, __Vtemp_1, __Vtemp_2);
        bufp->chgWData(oldp+70,(__Vtemp_3),128);
        VL_EXTENDS_WQ(128,64, __Vtemp_4, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__aSigned64);
        VL_EXTENDS_WQ(128,64, __Vtemp_5, (QData)((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)));
        VL_MULS_WWW(128, __Vtemp_6, __Vtemp_4, __Vtemp_5);
        bufp->chgWData(oldp+74,(__Vtemp_6),128);
        bufp->chgIData(oldp+78,(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__mulSS[0U]),32);
        bufp->chgIData(oldp+79,(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__mulSS[1U]),32);
        VL_EXTENDS_WQ(128,64, __Vtemp_7, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT__aSigned64);
        VL_EXTENDS_WQ(128,64, __Vtemp_8, (QData)((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)));
        VL_MULS_WWW(128, __Vtemp_9, __Vtemp_7, __Vtemp_8);
        bufp->chgIData(oldp+80,(__Vtemp_9[1U]),32);
        __Vtemp_10[0U] = vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1;
        __Vtemp_10[1U] = 0U;
        __Vtemp_10[2U] = 0U;
        __Vtemp_10[3U] = 0U;
        __Vtemp_11[0U] = vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b;
        __Vtemp_11[1U] = 0U;
        __Vtemp_11[2U] = 0U;
        __Vtemp_11[3U] = 0U;
        VL_MUL_W(4, __Vtemp_12, __Vtemp_10, __Vtemp_11);
        bufp->chgIData(oldp+81,(__Vtemp_12[1U]),32);
        bufp->chgIData(oldp+82,(((0U == vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                                  ? 0xffffffffU : VL_DIV_III(32, vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b))),32);
        bufp->chgIData(oldp+83,(((0U == vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                                  ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1
                                  : ((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___T_3)
                                      ? 0U : VL_MODDIVS_III(32, vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)))),32);
        bufp->chgIData(oldp+84,(((0U == vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                                  ? vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1
                                  : VL_MODDIV_III(32, vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1, vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b))),32);
        bufp->chgBit(oldp+85,((vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1 
                               == vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)));
        bufp->chgBit(oldp+86,((vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1 
                               != vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)));
        bufp->chgIData(oldp+87,(((0U == vlSelfRef.RV32ICore__DOT__datapath__DOT__alu_io_b)
                                  ? 0xffffffffU : ((IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___T_3)
                                                    ? 0x80000000U
                                                    : (IData)(vlSelfRef.RV32ICore__DOT__datapath__DOT__alu__DOT___divResult_T_1)))),32);
        bufp->chgCData(oldp+88,((0x7fU & vlSelfRef.RV32ICore__DOT__ifexInstr)),7);
        bufp->chgCData(oldp+89,((vlSelfRef.RV32ICore__DOT__ifexInstr 
                                 >> 0x19U)),7);
        bufp->chgIData(oldp+90,(vlSelfRef.RV32ICore__DOT__datapath__DOT__immGen__DOT__iImm),32);
        bufp->chgIData(oldp+91,(((((vlSelfRef.RV32ICore__DOT__ifexInstr 
                                    >> 0x1fU) ? 0xfffffU
                                    : 0U) << 0xcU) 
                                 | ((0xfe0U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                               >> 0x14U)) 
                                    | (0x1fU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                >> 7U))))),32);
        bufp->chgIData(oldp+92,(((((vlSelfRef.RV32ICore__DOT__ifexInstr 
                                    >> 0x1fU) ? 0x7ffffU
                                    : 0U) << 0xdU) 
                                 | (((0x1000U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                 >> 0x13U)) 
                                     | (0x800U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                  << 4U))) 
                                    | ((0x7e0U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                  >> 0x14U)) 
                                       | (0x1eU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                   >> 7U)))))),32);
        bufp->chgIData(oldp+93,((0xfffff000U & vlSelfRef.RV32ICore__DOT__ifexInstr)),32);
        bufp->chgIData(oldp+94,((((((vlSelfRef.RV32ICore__DOT__ifexInstr 
                                     >> 0x1fU) ? 0x7ffU
                                     : 0U) << 0x15U) 
                                  | (0x100000U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                  >> 0xbU))) 
                                 | (((0xff000U & vlSelfRef.RV32ICore__DOT__ifexInstr) 
                                     | (0x800U & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                  >> 9U))) 
                                    | (0x7feU & (vlSelfRef.RV32ICore__DOT__ifexInstr 
                                                 >> 0x14U))))),32);
        bufp->chgIData(oldp+95,(vlSelfRef.RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTarget),32);
        bufp->chgIData(oldp+96,((0xfffffffeU & (vlSelfRef.RV32ICore__DOT__datapath__DOT__immGen_io_imm 
                                                + vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile_io_readData1))),32);
        bufp->chgBit(oldp+97,(vlSelfRef.RV32ICore__DOT__datapath__DOT__pcUpdate__DOT__branchTaken));
        bufp->chgIData(oldp+98,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_0),32);
        bufp->chgIData(oldp+99,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_7),32);
        bufp->chgIData(oldp+100,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_8),32);
        bufp->chgIData(oldp+101,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_9),32);
        bufp->chgIData(oldp+102,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_10),32);
        bufp->chgIData(oldp+103,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_11),32);
        bufp->chgIData(oldp+104,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_12),32);
        bufp->chgIData(oldp+105,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_13),32);
        bufp->chgIData(oldp+106,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_14),32);
        bufp->chgIData(oldp+107,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_15),32);
        bufp->chgIData(oldp+108,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_16),32);
        bufp->chgIData(oldp+109,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_17),32);
        bufp->chgIData(oldp+110,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_18),32);
        bufp->chgIData(oldp+111,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_19),32);
        bufp->chgIData(oldp+112,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_20),32);
        bufp->chgIData(oldp+113,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_21),32);
        bufp->chgIData(oldp+114,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_22),32);
        bufp->chgIData(oldp+115,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_23),32);
        bufp->chgIData(oldp+116,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_24),32);
        bufp->chgIData(oldp+117,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_25),32);
        bufp->chgIData(oldp+118,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_26),32);
        bufp->chgIData(oldp+119,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_27),32);
        bufp->chgIData(oldp+120,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_28),32);
        bufp->chgIData(oldp+121,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_29),32);
        bufp->chgIData(oldp+122,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_30),32);
        bufp->chgIData(oldp+123,(vlSelfRef.RV32ICore__DOT__datapath__DOT__regFile__DOT__regs_31),32);
        bufp->chgCData(oldp+124,((0xffU & (vlSelfRef.RV32ICore__DOT__pcReg 
                                           >> 2U))),8);
        bufp->chgIData(oldp+125,(vlSelfRef.RV32ICore__DOT__instructionMemory__DOT__mem
                                 [(0xffU & (vlSelfRef.RV32ICore__DOT__pcReg 
                                            >> 2U))]),32);
        bufp->chgIData(oldp+126,(VL_SHIFTR_III(32,32,32, vlSelfRef.RV32ICore__DOT__pcReg, 2U)),32);
    }
    bufp->chgBit(oldp+127,(vlSelfRef.clock));
    bufp->chgBit(oldp+128,(vlSelfRef.reset));
    bufp->chgIData(oldp+129,(vlSelfRef.io_pc),32);
    bufp->chgIData(oldp+130,(vlSelfRef.io_nextPc),32);
    bufp->chgIData(oldp+131,(vlSelfRef.io_writeBack),32);
    bufp->chgIData(oldp+132,(vlSelfRef.io_debugInstr),32);
    bufp->chgIData(oldp+133,(vlSelfRef.io_debugX1),32);
    bufp->chgIData(oldp+134,(vlSelfRef.io_debugX2),32);
    bufp->chgIData(oldp+135,(vlSelfRef.io_debugX3),32);
    bufp->chgIData(oldp+136,(vlSelfRef.io_debugX4),32);
    bufp->chgIData(oldp+137,(vlSelfRef.io_debugX5),32);
    bufp->chgIData(oldp+138,(vlSelfRef.io_debugX6),32);
    bufp->chgIData(oldp+139,(vlSelfRef.io_debugALU),32);
    bufp->chgIData(oldp+140,(vlSelfRef.io_debugImm),32);
    bufp->chgIData(oldp+141,(vlSelfRef.io_debugFetchPC),32);
    bufp->chgIData(oldp+142,(vlSelfRef.io_debugExecPC),32);
    bufp->chgBit(oldp+143,(vlSelfRef.io_debugValid));
    bufp->chgBit(oldp+144,(vlSelfRef.io_debugFlush));
}

void VRV32ICore___024root__trace_cleanup(void* voidSelf, VerilatedVcd* /*unused*/) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VRV32ICore___024root__trace_cleanup\n"); );
    // Init
    VRV32ICore___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<VRV32ICore___024root*>(voidSelf);
    VRV32ICore__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    vlSymsp->__Vm_activity = false;
    vlSymsp->TOP.__Vm_traceActivity[0U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[1U] = 0U;
}
