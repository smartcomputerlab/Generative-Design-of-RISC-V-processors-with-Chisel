FIRRTL version 1.1.0
circuit RV32ICore :
  module InstructionMemory :
    input clock : Clock
    input reset : UInt<1>
    input io_addr : UInt<32>
    output io_instr : UInt<32>

    mem mem : @[InstructionMemory.scala 18:16]
      data-type => UInt<32>
      depth => 256
      read-latency => 0
      write-latency => 1
      reader => io_instr_MPORT
      read-under-write => undefined
    node wordAddr = dshr(io_addr, UInt<2>("h2")) @[InstructionMemory.scala 27:26]
    node _io_instr_T = lt(wordAddr, UInt<9>("h100")) @[InstructionMemory.scala 31:14]
    node _io_instr_T_1 = bits(wordAddr, 7, 0) @[InstructionMemory.scala 32:8]
    node _io_instr_T_2 = mux(_io_instr_T, mem.io_instr_MPORT.data, UInt<32>("h0")) @[InstructionMemory.scala 30:18]
    io_instr <= _io_instr_T_2 @[InstructionMemory.scala 30:12]
    mem.io_instr_MPORT.addr <= _io_instr_T_1 @[InstructionMemory.scala 32:8]
    mem.io_instr_MPORT.en <= UInt<1>("h1") @[InstructionMemory.scala 32:8]
    mem.io_instr_MPORT.clk <= clock @[InstructionMemory.scala 32:8]

  module DataMemory :
    input clock : Clock
    input reset : UInt<1>
    input io_addr : UInt<32>
    input io_wdata : UInt<32>
    output io_rdata : UInt<32>
    input io_memRead : UInt<1>
    input io_memWrite : UInt<1>
    input io_funct3 : UInt<3>

    mem mem : @[DataMemory.scala 18:16]
      data-type => UInt<8>
      depth => 1024
      read-latency => 0
      write-latency => 1
      reader => byte0
      reader => byte1
      reader => byte2
      reader => byte3
      writer => MPORT
      writer => MPORT_1
      writer => MPORT_2
      writer => MPORT_3
      writer => MPORT_4
      writer => MPORT_5
      writer => MPORT_6
      read-under-write => undefined
    node _byte0_T = bits(io_addr, 9, 0) @[DataMemory.scala 20:18]
    node _byte1_T = add(io_addr, UInt<1>("h1")) @[DataMemory.scala 21:27]
    node _byte1_T_1 = tail(_byte1_T, 1) @[DataMemory.scala 21:27]
    node _byte1_T_2 = bits(_byte1_T_1, 9, 0) @[DataMemory.scala 21:18]
    node _byte2_T = add(io_addr, UInt<2>("h2")) @[DataMemory.scala 22:27]
    node _byte2_T_1 = tail(_byte2_T, 1) @[DataMemory.scala 22:27]
    node _byte2_T_2 = bits(_byte2_T_1, 9, 0) @[DataMemory.scala 22:18]
    node _byte3_T = add(io_addr, UInt<2>("h3")) @[DataMemory.scala 23:27]
    node _byte3_T_1 = tail(_byte3_T, 1) @[DataMemory.scala 23:27]
    node _byte3_T_2 = bits(_byte3_T_1, 9, 0) @[DataMemory.scala 23:18]
    node loadData_lo = cat(mem.byte1.data, mem.byte0.data) @[Cat.scala 33:92]
    node loadData_hi = cat(mem.byte3.data, mem.byte2.data) @[Cat.scala 33:92]
    node loadData = cat(loadData_hi, loadData_lo) @[Cat.scala 33:92]
    node _T = eq(UInt<1>("h0"), io_funct3) @[DataMemory.scala 30:23]
    node _io_rdata_T = bits(mem.byte0.data, 7, 7) @[DataMemory.scala 32:39]
    node _io_rdata_T_1 = bits(_io_rdata_T, 0, 0) @[Bitwise.scala 77:15]
    node _io_rdata_T_2 = mux(_io_rdata_T_1, UInt<24>("hffffff"), UInt<24>("h0")) @[Bitwise.scala 77:12]
    node _io_rdata_T_3 = cat(_io_rdata_T_2, mem.byte0.data) @[Cat.scala 33:92]
    node _T_1 = eq(UInt<1>("h1"), io_funct3) @[DataMemory.scala 30:23]
    node _io_rdata_T_4 = bits(mem.byte1.data, 7, 7) @[DataMemory.scala 37:25]
    node _io_rdata_T_5 = bits(_io_rdata_T_4, 0, 0) @[Bitwise.scala 77:15]
    node _io_rdata_T_6 = mux(_io_rdata_T_5, UInt<16>("hffff"), UInt<16>("h0")) @[Bitwise.scala 77:12]
    node io_rdata_hi = cat(_io_rdata_T_6, mem.byte1.data) @[Cat.scala 33:92]
    node _io_rdata_T_7 = cat(io_rdata_hi, mem.byte0.data) @[Cat.scala 33:92]
    node _T_2 = eq(UInt<2>("h2"), io_funct3) @[DataMemory.scala 30:23]
    node _T_3 = eq(UInt<3>("h4"), io_funct3) @[DataMemory.scala 30:23]
    node _io_rdata_T_8 = cat(UInt<24>("h0"), mem.byte0.data) @[Cat.scala 33:92]
    node _T_4 = eq(UInt<3>("h5"), io_funct3) @[DataMemory.scala 30:23]
    node io_rdata_hi_1 = cat(UInt<16>("h0"), mem.byte1.data) @[Cat.scala 33:92]
    node _io_rdata_T_9 = cat(io_rdata_hi_1, mem.byte0.data) @[Cat.scala 33:92]
    node _GEN_0 = mux(_T_4, _io_rdata_T_9, UInt<1>("h0")) @[DataMemory.scala 27:12 30:23 52:18]
    node _GEN_1 = mux(_T_3, _io_rdata_T_8, _GEN_0) @[DataMemory.scala 30:23 48:18]
    node _GEN_2 = mux(_T_2, loadData, _GEN_1) @[DataMemory.scala 30:23 44:18]
    node _GEN_3 = mux(_T_1, _io_rdata_T_7, _GEN_2) @[DataMemory.scala 30:23 36:18]
    node _GEN_4 = mux(_T, _io_rdata_T_3, _GEN_3) @[DataMemory.scala 30:23 32:18]
    node _GEN_5 = mux(io_memRead, _GEN_4, UInt<1>("h0")) @[DataMemory.scala 27:12 29:20]
    node _T_5 = eq(UInt<1>("h0"), io_funct3) @[DataMemory.scala 62:23]
    node _T_6 = bits(io_addr, 9, 0) @[DataMemory.scala 64:12]
    node _T_7 = bits(io_wdata, 7, 0) @[DataMemory.scala 64:33]
    node _T_8 = eq(UInt<1>("h1"), io_funct3) @[DataMemory.scala 62:23]
    node _T_9 = bits(io_addr, 9, 0) @[DataMemory.scala 68:12]
    node _T_10 = bits(io_wdata, 7, 0) @[DataMemory.scala 68:37]
    node _T_11 = add(io_addr, UInt<1>("h1")) @[DataMemory.scala 69:21]
    node _T_12 = tail(_T_11, 1) @[DataMemory.scala 69:21]
    node _T_13 = bits(_T_12, 9, 0) @[DataMemory.scala 69:12]
    node _T_14 = bits(io_wdata, 15, 8) @[DataMemory.scala 69:39]
    node _T_15 = eq(UInt<2>("h2"), io_funct3) @[DataMemory.scala 62:23]
    node _T_16 = bits(io_addr, 9, 0) @[DataMemory.scala 73:12]
    node _T_17 = bits(io_wdata, 7, 0) @[DataMemory.scala 73:37]
    node _T_18 = add(io_addr, UInt<1>("h1")) @[DataMemory.scala 74:21]
    node _T_19 = tail(_T_18, 1) @[DataMemory.scala 74:21]
    node _T_20 = bits(_T_19, 9, 0) @[DataMemory.scala 74:12]
    node _T_21 = bits(io_wdata, 15, 8) @[DataMemory.scala 74:39]
    node _T_22 = add(io_addr, UInt<2>("h2")) @[DataMemory.scala 75:21]
    node _T_23 = tail(_T_22, 1) @[DataMemory.scala 75:21]
    node _T_24 = bits(_T_23, 9, 0) @[DataMemory.scala 75:12]
    node _T_25 = bits(io_wdata, 23, 16) @[DataMemory.scala 75:39]
    node _T_26 = add(io_addr, UInt<2>("h3")) @[DataMemory.scala 76:21]
    node _T_27 = tail(_T_26, 1) @[DataMemory.scala 76:21]
    node _T_28 = bits(_T_27, 9, 0) @[DataMemory.scala 76:12]
    node _T_29 = bits(io_wdata, 31, 24) @[DataMemory.scala 76:39]
    node _GEN_6 = validif(_T_15, _T_16) @[DataMemory.scala 62:23 73:12]
    node _GEN_7 = validif(_T_15, clock) @[DataMemory.scala 62:23 73:12]
    node _GEN_8 = mux(_T_15, UInt<1>("h1"), UInt<1>("h0")) @[DataMemory.scala 62:23 73:12 18:16]
    node _GEN_9 = validif(_T_15, UInt<1>("h1")) @[DataMemory.scala 62:23 73:26]
    node _GEN_10 = validif(_T_15, _T_17) @[DataMemory.scala 62:23 73:26]
    node _GEN_11 = validif(_T_15, _T_20) @[DataMemory.scala 62:23 74:12]
    node _GEN_12 = validif(_T_15, _T_21) @[DataMemory.scala 62:23 74:28]
    node _GEN_13 = validif(_T_15, _T_24) @[DataMemory.scala 62:23 75:12]
    node _GEN_14 = validif(_T_15, _T_25) @[DataMemory.scala 62:23 75:28]
    node _GEN_15 = validif(_T_15, _T_28) @[DataMemory.scala 62:23 76:12]
    node _GEN_16 = validif(_T_15, _T_29) @[DataMemory.scala 62:23 76:28]
    node _GEN_17 = validif(_T_8, _T_9) @[DataMemory.scala 62:23 68:12]
    node _GEN_18 = validif(_T_8, clock) @[DataMemory.scala 62:23 68:12]
    node _GEN_19 = mux(_T_8, UInt<1>("h1"), UInt<1>("h0")) @[DataMemory.scala 62:23 68:12 18:16]
    node _GEN_20 = validif(_T_8, UInt<1>("h1")) @[DataMemory.scala 62:23 68:26]
    node _GEN_21 = validif(_T_8, _T_10) @[DataMemory.scala 62:23 68:26]
    node _GEN_22 = validif(_T_8, _T_13) @[DataMemory.scala 62:23 69:12]
    node _GEN_23 = validif(_T_8, _T_14) @[DataMemory.scala 62:23 69:28]
    node _GEN_24 = validif(eq(_T_8, UInt<1>("h0")), _GEN_6) @[DataMemory.scala 62:23]
    node _GEN_25 = validif(eq(_T_8, UInt<1>("h0")), _GEN_7) @[DataMemory.scala 62:23]
    node _GEN_26 = mux(_T_8, UInt<1>("h0"), _GEN_8) @[DataMemory.scala 18:16 62:23]
    node _GEN_27 = validif(eq(_T_8, UInt<1>("h0")), _GEN_9) @[DataMemory.scala 62:23]
    node _GEN_28 = validif(eq(_T_8, UInt<1>("h0")), _GEN_10) @[DataMemory.scala 62:23]
    node _GEN_29 = validif(eq(_T_8, UInt<1>("h0")), _GEN_11) @[DataMemory.scala 62:23]
    node _GEN_30 = validif(eq(_T_8, UInt<1>("h0")), _GEN_12) @[DataMemory.scala 62:23]
    node _GEN_31 = validif(eq(_T_8, UInt<1>("h0")), _GEN_13) @[DataMemory.scala 62:23]
    node _GEN_32 = validif(eq(_T_8, UInt<1>("h0")), _GEN_14) @[DataMemory.scala 62:23]
    node _GEN_33 = validif(eq(_T_8, UInt<1>("h0")), _GEN_15) @[DataMemory.scala 62:23]
    node _GEN_34 = validif(eq(_T_8, UInt<1>("h0")), _GEN_16) @[DataMemory.scala 62:23]
    node _GEN_35 = validif(_T_5, _T_6) @[DataMemory.scala 62:23 64:12]
    node _GEN_36 = validif(_T_5, clock) @[DataMemory.scala 62:23 64:12]
    node _GEN_37 = mux(_T_5, UInt<1>("h1"), UInt<1>("h0")) @[DataMemory.scala 62:23 64:12 18:16]
    node _GEN_38 = validif(_T_5, UInt<1>("h1")) @[DataMemory.scala 62:23 64:22]
    node _GEN_39 = validif(_T_5, _T_7) @[DataMemory.scala 62:23 64:22]
    node _GEN_40 = validif(eq(_T_5, UInt<1>("h0")), _GEN_17) @[DataMemory.scala 62:23]
    node _GEN_41 = validif(eq(_T_5, UInt<1>("h0")), _GEN_18) @[DataMemory.scala 62:23]
    node _GEN_42 = mux(_T_5, UInt<1>("h0"), _GEN_19) @[DataMemory.scala 18:16 62:23]
    node _GEN_43 = validif(eq(_T_5, UInt<1>("h0")), _GEN_20) @[DataMemory.scala 62:23]
    node _GEN_44 = validif(eq(_T_5, UInt<1>("h0")), _GEN_21) @[DataMemory.scala 62:23]
    node _GEN_45 = validif(eq(_T_5, UInt<1>("h0")), _GEN_22) @[DataMemory.scala 62:23]
    node _GEN_46 = validif(eq(_T_5, UInt<1>("h0")), _GEN_23) @[DataMemory.scala 62:23]
    node _GEN_47 = validif(eq(_T_5, UInt<1>("h0")), _GEN_24) @[DataMemory.scala 62:23]
    node _GEN_48 = validif(eq(_T_5, UInt<1>("h0")), _GEN_25) @[DataMemory.scala 62:23]
    node _GEN_49 = mux(_T_5, UInt<1>("h0"), _GEN_26) @[DataMemory.scala 18:16 62:23]
    node _GEN_50 = validif(eq(_T_5, UInt<1>("h0")), _GEN_27) @[DataMemory.scala 62:23]
    node _GEN_51 = validif(eq(_T_5, UInt<1>("h0")), _GEN_28) @[DataMemory.scala 62:23]
    node _GEN_52 = validif(eq(_T_5, UInt<1>("h0")), _GEN_29) @[DataMemory.scala 62:23]
    node _GEN_53 = validif(eq(_T_5, UInt<1>("h0")), _GEN_30) @[DataMemory.scala 62:23]
    node _GEN_54 = validif(eq(_T_5, UInt<1>("h0")), _GEN_31) @[DataMemory.scala 62:23]
    node _GEN_55 = validif(eq(_T_5, UInt<1>("h0")), _GEN_32) @[DataMemory.scala 62:23]
    node _GEN_56 = validif(eq(_T_5, UInt<1>("h0")), _GEN_33) @[DataMemory.scala 62:23]
    node _GEN_57 = validif(eq(_T_5, UInt<1>("h0")), _GEN_34) @[DataMemory.scala 62:23]
    node _GEN_58 = validif(io_memWrite, _GEN_35) @[DataMemory.scala 61:21]
    node _GEN_59 = validif(io_memWrite, _GEN_36) @[DataMemory.scala 61:21]
    node _GEN_60 = mux(io_memWrite, _GEN_37, UInt<1>("h0")) @[DataMemory.scala 18:16 61:21]
    node _GEN_61 = validif(io_memWrite, _GEN_38) @[DataMemory.scala 61:21]
    node _GEN_62 = validif(io_memWrite, _GEN_39) @[DataMemory.scala 61:21]
    node _GEN_63 = validif(io_memWrite, _GEN_40) @[DataMemory.scala 61:21]
    node _GEN_64 = validif(io_memWrite, _GEN_41) @[DataMemory.scala 61:21]
    node _GEN_65 = mux(io_memWrite, _GEN_42, UInt<1>("h0")) @[DataMemory.scala 18:16 61:21]
    node _GEN_66 = validif(io_memWrite, _GEN_43) @[DataMemory.scala 61:21]
    node _GEN_67 = validif(io_memWrite, _GEN_44) @[DataMemory.scala 61:21]
    node _GEN_68 = validif(io_memWrite, _GEN_45) @[DataMemory.scala 61:21]
    node _GEN_69 = validif(io_memWrite, _GEN_46) @[DataMemory.scala 61:21]
    node _GEN_70 = validif(io_memWrite, _GEN_47) @[DataMemory.scala 61:21]
    node _GEN_71 = validif(io_memWrite, _GEN_48) @[DataMemory.scala 61:21]
    node _GEN_72 = mux(io_memWrite, _GEN_49, UInt<1>("h0")) @[DataMemory.scala 18:16 61:21]
    node _GEN_73 = validif(io_memWrite, _GEN_50) @[DataMemory.scala 61:21]
    node _GEN_74 = validif(io_memWrite, _GEN_51) @[DataMemory.scala 61:21]
    node _GEN_75 = validif(io_memWrite, _GEN_52) @[DataMemory.scala 61:21]
    node _GEN_76 = validif(io_memWrite, _GEN_53) @[DataMemory.scala 61:21]
    node _GEN_77 = validif(io_memWrite, _GEN_54) @[DataMemory.scala 61:21]
    node _GEN_78 = validif(io_memWrite, _GEN_55) @[DataMemory.scala 61:21]
    node _GEN_79 = validif(io_memWrite, _GEN_56) @[DataMemory.scala 61:21]
    node _GEN_80 = validif(io_memWrite, _GEN_57) @[DataMemory.scala 61:21]
    io_rdata <= _GEN_5
    mem.byte0.addr <= _byte0_T @[DataMemory.scala 20:18]
    mem.byte0.en <= UInt<1>("h1") @[DataMemory.scala 20:18]
    mem.byte0.clk <= clock @[DataMemory.scala 20:18]
    mem.byte1.addr <= _byte1_T_2 @[DataMemory.scala 21:18]
    mem.byte1.en <= UInt<1>("h1") @[DataMemory.scala 21:18]
    mem.byte1.clk <= clock @[DataMemory.scala 21:18]
    mem.byte2.addr <= _byte2_T_2 @[DataMemory.scala 22:18]
    mem.byte2.en <= UInt<1>("h1") @[DataMemory.scala 22:18]
    mem.byte2.clk <= clock @[DataMemory.scala 22:18]
    mem.byte3.addr <= _byte3_T_2 @[DataMemory.scala 23:18]
    mem.byte3.en <= UInt<1>("h1") @[DataMemory.scala 23:18]
    mem.byte3.clk <= clock @[DataMemory.scala 23:18]
    mem.MPORT.addr <= _GEN_58
    mem.MPORT.en <= _GEN_60
    mem.MPORT.clk <= _GEN_59
    mem.MPORT.data <= _GEN_62
    mem.MPORT.mask <= _GEN_61
    mem.MPORT_1.addr <= _GEN_63
    mem.MPORT_1.en <= _GEN_65
    mem.MPORT_1.clk <= _GEN_64
    mem.MPORT_1.data <= _GEN_67
    mem.MPORT_1.mask <= _GEN_66
    mem.MPORT_2.addr <= _GEN_68
    mem.MPORT_2.en <= _GEN_65
    mem.MPORT_2.clk <= _GEN_64
    mem.MPORT_2.data <= _GEN_69
    mem.MPORT_2.mask <= _GEN_66
    mem.MPORT_3.addr <= _GEN_70
    mem.MPORT_3.en <= _GEN_72
    mem.MPORT_3.clk <= _GEN_71
    mem.MPORT_3.data <= _GEN_74
    mem.MPORT_3.mask <= _GEN_73
    mem.MPORT_4.addr <= _GEN_75
    mem.MPORT_4.en <= _GEN_72
    mem.MPORT_4.clk <= _GEN_71
    mem.MPORT_4.data <= _GEN_76
    mem.MPORT_4.mask <= _GEN_73
    mem.MPORT_5.addr <= _GEN_77
    mem.MPORT_5.en <= _GEN_72
    mem.MPORT_5.clk <= _GEN_71
    mem.MPORT_5.data <= _GEN_78
    mem.MPORT_5.mask <= _GEN_73
    mem.MPORT_6.addr <= _GEN_79
    mem.MPORT_6.en <= _GEN_72
    mem.MPORT_6.clk <= _GEN_71
    mem.MPORT_6.data <= _GEN_80
    mem.MPORT_6.mask <= _GEN_73

  module Decoder :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    output io_rs1 : UInt<5>
    output io_rs2 : UInt<5>
    output io_rd : UInt<5>
    output io_funct3 : UInt<3>
    output io_funct7 : UInt<7>
    output io_aluSrc : UInt<1>
    output io_regWrite : UInt<1>
    output io_valid : UInt<1>
    output io_aluOp : UInt<5>

    node opcode = bits(io_instr, 6, 0) @[Decoder.scala 31:24]
    node funct3 = bits(io_instr, 14, 12) @[Decoder.scala 32:24]
    node funct7 = bits(io_instr, 31, 25) @[Decoder.scala 33:24]
    node _io_rs1_T = bits(io_instr, 19, 15) @[Decoder.scala 35:24]
    node _io_rs2_T = bits(io_instr, 24, 20) @[Decoder.scala 36:24]
    node _io_rd_T = bits(io_instr, 11, 7) @[Decoder.scala 37:24]
    node _T = eq(UInt<6>("h33"), opcode) @[Decoder.scala 73:18]
    node _T_1 = eq(UInt<1>("h0"), funct3) @[Decoder.scala 84:22]
    node _T_2 = eq(funct7, UInt<1>("h1")) @[Decoder.scala 88:23]
    node _T_3 = eq(funct7, UInt<6>("h20")) @[Decoder.scala 90:29]
    node _GEN_0 = mux(_T_3, UInt<5>("h1"), UInt<5>("h0")) @[Decoder.scala 90:47 91:22 93:22]
    node _GEN_1 = mux(_T_2, UInt<5>("ha"), _GEN_0) @[Decoder.scala 88:41 89:22]
    node _T_4 = eq(UInt<1>("h1"), funct3) @[Decoder.scala 84:22]
    node _T_5 = eq(funct7, UInt<1>("h1")) @[Decoder.scala 99:23]
    node _GEN_2 = mux(_T_5, UInt<5>("hb"), UInt<5>("h2")) @[Decoder.scala 100:22 102:22 99:41]
    node _T_6 = eq(UInt<2>("h2"), funct3) @[Decoder.scala 84:22]
    node _T_7 = eq(funct7, UInt<1>("h1")) @[Decoder.scala 108:23]
    node _GEN_3 = mux(_T_7, UInt<5>("hc"), UInt<5>("h3")) @[Decoder.scala 108:41 109:22 111:22]
    node _T_8 = eq(UInt<2>("h3"), funct3) @[Decoder.scala 84:22]
    node _T_9 = eq(funct7, UInt<1>("h1")) @[Decoder.scala 117:23]
    node _GEN_4 = mux(_T_9, UInt<5>("hd"), UInt<5>("h4")) @[Decoder.scala 117:41 118:22 120:22]
    node _T_10 = eq(UInt<3>("h4"), funct3) @[Decoder.scala 84:22]
    node _T_11 = eq(UInt<3>("h5"), funct3) @[Decoder.scala 84:22]
    node _T_12 = eq(funct7, UInt<6>("h20")) @[Decoder.scala 131:23]
    node _GEN_5 = mux(_T_12, UInt<5>("h7"), UInt<5>("h6")) @[Decoder.scala 131:41 132:22 134:22]
    node _T_13 = eq(UInt<3>("h6"), funct3) @[Decoder.scala 84:22]
    node _T_14 = eq(UInt<3>("h7"), funct3) @[Decoder.scala 84:22]
    node _GEN_6 = mux(_T_14, UInt<5>("h9"), UInt<5>("h0")) @[Decoder.scala 145:20 67:12 84:22]
    node _GEN_7 = mux(_T_13, UInt<5>("h8"), _GEN_6) @[Decoder.scala 140:20 84:22]
    node _GEN_8 = mux(_T_11, _GEN_5, _GEN_7) @[Decoder.scala 84:22]
    node _GEN_9 = mux(_T_10, UInt<5>("h5"), _GEN_8) @[Decoder.scala 126:20 84:22]
    node _GEN_10 = mux(_T_8, _GEN_4, _GEN_9) @[Decoder.scala 84:22]
    node _GEN_11 = mux(_T_6, _GEN_3, _GEN_10) @[Decoder.scala 84:22]
    node _GEN_12 = mux(_T_4, _GEN_2, _GEN_11) @[Decoder.scala 84:22]
    node _GEN_13 = mux(_T_1, _GEN_1, _GEN_12) @[Decoder.scala 84:22]
    node _T_15 = eq(UInt<5>("h13"), opcode) @[Decoder.scala 73:18]
    node _T_16 = eq(UInt<1>("h0"), funct3) @[Decoder.scala 159:22]
    node _T_17 = eq(UInt<1>("h1"), funct3) @[Decoder.scala 159:22]
    node _T_18 = eq(UInt<2>("h2"), funct3) @[Decoder.scala 159:22]
    node _T_19 = eq(UInt<2>("h3"), funct3) @[Decoder.scala 159:22]
    node _T_20 = eq(UInt<3>("h4"), funct3) @[Decoder.scala 159:22]
    node _T_21 = eq(UInt<3>("h5"), funct3) @[Decoder.scala 159:22]
    node _T_22 = eq(funct7, UInt<6>("h20")) @[Decoder.scala 188:23]
    node _GEN_14 = mux(_T_22, UInt<5>("h7"), UInt<5>("h6")) @[Decoder.scala 188:41 189:22 191:22]
    node _T_23 = eq(UInt<3>("h6"), funct3) @[Decoder.scala 159:22]
    node _T_24 = eq(UInt<3>("h7"), funct3) @[Decoder.scala 159:22]
    node _GEN_15 = mux(_T_24, UInt<5>("h9"), UInt<5>("h0")) @[Decoder.scala 159:22 202:20 67:12]
    node _GEN_16 = mux(_T_23, UInt<5>("h8"), _GEN_15) @[Decoder.scala 159:22 197:20]
    node _GEN_17 = mux(_T_21, _GEN_14, _GEN_16) @[Decoder.scala 159:22]
    node _GEN_18 = mux(_T_20, UInt<5>("h5"), _GEN_17) @[Decoder.scala 159:22 183:20]
    node _GEN_19 = mux(_T_19, UInt<5>("h4"), _GEN_18) @[Decoder.scala 159:22 178:20]
    node _GEN_20 = mux(_T_18, UInt<5>("h3"), _GEN_19) @[Decoder.scala 159:22 173:20]
    node _GEN_21 = mux(_T_17, UInt<5>("h2"), _GEN_20) @[Decoder.scala 159:22 168:20]
    node _GEN_22 = mux(_T_16, UInt<5>("h0"), _GEN_21) @[Decoder.scala 159:22 163:20]
    node _T_25 = eq(UInt<2>("h3"), opcode) @[Decoder.scala 73:18]
    node _T_26 = eq(UInt<6>("h23"), opcode) @[Decoder.scala 73:18]
    node _T_27 = eq(UInt<7>("h63"), opcode) @[Decoder.scala 73:18]
    node _T_28 = eq(UInt<1>("h0"), funct3) @[Decoder.scala 238:22]
    node _T_29 = eq(UInt<1>("h1"), funct3) @[Decoder.scala 238:22]
    node _T_30 = eq(UInt<3>("h4"), funct3) @[Decoder.scala 238:22]
    node _T_31 = eq(UInt<3>("h5"), funct3) @[Decoder.scala 238:22]
    node _T_32 = eq(UInt<3>("h6"), funct3) @[Decoder.scala 238:22]
    node _T_33 = eq(UInt<3>("h7"), funct3) @[Decoder.scala 238:22]
    node _GEN_23 = mux(_T_33, UInt<5>("h4"), UInt<5>("h0")) @[Decoder.scala 238:22 267:20 67:12]
    node _GEN_24 = mux(_T_32, UInt<5>("h4"), _GEN_23) @[Decoder.scala 238:22 262:20]
    node _GEN_25 = mux(_T_31, UInt<5>("h3"), _GEN_24) @[Decoder.scala 238:22 257:20]
    node _GEN_26 = mux(_T_30, UInt<5>("h3"), _GEN_25) @[Decoder.scala 238:22 252:20]
    node _GEN_27 = mux(_T_29, UInt<5>("hf"), _GEN_26) @[Decoder.scala 238:22 247:20]
    node _GEN_28 = mux(_T_28, UInt<5>("he"), _GEN_27) @[Decoder.scala 238:22 242:20]
    node _T_34 = eq(UInt<7>("h6f"), opcode) @[Decoder.scala 73:18]
    node _T_35 = eq(UInt<7>("h67"), opcode) @[Decoder.scala 73:18]
    node _T_36 = eq(UInt<6>("h37"), opcode) @[Decoder.scala 73:18]
    node _T_37 = eq(UInt<5>("h17"), opcode) @[Decoder.scala 73:18]
    node _GEN_29 = mux(_T_37, UInt<1>("h1"), UInt<1>("h0")) @[Decoder.scala 73:18 310:19 60:15]
    node _GEN_30 = mux(_T_37, UInt<5>("h0"), UInt<5>("h0")) @[Decoder.scala 73:18 313:19 67:12]
    node _GEN_31 = mux(_T_36, UInt<1>("h1"), _GEN_29) @[Decoder.scala 73:18 299:19]
    node _GEN_32 = mux(_T_36, UInt<5>("h0"), _GEN_30) @[Decoder.scala 73:18 302:19]
    node _GEN_33 = mux(_T_35, UInt<1>("h1"), _GEN_31) @[Decoder.scala 73:18 288:19]
    node _GEN_34 = mux(_T_35, UInt<5>("h0"), _GEN_32) @[Decoder.scala 73:18 291:19]
    node _GEN_35 = mux(_T_34, UInt<1>("h1"), _GEN_33) @[Decoder.scala 73:18 277:19]
    node _GEN_36 = mux(_T_34, UInt<1>("h0"), _GEN_33) @[Decoder.scala 73:18 278:19]
    node _GEN_37 = mux(_T_34, UInt<5>("h0"), _GEN_34) @[Decoder.scala 73:18 280:19]
    node _GEN_38 = mux(_T_27, UInt<1>("h1"), _GEN_35) @[Decoder.scala 73:18 234:19]
    node _GEN_39 = mux(_T_27, UInt<1>("h0"), _GEN_36) @[Decoder.scala 73:18 235:19]
    node _GEN_40 = mux(_T_27, UInt<1>("h0"), _GEN_35) @[Decoder.scala 73:18 236:19]
    node _GEN_41 = mux(_T_27, _GEN_28, _GEN_37) @[Decoder.scala 73:18]
    node _GEN_42 = mux(_T_26, UInt<1>("h1"), _GEN_38) @[Decoder.scala 73:18 223:19]
    node _GEN_43 = mux(_T_26, UInt<1>("h1"), _GEN_39) @[Decoder.scala 73:18 224:19]
    node _GEN_44 = mux(_T_26, UInt<1>("h0"), _GEN_40) @[Decoder.scala 73:18 225:19]
    node _GEN_45 = mux(_T_26, UInt<5>("h0"), _GEN_41) @[Decoder.scala 73:18 226:19]
    node _GEN_46 = mux(_T_25, UInt<1>("h1"), _GEN_42) @[Decoder.scala 73:18 212:19]
    node _GEN_47 = mux(_T_25, UInt<1>("h1"), _GEN_43) @[Decoder.scala 73:18 213:19]
    node _GEN_48 = mux(_T_25, UInt<1>("h1"), _GEN_44) @[Decoder.scala 73:18 214:19]
    node _GEN_49 = mux(_T_25, UInt<5>("h0"), _GEN_45) @[Decoder.scala 73:18 215:19]
    node _GEN_50 = mux(_T_15, UInt<1>("h1"), _GEN_46) @[Decoder.scala 73:18 155:19]
    node _GEN_51 = mux(_T_15, UInt<1>("h1"), _GEN_47) @[Decoder.scala 73:18 156:19]
    node _GEN_52 = mux(_T_15, UInt<1>("h1"), _GEN_48) @[Decoder.scala 73:18 157:19]
    node _GEN_53 = mux(_T_15, _GEN_22, _GEN_49) @[Decoder.scala 73:18]
    node _GEN_54 = mux(_T, UInt<1>("h1"), _GEN_50) @[Decoder.scala 73:18 80:19]
    node _GEN_55 = mux(_T, UInt<1>("h0"), _GEN_51) @[Decoder.scala 73:18 81:19]
    node _GEN_56 = mux(_T, UInt<1>("h1"), _GEN_52) @[Decoder.scala 73:18 82:19]
    node _GEN_57 = mux(_T, _GEN_13, _GEN_53) @[Decoder.scala 73:18]
    io_rs1 <= _io_rs1_T @[Decoder.scala 35:13]
    io_rs2 <= _io_rs2_T @[Decoder.scala 36:13]
    io_rd <= _io_rd_T @[Decoder.scala 37:13]
    io_funct3 <= funct3 @[Decoder.scala 39:13]
    io_funct7 <= funct7 @[Decoder.scala 40:13]
    io_aluSrc <= _GEN_55
    io_regWrite <= _GEN_56
    io_valid <= _GEN_54
    io_aluOp <= _GEN_57

  module Control :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    output io_valid : UInt<1>
    output io_aluOp : UInt<5>
    output io_aluASel : UInt<2>
    output io_aluSrc : UInt<1>
    output io_memRead : UInt<1>
    output io_memWrite : UInt<1>
    output io_memToReg : UInt<1>
    output io_regWrite : UInt<1>
    output io_wbSel : UInt<2>
    output io_branch : UInt<1>
    output io_jump : UInt<1>
    output io_jalr : UInt<1>
    output io_usesRs1 : UInt<1>
    output io_usesRs2 : UInt<1>

    node opcode = bits(io_instr, 6, 0) @[Control.scala 28:24]
    node funct3 = bits(io_instr, 14, 12) @[Control.scala 28:52]
    node funct7 = bits(io_instr, 31, 25) @[Control.scala 28:82]
    node _T = eq(UInt<6>("h33"), opcode) @[Control.scala 40:18]
    node _T_1 = eq(UInt<1>("h0"), funct3) @[Control.scala 43:22]
    node _io_aluOp_T = eq(funct7, UInt<1>("h1")) @[Control.scala 44:41]
    node _io_aluOp_T_1 = eq(funct7, UInt<6>("h20")) @[Control.scala 44:70]
    node _io_aluOp_T_2 = mux(_io_aluOp_T_1, UInt<5>("h1"), UInt<5>("h0")) @[Control.scala 44:63]
    node _io_aluOp_T_3 = mux(_io_aluOp_T, UInt<5>("ha"), _io_aluOp_T_2) @[Control.scala 44:34]
    node _T_2 = eq(UInt<1>("h1"), funct3) @[Control.scala 43:22]
    node _io_aluOp_T_4 = eq(funct7, UInt<1>("h1")) @[Control.scala 45:41]
    node _io_aluOp_T_5 = mux(_io_aluOp_T_4, UInt<5>("hb"), UInt<5>("h2")) @[Control.scala 45:34]
    node _T_3 = eq(UInt<2>("h2"), funct3) @[Control.scala 43:22]
    node _io_aluOp_T_6 = eq(funct7, UInt<1>("h1")) @[Control.scala 46:41]
    node _io_aluOp_T_7 = mux(_io_aluOp_T_6, UInt<5>("hc"), UInt<5>("h3")) @[Control.scala 46:34]
    node _T_4 = eq(UInt<2>("h3"), funct3) @[Control.scala 43:22]
    node _io_aluOp_T_8 = eq(funct7, UInt<1>("h1")) @[Control.scala 47:41]
    node _io_aluOp_T_9 = mux(_io_aluOp_T_8, UInt<5>("hd"), UInt<5>("h4")) @[Control.scala 47:34]
    node _T_5 = eq(UInt<3>("h4"), funct3) @[Control.scala 43:22]
    node _io_aluOp_T_10 = eq(funct7, UInt<1>("h1")) @[Control.scala 48:41]
    node _io_aluOp_T_11 = mux(_io_aluOp_T_10, UInt<5>("h10"), UInt<5>("h5")) @[Control.scala 48:34]
    node _T_6 = eq(UInt<3>("h5"), funct3) @[Control.scala 43:22]
    node _io_aluOp_T_12 = eq(funct7, UInt<1>("h1")) @[Control.scala 49:41]
    node _io_aluOp_T_13 = eq(funct7, UInt<6>("h20")) @[Control.scala 49:71]
    node _io_aluOp_T_14 = mux(_io_aluOp_T_13, UInt<5>("h7"), UInt<5>("h6")) @[Control.scala 49:64]
    node _io_aluOp_T_15 = mux(_io_aluOp_T_12, UInt<5>("h11"), _io_aluOp_T_14) @[Control.scala 49:34]
    node _T_7 = eq(UInt<3>("h6"), funct3) @[Control.scala 43:22]
    node _io_aluOp_T_16 = eq(funct7, UInt<1>("h1")) @[Control.scala 50:41]
    node _io_aluOp_T_17 = mux(_io_aluOp_T_16, UInt<5>("h12"), UInt<5>("h8")) @[Control.scala 50:34]
    node _T_8 = eq(UInt<3>("h7"), funct3) @[Control.scala 43:22]
    node _io_aluOp_T_18 = eq(funct7, UInt<1>("h1")) @[Control.scala 51:41]
    node _io_aluOp_T_19 = mux(_io_aluOp_T_18, UInt<5>("h13"), UInt<5>("h9")) @[Control.scala 51:34]
    node _GEN_0 = mux(_T_8, _io_aluOp_T_19, UInt<5>("h0")) @[Control.scala 43:22 51:28 34:33]
    node _GEN_1 = mux(_T_7, _io_aluOp_T_17, _GEN_0) @[Control.scala 43:22 50:28]
    node _GEN_2 = mux(_T_6, _io_aluOp_T_15, _GEN_1) @[Control.scala 43:22 49:28]
    node _GEN_3 = mux(_T_5, _io_aluOp_T_11, _GEN_2) @[Control.scala 43:22 48:28]
    node _GEN_4 = mux(_T_4, _io_aluOp_T_9, _GEN_3) @[Control.scala 43:22 47:28]
    node _GEN_5 = mux(_T_3, _io_aluOp_T_7, _GEN_4) @[Control.scala 43:22 46:28]
    node _GEN_6 = mux(_T_2, _io_aluOp_T_5, _GEN_5) @[Control.scala 43:22 45:28]
    node _GEN_7 = mux(_T_1, _io_aluOp_T_3, _GEN_6) @[Control.scala 43:22 44:28]
    node _T_9 = eq(UInt<5>("h13"), opcode) @[Control.scala 40:18]
    node _T_10 = eq(UInt<1>("h0"), funct3) @[Control.scala 56:22]
    node _T_11 = eq(UInt<2>("h2"), funct3) @[Control.scala 56:22]
    node _T_12 = eq(UInt<2>("h3"), funct3) @[Control.scala 56:22]
    node _T_13 = eq(UInt<3>("h4"), funct3) @[Control.scala 56:22]
    node _T_14 = eq(UInt<3>("h6"), funct3) @[Control.scala 56:22]
    node _T_15 = eq(UInt<3>("h7"), funct3) @[Control.scala 56:22]
    node _T_16 = eq(UInt<1>("h1"), funct3) @[Control.scala 56:22]
    node _T_17 = eq(UInt<3>("h5"), funct3) @[Control.scala 56:22]
    node _io_aluOp_T_20 = eq(funct7, UInt<6>("h20")) @[Control.scala 61:41]
    node _io_aluOp_T_21 = mux(_io_aluOp_T_20, UInt<5>("h7"), UInt<5>("h6")) @[Control.scala 61:34]
    node _GEN_8 = mux(_T_17, _io_aluOp_T_21, UInt<5>("h0")) @[Control.scala 56:22 61:28 34:33]
    node _GEN_9 = mux(_T_16, UInt<5>("h2"), _GEN_8) @[Control.scala 56:22 60:28]
    node _GEN_10 = mux(_T_15, UInt<5>("h9"), _GEN_9) @[Control.scala 56:22 59:64]
    node _GEN_11 = mux(_T_14, UInt<5>("h8"), _GEN_10) @[Control.scala 56:22 59:28]
    node _GEN_12 = mux(_T_13, UInt<5>("h5"), _GEN_11) @[Control.scala 56:22 58:64]
    node _GEN_13 = mux(_T_12, UInt<5>("h4"), _GEN_12) @[Control.scala 56:22 58:28]
    node _GEN_14 = mux(_T_11, UInt<5>("h3"), _GEN_13) @[Control.scala 56:22 57:64]
    node _GEN_15 = mux(_T_10, UInt<5>("h0"), _GEN_14) @[Control.scala 56:22 57:28]
    node _T_18 = eq(UInt<2>("h3"), opcode) @[Control.scala 40:18]
    node _T_19 = eq(UInt<6>("h23"), opcode) @[Control.scala 40:18]
    node _T_20 = eq(UInt<7>("h63"), opcode) @[Control.scala 40:18]
    node _T_21 = eq(UInt<7>("h6f"), opcode) @[Control.scala 40:18]
    node _T_22 = eq(UInt<7>("h67"), opcode) @[Control.scala 40:18]
    node _T_23 = eq(UInt<6>("h37"), opcode) @[Control.scala 40:18]
    node _T_24 = eq(UInt<5>("h17"), opcode) @[Control.scala 40:18]
    node _GEN_16 = mux(_T_24, UInt<1>("h1"), UInt<1>("h0")) @[Control.scala 34:12 40:18 89:16]
    node _GEN_17 = mux(_T_24, UInt<2>("h2"), UInt<2>("h0")) @[Control.scala 40:18 89:38 34:58]
    node _GEN_18 = mux(_T_24, UInt<5>("h0"), UInt<5>("h0")) @[Control.scala 40:18 34:33 90:37]
    node _GEN_19 = mux(_T_23, UInt<1>("h1"), _GEN_16) @[Control.scala 40:18 85:16]
    node _GEN_20 = mux(_T_23, UInt<2>("h1"), _GEN_17) @[Control.scala 40:18 85:38]
    node _GEN_21 = mux(_T_23, UInt<5>("h0"), _GEN_18) @[Control.scala 40:18 86:37]
    node _GEN_22 = mux(_T_22, UInt<1>("h1"), _GEN_19) @[Control.scala 40:18 80:16]
    node _GEN_23 = mux(_T_22, UInt<1>("h1"), UInt<1>("h0")) @[Control.scala 38:14 40:18 80:38]
    node _GEN_24 = mux(_T_22, UInt<5>("h0"), _GEN_21) @[Control.scala 40:18 82:16]
    node _GEN_25 = mux(_T_22, UInt<2>("h2"), UInt<2>("h0")) @[Control.scala 40:18 82:39 36:60]
    node _GEN_26 = mux(_T_22, UInt<2>("h0"), _GEN_20) @[Control.scala 40:18 34:58]
    node _GEN_27 = mux(_T_21, UInt<1>("h1"), _GEN_22) @[Control.scala 40:18 77:16]
    node _GEN_28 = mux(_T_21, UInt<1>("h1"), UInt<1>("h0")) @[Control.scala 40:18 37:33 77:35]
    node _GEN_29 = mux(_T_21, UInt<2>("h2"), _GEN_25) @[Control.scala 40:18 77:78]
    node _GEN_30 = mux(_T_21, UInt<1>("h0"), _GEN_23) @[Control.scala 38:14 40:18]
    node _GEN_31 = mux(_T_21, UInt<1>("h0"), _GEN_22) @[Control.scala 35:13 40:18]
    node _GEN_32 = mux(_T_21, UInt<5>("h0"), _GEN_24) @[Control.scala 40:18 34:33]
    node _GEN_33 = mux(_T_21, UInt<2>("h0"), _GEN_26) @[Control.scala 40:18 34:58]
    node _GEN_34 = mux(_T_20, UInt<1>("h1"), _GEN_27) @[Control.scala 40:18 74:16]
    node _GEN_35 = mux(_T_20, UInt<1>("h1"), _GEN_30) @[Control.scala 40:18 74:38]
    node _GEN_36 = mux(_T_20, UInt<1>("h1"), UInt<1>("h0")) @[Control.scala 40:18 38:37 74:60]
    node _GEN_37 = mux(_T_20, UInt<1>("h0"), _GEN_28) @[Control.scala 40:18 37:33]
    node _GEN_38 = mux(_T_20, UInt<1>("h0"), _GEN_27) @[Control.scala 40:18 36:39]
    node _GEN_39 = mux(_T_20, UInt<2>("h0"), _GEN_29) @[Control.scala 40:18 36:60]
    node _GEN_40 = mux(_T_20, UInt<1>("h0"), _GEN_30) @[Control.scala 40:18 37:53]
    node _GEN_41 = mux(_T_20, UInt<1>("h0"), _GEN_31) @[Control.scala 35:13 40:18]
    node _GEN_42 = mux(_T_20, UInt<5>("h0"), _GEN_32) @[Control.scala 40:18 34:33]
    node _GEN_43 = mux(_T_20, UInt<2>("h0"), _GEN_33) @[Control.scala 40:18 34:58]
    node _GEN_44 = mux(_T_19, UInt<1>("h1"), _GEN_34) @[Control.scala 40:18 70:16]
    node _GEN_45 = mux(_T_19, UInt<1>("h1"), _GEN_35) @[Control.scala 40:18 70:38]
    node _GEN_46 = mux(_T_19, UInt<1>("h1"), _GEN_36) @[Control.scala 40:18 70:60]
    node _GEN_47 = mux(_T_19, UInt<1>("h1"), _GEN_41) @[Control.scala 40:18 71:17]
    node _GEN_48 = mux(_T_19, UInt<5>("h0"), _GEN_42) @[Control.scala 40:18 71:37]
    node _GEN_49 = mux(_T_19, UInt<1>("h1"), UInt<1>("h0")) @[Control.scala 40:18 35:60 71:63]
    node _GEN_50 = mux(_T_19, UInt<1>("h0"), _GEN_36) @[Control.scala 37:13 40:18]
    node _GEN_51 = mux(_T_19, UInt<1>("h0"), _GEN_37) @[Control.scala 40:18 37:33]
    node _GEN_52 = mux(_T_19, UInt<1>("h0"), _GEN_38) @[Control.scala 40:18 36:39]
    node _GEN_53 = mux(_T_19, UInt<2>("h0"), _GEN_39) @[Control.scala 40:18 36:60]
    node _GEN_54 = mux(_T_19, UInt<1>("h0"), _GEN_40) @[Control.scala 40:18 37:53]
    node _GEN_55 = mux(_T_19, UInt<2>("h0"), _GEN_43) @[Control.scala 40:18 34:58]
    node _GEN_56 = mux(_T_18, UInt<1>("h1"), _GEN_44) @[Control.scala 40:18 65:16]
    node _GEN_57 = mux(_T_18, UInt<1>("h1"), _GEN_45) @[Control.scala 40:18 65:38]
    node _GEN_58 = mux(_T_18, UInt<1>("h1"), _GEN_47) @[Control.scala 40:18 65:59]
    node _GEN_59 = mux(_T_18, UInt<5>("h0"), _GEN_48) @[Control.scala 40:18 66:16]
    node _GEN_60 = mux(_T_18, UInt<1>("h1"), UInt<1>("h0")) @[Control.scala 40:18 35:36 66:41]
    node _GEN_61 = mux(_T_18, UInt<1>("h1"), _GEN_52) @[Control.scala 40:18 67:19]
    node _GEN_62 = mux(_T_18, UInt<2>("h1"), _GEN_53) @[Control.scala 40:18 67:39]
    node _GEN_63 = mux(_T_18, UInt<1>("h0"), _GEN_46) @[Control.scala 40:18 38:37]
    node _GEN_64 = mux(_T_18, UInt<1>("h0"), _GEN_49) @[Control.scala 40:18 35:60]
    node _GEN_65 = mux(_T_18, UInt<1>("h0"), _GEN_50) @[Control.scala 37:13 40:18]
    node _GEN_66 = mux(_T_18, UInt<1>("h0"), _GEN_51) @[Control.scala 40:18 37:33]
    node _GEN_67 = mux(_T_18, UInt<1>("h0"), _GEN_54) @[Control.scala 40:18 37:53]
    node _GEN_68 = mux(_T_18, UInt<2>("h0"), _GEN_55) @[Control.scala 40:18 34:58]
    node _GEN_69 = mux(_T_9, UInt<1>("h1"), _GEN_56) @[Control.scala 40:18 55:16]
    node _GEN_70 = mux(_T_9, UInt<1>("h1"), _GEN_57) @[Control.scala 40:18 55:38]
    node _GEN_71 = mux(_T_9, UInt<1>("h1"), _GEN_58) @[Control.scala 40:18 55:59]
    node _GEN_72 = mux(_T_9, UInt<1>("h1"), _GEN_61) @[Control.scala 40:18 55:82]
    node _GEN_73 = mux(_T_9, _GEN_15, _GEN_59) @[Control.scala 40:18]
    node _GEN_74 = mux(_T_9, UInt<1>("h0"), _GEN_60) @[Control.scala 40:18 35:36]
    node _GEN_75 = mux(_T_9, UInt<2>("h0"), _GEN_62) @[Control.scala 40:18 36:60]
    node _GEN_76 = mux(_T_9, UInt<1>("h0"), _GEN_63) @[Control.scala 40:18 38:37]
    node _GEN_77 = mux(_T_9, UInt<1>("h0"), _GEN_64) @[Control.scala 40:18 35:60]
    node _GEN_78 = mux(_T_9, UInt<1>("h0"), _GEN_65) @[Control.scala 37:13 40:18]
    node _GEN_79 = mux(_T_9, UInt<1>("h0"), _GEN_66) @[Control.scala 40:18 37:33]
    node _GEN_80 = mux(_T_9, UInt<1>("h0"), _GEN_67) @[Control.scala 40:18 37:53]
    node _GEN_81 = mux(_T_9, UInt<2>("h0"), _GEN_68) @[Control.scala 40:18 34:58]
    node _GEN_82 = mux(_T, UInt<1>("h1"), _GEN_69) @[Control.scala 40:18 42:16]
    node _GEN_83 = mux(_T, UInt<1>("h1"), _GEN_70) @[Control.scala 40:18 42:38]
    node _GEN_84 = mux(_T, UInt<1>("h1"), _GEN_76) @[Control.scala 40:18 42:60]
    node _GEN_85 = mux(_T, UInt<1>("h1"), _GEN_72) @[Control.scala 40:18 42:83]
    node _GEN_86 = mux(_T, _GEN_7, _GEN_73) @[Control.scala 40:18]
    node _GEN_87 = mux(_T, UInt<1>("h0"), _GEN_71) @[Control.scala 35:13 40:18]
    node _GEN_88 = mux(_T, UInt<1>("h0"), _GEN_74) @[Control.scala 40:18 35:36]
    node _GEN_89 = mux(_T, UInt<2>("h0"), _GEN_75) @[Control.scala 40:18 36:60]
    node _GEN_90 = mux(_T, UInt<1>("h0"), _GEN_77) @[Control.scala 40:18 35:60]
    node _GEN_91 = mux(_T, UInt<1>("h0"), _GEN_78) @[Control.scala 37:13 40:18]
    node _GEN_92 = mux(_T, UInt<1>("h0"), _GEN_79) @[Control.scala 40:18 37:33]
    node _GEN_93 = mux(_T, UInt<1>("h0"), _GEN_80) @[Control.scala 40:18 37:53]
    node _GEN_94 = mux(_T, UInt<2>("h0"), _GEN_81) @[Control.scala 40:18 34:58]
    io_valid <= _GEN_82
    io_aluOp <= _GEN_86
    io_aluASel <= _GEN_94
    io_aluSrc <= _GEN_87
    io_memRead <= _GEN_88
    io_memWrite <= _GEN_90
    io_memToReg <= _GEN_88
    io_regWrite <= _GEN_85
    io_wbSel <= _GEN_89
    io_branch <= _GEN_91
    io_jump <= _GEN_92
    io_jalr <= _GEN_93
    io_usesRs1 <= _GEN_83
    io_usesRs2 <= _GEN_84

  module ImmediateGenerator :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    output io_imm : UInt<32>

    node opcode = bits(io_instr, 6, 0) @[ImmediateGenerator.scala 12:24]
    node _iImm_T = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 15:22]
    node _iImm_T_1 = bits(_iImm_T, 0, 0) @[Bitwise.scala 77:15]
    node _iImm_T_2 = mux(_iImm_T_1, UInt<20>("hfffff"), UInt<20>("h0")) @[Bitwise.scala 77:12]
    node _iImm_T_3 = bits(io_instr, 31, 20) @[ImmediateGenerator.scala 16:13]
    node iImm = cat(_iImm_T_2, _iImm_T_3) @[Cat.scala 33:92]
    node _sImm_T = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 20:22]
    node _sImm_T_1 = bits(_sImm_T, 0, 0) @[Bitwise.scala 77:15]
    node _sImm_T_2 = mux(_sImm_T_1, UInt<20>("hfffff"), UInt<20>("h0")) @[Bitwise.scala 77:12]
    node _sImm_T_3 = bits(io_instr, 31, 25) @[ImmediateGenerator.scala 21:13]
    node _sImm_T_4 = bits(io_instr, 11, 7) @[ImmediateGenerator.scala 22:13]
    node sImm_hi = cat(_sImm_T_2, _sImm_T_3) @[Cat.scala 33:92]
    node sImm = cat(sImm_hi, _sImm_T_4) @[Cat.scala 33:92]
    node _bImm_T = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 26:22]
    node _bImm_T_1 = bits(_bImm_T, 0, 0) @[Bitwise.scala 77:15]
    node _bImm_T_2 = mux(_bImm_T_1, UInt<19>("h7ffff"), UInt<19>("h0")) @[Bitwise.scala 77:12]
    node _bImm_T_3 = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 27:13]
    node _bImm_T_4 = bits(io_instr, 7, 7) @[ImmediateGenerator.scala 28:13]
    node _bImm_T_5 = bits(io_instr, 30, 25) @[ImmediateGenerator.scala 29:13]
    node _bImm_T_6 = bits(io_instr, 11, 8) @[ImmediateGenerator.scala 30:13]
    node bImm_lo_hi = cat(_bImm_T_5, _bImm_T_6) @[Cat.scala 33:92]
    node bImm_lo = cat(bImm_lo_hi, UInt<1>("h0")) @[Cat.scala 33:92]
    node bImm_hi_hi = cat(_bImm_T_2, _bImm_T_3) @[Cat.scala 33:92]
    node bImm_hi = cat(bImm_hi_hi, _bImm_T_4) @[Cat.scala 33:92]
    node bImm = cat(bImm_hi, bImm_lo) @[Cat.scala 33:92]
    node _uImm_T = bits(io_instr, 31, 12) @[ImmediateGenerator.scala 35:13]
    node uImm = cat(_uImm_T, UInt<12>("h0")) @[Cat.scala 33:92]
    node _jImm_T = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 40:22]
    node _jImm_T_1 = bits(_jImm_T, 0, 0) @[Bitwise.scala 77:15]
    node _jImm_T_2 = mux(_jImm_T_1, UInt<11>("h7ff"), UInt<11>("h0")) @[Bitwise.scala 77:12]
    node _jImm_T_3 = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 41:13]
    node _jImm_T_4 = bits(io_instr, 19, 12) @[ImmediateGenerator.scala 42:13]
    node _jImm_T_5 = bits(io_instr, 20, 20) @[ImmediateGenerator.scala 43:13]
    node _jImm_T_6 = bits(io_instr, 30, 21) @[ImmediateGenerator.scala 44:13]
    node jImm_lo_hi = cat(_jImm_T_5, _jImm_T_6) @[Cat.scala 33:92]
    node jImm_lo = cat(jImm_lo_hi, UInt<1>("h0")) @[Cat.scala 33:92]
    node jImm_hi_hi = cat(_jImm_T_2, _jImm_T_3) @[Cat.scala 33:92]
    node jImm_hi = cat(jImm_hi_hi, _jImm_T_4) @[Cat.scala 33:92]
    node jImm = cat(jImm_hi, jImm_lo) @[Cat.scala 33:92]
    node _T = eq(UInt<2>("h3"), opcode) @[ImmediateGenerator.scala 50:18]
    node _T_1 = eq(UInt<5>("h13"), opcode) @[ImmediateGenerator.scala 50:18]
    node _T_2 = eq(UInt<7>("h67"), opcode) @[ImmediateGenerator.scala 50:18]
    node _T_3 = eq(UInt<6>("h23"), opcode) @[ImmediateGenerator.scala 50:18]
    node _T_4 = eq(UInt<7>("h63"), opcode) @[ImmediateGenerator.scala 50:18]
    node _T_5 = eq(UInt<6>("h37"), opcode) @[ImmediateGenerator.scala 50:18]
    node _T_6 = eq(UInt<5>("h17"), opcode) @[ImmediateGenerator.scala 50:18]
    node _T_7 = eq(UInt<7>("h6f"), opcode) @[ImmediateGenerator.scala 50:18]
    node _GEN_0 = mux(_T_7, jImm, UInt<1>("h0")) @[ImmediateGenerator.scala 48:10 50:18 81:14]
    node _GEN_1 = mux(_T_6, uImm, _GEN_0) @[ImmediateGenerator.scala 50:18 77:14]
    node _GEN_2 = mux(_T_5, uImm, _GEN_1) @[ImmediateGenerator.scala 50:18 73:14]
    node _GEN_3 = mux(_T_4, bImm, _GEN_2) @[ImmediateGenerator.scala 50:18 69:14]
    node _GEN_4 = mux(_T_3, sImm, _GEN_3) @[ImmediateGenerator.scala 50:18 65:14]
    node _GEN_5 = mux(_T_2, iImm, _GEN_4) @[ImmediateGenerator.scala 50:18 61:14]
    node _GEN_6 = mux(_T_1, iImm, _GEN_5) @[ImmediateGenerator.scala 50:18 57:14]
    node _GEN_7 = mux(_T, iImm, _GEN_6) @[ImmediateGenerator.scala 50:18 53:14]
    io_imm <= _GEN_7

  module RegisterFile :
    input clock : Clock
    input reset : UInt<1>
    input io_rs1 : UInt<5>
    input io_rs2 : UInt<5>
    output io_readData1 : UInt<32>
    output io_readData2 : UInt<32>
    input io_rd : UInt<5>
    input io_writeData : UInt<32>
    input io_writeEnable : UInt<1>
    output io_debugRead_0 : UInt<32>
    output io_debugRead_1 : UInt<32>
    output io_debugRead_2 : UInt<32>
    output io_debugRead_3 : UInt<32>
    output io_debugRead_4 : UInt<32>
    output io_debugRead_5 : UInt<32>
    output io_debugRead_6 : UInt<32>
    output io_debugRead_7 : UInt<32>
    output io_debugRead_8 : UInt<32>
    output io_debugRead_9 : UInt<32>
    output io_debugRead_10 : UInt<32>
    output io_debugRead_11 : UInt<32>
    output io_debugRead_12 : UInt<32>
    output io_debugRead_13 : UInt<32>
    output io_debugRead_14 : UInt<32>
    output io_debugRead_15 : UInt<32>
    output io_debugRead_16 : UInt<32>
    output io_debugRead_17 : UInt<32>
    output io_debugRead_18 : UInt<32>
    output io_debugRead_19 : UInt<32>
    output io_debugRead_20 : UInt<32>
    output io_debugRead_21 : UInt<32>
    output io_debugRead_22 : UInt<32>
    output io_debugRead_23 : UInt<32>
    output io_debugRead_24 : UInt<32>
    output io_debugRead_25 : UInt<32>
    output io_debugRead_26 : UInt<32>
    output io_debugRead_27 : UInt<32>
    output io_debugRead_28 : UInt<32>
    output io_debugRead_29 : UInt<32>
    output io_debugRead_30 : UInt<32>
    output io_debugRead_31 : UInt<32>

    reg regs_0 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_0) @[RegisterFile.scala 39:21]
    reg regs_1 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_1) @[RegisterFile.scala 39:21]
    reg regs_2 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_2) @[RegisterFile.scala 39:21]
    reg regs_3 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_3) @[RegisterFile.scala 39:21]
    reg regs_4 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_4) @[RegisterFile.scala 39:21]
    reg regs_5 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_5) @[RegisterFile.scala 39:21]
    reg regs_6 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_6) @[RegisterFile.scala 39:21]
    reg regs_7 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_7) @[RegisterFile.scala 39:21]
    reg regs_8 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_8) @[RegisterFile.scala 39:21]
    reg regs_9 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_9) @[RegisterFile.scala 39:21]
    reg regs_10 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_10) @[RegisterFile.scala 39:21]
    reg regs_11 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_11) @[RegisterFile.scala 39:21]
    reg regs_12 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_12) @[RegisterFile.scala 39:21]
    reg regs_13 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_13) @[RegisterFile.scala 39:21]
    reg regs_14 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_14) @[RegisterFile.scala 39:21]
    reg regs_15 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_15) @[RegisterFile.scala 39:21]
    reg regs_16 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_16) @[RegisterFile.scala 39:21]
    reg regs_17 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_17) @[RegisterFile.scala 39:21]
    reg regs_18 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_18) @[RegisterFile.scala 39:21]
    reg regs_19 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_19) @[RegisterFile.scala 39:21]
    reg regs_20 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_20) @[RegisterFile.scala 39:21]
    reg regs_21 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_21) @[RegisterFile.scala 39:21]
    reg regs_22 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_22) @[RegisterFile.scala 39:21]
    reg regs_23 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_23) @[RegisterFile.scala 39:21]
    reg regs_24 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_24) @[RegisterFile.scala 39:21]
    reg regs_25 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_25) @[RegisterFile.scala 39:21]
    reg regs_26 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_26) @[RegisterFile.scala 39:21]
    reg regs_27 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_27) @[RegisterFile.scala 39:21]
    reg regs_28 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_28) @[RegisterFile.scala 39:21]
    reg regs_29 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_29) @[RegisterFile.scala 39:21]
    reg regs_30 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_30) @[RegisterFile.scala 39:21]
    reg regs_31 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_31) @[RegisterFile.scala 39:21]
    node _io_readData1_T = eq(io_rs1, UInt<1>("h0")) @[RegisterFile.scala 42:30]
    node _GEN_0 = validif(eq(UInt<1>("h0"), io_rs1), regs_0) @[RegisterFile.scala 42:{22,22}]
    node _GEN_1 = mux(eq(UInt<1>("h1"), io_rs1), regs_1, _GEN_0) @[RegisterFile.scala 42:{22,22}]
    node _GEN_2 = mux(eq(UInt<2>("h2"), io_rs1), regs_2, _GEN_1) @[RegisterFile.scala 42:{22,22}]
    node _GEN_3 = mux(eq(UInt<2>("h3"), io_rs1), regs_3, _GEN_2) @[RegisterFile.scala 42:{22,22}]
    node _GEN_4 = mux(eq(UInt<3>("h4"), io_rs1), regs_4, _GEN_3) @[RegisterFile.scala 42:{22,22}]
    node _GEN_5 = mux(eq(UInt<3>("h5"), io_rs1), regs_5, _GEN_4) @[RegisterFile.scala 42:{22,22}]
    node _GEN_6 = mux(eq(UInt<3>("h6"), io_rs1), regs_6, _GEN_5) @[RegisterFile.scala 42:{22,22}]
    node _GEN_7 = mux(eq(UInt<3>("h7"), io_rs1), regs_7, _GEN_6) @[RegisterFile.scala 42:{22,22}]
    node _GEN_8 = mux(eq(UInt<4>("h8"), io_rs1), regs_8, _GEN_7) @[RegisterFile.scala 42:{22,22}]
    node _GEN_9 = mux(eq(UInt<4>("h9"), io_rs1), regs_9, _GEN_8) @[RegisterFile.scala 42:{22,22}]
    node _GEN_10 = mux(eq(UInt<4>("ha"), io_rs1), regs_10, _GEN_9) @[RegisterFile.scala 42:{22,22}]
    node _GEN_11 = mux(eq(UInt<4>("hb"), io_rs1), regs_11, _GEN_10) @[RegisterFile.scala 42:{22,22}]
    node _GEN_12 = mux(eq(UInt<4>("hc"), io_rs1), regs_12, _GEN_11) @[RegisterFile.scala 42:{22,22}]
    node _GEN_13 = mux(eq(UInt<4>("hd"), io_rs1), regs_13, _GEN_12) @[RegisterFile.scala 42:{22,22}]
    node _GEN_14 = mux(eq(UInt<4>("he"), io_rs1), regs_14, _GEN_13) @[RegisterFile.scala 42:{22,22}]
    node _GEN_15 = mux(eq(UInt<4>("hf"), io_rs1), regs_15, _GEN_14) @[RegisterFile.scala 42:{22,22}]
    node _GEN_16 = mux(eq(UInt<5>("h10"), io_rs1), regs_16, _GEN_15) @[RegisterFile.scala 42:{22,22}]
    node _GEN_17 = mux(eq(UInt<5>("h11"), io_rs1), regs_17, _GEN_16) @[RegisterFile.scala 42:{22,22}]
    node _GEN_18 = mux(eq(UInt<5>("h12"), io_rs1), regs_18, _GEN_17) @[RegisterFile.scala 42:{22,22}]
    node _GEN_19 = mux(eq(UInt<5>("h13"), io_rs1), regs_19, _GEN_18) @[RegisterFile.scala 42:{22,22}]
    node _GEN_20 = mux(eq(UInt<5>("h14"), io_rs1), regs_20, _GEN_19) @[RegisterFile.scala 42:{22,22}]
    node _GEN_21 = mux(eq(UInt<5>("h15"), io_rs1), regs_21, _GEN_20) @[RegisterFile.scala 42:{22,22}]
    node _GEN_22 = mux(eq(UInt<5>("h16"), io_rs1), regs_22, _GEN_21) @[RegisterFile.scala 42:{22,22}]
    node _GEN_23 = mux(eq(UInt<5>("h17"), io_rs1), regs_23, _GEN_22) @[RegisterFile.scala 42:{22,22}]
    node _GEN_24 = mux(eq(UInt<5>("h18"), io_rs1), regs_24, _GEN_23) @[RegisterFile.scala 42:{22,22}]
    node _GEN_25 = mux(eq(UInt<5>("h19"), io_rs1), regs_25, _GEN_24) @[RegisterFile.scala 42:{22,22}]
    node _GEN_26 = mux(eq(UInt<5>("h1a"), io_rs1), regs_26, _GEN_25) @[RegisterFile.scala 42:{22,22}]
    node _GEN_27 = mux(eq(UInt<5>("h1b"), io_rs1), regs_27, _GEN_26) @[RegisterFile.scala 42:{22,22}]
    node _GEN_28 = mux(eq(UInt<5>("h1c"), io_rs1), regs_28, _GEN_27) @[RegisterFile.scala 42:{22,22}]
    node _GEN_29 = mux(eq(UInt<5>("h1d"), io_rs1), regs_29, _GEN_28) @[RegisterFile.scala 42:{22,22}]
    node _GEN_30 = mux(eq(UInt<5>("h1e"), io_rs1), regs_30, _GEN_29) @[RegisterFile.scala 42:{22,22}]
    node _GEN_31 = mux(eq(UInt<5>("h1f"), io_rs1), regs_31, _GEN_30) @[RegisterFile.scala 42:{22,22}]
    node _regs_io_rs1 = _GEN_31 @[RegisterFile.scala 42:22]
    node _io_readData1_T_1 = mux(_io_readData1_T, UInt<32>("h0"), _regs_io_rs1) @[RegisterFile.scala 42:22]
    node _io_readData2_T = eq(io_rs2, UInt<1>("h0")) @[RegisterFile.scala 43:30]
    node _GEN_32 = validif(eq(UInt<1>("h0"), io_rs2), regs_0) @[RegisterFile.scala 43:{22,22}]
    node _GEN_33 = mux(eq(UInt<1>("h1"), io_rs2), regs_1, _GEN_32) @[RegisterFile.scala 43:{22,22}]
    node _GEN_34 = mux(eq(UInt<2>("h2"), io_rs2), regs_2, _GEN_33) @[RegisterFile.scala 43:{22,22}]
    node _GEN_35 = mux(eq(UInt<2>("h3"), io_rs2), regs_3, _GEN_34) @[RegisterFile.scala 43:{22,22}]
    node _GEN_36 = mux(eq(UInt<3>("h4"), io_rs2), regs_4, _GEN_35) @[RegisterFile.scala 43:{22,22}]
    node _GEN_37 = mux(eq(UInt<3>("h5"), io_rs2), regs_5, _GEN_36) @[RegisterFile.scala 43:{22,22}]
    node _GEN_38 = mux(eq(UInt<3>("h6"), io_rs2), regs_6, _GEN_37) @[RegisterFile.scala 43:{22,22}]
    node _GEN_39 = mux(eq(UInt<3>("h7"), io_rs2), regs_7, _GEN_38) @[RegisterFile.scala 43:{22,22}]
    node _GEN_40 = mux(eq(UInt<4>("h8"), io_rs2), regs_8, _GEN_39) @[RegisterFile.scala 43:{22,22}]
    node _GEN_41 = mux(eq(UInt<4>("h9"), io_rs2), regs_9, _GEN_40) @[RegisterFile.scala 43:{22,22}]
    node _GEN_42 = mux(eq(UInt<4>("ha"), io_rs2), regs_10, _GEN_41) @[RegisterFile.scala 43:{22,22}]
    node _GEN_43 = mux(eq(UInt<4>("hb"), io_rs2), regs_11, _GEN_42) @[RegisterFile.scala 43:{22,22}]
    node _GEN_44 = mux(eq(UInt<4>("hc"), io_rs2), regs_12, _GEN_43) @[RegisterFile.scala 43:{22,22}]
    node _GEN_45 = mux(eq(UInt<4>("hd"), io_rs2), regs_13, _GEN_44) @[RegisterFile.scala 43:{22,22}]
    node _GEN_46 = mux(eq(UInt<4>("he"), io_rs2), regs_14, _GEN_45) @[RegisterFile.scala 43:{22,22}]
    node _GEN_47 = mux(eq(UInt<4>("hf"), io_rs2), regs_15, _GEN_46) @[RegisterFile.scala 43:{22,22}]
    node _GEN_48 = mux(eq(UInt<5>("h10"), io_rs2), regs_16, _GEN_47) @[RegisterFile.scala 43:{22,22}]
    node _GEN_49 = mux(eq(UInt<5>("h11"), io_rs2), regs_17, _GEN_48) @[RegisterFile.scala 43:{22,22}]
    node _GEN_50 = mux(eq(UInt<5>("h12"), io_rs2), regs_18, _GEN_49) @[RegisterFile.scala 43:{22,22}]
    node _GEN_51 = mux(eq(UInt<5>("h13"), io_rs2), regs_19, _GEN_50) @[RegisterFile.scala 43:{22,22}]
    node _GEN_52 = mux(eq(UInt<5>("h14"), io_rs2), regs_20, _GEN_51) @[RegisterFile.scala 43:{22,22}]
    node _GEN_53 = mux(eq(UInt<5>("h15"), io_rs2), regs_21, _GEN_52) @[RegisterFile.scala 43:{22,22}]
    node _GEN_54 = mux(eq(UInt<5>("h16"), io_rs2), regs_22, _GEN_53) @[RegisterFile.scala 43:{22,22}]
    node _GEN_55 = mux(eq(UInt<5>("h17"), io_rs2), regs_23, _GEN_54) @[RegisterFile.scala 43:{22,22}]
    node _GEN_56 = mux(eq(UInt<5>("h18"), io_rs2), regs_24, _GEN_55) @[RegisterFile.scala 43:{22,22}]
    node _GEN_57 = mux(eq(UInt<5>("h19"), io_rs2), regs_25, _GEN_56) @[RegisterFile.scala 43:{22,22}]
    node _GEN_58 = mux(eq(UInt<5>("h1a"), io_rs2), regs_26, _GEN_57) @[RegisterFile.scala 43:{22,22}]
    node _GEN_59 = mux(eq(UInt<5>("h1b"), io_rs2), regs_27, _GEN_58) @[RegisterFile.scala 43:{22,22}]
    node _GEN_60 = mux(eq(UInt<5>("h1c"), io_rs2), regs_28, _GEN_59) @[RegisterFile.scala 43:{22,22}]
    node _GEN_61 = mux(eq(UInt<5>("h1d"), io_rs2), regs_29, _GEN_60) @[RegisterFile.scala 43:{22,22}]
    node _GEN_62 = mux(eq(UInt<5>("h1e"), io_rs2), regs_30, _GEN_61) @[RegisterFile.scala 43:{22,22}]
    node _GEN_63 = mux(eq(UInt<5>("h1f"), io_rs2), regs_31, _GEN_62) @[RegisterFile.scala 43:{22,22}]
    node _regs_io_rs2 = _GEN_63 @[RegisterFile.scala 43:22]
    node _io_readData2_T_1 = mux(_io_readData2_T, UInt<32>("h0"), _regs_io_rs2) @[RegisterFile.scala 43:22]
    node _T = neq(io_rd, UInt<1>("h0")) @[RegisterFile.scala 46:33]
    node _T_1 = and(io_writeEnable, _T) @[RegisterFile.scala 46:23]
    node _regs_io_rd = io_writeData @[RegisterFile.scala 47:{17,17}]
    node _GEN_64 = mux(eq(UInt<1>("h0"), io_rd), _regs_io_rd, regs_0) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_65 = mux(eq(UInt<1>("h1"), io_rd), _regs_io_rd, regs_1) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_66 = mux(eq(UInt<2>("h2"), io_rd), _regs_io_rd, regs_2) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_67 = mux(eq(UInt<2>("h3"), io_rd), _regs_io_rd, regs_3) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_68 = mux(eq(UInt<3>("h4"), io_rd), _regs_io_rd, regs_4) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_69 = mux(eq(UInt<3>("h5"), io_rd), _regs_io_rd, regs_5) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_70 = mux(eq(UInt<3>("h6"), io_rd), _regs_io_rd, regs_6) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_71 = mux(eq(UInt<3>("h7"), io_rd), _regs_io_rd, regs_7) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_72 = mux(eq(UInt<4>("h8"), io_rd), _regs_io_rd, regs_8) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_73 = mux(eq(UInt<4>("h9"), io_rd), _regs_io_rd, regs_9) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_74 = mux(eq(UInt<4>("ha"), io_rd), _regs_io_rd, regs_10) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_75 = mux(eq(UInt<4>("hb"), io_rd), _regs_io_rd, regs_11) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_76 = mux(eq(UInt<4>("hc"), io_rd), _regs_io_rd, regs_12) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_77 = mux(eq(UInt<4>("hd"), io_rd), _regs_io_rd, regs_13) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_78 = mux(eq(UInt<4>("he"), io_rd), _regs_io_rd, regs_14) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_79 = mux(eq(UInt<4>("hf"), io_rd), _regs_io_rd, regs_15) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_80 = mux(eq(UInt<5>("h10"), io_rd), _regs_io_rd, regs_16) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_81 = mux(eq(UInt<5>("h11"), io_rd), _regs_io_rd, regs_17) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_82 = mux(eq(UInt<5>("h12"), io_rd), _regs_io_rd, regs_18) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_83 = mux(eq(UInt<5>("h13"), io_rd), _regs_io_rd, regs_19) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_84 = mux(eq(UInt<5>("h14"), io_rd), _regs_io_rd, regs_20) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_85 = mux(eq(UInt<5>("h15"), io_rd), _regs_io_rd, regs_21) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_86 = mux(eq(UInt<5>("h16"), io_rd), _regs_io_rd, regs_22) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_87 = mux(eq(UInt<5>("h17"), io_rd), _regs_io_rd, regs_23) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_88 = mux(eq(UInt<5>("h18"), io_rd), _regs_io_rd, regs_24) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_89 = mux(eq(UInt<5>("h19"), io_rd), _regs_io_rd, regs_25) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_90 = mux(eq(UInt<5>("h1a"), io_rd), _regs_io_rd, regs_26) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_91 = mux(eq(UInt<5>("h1b"), io_rd), _regs_io_rd, regs_27) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_92 = mux(eq(UInt<5>("h1c"), io_rd), _regs_io_rd, regs_28) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_93 = mux(eq(UInt<5>("h1d"), io_rd), _regs_io_rd, regs_29) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_94 = mux(eq(UInt<5>("h1e"), io_rd), _regs_io_rd, regs_30) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_95 = mux(eq(UInt<5>("h1f"), io_rd), _regs_io_rd, regs_31) @[RegisterFile.scala 47:{17,17} 39:21]
    node _GEN_96 = mux(_T_1, _GEN_64, regs_0) @[RegisterFile.scala 39:21 46:43]
    node _GEN_97 = mux(_T_1, _GEN_65, regs_1) @[RegisterFile.scala 39:21 46:43]
    node _GEN_98 = mux(_T_1, _GEN_66, regs_2) @[RegisterFile.scala 39:21 46:43]
    node _GEN_99 = mux(_T_1, _GEN_67, regs_3) @[RegisterFile.scala 39:21 46:43]
    node _GEN_100 = mux(_T_1, _GEN_68, regs_4) @[RegisterFile.scala 39:21 46:43]
    node _GEN_101 = mux(_T_1, _GEN_69, regs_5) @[RegisterFile.scala 39:21 46:43]
    node _GEN_102 = mux(_T_1, _GEN_70, regs_6) @[RegisterFile.scala 39:21 46:43]
    node _GEN_103 = mux(_T_1, _GEN_71, regs_7) @[RegisterFile.scala 39:21 46:43]
    node _GEN_104 = mux(_T_1, _GEN_72, regs_8) @[RegisterFile.scala 39:21 46:43]
    node _GEN_105 = mux(_T_1, _GEN_73, regs_9) @[RegisterFile.scala 39:21 46:43]
    node _GEN_106 = mux(_T_1, _GEN_74, regs_10) @[RegisterFile.scala 39:21 46:43]
    node _GEN_107 = mux(_T_1, _GEN_75, regs_11) @[RegisterFile.scala 39:21 46:43]
    node _GEN_108 = mux(_T_1, _GEN_76, regs_12) @[RegisterFile.scala 39:21 46:43]
    node _GEN_109 = mux(_T_1, _GEN_77, regs_13) @[RegisterFile.scala 39:21 46:43]
    node _GEN_110 = mux(_T_1, _GEN_78, regs_14) @[RegisterFile.scala 39:21 46:43]
    node _GEN_111 = mux(_T_1, _GEN_79, regs_15) @[RegisterFile.scala 39:21 46:43]
    node _GEN_112 = mux(_T_1, _GEN_80, regs_16) @[RegisterFile.scala 39:21 46:43]
    node _GEN_113 = mux(_T_1, _GEN_81, regs_17) @[RegisterFile.scala 39:21 46:43]
    node _GEN_114 = mux(_T_1, _GEN_82, regs_18) @[RegisterFile.scala 39:21 46:43]
    node _GEN_115 = mux(_T_1, _GEN_83, regs_19) @[RegisterFile.scala 39:21 46:43]
    node _GEN_116 = mux(_T_1, _GEN_84, regs_20) @[RegisterFile.scala 39:21 46:43]
    node _GEN_117 = mux(_T_1, _GEN_85, regs_21) @[RegisterFile.scala 39:21 46:43]
    node _GEN_118 = mux(_T_1, _GEN_86, regs_22) @[RegisterFile.scala 39:21 46:43]
    node _GEN_119 = mux(_T_1, _GEN_87, regs_23) @[RegisterFile.scala 39:21 46:43]
    node _GEN_120 = mux(_T_1, _GEN_88, regs_24) @[RegisterFile.scala 39:21 46:43]
    node _GEN_121 = mux(_T_1, _GEN_89, regs_25) @[RegisterFile.scala 39:21 46:43]
    node _GEN_122 = mux(_T_1, _GEN_90, regs_26) @[RegisterFile.scala 39:21 46:43]
    node _GEN_123 = mux(_T_1, _GEN_91, regs_27) @[RegisterFile.scala 39:21 46:43]
    node _GEN_124 = mux(_T_1, _GEN_92, regs_28) @[RegisterFile.scala 39:21 46:43]
    node _GEN_125 = mux(_T_1, _GEN_93, regs_29) @[RegisterFile.scala 39:21 46:43]
    node _GEN_126 = mux(_T_1, _GEN_94, regs_30) @[RegisterFile.scala 39:21 46:43]
    node _GEN_127 = mux(_T_1, _GEN_95, regs_31) @[RegisterFile.scala 39:21 46:43]
    node _regs_WIRE_0 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_1 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_2 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_3 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_4 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_5 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_6 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_7 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_8 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_9 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_10 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_11 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_12 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_13 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_14 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_15 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_16 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_17 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_18 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_19 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_20 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_21 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_22 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_23 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_24 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_25 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_26 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_27 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_28 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_29 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_30 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    node _regs_WIRE_31 = UInt<32>("h0") @[RegisterFile.scala 39:{29,29}]
    io_readData1 <= _io_readData1_T_1 @[RegisterFile.scala 42:16]
    io_readData2 <= _io_readData2_T_1 @[RegisterFile.scala 43:16]
    io_debugRead_0 <= UInt<32>("h0") @[RegisterFile.scala 52:21]
    io_debugRead_1 <= regs_1 @[RegisterFile.scala 52:21]
    io_debugRead_2 <= regs_2 @[RegisterFile.scala 52:21]
    io_debugRead_3 <= regs_3 @[RegisterFile.scala 52:21]
    io_debugRead_4 <= regs_4 @[RegisterFile.scala 52:21]
    io_debugRead_5 <= regs_5 @[RegisterFile.scala 52:21]
    io_debugRead_6 <= regs_6 @[RegisterFile.scala 52:21]
    io_debugRead_7 <= regs_7 @[RegisterFile.scala 52:21]
    io_debugRead_8 <= regs_8 @[RegisterFile.scala 52:21]
    io_debugRead_9 <= regs_9 @[RegisterFile.scala 52:21]
    io_debugRead_10 <= regs_10 @[RegisterFile.scala 52:21]
    io_debugRead_11 <= regs_11 @[RegisterFile.scala 52:21]
    io_debugRead_12 <= regs_12 @[RegisterFile.scala 52:21]
    io_debugRead_13 <= regs_13 @[RegisterFile.scala 52:21]
    io_debugRead_14 <= regs_14 @[RegisterFile.scala 52:21]
    io_debugRead_15 <= regs_15 @[RegisterFile.scala 52:21]
    io_debugRead_16 <= regs_16 @[RegisterFile.scala 52:21]
    io_debugRead_17 <= regs_17 @[RegisterFile.scala 52:21]
    io_debugRead_18 <= regs_18 @[RegisterFile.scala 52:21]
    io_debugRead_19 <= regs_19 @[RegisterFile.scala 52:21]
    io_debugRead_20 <= regs_20 @[RegisterFile.scala 52:21]
    io_debugRead_21 <= regs_21 @[RegisterFile.scala 52:21]
    io_debugRead_22 <= regs_22 @[RegisterFile.scala 52:21]
    io_debugRead_23 <= regs_23 @[RegisterFile.scala 52:21]
    io_debugRead_24 <= regs_24 @[RegisterFile.scala 52:21]
    io_debugRead_25 <= regs_25 @[RegisterFile.scala 52:21]
    io_debugRead_26 <= regs_26 @[RegisterFile.scala 52:21]
    io_debugRead_27 <= regs_27 @[RegisterFile.scala 52:21]
    io_debugRead_28 <= regs_28 @[RegisterFile.scala 52:21]
    io_debugRead_29 <= regs_29 @[RegisterFile.scala 52:21]
    io_debugRead_30 <= regs_30 @[RegisterFile.scala 52:21]
    io_debugRead_31 <= regs_31 @[RegisterFile.scala 52:21]
    regs_0 <= mux(reset, _regs_WIRE_0, _GEN_96) @[RegisterFile.scala 39:{21,21}]
    regs_1 <= mux(reset, _regs_WIRE_1, _GEN_97) @[RegisterFile.scala 39:{21,21}]
    regs_2 <= mux(reset, _regs_WIRE_2, _GEN_98) @[RegisterFile.scala 39:{21,21}]
    regs_3 <= mux(reset, _regs_WIRE_3, _GEN_99) @[RegisterFile.scala 39:{21,21}]
    regs_4 <= mux(reset, _regs_WIRE_4, _GEN_100) @[RegisterFile.scala 39:{21,21}]
    regs_5 <= mux(reset, _regs_WIRE_5, _GEN_101) @[RegisterFile.scala 39:{21,21}]
    regs_6 <= mux(reset, _regs_WIRE_6, _GEN_102) @[RegisterFile.scala 39:{21,21}]
    regs_7 <= mux(reset, _regs_WIRE_7, _GEN_103) @[RegisterFile.scala 39:{21,21}]
    regs_8 <= mux(reset, _regs_WIRE_8, _GEN_104) @[RegisterFile.scala 39:{21,21}]
    regs_9 <= mux(reset, _regs_WIRE_9, _GEN_105) @[RegisterFile.scala 39:{21,21}]
    regs_10 <= mux(reset, _regs_WIRE_10, _GEN_106) @[RegisterFile.scala 39:{21,21}]
    regs_11 <= mux(reset, _regs_WIRE_11, _GEN_107) @[RegisterFile.scala 39:{21,21}]
    regs_12 <= mux(reset, _regs_WIRE_12, _GEN_108) @[RegisterFile.scala 39:{21,21}]
    regs_13 <= mux(reset, _regs_WIRE_13, _GEN_109) @[RegisterFile.scala 39:{21,21}]
    regs_14 <= mux(reset, _regs_WIRE_14, _GEN_110) @[RegisterFile.scala 39:{21,21}]
    regs_15 <= mux(reset, _regs_WIRE_15, _GEN_111) @[RegisterFile.scala 39:{21,21}]
    regs_16 <= mux(reset, _regs_WIRE_16, _GEN_112) @[RegisterFile.scala 39:{21,21}]
    regs_17 <= mux(reset, _regs_WIRE_17, _GEN_113) @[RegisterFile.scala 39:{21,21}]
    regs_18 <= mux(reset, _regs_WIRE_18, _GEN_114) @[RegisterFile.scala 39:{21,21}]
    regs_19 <= mux(reset, _regs_WIRE_19, _GEN_115) @[RegisterFile.scala 39:{21,21}]
    regs_20 <= mux(reset, _regs_WIRE_20, _GEN_116) @[RegisterFile.scala 39:{21,21}]
    regs_21 <= mux(reset, _regs_WIRE_21, _GEN_117) @[RegisterFile.scala 39:{21,21}]
    regs_22 <= mux(reset, _regs_WIRE_22, _GEN_118) @[RegisterFile.scala 39:{21,21}]
    regs_23 <= mux(reset, _regs_WIRE_23, _GEN_119) @[RegisterFile.scala 39:{21,21}]
    regs_24 <= mux(reset, _regs_WIRE_24, _GEN_120) @[RegisterFile.scala 39:{21,21}]
    regs_25 <= mux(reset, _regs_WIRE_25, _GEN_121) @[RegisterFile.scala 39:{21,21}]
    regs_26 <= mux(reset, _regs_WIRE_26, _GEN_122) @[RegisterFile.scala 39:{21,21}]
    regs_27 <= mux(reset, _regs_WIRE_27, _GEN_123) @[RegisterFile.scala 39:{21,21}]
    regs_28 <= mux(reset, _regs_WIRE_28, _GEN_124) @[RegisterFile.scala 39:{21,21}]
    regs_29 <= mux(reset, _regs_WIRE_29, _GEN_125) @[RegisterFile.scala 39:{21,21}]
    regs_30 <= mux(reset, _regs_WIRE_30, _GEN_126) @[RegisterFile.scala 39:{21,21}]
    regs_31 <= mux(reset, _regs_WIRE_31, _GEN_127) @[RegisterFile.scala 39:{21,21}]

  module IDStage :
    input clock : Clock
    input reset : UInt<1>
    input io_valid : UInt<1>
    input io_pc : UInt<32>
    input io_instr : UInt<32>
    input io_wbRd : UInt<5>
    input io_wbWriteData : UInt<32>
    input io_wbWriteEnable : UInt<1>
    output io_rs1 : UInt<5>
    output io_rs2 : UInt<5>
    output io_rd : UInt<5>
    output io_rs1Data : UInt<32>
    output io_rs2Data : UInt<32>
    output io_imm : UInt<32>
    output io_funct3 : UInt<3>
    output io_aluOp : UInt<5>
    output io_aluASel : UInt<2>
    output io_aluSrc : UInt<1>
    output io_regWrite : UInt<1>
    output io_memRead : UInt<1>
    output io_memWrite : UInt<1>
    output io_memToReg : UInt<1>
    output io_branch : UInt<1>
    output io_jump : UInt<1>
    output io_jalr : UInt<1>
    output io_usesRs1 : UInt<1>
    output io_usesRs2 : UInt<1>
    output io_debugX1 : UInt<32>
    output io_debugX2 : UInt<32>
    output io_debugX3 : UInt<32>
    output io_debugX4 : UInt<32>
    output io_debugX5 : UInt<32>
    output io_debugX6 : UInt<32>

    inst decoder of Decoder @[IDStage.scala 124:11]
    inst control of Control @[IDStage.scala 127:11]
    inst immGen of ImmediateGenerator @[IDStage.scala 130:11]
    inst regFile of RegisterFile @[IDStage.scala 133:11]
    node _wbBypassRs1_T = neq(io_wbRd, UInt<1>("h0")) @[IDStage.scala 205:14]
    node _wbBypassRs1_T_1 = and(io_wbWriteEnable, _wbBypassRs1_T) @[IDStage.scala 204:22]
    node _wbBypassRs1_T_2 = eq(io_wbRd, decoder.io_rs1) @[IDStage.scala 206:14]
    node wbBypassRs1 = and(_wbBypassRs1_T_1, _wbBypassRs1_T_2) @[IDStage.scala 205:23]
    node _wbBypassRs2_T = neq(io_wbRd, UInt<1>("h0")) @[IDStage.scala 210:14]
    node _wbBypassRs2_T_1 = and(io_wbWriteEnable, _wbBypassRs2_T) @[IDStage.scala 209:22]
    node _wbBypassRs2_T_2 = eq(io_wbRd, decoder.io_rs2) @[IDStage.scala 211:14]
    node wbBypassRs2 = and(_wbBypassRs2_T_1, _wbBypassRs2_T_2) @[IDStage.scala 210:23]
    node _io_rs1Data_T = mux(wbBypassRs1, io_wbWriteData, regFile.io_readData1) @[IDStage.scala 214:8]
    node _io_rs2Data_T = mux(wbBypassRs2, io_wbWriteData, regFile.io_readData2) @[IDStage.scala 221:8]
    node _io_regWrite_T = and(control.io_regWrite, io_valid) @[IDStage.scala 272:25]
    node _io_memRead_T = and(control.io_memRead, io_valid) @[IDStage.scala 276:24]
    node _io_memWrite_T = and(control.io_memWrite, io_valid) @[IDStage.scala 280:25]
    node _io_branch_T = and(control.io_branch, io_valid) @[IDStage.scala 287:23]
    node _io_jump_T = and(control.io_jump, io_valid) @[IDStage.scala 291:21]
    node _io_jalr_T = and(control.io_jalr, io_valid) @[IDStage.scala 295:21]
    node _io_usesRs1_T = and(control.io_usesRs1, io_valid) @[IDStage.scala 304:24]
    node _io_usesRs2_T = and(control.io_usesRs2, io_valid) @[IDStage.scala 308:24]
    io_rs1 <= decoder.io_rs1 @[IDStage.scala 232:10]
    io_rs2 <= decoder.io_rs2 @[IDStage.scala 235:10]
    io_rd <= decoder.io_rd @[IDStage.scala 238:9]
    io_rs1Data <= _io_rs1Data_T @[IDStage.scala 213:14]
    io_rs2Data <= _io_rs2Data_T @[IDStage.scala 220:14]
    io_imm <= immGen.io_imm @[IDStage.scala 246:10]
    io_funct3 <= decoder.io_funct3 @[IDStage.scala 249:13]
    io_aluOp <= control.io_aluOp @[IDStage.scala 257:12]
    io_aluASel <= control.io_aluASel @[IDStage.scala 260:14]
    io_aluSrc <= control.io_aluSrc @[IDStage.scala 263:13]
    io_regWrite <= _io_regWrite_T @[IDStage.scala 271:15]
    io_memRead <= _io_memRead_T @[IDStage.scala 275:14]
    io_memWrite <= _io_memWrite_T @[IDStage.scala 279:15]
    io_memToReg <= control.io_memToReg @[IDStage.scala 283:15]
    io_branch <= _io_branch_T @[IDStage.scala 286:13]
    io_jump <= _io_jump_T @[IDStage.scala 290:11]
    io_jalr <= _io_jalr_T @[IDStage.scala 294:11]
    io_usesRs1 <= _io_usesRs1_T @[IDStage.scala 303:14]
    io_usesRs2 <= _io_usesRs2_T @[IDStage.scala 307:14]
    io_debugX1 <= regFile.io_debugRead_1 @[IDStage.scala 316:14]
    io_debugX2 <= regFile.io_debugRead_2 @[IDStage.scala 319:14]
    io_debugX3 <= regFile.io_debugRead_3 @[IDStage.scala 322:14]
    io_debugX4 <= regFile.io_debugRead_4 @[IDStage.scala 325:14]
    io_debugX5 <= regFile.io_debugRead_5 @[IDStage.scala 328:14]
    io_debugX6 <= regFile.io_debugRead_6 @[IDStage.scala 331:14]
    decoder.clock <= clock
    decoder.reset <= reset
    decoder.io_instr <= io_instr @[IDStage.scala 140:20]
    control.clock <= clock
    control.reset <= reset
    control.io_instr <= io_instr @[IDStage.scala 143:20]
    immGen.clock <= clock
    immGen.reset <= reset
    immGen.io_instr <= io_instr @[IDStage.scala 146:19]
    regFile.clock <= clock
    regFile.reset <= reset
    regFile.io_rs1 <= decoder.io_rs1 @[IDStage.scala 154:18]
    regFile.io_rs2 <= decoder.io_rs2 @[IDStage.scala 157:18]
    regFile.io_rd <= io_wbRd @[IDStage.scala 171:17]
    regFile.io_writeData <= io_wbWriteData @[IDStage.scala 174:24]
    regFile.io_writeEnable <= io_wbWriteEnable @[IDStage.scala 177:26]

  module ALU :
    input clock : Clock
    input reset : UInt<1>
    input io_a : UInt<32>
    input io_b : UInt<32>
    input io_op : UInt<5>
    output io_y : UInt<32>

    node shamt = bits(io_b, 4, 0) @[ALU.scala 64:19]
    node signedA = asSInt(io_a) @[ALU.scala 70:22]
    node signedB = asSInt(io_b) @[ALU.scala 71:22]
    node _aSigned64_T = bits(io_a, 31, 31) @[ALU.scala 78:22]
    node _aSigned64_T_1 = bits(_aSigned64_T, 0, 0) @[Bitwise.scala 77:15]
    node _aSigned64_T_2 = mux(_aSigned64_T_1, UInt<32>("hffffffff"), UInt<32>("h0")) @[Bitwise.scala 77:12]
    node _aSigned64_T_3 = cat(_aSigned64_T_2, io_a) @[Cat.scala 33:92]
    node aSigned64 = asSInt(_aSigned64_T_3) @[ALU.scala 78:35]
    node _bSigned64_T = bits(io_b, 31, 31) @[ALU.scala 81:22]
    node _bSigned64_T_1 = bits(_bSigned64_T, 0, 0) @[Bitwise.scala 77:15]
    node _bSigned64_T_2 = mux(_bSigned64_T_1, UInt<32>("hffffffff"), UInt<32>("h0")) @[Bitwise.scala 77:12]
    node _bSigned64_T_3 = cat(_bSigned64_T_2, io_b) @[Cat.scala 33:92]
    node bSigned64 = asSInt(_bSigned64_T_3) @[ALU.scala 81:35]
    node aUnsigned64 = cat(UInt<32>("h0"), io_a) @[Cat.scala 33:92]
    node bUnsigned64 = cat(UInt<32>("h0"), io_b) @[Cat.scala 33:92]
    node mulSS = mul(aSigned64, bSigned64) @[ALU.scala 93:26]
    node mulUU = mul(aUnsigned64, bUnsigned64) @[ALU.scala 94:28]
    node _mulHSU_T = asSInt(bUnsigned64) @[ALU.scala 95:40]
    node mulHSU = mul(aSigned64, _mulHSU_T) @[ALU.scala 95:26]
    node mulLow = bits(mulSS, 31, 0) @[ALU.scala 98:10]
    node mulHighSS = bits(mulSS, 63, 32) @[ALU.scala 101:10]
    node mulHighSU = bits(mulHSU, 63, 32) @[ALU.scala 104:11]
    node mulHighUU = bits(mulUU, 63, 32) @[ALU.scala 107:10]
    node _T = eq(io_b, UInt<1>("h0")) @[ALU.scala 147:14]
    node _T_1 = eq(io_a, UInt<32>("h80000000")) @[ALU.scala 151:11]
    node _T_2 = eq(io_b, UInt<32>("hffffffff")) @[ALU.scala 152:11]
    node _T_3 = and(_T_1, _T_2) @[ALU.scala 151:23]
    node _divResult_T = div(signedA, signedB) @[ALU.scala 157:27]
    node _divResult_T_1 = asUInt(_divResult_T) @[ALU.scala 157:38]
    node _GEN_0 = mux(_T_3, UInt<32>("h80000000"), _divResult_T_1) @[ALU.scala 153:5 155:15 157:15]
    node _GEN_1 = mux(_T, UInt<32>("hffffffff"), _GEN_0) @[ALU.scala 147:23 149:15]
    node _T_4 = eq(io_b, UInt<1>("h0")) @[ALU.scala 166:14]
    node _divuResult_T = div(io_a, io_b) @[ALU.scala 170:24]
    node _GEN_2 = mux(_T_4, UInt<32>("hffffffff"), _divuResult_T) @[ALU.scala 166:23 168:16 170:16]
    node _T_5 = eq(io_b, UInt<1>("h0")) @[ALU.scala 179:14]
    node _T_6 = eq(io_a, UInt<32>("h80000000")) @[ALU.scala 183:11]
    node _T_7 = eq(io_b, UInt<32>("hffffffff")) @[ALU.scala 184:11]
    node _T_8 = and(_T_6, _T_7) @[ALU.scala 183:23]
    node _remResult_T = rem(signedA, signedB) @[ALU.scala 189:27]
    node _remResult_T_1 = asUInt(_remResult_T) @[ALU.scala 189:38]
    node _GEN_3 = mux(_T_8, UInt<1>("h0"), _remResult_T_1) @[ALU.scala 185:5 187:15 189:15]
    node _GEN_4 = mux(_T_5, io_a, _GEN_3) @[ALU.scala 179:23 181:15]
    node _T_9 = eq(io_b, UInt<1>("h0")) @[ALU.scala 198:14]
    node _remuResult_T = rem(io_a, io_b) @[ALU.scala 202:24]
    node _GEN_5 = mux(_T_9, io_a, _remuResult_T) @[ALU.scala 198:23 200:16 202:16]
    node equal = eq(io_a, io_b) @[ALU.scala 210:10]
    node notEqual = neq(io_a, io_b) @[ALU.scala 213:10]
    node _io_y_T = add(io_a, io_b) @[ALU.scala 229:15]
    node _io_y_T_1 = tail(_io_y_T, 1) @[ALU.scala 229:15]
    node _io_y_T_2 = sub(io_a, io_b) @[ALU.scala 232:15]
    node _io_y_T_3 = tail(_io_y_T_2, 1) @[ALU.scala 232:15]
    node _io_y_T_4 = dshl(io_a, shamt) @[ALU.scala 235:15]
    node _io_y_T_5 = lt(signedA, signedB) @[ALU.scala 239:19]
    node _io_y_T_6 = mux(_io_y_T_5, UInt<32>("h1"), UInt<32>("h0")) @[ALU.scala 238:12]
    node _io_y_T_7 = lt(io_a, io_b) @[ALU.scala 246:16]
    node _io_y_T_8 = mux(_io_y_T_7, UInt<32>("h1"), UInt<32>("h0")) @[ALU.scala 245:12]
    node _io_y_T_9 = xor(io_a, io_b) @[ALU.scala 252:15]
    node _io_y_T_10 = dshr(io_a, shamt) @[ALU.scala 255:15]
    node _io_y_T_11 = dshr(signedA, shamt) @[ALU.scala 258:18]
    node _io_y_T_12 = asUInt(_io_y_T_11) @[ALU.scala 258:28]
    node _io_y_T_13 = or(io_a, io_b) @[ALU.scala 261:15]
    node _io_y_T_14 = and(io_a, io_b) @[ALU.scala 264:15]
    node _io_y_T_15 = mux(equal, UInt<32>("h1"), UInt<32>("h0")) @[ALU.scala 287:12]
    node _io_y_T_16 = mux(notEqual, UInt<32>("h1"), UInt<32>("h0")) @[ALU.scala 294:12]
    node _io_y_T_17 = eq(UInt<5>("h0"), io_op) @[Mux.scala 81:61]
    node _io_y_T_18 = mux(_io_y_T_17, _io_y_T_1, UInt<32>("h0")) @[Mux.scala 81:58]
    node _io_y_T_19 = eq(UInt<5>("h1"), io_op) @[Mux.scala 81:61]
    node _io_y_T_20 = mux(_io_y_T_19, _io_y_T_3, _io_y_T_18) @[Mux.scala 81:58]
    node _io_y_T_21 = eq(UInt<5>("h2"), io_op) @[Mux.scala 81:61]
    node _io_y_T_22 = mux(_io_y_T_21, _io_y_T_4, _io_y_T_20) @[Mux.scala 81:58]
    node _io_y_T_23 = eq(UInt<5>("h3"), io_op) @[Mux.scala 81:61]
    node _io_y_T_24 = mux(_io_y_T_23, _io_y_T_6, _io_y_T_22) @[Mux.scala 81:58]
    node _io_y_T_25 = eq(UInt<5>("h4"), io_op) @[Mux.scala 81:61]
    node _io_y_T_26 = mux(_io_y_T_25, _io_y_T_8, _io_y_T_24) @[Mux.scala 81:58]
    node _io_y_T_27 = eq(UInt<5>("h5"), io_op) @[Mux.scala 81:61]
    node _io_y_T_28 = mux(_io_y_T_27, _io_y_T_9, _io_y_T_26) @[Mux.scala 81:58]
    node _io_y_T_29 = eq(UInt<5>("h6"), io_op) @[Mux.scala 81:61]
    node _io_y_T_30 = mux(_io_y_T_29, _io_y_T_10, _io_y_T_28) @[Mux.scala 81:58]
    node _io_y_T_31 = eq(UInt<5>("h7"), io_op) @[Mux.scala 81:61]
    node _io_y_T_32 = mux(_io_y_T_31, _io_y_T_12, _io_y_T_30) @[Mux.scala 81:58]
    node _io_y_T_33 = eq(UInt<5>("h8"), io_op) @[Mux.scala 81:61]
    node _io_y_T_34 = mux(_io_y_T_33, _io_y_T_13, _io_y_T_32) @[Mux.scala 81:58]
    node _io_y_T_35 = eq(UInt<5>("h9"), io_op) @[Mux.scala 81:61]
    node _io_y_T_36 = mux(_io_y_T_35, _io_y_T_14, _io_y_T_34) @[Mux.scala 81:58]
    node _io_y_T_37 = eq(UInt<5>("ha"), io_op) @[Mux.scala 81:61]
    node _io_y_T_38 = mux(_io_y_T_37, mulLow, _io_y_T_36) @[Mux.scala 81:58]
    node _io_y_T_39 = eq(UInt<5>("hb"), io_op) @[Mux.scala 81:61]
    node _io_y_T_40 = mux(_io_y_T_39, mulHighSS, _io_y_T_38) @[Mux.scala 81:58]
    node _io_y_T_41 = eq(UInt<5>("hc"), io_op) @[Mux.scala 81:61]
    node _io_y_T_42 = mux(_io_y_T_41, mulHighSU, _io_y_T_40) @[Mux.scala 81:58]
    node _io_y_T_43 = eq(UInt<5>("hd"), io_op) @[Mux.scala 81:61]
    node _io_y_T_44 = mux(_io_y_T_43, mulHighUU, _io_y_T_42) @[Mux.scala 81:58]
    node _io_y_T_45 = eq(UInt<5>("he"), io_op) @[Mux.scala 81:61]
    node _io_y_T_46 = mux(_io_y_T_45, _io_y_T_15, _io_y_T_44) @[Mux.scala 81:58]
    node _io_y_T_47 = eq(UInt<5>("hf"), io_op) @[Mux.scala 81:61]
    node _io_y_T_48 = mux(_io_y_T_47, _io_y_T_16, _io_y_T_46) @[Mux.scala 81:58]
    node _io_y_T_49 = eq(UInt<5>("h10"), io_op) @[Mux.scala 81:61]
    node divResult = bits(_GEN_1, 31, 0) @[ALU.scala 145:23]
    node _io_y_T_50 = mux(_io_y_T_49, divResult, _io_y_T_48) @[Mux.scala 81:58]
    node _io_y_T_51 = eq(UInt<5>("h11"), io_op) @[Mux.scala 81:61]
    node divuResult = _GEN_2 @[ALU.scala 164:24]
    node _io_y_T_52 = mux(_io_y_T_51, divuResult, _io_y_T_50) @[Mux.scala 81:58]
    node _io_y_T_53 = eq(UInt<5>("h12"), io_op) @[Mux.scala 81:61]
    node remResult = _GEN_4 @[ALU.scala 177:23]
    node _io_y_T_54 = mux(_io_y_T_53, remResult, _io_y_T_52) @[Mux.scala 81:58]
    node _io_y_T_55 = eq(UInt<5>("h13"), io_op) @[Mux.scala 81:61]
    node remuResult = _GEN_5 @[ALU.scala 196:24]
    node _io_y_T_56 = mux(_io_y_T_55, remuResult, _io_y_T_54) @[Mux.scala 81:58]
    io_y <= bits(_io_y_T_56, 31, 0) @[ALU.scala 219:8]

  module PCUpdate :
    input clock : Clock
    input reset : UInt<1>
    input io_valid : UInt<1>
    input io_pc : UInt<32>
    input io_rs1 : UInt<32>
    input io_rs2 : UInt<32>
    input io_imm : UInt<32>
    input io_funct3 : UInt<3>
    input io_branch : UInt<1>
    input io_jump : UInt<1>
    input io_jalr : UInt<1>
    output io_redirect : UInt<1>
    output io_redirectPC : UInt<32>
    output io_nextPc : UInt<32>
    output io_branchTaken : UInt<1>

    node _branchCondition_T = eq(io_rs1, io_rs2) @[PCUpdate.scala 31:25]
    node _branchCondition_T_1 = neq(io_rs1, io_rs2) @[PCUpdate.scala 32:25]
    node _branchCondition_T_2 = asSInt(io_rs1) @[PCUpdate.scala 33:25]
    node _branchCondition_T_3 = asSInt(io_rs2) @[PCUpdate.scala 33:41]
    node _branchCondition_T_4 = lt(_branchCondition_T_2, _branchCondition_T_3) @[PCUpdate.scala 33:32]
    node _branchCondition_T_5 = asSInt(io_rs1) @[PCUpdate.scala 34:25]
    node _branchCondition_T_6 = asSInt(io_rs2) @[PCUpdate.scala 34:42]
    node _branchCondition_T_7 = geq(_branchCondition_T_5, _branchCondition_T_6) @[PCUpdate.scala 34:32]
    node _branchCondition_T_8 = lt(io_rs1, io_rs2) @[PCUpdate.scala 35:25]
    node _branchCondition_T_9 = geq(io_rs1, io_rs2) @[PCUpdate.scala 36:25]
    node _branchCondition_T_10 = eq(UInt<1>("h0"), io_funct3) @[Mux.scala 81:61]
    node _branchCondition_T_11 = mux(_branchCondition_T_10, _branchCondition_T, UInt<1>("h0")) @[Mux.scala 81:58]
    node _branchCondition_T_12 = eq(UInt<1>("h1"), io_funct3) @[Mux.scala 81:61]
    node _branchCondition_T_13 = mux(_branchCondition_T_12, _branchCondition_T_1, _branchCondition_T_11) @[Mux.scala 81:58]
    node _branchCondition_T_14 = eq(UInt<3>("h4"), io_funct3) @[Mux.scala 81:61]
    node _branchCondition_T_15 = mux(_branchCondition_T_14, _branchCondition_T_4, _branchCondition_T_13) @[Mux.scala 81:58]
    node _branchCondition_T_16 = eq(UInt<3>("h5"), io_funct3) @[Mux.scala 81:61]
    node _branchCondition_T_17 = mux(_branchCondition_T_16, _branchCondition_T_7, _branchCondition_T_15) @[Mux.scala 81:58]
    node _branchCondition_T_18 = eq(UInt<3>("h6"), io_funct3) @[Mux.scala 81:61]
    node _branchCondition_T_19 = mux(_branchCondition_T_18, _branchCondition_T_8, _branchCondition_T_17) @[Mux.scala 81:58]
    node _branchCondition_T_20 = eq(UInt<3>("h7"), io_funct3) @[Mux.scala 81:61]
    node branchCondition = mux(_branchCondition_T_20, _branchCondition_T_9, _branchCondition_T_19) @[Mux.scala 81:58]
    node _takeBranch_T = and(io_valid, io_branch) @[PCUpdate.scala 40:29]
    node takeBranch = and(_takeBranch_T, branchCondition) @[PCUpdate.scala 40:42]
    node takeJal = and(io_valid, io_jump) @[PCUpdate.scala 41:29]
    node takeJalr = and(io_valid, io_jalr) @[PCUpdate.scala 42:29]
    node _pcTarget_T = add(io_pc, io_imm) @[PCUpdate.scala 45:26]
    node pcTarget = tail(_pcTarget_T, 1) @[PCUpdate.scala 45:26]
    node _jalrTarget_T = add(io_rs1, io_imm) @[PCUpdate.scala 46:28]
    node _jalrTarget_T_1 = tail(_jalrTarget_T, 1) @[PCUpdate.scala 46:28]
    node _jalrTarget_T_2 = not(UInt<32>("h1")) @[PCUpdate.scala 46:41]
    node jalrTarget = and(_jalrTarget_T_1, _jalrTarget_T_2) @[PCUpdate.scala 46:38]
    node _io_redirect_T = or(takeBranch, takeJal) @[PCUpdate.scala 49:32]
    node _io_redirect_T_1 = or(_io_redirect_T, takeJalr) @[PCUpdate.scala 49:43]
    node _io_redirectPC_T = mux(takeJalr, jalrTarget, pcTarget) @[PCUpdate.scala 50:24]
    node _io_nextPc_T = add(io_pc, UInt<3>("h4")) @[PCUpdate.scala 51:59]
    node _io_nextPc_T_1 = tail(_io_nextPc_T, 1) @[PCUpdate.scala 51:59]
    node _io_nextPc_T_2 = mux(io_redirect, io_redirectPC, _io_nextPc_T_1) @[PCUpdate.scala 51:24]
    io_redirect <= _io_redirect_T_1 @[PCUpdate.scala 49:18]
    io_redirectPC <= _io_redirectPC_T @[PCUpdate.scala 50:18]
    io_nextPc <= _io_nextPc_T_2 @[PCUpdate.scala 51:18]
    io_branchTaken <= takeBranch @[PCUpdate.scala 52:18]

  module EXStage :
    input clock : Clock
    input reset : UInt<1>
    input io_valid : UInt<1>
    input io_pc : UInt<32>
    input io_rs1 : UInt<5>
    input io_rs2 : UInt<5>
    input io_rd : UInt<5>
    input io_rs1Data : UInt<32>
    input io_rs2Data : UInt<32>
    input io_imm : UInt<32>
    input io_funct3 : UInt<3>
    input io_aluOp : UInt<5>
    input io_aluASel : UInt<2>
    input io_aluSrc : UInt<1>
    input io_regWrite : UInt<1>
    input io_memRead : UInt<1>
    input io_memWrite : UInt<1>
    input io_memToReg : UInt<1>
    input io_branch : UInt<1>
    input io_jump : UInt<1>
    input io_jalr : UInt<1>
    input io_forwardA : UInt<2>
    input io_forwardB : UInt<2>
    input io_exmemForwardData : UInt<32>
    input io_memwbForwardData : UInt<32>
    output io_aluResult : UInt<32>
    output io_storeData : UInt<32>
    output io_rdOut : UInt<5>
    output io_funct3Out : UInt<3>
    output io_pcPlus4 : UInt<32>
    output io_regWriteOut : UInt<1>
    output io_memReadOut : UInt<1>
    output io_memWriteOut : UInt<1>
    output io_memToRegOut : UInt<1>
    output io_linkOut : UInt<1>
    output io_redirect : UInt<1>
    output io_redirectPC : UInt<32>
    output io_branchTaken : UInt<1>
    output io_debugALU : UInt<32>
    output io_debugOperandA : UInt<32>
    output io_debugOperandB : UInt<32>

    inst alu of ALU @[EXStage.scala 65:24]
    inst pcUpdate of PCUpdate @[EXStage.scala 66:24]
    node _rs1Forwarded_T = eq(UInt<1>("h1"), io_forwardA) @[Mux.scala 81:61]
    node _rs1Forwarded_T_1 = mux(_rs1Forwarded_T, io_memwbForwardData, io_rs1Data) @[Mux.scala 81:58]
    node _rs1Forwarded_T_2 = eq(UInt<2>("h2"), io_forwardA) @[Mux.scala 81:61]
    node rs1Forwarded = mux(_rs1Forwarded_T_2, io_exmemForwardData, _rs1Forwarded_T_1) @[Mux.scala 81:58]
    node _rs2Forwarded_T = eq(UInt<1>("h1"), io_forwardB) @[Mux.scala 81:61]
    node _rs2Forwarded_T_1 = mux(_rs2Forwarded_T, io_memwbForwardData, io_rs2Data) @[Mux.scala 81:58]
    node _rs2Forwarded_T_2 = eq(UInt<2>("h2"), io_forwardB) @[Mux.scala 81:61]
    node rs2Forwarded = mux(_rs2Forwarded_T_2, io_exmemForwardData, _rs2Forwarded_T_1) @[Mux.scala 81:58]
    node _operandA_T = eq(UInt<1>("h1"), io_aluASel) @[Mux.scala 81:61]
    node _operandA_T_1 = mux(_operandA_T, io_pc, rs1Forwarded) @[Mux.scala 81:58]
    node _operandA_T_2 = eq(UInt<2>("h2"), io_aluASel) @[Mux.scala 81:61]
    node operandA = mux(_operandA_T_2, UInt<32>("h0"), _operandA_T_1) @[Mux.scala 81:58]
    node operandB = mux(io_aluSrc, io_imm, rs2Forwarded) @[EXStage.scala 85:21]
    node _io_pcPlus4_T = add(io_pc, UInt<3>("h4")) @[EXStage.scala 113:25]
    node _io_pcPlus4_T_1 = tail(_io_pcPlus4_T, 1) @[EXStage.scala 113:25]
    node _io_regWriteOut_T = and(io_regWrite, io_valid) @[EXStage.scala 116:33]
    node _io_memReadOut_T = and(io_memRead, io_valid) @[EXStage.scala 117:33]
    node _io_memWriteOut_T = and(io_memWrite, io_valid) @[EXStage.scala 118:33]
    node _io_linkOut_T = or(io_jump, io_jalr) @[EXStage.scala 120:30]
    node _io_linkOut_T_1 = and(_io_linkOut_T, io_valid) @[EXStage.scala 120:42]
    io_aluResult <= alu.io_y @[EXStage.scala 109:16]
    io_storeData <= rs2Forwarded @[EXStage.scala 110:16]
    io_rdOut <= io_rd @[EXStage.scala 111:16]
    io_funct3Out <= io_funct3 @[EXStage.scala 112:16]
    io_pcPlus4 <= _io_pcPlus4_T_1 @[EXStage.scala 113:16]
    io_regWriteOut <= _io_regWriteOut_T @[EXStage.scala 116:18]
    io_memReadOut <= _io_memReadOut_T @[EXStage.scala 117:18]
    io_memWriteOut <= _io_memWriteOut_T @[EXStage.scala 118:18]
    io_memToRegOut <= io_memToReg @[EXStage.scala 119:18]
    io_linkOut <= _io_linkOut_T_1 @[EXStage.scala 120:18]
    io_redirect <= pcUpdate.io_redirect @[EXStage.scala 104:18]
    io_redirectPC <= pcUpdate.io_redirectPC @[EXStage.scala 105:18]
    io_branchTaken <= pcUpdate.io_branchTaken @[EXStage.scala 106:18]
    io_debugALU <= alu.io_y @[EXStage.scala 123:20]
    io_debugOperandA <= operandA @[EXStage.scala 124:20]
    io_debugOperandB <= operandB @[EXStage.scala 125:20]
    alu.clock <= clock
    alu.reset <= reset
    alu.io_a <= operandA @[EXStage.scala 88:13]
    alu.io_b <= operandB @[EXStage.scala 89:13]
    alu.io_op <= io_aluOp @[EXStage.scala 90:13]
    pcUpdate.clock <= clock
    pcUpdate.reset <= reset
    pcUpdate.io_valid <= io_valid @[EXStage.scala 93:22]
    pcUpdate.io_pc <= io_pc @[EXStage.scala 94:22]
    pcUpdate.io_rs1 <= rs1Forwarded @[EXStage.scala 95:22]
    pcUpdate.io_rs2 <= rs2Forwarded @[EXStage.scala 96:22]
    pcUpdate.io_imm <= io_imm @[EXStage.scala 97:22]
    pcUpdate.io_funct3 <= io_funct3 @[EXStage.scala 98:22]
    pcUpdate.io_branch <= io_branch @[EXStage.scala 99:22]
    pcUpdate.io_jump <= io_jump @[EXStage.scala 100:22]
    pcUpdate.io_jalr <= io_jalr @[EXStage.scala 101:22]

  module MEMStage :
    input clock : Clock
    input reset : UInt<1>
    input io_valid : UInt<1>
    input io_aluResult : UInt<32>
    input io_storeData : UInt<32>
    input io_rd : UInt<5>
    input io_funct3 : UInt<3>
    input io_pcPlus4 : UInt<32>
    input io_regWrite : UInt<1>
    input io_memRead : UInt<1>
    input io_memWrite : UInt<1>
    input io_memToReg : UInt<1>
    input io_link : UInt<1>
    output io_memAddr : UInt<32>
    output io_memWdata : UInt<32>
    output io_memReadOut : UInt<1>
    output io_memWriteOut : UInt<1>
    output io_memFunct3 : UInt<3>
    input io_memRdata : UInt<32>
    output io_memDataOut : UInt<32>
    output io_aluResultOut : UInt<32>
    output io_pcPlus4Out : UInt<32>
    output io_rdOut : UInt<5>
    output io_regWriteOut : UInt<1>
    output io_memToRegOut : UInt<1>
    output io_linkOut : UInt<1>

    node _io_memReadOut_T = and(io_memRead, io_valid) @[MEMStage.scala 38:32]
    node _io_memWriteOut_T = and(io_memWrite, io_valid) @[MEMStage.scala 39:33]
    node _io_regWriteOut_T = and(io_regWrite, io_valid) @[MEMStage.scala 45:34]
    io_memAddr <= io_aluResult @[MEMStage.scala 35:18]
    io_memWdata <= io_storeData @[MEMStage.scala 36:18]
    io_memReadOut <= _io_memReadOut_T @[MEMStage.scala 38:18]
    io_memWriteOut <= _io_memWriteOut_T @[MEMStage.scala 39:18]
    io_memFunct3 <= io_funct3 @[MEMStage.scala 37:18]
    io_memDataOut <= io_memRdata @[MEMStage.scala 41:19]
    io_aluResultOut <= io_aluResult @[MEMStage.scala 42:19]
    io_pcPlus4Out <= io_pcPlus4 @[MEMStage.scala 43:19]
    io_rdOut <= io_rd @[MEMStage.scala 44:19]
    io_regWriteOut <= _io_regWriteOut_T @[MEMStage.scala 45:19]
    io_memToRegOut <= io_memToReg @[MEMStage.scala 46:19]
    io_linkOut <= io_link @[MEMStage.scala 47:19]

  module WBStage :
    input clock : Clock
    input reset : UInt<1>
    input io_valid : UInt<1>
    input io_aluResult : UInt<32>
    input io_memData : UInt<32>
    input io_pcPlus4 : UInt<32>
    input io_rd : UInt<5>
    input io_regWrite : UInt<1>
    input io_memToReg : UInt<1>
    input io_link : UInt<1>
    output io_writeRd : UInt<5>
    output io_writeData : UInt<32>
    output io_writeEnable : UInt<1>

    node _io_writeData_T = mux(io_memToReg, io_memData, io_aluResult) @[WBStage.scala 22:22]
    node _io_writeData_T_1 = mux(io_link, io_pcPlus4, _io_writeData_T) @[WBStage.scala 21:22]
    node _io_writeEnable_T = and(io_valid, io_regWrite) @[WBStage.scala 25:30]
    node _io_writeEnable_T_1 = neq(io_rd, UInt<1>("h0")) @[WBStage.scala 25:55]
    node _io_writeEnable_T_2 = and(_io_writeEnable_T, _io_writeEnable_T_1) @[WBStage.scala 25:45]
    io_writeRd <= io_rd @[WBStage.scala 24:18]
    io_writeData <= _io_writeData_T_1 @[WBStage.scala 21:16]
    io_writeEnable <= _io_writeEnable_T_2 @[WBStage.scala 25:18]

  module ForwardingUnit :
    input clock : Clock
    input reset : UInt<1>
    input io_idexRs1 : UInt<5>
    input io_idexRs2 : UInt<5>
    input io_exmemRd : UInt<5>
    input io_exmemRegWrite : UInt<1>
    input io_exmemValid : UInt<1>
    input io_memwbRd : UInt<5>
    input io_memwbRegWrite : UInt<1>
    input io_memwbValid : UInt<1>
    output io_forwardA : UInt<2>
    output io_forwardB : UInt<2>

    node _T = and(io_exmemValid, io_exmemRegWrite) @[ForwardingUnit.scala 43:19]
    node _T_1 = neq(io_exmemRd, UInt<1>("h0")) @[ForwardingUnit.scala 45:17]
    node _T_2 = and(_T, _T_1) @[ForwardingUnit.scala 44:22]
    node _T_3 = eq(io_exmemRd, io_idexRs1) @[ForwardingUnit.scala 46:17]
    node _T_4 = and(_T_2, _T_3) @[ForwardingUnit.scala 45:26]
    node _T_5 = and(io_memwbValid, io_memwbRegWrite) @[ForwardingUnit.scala 53:19]
    node _T_6 = neq(io_memwbRd, UInt<1>("h0")) @[ForwardingUnit.scala 55:17]
    node _T_7 = and(_T_5, _T_6) @[ForwardingUnit.scala 54:22]
    node _T_8 = eq(io_memwbRd, io_idexRs1) @[ForwardingUnit.scala 56:17]
    node _T_9 = and(_T_7, _T_8) @[ForwardingUnit.scala 55:26]
    node _GEN_0 = mux(_T_9, UInt<1>("h1"), UInt<1>("h0")) @[ForwardingUnit.scala 35:15 57:5 59:17]
    node _GEN_1 = mux(_T_4, UInt<2>("h2"), _GEN_0) @[ForwardingUnit.scala 47:5 50:17]
    node _T_10 = and(io_exmemValid, io_exmemRegWrite) @[ForwardingUnit.scala 67:19]
    node _T_11 = neq(io_exmemRd, UInt<1>("h0")) @[ForwardingUnit.scala 69:17]
    node _T_12 = and(_T_10, _T_11) @[ForwardingUnit.scala 68:22]
    node _T_13 = eq(io_exmemRd, io_idexRs2) @[ForwardingUnit.scala 70:17]
    node _T_14 = and(_T_12, _T_13) @[ForwardingUnit.scala 69:26]
    node _T_15 = and(io_memwbValid, io_memwbRegWrite) @[ForwardingUnit.scala 76:19]
    node _T_16 = neq(io_memwbRd, UInt<1>("h0")) @[ForwardingUnit.scala 78:17]
    node _T_17 = and(_T_15, _T_16) @[ForwardingUnit.scala 77:22]
    node _T_18 = eq(io_memwbRd, io_idexRs2) @[ForwardingUnit.scala 79:17]
    node _T_19 = and(_T_17, _T_18) @[ForwardingUnit.scala 78:26]
    node _GEN_2 = mux(_T_19, UInt<1>("h1"), UInt<1>("h0")) @[ForwardingUnit.scala 36:15 80:5 82:17]
    node _GEN_3 = mux(_T_14, UInt<2>("h2"), _GEN_2) @[ForwardingUnit.scala 71:5 73:17]
    io_forwardA <= _GEN_1
    io_forwardB <= _GEN_3

  module HazardDetectionUnit :
    input clock : Clock
    input reset : UInt<1>
    input io_ifidRs1 : UInt<5>
    input io_ifidRs2 : UInt<5>
    input io_ifidUsesRs1 : UInt<1>
    input io_ifidUsesRs2 : UInt<1>
    input io_idexRd : UInt<5>
    input io_idexMemRead : UInt<1>
    input io_idexValid : UInt<1>
    output io_stallPC : UInt<1>
    output io_stallIFID : UInt<1>
    output io_bubbleIDEX : UInt<1>

    node _rs1Hazard_T = eq(io_idexRd, io_ifidRs1) @[HazardDetectionUnit.scala 49:16]
    node rs1Hazard = and(io_ifidUsesRs1, _rs1Hazard_T) @[HazardDetectionUnit.scala 48:20]
    node _rs2Hazard_T = eq(io_idexRd, io_ifidRs2) @[HazardDetectionUnit.scala 53:16]
    node rs2Hazard = and(io_ifidUsesRs2, _rs2Hazard_T) @[HazardDetectionUnit.scala 52:20]
    node _loadUseHazard_T = and(io_idexValid, io_idexMemRead) @[HazardDetectionUnit.scala 56:18]
    node _loadUseHazard_T_1 = neq(io_idexRd, UInt<1>("h0")) @[HazardDetectionUnit.scala 58:16]
    node _loadUseHazard_T_2 = and(_loadUseHazard_T, _loadUseHazard_T_1) @[HazardDetectionUnit.scala 57:20]
    node _loadUseHazard_T_3 = or(rs1Hazard, rs2Hazard) @[HazardDetectionUnit.scala 59:16]
    node loadUseHazard = and(_loadUseHazard_T_2, _loadUseHazard_T_3) @[HazardDetectionUnit.scala 58:25]
    io_stallPC <= loadUseHazard @[HazardDetectionUnit.scala 61:14]
    io_stallIFID <= loadUseHazard @[HazardDetectionUnit.scala 64:16]
    io_bubbleIDEX <= loadUseHazard @[HazardDetectionUnit.scala 67:17]

  module RV32ICore :
    input clock : Clock
    input reset : UInt<1>
    output io_pc : UInt<32>
    output io_nextPc : UInt<32>
    output io_writeBack : UInt<32>
    output io_debugInstr : UInt<32>
    output io_debugX1 : UInt<32>
    output io_debugX2 : UInt<32>
    output io_debugX3 : UInt<32>
    output io_debugX4 : UInt<32>
    output io_debugX5 : UInt<32>
    output io_debugX6 : UInt<32>
    output io_debugALU : UInt<32>
    output io_debugImm : UInt<32>
    output io_debugFetchPC : UInt<32>
    output io_debugDecodePC : UInt<32>
    output io_debugExecPC : UInt<32>
    output io_debugMemPC : UInt<32>
    output io_debugValid : UInt<1>
    output io_debugFlush : UInt<1>
    output io_debugStall : UInt<1>
    output io_debugIFIDValid : UInt<1>
    output io_debugIDEXValid : UInt<1>
    output io_debugEXMEMValid : UInt<1>
    output io_debugMEMWBValid : UInt<1>

    inst instructionMemory of InstructionMemory @[RV32ICore.scala 35:33]
    inst dataMemory of DataMemory @[RV32ICore.scala 36:33]
    inst idStage of IDStage @[RV32ICore.scala 37:33]
    inst exStage of EXStage @[RV32ICore.scala 38:33]
    inst memStage of MEMStage @[RV32ICore.scala 39:33]
    inst wbStage of WBStage @[RV32ICore.scala 40:33]
    inst forwardingUnit of ForwardingUnit @[RV32ICore.scala 41:33]
    inst hazardUnit of HazardDetectionUnit @[RV32ICore.scala 42:33]
    reg pcReg : UInt<32>, clock with :
      reset => (UInt<1>("h0"), pcReg) @[RV32ICore.scala 45:22]
    node _sequentialPC_T = add(pcReg, UInt<3>("h4")) @[RV32ICore.scala 46:28]
    node sequentialPC = tail(_sequentialPC_T, 1) @[RV32ICore.scala 46:28]
    reg ifidValid : UInt<1>, clock with :
      reset => (UInt<1>("h0"), ifidValid) @[RV32ICore.scala 49:26]
    reg ifidPC : UInt<32>, clock with :
      reset => (UInt<1>("h0"), ifidPC) @[RV32ICore.scala 50:26]
    reg ifidInstr : UInt<32>, clock with :
      reset => (UInt<1>("h0"), ifidInstr) @[RV32ICore.scala 51:26]
    reg idexValid : UInt<1>, clock with :
      reset => (UInt<1>("h0"), idexValid) @[RV32ICore.scala 54:30]
    reg idexPC : UInt<32>, clock with :
      reset => (UInt<1>("h0"), idexPC) @[RV32ICore.scala 55:30]
    reg idexInstr : UInt<32>, clock with :
      reset => (UInt<1>("h0"), idexInstr) @[RV32ICore.scala 56:30]
    reg idexRs1 : UInt<5>, clock with :
      reset => (UInt<1>("h0"), idexRs1) @[RV32ICore.scala 57:30]
    reg idexRs2 : UInt<5>, clock with :
      reset => (UInt<1>("h0"), idexRs2) @[RV32ICore.scala 58:30]
    reg idexRd : UInt<5>, clock with :
      reset => (UInt<1>("h0"), idexRd) @[RV32ICore.scala 59:30]
    reg idexRs1Data : UInt<32>, clock with :
      reset => (UInt<1>("h0"), idexRs1Data) @[RV32ICore.scala 60:30]
    reg idexRs2Data : UInt<32>, clock with :
      reset => (UInt<1>("h0"), idexRs2Data) @[RV32ICore.scala 61:30]
    reg idexImm : UInt<32>, clock with :
      reset => (UInt<1>("h0"), idexImm) @[RV32ICore.scala 62:30]
    reg idexFunct3 : UInt<3>, clock with :
      reset => (UInt<1>("h0"), idexFunct3) @[RV32ICore.scala 63:30]
    reg idexAluOp : UInt<5>, clock with :
      reset => (UInt<1>("h0"), idexAluOp) @[RV32ICore.scala 64:30]
    reg idexAluASel : UInt<2>, clock with :
      reset => (UInt<1>("h0"), idexAluASel) @[RV32ICore.scala 65:30]
    reg idexAluSrc : UInt<1>, clock with :
      reset => (UInt<1>("h0"), idexAluSrc) @[RV32ICore.scala 66:30]
    reg idexRegWrite : UInt<1>, clock with :
      reset => (UInt<1>("h0"), idexRegWrite) @[RV32ICore.scala 67:30]
    reg idexMemRead : UInt<1>, clock with :
      reset => (UInt<1>("h0"), idexMemRead) @[RV32ICore.scala 68:30]
    reg idexMemWrite : UInt<1>, clock with :
      reset => (UInt<1>("h0"), idexMemWrite) @[RV32ICore.scala 69:30]
    reg idexMemToReg : UInt<1>, clock with :
      reset => (UInt<1>("h0"), idexMemToReg) @[RV32ICore.scala 70:30]
    reg idexBranch : UInt<1>, clock with :
      reset => (UInt<1>("h0"), idexBranch) @[RV32ICore.scala 71:30]
    reg idexJump : UInt<1>, clock with :
      reset => (UInt<1>("h0"), idexJump) @[RV32ICore.scala 72:30]
    reg idexJalr : UInt<1>, clock with :
      reset => (UInt<1>("h0"), idexJalr) @[RV32ICore.scala 73:30]
    reg exmemValid : UInt<1>, clock with :
      reset => (UInt<1>("h0"), exmemValid) @[RV32ICore.scala 76:31]
    reg exmemPC : UInt<32>, clock with :
      reset => (UInt<1>("h0"), exmemPC) @[RV32ICore.scala 77:31]
    reg exmemAluResult : UInt<32>, clock with :
      reset => (UInt<1>("h0"), exmemAluResult) @[RV32ICore.scala 78:31]
    reg exmemStoreData : UInt<32>, clock with :
      reset => (UInt<1>("h0"), exmemStoreData) @[RV32ICore.scala 79:31]
    reg exmemRd : UInt<5>, clock with :
      reset => (UInt<1>("h0"), exmemRd) @[RV32ICore.scala 80:31]
    reg exmemFunct3 : UInt<3>, clock with :
      reset => (UInt<1>("h0"), exmemFunct3) @[RV32ICore.scala 81:31]
    reg exmemPCPlus4 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), exmemPCPlus4) @[RV32ICore.scala 82:31]
    reg exmemRegWrite : UInt<1>, clock with :
      reset => (UInt<1>("h0"), exmemRegWrite) @[RV32ICore.scala 83:31]
    reg exmemMemRead : UInt<1>, clock with :
      reset => (UInt<1>("h0"), exmemMemRead) @[RV32ICore.scala 84:31]
    reg exmemMemWrite : UInt<1>, clock with :
      reset => (UInt<1>("h0"), exmemMemWrite) @[RV32ICore.scala 85:31]
    reg exmemMemToReg : UInt<1>, clock with :
      reset => (UInt<1>("h0"), exmemMemToReg) @[RV32ICore.scala 86:31]
    reg exmemLink : UInt<1>, clock with :
      reset => (UInt<1>("h0"), exmemLink) @[RV32ICore.scala 87:31]
    reg memwbValid : UInt<1>, clock with :
      reset => (UInt<1>("h0"), memwbValid) @[RV32ICore.scala 90:31]
    reg memwbAluResult : UInt<32>, clock with :
      reset => (UInt<1>("h0"), memwbAluResult) @[RV32ICore.scala 91:31]
    reg memwbMemData : UInt<32>, clock with :
      reset => (UInt<1>("h0"), memwbMemData) @[RV32ICore.scala 92:31]
    reg memwbPCPlus4 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), memwbPCPlus4) @[RV32ICore.scala 93:31]
    reg memwbRd : UInt<5>, clock with :
      reset => (UInt<1>("h0"), memwbRd) @[RV32ICore.scala 94:31]
    reg memwbRegWrite : UInt<1>, clock with :
      reset => (UInt<1>("h0"), memwbRegWrite) @[RV32ICore.scala 95:31]
    reg memwbMemToReg : UInt<1>, clock with :
      reset => (UInt<1>("h0"), memwbMemToReg) @[RV32ICore.scala 96:31]
    reg memwbLink : UInt<1>, clock with :
      reset => (UInt<1>("h0"), memwbLink) @[RV32ICore.scala 97:31]
    node _exStage_io_exmemForwardData_T = mux(exmemLink, exmemPCPlus4, exmemAluResult) @[RV32ICore.scala 166:8]
    node _T = eq(hazardUnit.io_stallPC, UInt<1>("h0")) @[RV32ICore.scala 196:14]
    node _GEN_0 = mux(_T, sequentialPC, pcReg) @[RV32ICore.scala 196:38 197:11 45:22]
    node _GEN_1 = mux(exStage.io_redirect, exStage.io_redirectPC, _GEN_0) @[RV32ICore.scala 194:18 195:11]
    node _T_1 = eq(hazardUnit.io_stallIFID, UInt<1>("h0")) @[RV32ICore.scala 205:14]
    node _GEN_2 = mux(_T_1, UInt<1>("h1"), ifidValid) @[RV32ICore.scala 205:40 206:15 49:26]
    node _GEN_3 = mux(_T_1, pcReg, ifidPC) @[RV32ICore.scala 205:40 207:15 50:26]
    node _GEN_4 = mux(_T_1, instructionMemory.io_instr, ifidInstr) @[RV32ICore.scala 205:40 208:15 51:26]
    node _GEN_5 = mux(exStage.io_redirect, UInt<1>("h0"), _GEN_2) @[RV32ICore.scala 201:18 202:15]
    node _GEN_6 = mux(exStage.io_redirect, UInt<1>("h0"), _GEN_3) @[RV32ICore.scala 201:18 203:15]
    node _GEN_7 = mux(exStage.io_redirect, UInt<32>("h13"), _GEN_4) @[RV32ICore.scala 201:18 204:15]
    node _T_2 = or(exStage.io_redirect, hazardUnit.io_bubbleIDEX) @[RV32ICore.scala 212:17]
    node _idexValid_T = and(ifidValid, idStage.io_valid) @[RV32ICore.scala 234:31]
    node _GEN_8 = mux(_T_2, UInt<1>("h0"), _idexValid_T) @[RV32ICore.scala 212:46 213:18 234:18]
    node _GEN_9 = mux(_T_2, UInt<1>("h0"), ifidPC) @[RV32ICore.scala 212:46 214:18 235:18]
    node _GEN_10 = mux(_T_2, UInt<32>("h13"), ifidInstr) @[RV32ICore.scala 212:46 215:18 236:18]
    node _GEN_11 = mux(_T_2, UInt<1>("h0"), idStage.io_rs1) @[RV32ICore.scala 212:46 216:18 237:18]
    node _GEN_12 = mux(_T_2, UInt<1>("h0"), idStage.io_rs2) @[RV32ICore.scala 212:46 217:18 238:18]
    node _GEN_13 = mux(_T_2, UInt<1>("h0"), idStage.io_rd) @[RV32ICore.scala 212:46 218:18 239:18]
    node _GEN_14 = mux(_T_2, UInt<1>("h0"), idStage.io_rs1Data) @[RV32ICore.scala 212:46 219:18 240:18]
    node _GEN_15 = mux(_T_2, UInt<1>("h0"), idStage.io_rs2Data) @[RV32ICore.scala 212:46 220:18 241:18]
    node _GEN_16 = mux(_T_2, UInt<1>("h0"), idStage.io_imm) @[RV32ICore.scala 212:46 221:18 242:18]
    node _GEN_17 = mux(_T_2, UInt<1>("h0"), idStage.io_funct3) @[RV32ICore.scala 212:46 222:18 243:18]
    node _GEN_18 = mux(_T_2, UInt<5>("h0"), idStage.io_aluOp) @[RV32ICore.scala 212:46 223:18 244:18]
    node _GEN_19 = mux(_T_2, UInt<2>("h0"), idStage.io_aluASel) @[RV32ICore.scala 212:46 224:18 245:18]
    node _GEN_20 = mux(_T_2, UInt<1>("h0"), idStage.io_aluSrc) @[RV32ICore.scala 212:46 225:18 246:18]
    node _GEN_21 = mux(_T_2, UInt<1>("h0"), idStage.io_regWrite) @[RV32ICore.scala 212:46 226:18 247:18]
    node _GEN_22 = mux(_T_2, UInt<1>("h0"), idStage.io_memRead) @[RV32ICore.scala 212:46 227:18 248:18]
    node _GEN_23 = mux(_T_2, UInt<1>("h0"), idStage.io_memWrite) @[RV32ICore.scala 212:46 228:18 249:18]
    node _GEN_24 = mux(_T_2, UInt<1>("h0"), idStage.io_memToReg) @[RV32ICore.scala 212:46 229:18 250:18]
    node _GEN_25 = mux(_T_2, UInt<1>("h0"), idStage.io_branch) @[RV32ICore.scala 212:46 230:18 251:18]
    node _GEN_26 = mux(_T_2, UInt<1>("h0"), idStage.io_jump) @[RV32ICore.scala 212:46 231:18 252:18]
    node _GEN_27 = mux(_T_2, UInt<1>("h0"), idStage.io_jalr) @[RV32ICore.scala 212:46 232:18 253:18]
    node _io_nextPc_T = mux(hazardUnit.io_stallPC, pcReg, sequentialPC) @[RV32ICore.scala 283:24]
    node _io_nextPc_T_1 = mux(exStage.io_redirect, exStage.io_redirectPC, _io_nextPc_T) @[RV32ICore.scala 282:22]
    node _io_writeBack_T = mux(wbStage.io_writeEnable, wbStage.io_writeData, UInt<1>("h0")) @[RV32ICore.scala 284:22]
    io_pc <= pcReg @[RV32ICore.scala 281:16]
    io_nextPc <= _io_nextPc_T_1 @[RV32ICore.scala 282:16]
    io_writeBack <= _io_writeBack_T @[RV32ICore.scala 284:16]
    io_debugInstr <= idexInstr @[RV32ICore.scala 287:17]
    io_debugX1 <= idStage.io_debugX1 @[RV32ICore.scala 288:17]
    io_debugX2 <= idStage.io_debugX2 @[RV32ICore.scala 289:17]
    io_debugX3 <= idStage.io_debugX3 @[RV32ICore.scala 290:17]
    io_debugX4 <= idStage.io_debugX4 @[RV32ICore.scala 291:17]
    io_debugX5 <= idStage.io_debugX5 @[RV32ICore.scala 292:17]
    io_debugX6 <= idStage.io_debugX6 @[RV32ICore.scala 293:17]
    io_debugALU <= exStage.io_debugALU @[RV32ICore.scala 294:17]
    io_debugImm <= idexImm @[RV32ICore.scala 295:17]
    io_debugFetchPC <= pcReg @[RV32ICore.scala 297:22]
    io_debugDecodePC <= ifidPC @[RV32ICore.scala 298:22]
    io_debugExecPC <= idexPC @[RV32ICore.scala 299:22]
    io_debugMemPC <= exmemPC @[RV32ICore.scala 300:22]
    io_debugValid <= idexValid @[RV32ICore.scala 301:22]
    io_debugFlush <= exStage.io_redirect @[RV32ICore.scala 302:22]
    io_debugStall <= hazardUnit.io_stallPC @[RV32ICore.scala 303:22]
    io_debugIFIDValid <= ifidValid @[RV32ICore.scala 304:22]
    io_debugIDEXValid <= idexValid @[RV32ICore.scala 305:22]
    io_debugEXMEMValid <= exmemValid @[RV32ICore.scala 306:22]
    io_debugMEMWBValid <= memwbValid @[RV32ICore.scala 307:22]
    instructionMemory.clock <= clock
    instructionMemory.reset <= reset
    instructionMemory.io_addr <= pcReg @[RV32ICore.scala 100:29]
    dataMemory.clock <= clock
    dataMemory.reset <= reset
    dataMemory.io_addr <= memStage.io_memAddr @[RV32ICore.scala 186:26]
    dataMemory.io_wdata <= memStage.io_memWdata @[RV32ICore.scala 187:26]
    dataMemory.io_memRead <= memStage.io_memReadOut @[RV32ICore.scala 188:26]
    dataMemory.io_memWrite <= memStage.io_memWriteOut @[RV32ICore.scala 189:26]
    dataMemory.io_funct3 <= memStage.io_memFunct3 @[RV32ICore.scala 190:26]
    idStage.clock <= clock
    idStage.reset <= reset
    idStage.io_valid <= ifidValid @[RV32ICore.scala 116:28]
    idStage.io_pc <= ifidPC @[RV32ICore.scala 117:28]
    idStage.io_instr <= ifidInstr @[RV32ICore.scala 118:28]
    idStage.io_wbRd <= wbStage.io_writeRd @[RV32ICore.scala 119:28]
    idStage.io_wbWriteData <= wbStage.io_writeData @[RV32ICore.scala 120:28]
    idStage.io_wbWriteEnable <= wbStage.io_writeEnable @[RV32ICore.scala 121:28]
    exStage.clock <= clock
    exStage.reset <= reset
    exStage.io_valid <= idexValid @[RV32ICore.scala 143:24]
    exStage.io_pc <= idexPC @[RV32ICore.scala 144:24]
    exStage.io_rs1 <= idexRs1 @[RV32ICore.scala 145:24]
    exStage.io_rs2 <= idexRs2 @[RV32ICore.scala 146:24]
    exStage.io_rd <= idexRd @[RV32ICore.scala 147:24]
    exStage.io_rs1Data <= idexRs1Data @[RV32ICore.scala 148:24]
    exStage.io_rs2Data <= idexRs2Data @[RV32ICore.scala 149:24]
    exStage.io_imm <= idexImm @[RV32ICore.scala 150:24]
    exStage.io_funct3 <= idexFunct3 @[RV32ICore.scala 151:24]
    exStage.io_aluOp <= idexAluOp @[RV32ICore.scala 152:24]
    exStage.io_aluASel <= idexAluASel @[RV32ICore.scala 153:24]
    exStage.io_aluSrc <= idexAluSrc @[RV32ICore.scala 154:24]
    exStage.io_regWrite <= idexRegWrite @[RV32ICore.scala 155:24]
    exStage.io_memRead <= idexMemRead @[RV32ICore.scala 156:24]
    exStage.io_memWrite <= idexMemWrite @[RV32ICore.scala 157:24]
    exStage.io_memToReg <= idexMemToReg @[RV32ICore.scala 158:24]
    exStage.io_branch <= idexBranch @[RV32ICore.scala 159:24]
    exStage.io_jump <= idexJump @[RV32ICore.scala 160:24]
    exStage.io_jalr <= idexJalr @[RV32ICore.scala 161:24]
    exStage.io_forwardA <= forwardingUnit.io_forwardA @[RV32ICore.scala 162:24]
    exStage.io_forwardB <= forwardingUnit.io_forwardB @[RV32ICore.scala 163:24]
    exStage.io_exmemForwardData <= _exStage_io_exmemForwardData_T @[RV32ICore.scala 165:31]
    exStage.io_memwbForwardData <= wbStage.io_writeData @[RV32ICore.scala 167:31]
    memStage.clock <= clock
    memStage.reset <= reset
    memStage.io_valid <= exmemValid @[RV32ICore.scala 173:25]
    memStage.io_aluResult <= exmemAluResult @[RV32ICore.scala 174:25]
    memStage.io_storeData <= exmemStoreData @[RV32ICore.scala 175:25]
    memStage.io_rd <= exmemRd @[RV32ICore.scala 176:25]
    memStage.io_funct3 <= exmemFunct3 @[RV32ICore.scala 177:25]
    memStage.io_pcPlus4 <= exmemPCPlus4 @[RV32ICore.scala 178:25]
    memStage.io_regWrite <= exmemRegWrite @[RV32ICore.scala 179:25]
    memStage.io_memRead <= exmemMemRead @[RV32ICore.scala 180:25]
    memStage.io_memWrite <= exmemMemWrite @[RV32ICore.scala 181:25]
    memStage.io_memToReg <= exmemMemToReg @[RV32ICore.scala 182:25]
    memStage.io_link <= exmemLink @[RV32ICore.scala 183:25]
    memStage.io_memRdata <= dataMemory.io_rdata @[RV32ICore.scala 191:26]
    wbStage.clock <= clock
    wbStage.reset <= reset
    wbStage.io_valid <= memwbValid @[RV32ICore.scala 104:24]
    wbStage.io_aluResult <= memwbAluResult @[RV32ICore.scala 105:24]
    wbStage.io_memData <= memwbMemData @[RV32ICore.scala 106:24]
    wbStage.io_pcPlus4 <= memwbPCPlus4 @[RV32ICore.scala 107:24]
    wbStage.io_rd <= memwbRd @[RV32ICore.scala 108:24]
    wbStage.io_regWrite <= memwbRegWrite @[RV32ICore.scala 109:24]
    wbStage.io_memToReg <= memwbMemToReg @[RV32ICore.scala 110:24]
    wbStage.io_link <= memwbLink @[RV32ICore.scala 111:24]
    forwardingUnit.clock <= clock
    forwardingUnit.reset <= reset
    forwardingUnit.io_idexRs1 <= idexRs1 @[RV32ICore.scala 133:36]
    forwardingUnit.io_idexRs2 <= idexRs2 @[RV32ICore.scala 134:36]
    forwardingUnit.io_exmemRd <= exmemRd @[RV32ICore.scala 135:36]
    forwardingUnit.io_exmemRegWrite <= exmemRegWrite @[RV32ICore.scala 136:36]
    forwardingUnit.io_exmemValid <= exmemValid @[RV32ICore.scala 137:36]
    forwardingUnit.io_memwbRd <= memwbRd @[RV32ICore.scala 138:36]
    forwardingUnit.io_memwbRegWrite <= memwbRegWrite @[RV32ICore.scala 139:36]
    forwardingUnit.io_memwbValid <= memwbValid @[RV32ICore.scala 140:36]
    hazardUnit.clock <= clock
    hazardUnit.reset <= reset
    hazardUnit.io_ifidRs1 <= idStage.io_rs1 @[RV32ICore.scala 124:29]
    hazardUnit.io_ifidRs2 <= idStage.io_rs2 @[RV32ICore.scala 125:29]
    hazardUnit.io_ifidUsesRs1 <= idStage.io_usesRs1 @[RV32ICore.scala 126:29]
    hazardUnit.io_ifidUsesRs2 <= idStage.io_usesRs2 @[RV32ICore.scala 127:29]
    hazardUnit.io_idexRd <= idexRd @[RV32ICore.scala 128:29]
    hazardUnit.io_idexMemRead <= idexMemRead @[RV32ICore.scala 129:29]
    hazardUnit.io_idexValid <= idexValid @[RV32ICore.scala 130:29]
    pcReg <= mux(reset, UInt<32>("h0"), _GEN_1) @[RV32ICore.scala 45:{22,22}]
    ifidValid <= mux(reset, UInt<1>("h0"), _GEN_5) @[RV32ICore.scala 49:{26,26}]
    ifidPC <= mux(reset, UInt<32>("h0"), _GEN_6) @[RV32ICore.scala 50:{26,26}]
    ifidInstr <= mux(reset, UInt<32>("h13"), _GEN_7) @[RV32ICore.scala 51:{26,26}]
    idexValid <= mux(reset, UInt<1>("h0"), _GEN_8) @[RV32ICore.scala 54:{30,30}]
    idexPC <= mux(reset, UInt<32>("h0"), _GEN_9) @[RV32ICore.scala 55:{30,30}]
    idexInstr <= mux(reset, UInt<32>("h13"), _GEN_10) @[RV32ICore.scala 56:{30,30}]
    idexRs1 <= mux(reset, UInt<5>("h0"), _GEN_11) @[RV32ICore.scala 57:{30,30}]
    idexRs2 <= mux(reset, UInt<5>("h0"), _GEN_12) @[RV32ICore.scala 58:{30,30}]
    idexRd <= mux(reset, UInt<5>("h0"), _GEN_13) @[RV32ICore.scala 59:{30,30}]
    idexRs1Data <= mux(reset, UInt<32>("h0"), _GEN_14) @[RV32ICore.scala 60:{30,30}]
    idexRs2Data <= mux(reset, UInt<32>("h0"), _GEN_15) @[RV32ICore.scala 61:{30,30}]
    idexImm <= mux(reset, UInt<32>("h0"), _GEN_16) @[RV32ICore.scala 62:{30,30}]
    idexFunct3 <= mux(reset, UInt<3>("h0"), _GEN_17) @[RV32ICore.scala 63:{30,30}]
    idexAluOp <= mux(reset, UInt<5>("h0"), _GEN_18) @[RV32ICore.scala 64:{30,30}]
    idexAluASel <= mux(reset, UInt<2>("h0"), _GEN_19) @[RV32ICore.scala 65:{30,30}]
    idexAluSrc <= mux(reset, UInt<1>("h0"), _GEN_20) @[RV32ICore.scala 66:{30,30}]
    idexRegWrite <= mux(reset, UInt<1>("h0"), _GEN_21) @[RV32ICore.scala 67:{30,30}]
    idexMemRead <= mux(reset, UInt<1>("h0"), _GEN_22) @[RV32ICore.scala 68:{30,30}]
    idexMemWrite <= mux(reset, UInt<1>("h0"), _GEN_23) @[RV32ICore.scala 69:{30,30}]
    idexMemToReg <= mux(reset, UInt<1>("h0"), _GEN_24) @[RV32ICore.scala 70:{30,30}]
    idexBranch <= mux(reset, UInt<1>("h0"), _GEN_25) @[RV32ICore.scala 71:{30,30}]
    idexJump <= mux(reset, UInt<1>("h0"), _GEN_26) @[RV32ICore.scala 72:{30,30}]
    idexJalr <= mux(reset, UInt<1>("h0"), _GEN_27) @[RV32ICore.scala 73:{30,30}]
    exmemValid <= mux(reset, UInt<1>("h0"), idexValid) @[RV32ICore.scala 257:18 76:{31,31}]
    exmemPC <= mux(reset, UInt<32>("h0"), idexPC) @[RV32ICore.scala 258:18 77:{31,31}]
    exmemAluResult <= mux(reset, UInt<32>("h0"), exStage.io_aluResult) @[RV32ICore.scala 259:18 78:{31,31}]
    exmemStoreData <= mux(reset, UInt<32>("h0"), exStage.io_storeData) @[RV32ICore.scala 260:18 79:{31,31}]
    exmemRd <= mux(reset, UInt<5>("h0"), exStage.io_rdOut) @[RV32ICore.scala 261:18 80:{31,31}]
    exmemFunct3 <= mux(reset, UInt<3>("h0"), exStage.io_funct3Out) @[RV32ICore.scala 262:18 81:{31,31}]
    exmemPCPlus4 <= mux(reset, UInt<32>("h0"), exStage.io_pcPlus4) @[RV32ICore.scala 263:18 82:{31,31}]
    exmemRegWrite <= mux(reset, UInt<1>("h0"), exStage.io_regWriteOut) @[RV32ICore.scala 264:18 83:{31,31}]
    exmemMemRead <= mux(reset, UInt<1>("h0"), exStage.io_memReadOut) @[RV32ICore.scala 265:18 84:{31,31}]
    exmemMemWrite <= mux(reset, UInt<1>("h0"), exStage.io_memWriteOut) @[RV32ICore.scala 266:18 85:{31,31}]
    exmemMemToReg <= mux(reset, UInt<1>("h0"), exStage.io_memToRegOut) @[RV32ICore.scala 267:18 86:{31,31}]
    exmemLink <= mux(reset, UInt<1>("h0"), exStage.io_linkOut) @[RV32ICore.scala 268:18 87:{31,31}]
    memwbValid <= mux(reset, UInt<1>("h0"), exmemValid) @[RV32ICore.scala 271:18 90:{31,31}]
    memwbAluResult <= mux(reset, UInt<32>("h0"), memStage.io_aluResultOut) @[RV32ICore.scala 272:18 91:{31,31}]
    memwbMemData <= mux(reset, UInt<32>("h0"), memStage.io_memDataOut) @[RV32ICore.scala 273:18 92:{31,31}]
    memwbPCPlus4 <= mux(reset, UInt<32>("h0"), memStage.io_pcPlus4Out) @[RV32ICore.scala 274:18 93:{31,31}]
    memwbRd <= mux(reset, UInt<5>("h0"), memStage.io_rdOut) @[RV32ICore.scala 275:18 94:{31,31}]
    memwbRegWrite <= mux(reset, UInt<1>("h0"), memStage.io_regWriteOut) @[RV32ICore.scala 276:18 95:{31,31}]
    memwbMemToReg <= mux(reset, UInt<1>("h0"), memStage.io_memToRegOut) @[RV32ICore.scala 277:18 96:{31,31}]
    memwbLink <= mux(reset, UInt<1>("h0"), memStage.io_linkOut) @[RV32ICore.scala 278:18 97:{31,31}]
