module InstructionMemory(
  input         clock,
  input  [31:0] io_addr,
  output [31:0] io_instr
);
  reg [31:0] mem [0:255]; // @[InstructionMemory.scala 18:16]
  wire  mem_io_instr_MPORT_en; // @[InstructionMemory.scala 18:16]
  wire [7:0] mem_io_instr_MPORT_addr; // @[InstructionMemory.scala 18:16]
  wire [31:0] mem_io_instr_MPORT_data; // @[InstructionMemory.scala 18:16]
  wire [31:0] wordAddr = {{2'd0}, io_addr[31:2]}; // @[InstructionMemory.scala 27:26]
  wire  _io_instr_T = wordAddr < 32'h100; // @[InstructionMemory.scala 31:14]
  assign mem_io_instr_MPORT_en = 1'h1;
  assign mem_io_instr_MPORT_addr = wordAddr[7:0];
  assign mem_io_instr_MPORT_data = mem[mem_io_instr_MPORT_addr]; // @[InstructionMemory.scala 18:16]
  assign io_instr = _io_instr_T ? mem_io_instr_MPORT_data : 32'h0; // @[InstructionMemory.scala 30:18]
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
  integer initvar;
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
  `endif // RANDOMIZE
  $readmemh("memory.hex", mem);
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module DataMemory(
  input         clock,
  input  [31:0] io_addr,
  input  [31:0] io_wdata,
  output [31:0] io_rdata,
  input         io_memRead,
  input         io_memWrite,
  input  [2:0]  io_funct3
);
`ifdef RANDOMIZE_MEM_INIT
  reg [31:0] _RAND_0;
`endif // RANDOMIZE_MEM_INIT
  reg [7:0] mem [0:1023]; // @[DataMemory.scala 18:16]
  wire  mem_byte0_en; // @[DataMemory.scala 18:16]
  wire [9:0] mem_byte0_addr; // @[DataMemory.scala 18:16]
  wire [7:0] mem_byte0_data; // @[DataMemory.scala 18:16]
  wire  mem_byte1_en; // @[DataMemory.scala 18:16]
  wire [9:0] mem_byte1_addr; // @[DataMemory.scala 18:16]
  wire [7:0] mem_byte1_data; // @[DataMemory.scala 18:16]
  wire  mem_byte2_en; // @[DataMemory.scala 18:16]
  wire [9:0] mem_byte2_addr; // @[DataMemory.scala 18:16]
  wire [7:0] mem_byte2_data; // @[DataMemory.scala 18:16]
  wire  mem_byte3_en; // @[DataMemory.scala 18:16]
  wire [9:0] mem_byte3_addr; // @[DataMemory.scala 18:16]
  wire [7:0] mem_byte3_data; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_1_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_1_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_1_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_1_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_2_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_2_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_2_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_2_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_3_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_3_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_3_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_3_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_4_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_4_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_4_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_4_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_5_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_5_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_5_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_5_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_6_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_6_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_6_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_6_en; // @[DataMemory.scala 18:16]
  wire [31:0] _byte1_T_1 = io_addr + 32'h1; // @[DataMemory.scala 21:27]
  wire [31:0] _byte2_T_1 = io_addr + 32'h2; // @[DataMemory.scala 22:27]
  wire [31:0] _byte3_T_1 = io_addr + 32'h3; // @[DataMemory.scala 23:27]
  wire [31:0] loadData = {mem_byte3_data,mem_byte2_data,mem_byte1_data,mem_byte0_data}; // @[Cat.scala 33:92]
  wire  _T = 3'h0 == io_funct3; // @[DataMemory.scala 30:23]
  wire [23:0] _io_rdata_T_2 = mem_byte0_data[7] ? 24'hffffff : 24'h0; // @[Bitwise.scala 77:12]
  wire [31:0] _io_rdata_T_3 = {_io_rdata_T_2,mem_byte0_data}; // @[Cat.scala 33:92]
  wire  _T_1 = 3'h1 == io_funct3; // @[DataMemory.scala 30:23]
  wire [15:0] _io_rdata_T_6 = mem_byte1_data[7] ? 16'hffff : 16'h0; // @[Bitwise.scala 77:12]
  wire [31:0] _io_rdata_T_7 = {_io_rdata_T_6,mem_byte1_data,mem_byte0_data}; // @[Cat.scala 33:92]
  wire  _T_2 = 3'h2 == io_funct3; // @[DataMemory.scala 30:23]
  wire [31:0] _io_rdata_T_8 = {24'h0,mem_byte0_data}; // @[Cat.scala 33:92]
  wire [31:0] _io_rdata_T_9 = {16'h0,mem_byte1_data,mem_byte0_data}; // @[Cat.scala 33:92]
  wire [31:0] _GEN_0 = 3'h5 == io_funct3 ? _io_rdata_T_9 : 32'h0; // @[DataMemory.scala 27:12 30:23 52:18]
  wire [31:0] _GEN_1 = 3'h4 == io_funct3 ? _io_rdata_T_8 : _GEN_0; // @[DataMemory.scala 30:23 48:18]
  wire [31:0] _GEN_2 = 3'h2 == io_funct3 ? loadData : _GEN_1; // @[DataMemory.scala 30:23 44:18]
  wire [31:0] _GEN_3 = 3'h1 == io_funct3 ? _io_rdata_T_7 : _GEN_2; // @[DataMemory.scala 30:23 36:18]
  wire [31:0] _GEN_4 = 3'h0 == io_funct3 ? _io_rdata_T_3 : _GEN_3; // @[DataMemory.scala 30:23 32:18]
  wire  _GEN_26 = _T_1 ? 1'h0 : _T_2; // @[DataMemory.scala 18:16 62:23]
  wire  _GEN_42 = _T ? 1'h0 : _T_1; // @[DataMemory.scala 18:16 62:23]
  wire  _GEN_49 = _T ? 1'h0 : _GEN_26; // @[DataMemory.scala 18:16 62:23]
  assign mem_byte0_en = 1'h1;
  assign mem_byte0_addr = io_addr[9:0];
  assign mem_byte0_data = mem[mem_byte0_addr]; // @[DataMemory.scala 18:16]
  assign mem_byte1_en = 1'h1;
  assign mem_byte1_addr = _byte1_T_1[9:0];
  assign mem_byte1_data = mem[mem_byte1_addr]; // @[DataMemory.scala 18:16]
  assign mem_byte2_en = 1'h1;
  assign mem_byte2_addr = _byte2_T_1[9:0];
  assign mem_byte2_data = mem[mem_byte2_addr]; // @[DataMemory.scala 18:16]
  assign mem_byte3_en = 1'h1;
  assign mem_byte3_addr = _byte3_T_1[9:0];
  assign mem_byte3_data = mem[mem_byte3_addr]; // @[DataMemory.scala 18:16]
  assign mem_MPORT_data = io_wdata[7:0];
  assign mem_MPORT_addr = io_addr[9:0];
  assign mem_MPORT_mask = 1'h1;
  assign mem_MPORT_en = io_memWrite & _T;
  assign mem_MPORT_1_data = io_wdata[7:0];
  assign mem_MPORT_1_addr = io_addr[9:0];
  assign mem_MPORT_1_mask = 1'h1;
  assign mem_MPORT_1_en = io_memWrite & _GEN_42;
  assign mem_MPORT_2_data = io_wdata[15:8];
  assign mem_MPORT_2_addr = _byte1_T_1[9:0];
  assign mem_MPORT_2_mask = 1'h1;
  assign mem_MPORT_2_en = io_memWrite & _GEN_42;
  assign mem_MPORT_3_data = io_wdata[7:0];
  assign mem_MPORT_3_addr = io_addr[9:0];
  assign mem_MPORT_3_mask = 1'h1;
  assign mem_MPORT_3_en = io_memWrite & _GEN_49;
  assign mem_MPORT_4_data = io_wdata[15:8];
  assign mem_MPORT_4_addr = _byte1_T_1[9:0];
  assign mem_MPORT_4_mask = 1'h1;
  assign mem_MPORT_4_en = io_memWrite & _GEN_49;
  assign mem_MPORT_5_data = io_wdata[23:16];
  assign mem_MPORT_5_addr = _byte2_T_1[9:0];
  assign mem_MPORT_5_mask = 1'h1;
  assign mem_MPORT_5_en = io_memWrite & _GEN_49;
  assign mem_MPORT_6_data = io_wdata[31:24];
  assign mem_MPORT_6_addr = _byte3_T_1[9:0];
  assign mem_MPORT_6_mask = 1'h1;
  assign mem_MPORT_6_en = io_memWrite & _GEN_49;
  assign io_rdata = io_memRead ? _GEN_4 : 32'h0; // @[DataMemory.scala 27:12 29:20]
  always @(posedge clock) begin
    if (mem_MPORT_en & mem_MPORT_mask) begin
      mem[mem_MPORT_addr] <= mem_MPORT_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_1_en & mem_MPORT_1_mask) begin
      mem[mem_MPORT_1_addr] <= mem_MPORT_1_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_2_en & mem_MPORT_2_mask) begin
      mem[mem_MPORT_2_addr] <= mem_MPORT_2_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_3_en & mem_MPORT_3_mask) begin
      mem[mem_MPORT_3_addr] <= mem_MPORT_3_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_4_en & mem_MPORT_4_mask) begin
      mem[mem_MPORT_4_addr] <= mem_MPORT_4_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_5_en & mem_MPORT_5_mask) begin
      mem[mem_MPORT_5_addr] <= mem_MPORT_5_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_6_en & mem_MPORT_6_mask) begin
      mem[mem_MPORT_6_addr] <= mem_MPORT_6_data; // @[DataMemory.scala 18:16]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_MEM_INIT
  _RAND_0 = {1{`RANDOM}};
  for (initvar = 0; initvar < 1024; initvar = initvar+1)
    mem[initvar] = _RAND_0[7:0];
`endif // RANDOMIZE_MEM_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module Decoder(
  input  [31:0] io_instr,
  output [4:0]  io_rs1,
  output [4:0]  io_rs2,
  output [4:0]  io_rd,
  output [2:0]  io_funct3
);
  assign io_rs1 = io_instr[19:15]; // @[Decoder.scala 35:24]
  assign io_rs2 = io_instr[24:20]; // @[Decoder.scala 36:24]
  assign io_rd = io_instr[11:7]; // @[Decoder.scala 37:24]
  assign io_funct3 = io_instr[14:12]; // @[Decoder.scala 32:24]
endmodule
module Control(
  input  [31:0] io_instr,
  output [4:0]  io_aluOp,
  output [1:0]  io_aluASel,
  output        io_aluSrc,
  output        io_memRead,
  output        io_memWrite,
  output        io_memToReg,
  output        io_regWrite,
  output        io_branch,
  output        io_jump,
  output        io_jalr,
  output        io_usesRs1,
  output        io_usesRs2
);
  wire [6:0] opcode = io_instr[6:0]; // @[Control.scala 153:13]
  wire [2:0] funct3 = io_instr[14:12]; // @[Control.scala 156:13]
  wire [6:0] funct7 = io_instr[31:25]; // @[Control.scala 159:13]
  wire  _T_1 = 3'h0 == funct3; // @[Control.scala 279:22]
  wire  _T_2 = funct7 == 7'h1; // @[Control.scala 288:23]
  wire  _T_3 = funct7 == 7'h20; // @[Control.scala 293:29]
  wire [4:0] _GEN_0 = funct7 == 7'h20 ? 5'h1 : 5'h0; // @[Control.scala 293:47 295:22 300:22]
  wire [4:0] _GEN_1 = funct7 == 7'h1 ? 5'ha : _GEN_0; // @[Control.scala 288:41 290:22]
  wire  _T_4 = 3'h1 == funct3; // @[Control.scala 279:22]
  wire [4:0] _GEN_2 = _T_2 ? 5'hb : 5'h2; // @[Control.scala 312:41 314:22 319:22]
  wire  _T_6 = 3'h2 == funct3; // @[Control.scala 279:22]
  wire [4:0] _GEN_3 = _T_2 ? 5'hc : 5'h3; // @[Control.scala 331:41 333:22 338:22]
  wire  _T_8 = 3'h3 == funct3; // @[Control.scala 279:22]
  wire [4:0] _GEN_4 = _T_2 ? 5'hd : 5'h4; // @[Control.scala 350:41 352:22 357:22]
  wire  _T_10 = 3'h4 == funct3; // @[Control.scala 279:22]
  wire [4:0] _GEN_5 = _T_2 ? 5'h10 : 5'h5; // @[Control.scala 369:41 371:22 376:22]
  wire  _T_12 = 3'h5 == funct3; // @[Control.scala 279:22]
  wire [4:0] _GEN_6 = _T_3 ? 5'h7 : 5'h6; // @[Control.scala 393:47 395:22 400:22]
  wire [4:0] _GEN_7 = _T_2 ? 5'h11 : _GEN_6; // @[Control.scala 388:41 390:22]
  wire  _T_15 = 3'h6 == funct3; // @[Control.scala 279:22]
  wire [4:0] _GEN_8 = _T_2 ? 5'h12 : 5'h8; // @[Control.scala 412:41 414:22 419:22]
  wire  _T_17 = 3'h7 == funct3; // @[Control.scala 279:22]
  wire [4:0] _GEN_9 = _T_2 ? 5'h13 : 5'h9; // @[Control.scala 431:41 433:22 438:22]
  wire [4:0] _GEN_10 = 3'h7 == funct3 ? _GEN_9 : 5'h0; // @[Control.scala 204:12 279:22]
  wire [4:0] _GEN_11 = 3'h6 == funct3 ? _GEN_8 : _GEN_10; // @[Control.scala 279:22]
  wire [4:0] _GEN_12 = 3'h5 == funct3 ? _GEN_7 : _GEN_11; // @[Control.scala 279:22]
  wire [4:0] _GEN_13 = 3'h4 == funct3 ? _GEN_5 : _GEN_12; // @[Control.scala 279:22]
  wire [4:0] _GEN_14 = 3'h3 == funct3 ? _GEN_4 : _GEN_13; // @[Control.scala 279:22]
  wire [4:0] _GEN_15 = 3'h2 == funct3 ? _GEN_3 : _GEN_14; // @[Control.scala 279:22]
  wire [4:0] _GEN_16 = 3'h1 == funct3 ? _GEN_2 : _GEN_15; // @[Control.scala 279:22]
  wire [4:0] _GEN_17 = 3'h0 == funct3 ? _GEN_1 : _GEN_16; // @[Control.scala 279:22]
  wire [4:0] _GEN_19 = _T_12 ? _GEN_6 : 5'h0; // @[Control.scala 204:12 474:22]
  wire [4:0] _GEN_20 = _T_4 ? 5'h2 : _GEN_19; // @[Control.scala 474:22 528:20]
  wire [4:0] _GEN_21 = _T_17 ? 5'h9 : _GEN_20; // @[Control.scala 474:22 520:20]
  wire [4:0] _GEN_22 = _T_15 ? 5'h8 : _GEN_21; // @[Control.scala 474:22 512:20]
  wire [4:0] _GEN_23 = _T_10 ? 5'h5 : _GEN_22; // @[Control.scala 474:22 504:20]
  wire [4:0] _GEN_24 = _T_8 ? 5'h4 : _GEN_23; // @[Control.scala 474:22 496:20]
  wire [4:0] _GEN_25 = _T_6 ? 5'h3 : _GEN_24; // @[Control.scala 474:22 488:20]
  wire [4:0] _GEN_26 = _T_1 ? 5'h0 : _GEN_25; // @[Control.scala 474:22 480:20]
  wire [1:0] _GEN_29 = 7'h17 == opcode ? 2'h2 : 2'h0; // @[Control.scala 207:14 248:18 786:18]
  wire  _GEN_32 = 7'h37 == opcode | 7'h17 == opcode; // @[Control.scala 248:18 739:16]
  wire [1:0] _GEN_34 = 7'h37 == opcode ? 2'h1 : _GEN_29; // @[Control.scala 248:18 748:18]
  wire  _GEN_37 = 7'h67 == opcode | _GEN_32; // @[Control.scala 248:18 692:16]
  wire [1:0] _GEN_41 = 7'h67 == opcode ? 2'h0 : _GEN_34; // @[Control.scala 248:18 708:18]
  wire  _GEN_44 = 7'h6f == opcode | _GEN_37; // @[Control.scala 248:18 665:16]
  wire  _GEN_45 = 7'h6f == opcode ? 1'h0 : 7'h67 == opcode; // @[Control.scala 248:18 668:18]
  wire [1:0] _GEN_50 = 7'h6f == opcode ? 2'h0 : _GEN_41; // @[Control.scala 207:14 248:18]
  wire  _GEN_51 = 7'h6f == opcode ? 1'h0 : _GEN_37; // @[Control.scala 210:13 248:18]
  wire  _GEN_54 = 7'h63 == opcode | _GEN_45; // @[Control.scala 248:18 638:18]
  wire [1:0] _GEN_57 = 7'h63 == opcode ? 2'h0 : _GEN_50; // @[Control.scala 248:18 647:18]
  wire  _GEN_58 = 7'h63 == opcode ? 1'h0 : _GEN_51; // @[Control.scala 248:18 650:17]
  wire  _GEN_60 = 7'h63 == opcode ? 1'h0 : 7'h6f == opcode; // @[Control.scala 231:11 248:18]
  wire  _GEN_61 = 7'h63 == opcode ? 1'h0 : _GEN_44; // @[Control.scala 222:15 248:18]
  wire  _GEN_63 = 7'h63 == opcode ? 1'h0 : _GEN_45; // @[Control.scala 234:11 248:18]
  wire  _GEN_65 = 7'h23 == opcode | _GEN_54; // @[Control.scala 248:18 601:18]
  wire  _GEN_66 = 7'h23 == opcode | 7'h63 == opcode; // @[Control.scala 248:18 604:18]
  wire [1:0] _GEN_67 = 7'h23 == opcode ? 2'h0 : _GEN_57; // @[Control.scala 248:18 607:18]
  wire  _GEN_68 = 7'h23 == opcode | _GEN_58; // @[Control.scala 248:18 610:17]
  wire  _GEN_71 = 7'h23 == opcode ? 1'h0 : 7'h63 == opcode; // @[Control.scala 228:13 248:18]
  wire  _GEN_72 = 7'h23 == opcode ? 1'h0 : _GEN_60; // @[Control.scala 231:11 248:18]
  wire  _GEN_73 = 7'h23 == opcode ? 1'h0 : _GEN_61; // @[Control.scala 222:15 248:18]
  wire  _GEN_75 = 7'h23 == opcode ? 1'h0 : _GEN_63; // @[Control.scala 234:11 248:18]
  wire  _GEN_77 = 7'h3 == opcode | _GEN_65; // @[Control.scala 248:18 561:18]
  wire  _GEN_78 = 7'h3 == opcode ? 1'h0 : _GEN_66; // @[Control.scala 248:18 564:18]
  wire [1:0] _GEN_79 = 7'h3 == opcode ? 2'h0 : _GEN_67; // @[Control.scala 248:18 567:18]
  wire  _GEN_80 = 7'h3 == opcode | _GEN_68; // @[Control.scala 248:18 570:17]
  wire  _GEN_83 = 7'h3 == opcode | _GEN_73; // @[Control.scala 248:18 582:19]
  wire  _GEN_85 = 7'h3 == opcode ? 1'h0 : 7'h23 == opcode; // @[Control.scala 216:15 248:18]
  wire  _GEN_86 = 7'h3 == opcode ? 1'h0 : _GEN_71; // @[Control.scala 228:13 248:18]
  wire  _GEN_87 = 7'h3 == opcode ? 1'h0 : _GEN_72; // @[Control.scala 231:11 248:18]
  wire  _GEN_88 = 7'h3 == opcode ? 1'h0 : _GEN_75; // @[Control.scala 234:11 248:18]
  wire  _GEN_90 = 7'h13 == opcode | _GEN_77; // @[Control.scala 248:18 455:18]
  wire  _GEN_91 = 7'h13 == opcode ? 1'h0 : _GEN_78; // @[Control.scala 248:18 458:18]
  wire [1:0] _GEN_92 = 7'h13 == opcode ? 2'h0 : _GEN_79; // @[Control.scala 248:18 461:18]
  wire  _GEN_93 = 7'h13 == opcode | _GEN_80; // @[Control.scala 248:18 464:17]
  wire  _GEN_94 = 7'h13 == opcode | _GEN_83; // @[Control.scala 248:18 467:19]
  wire [4:0] _GEN_96 = 7'h13 == opcode ? _GEN_26 : 5'h0; // @[Control.scala 248:18]
  wire  _GEN_97 = 7'h13 == opcode ? 1'h0 : 7'h3 == opcode; // @[Control.scala 213:14 248:18]
  wire  _GEN_98 = 7'h13 == opcode ? 1'h0 : _GEN_85; // @[Control.scala 216:15 248:18]
  wire  _GEN_99 = 7'h13 == opcode ? 1'h0 : _GEN_86; // @[Control.scala 228:13 248:18]
  wire  _GEN_100 = 7'h13 == opcode ? 1'h0 : _GEN_87; // @[Control.scala 231:11 248:18]
  wire  _GEN_101 = 7'h13 == opcode ? 1'h0 : _GEN_88; // @[Control.scala 234:11 248:18]
  assign io_aluOp = 7'h33 == opcode ? _GEN_17 : _GEN_96; // @[Control.scala 248:18]
  assign io_aluASel = 7'h33 == opcode ? 2'h0 : _GEN_92; // @[Control.scala 248:18 266:18]
  assign io_aluSrc = 7'h33 == opcode ? 1'h0 : _GEN_93; // @[Control.scala 248:18 269:17]
  assign io_memRead = 7'h33 == opcode ? 1'h0 : _GEN_97; // @[Control.scala 213:14 248:18]
  assign io_memWrite = 7'h33 == opcode ? 1'h0 : _GEN_98; // @[Control.scala 216:15 248:18]
  assign io_memToReg = 7'h33 == opcode ? 1'h0 : _GEN_97; // @[Control.scala 213:14 248:18]
  assign io_regWrite = 7'h33 == opcode | _GEN_94; // @[Control.scala 248:18 272:19]
  assign io_branch = 7'h33 == opcode ? 1'h0 : _GEN_99; // @[Control.scala 228:13 248:18]
  assign io_jump = 7'h33 == opcode ? 1'h0 : _GEN_100; // @[Control.scala 231:11 248:18]
  assign io_jalr = 7'h33 == opcode ? 1'h0 : _GEN_101; // @[Control.scala 234:11 248:18]
  assign io_usesRs1 = 7'h33 == opcode | _GEN_90; // @[Control.scala 248:18 260:18]
  assign io_usesRs2 = 7'h33 == opcode | _GEN_91; // @[Control.scala 248:18 263:18]
endmodule
module ImmediateGenerator(
  input  [31:0] io_instr,
  output [31:0] io_imm
);
  wire [6:0] opcode = io_instr[6:0]; // @[ImmediateGenerator.scala 12:24]
  wire [19:0] _iImm_T_2 = io_instr[31] ? 20'hfffff : 20'h0; // @[Bitwise.scala 77:12]
  wire [31:0] iImm = {_iImm_T_2,io_instr[31:20]}; // @[Cat.scala 33:92]
  wire [31:0] sImm = {_iImm_T_2,io_instr[31:25],io_instr[11:7]}; // @[Cat.scala 33:92]
  wire [18:0] _bImm_T_2 = io_instr[31] ? 19'h7ffff : 19'h0; // @[Bitwise.scala 77:12]
  wire [31:0] bImm = {_bImm_T_2,io_instr[31],io_instr[7],io_instr[30:25],io_instr[11:8],1'h0}; // @[Cat.scala 33:92]
  wire [31:0] uImm = {io_instr[31:12],12'h0}; // @[Cat.scala 33:92]
  wire [10:0] _jImm_T_2 = io_instr[31] ? 11'h7ff : 11'h0; // @[Bitwise.scala 77:12]
  wire [31:0] jImm = {_jImm_T_2,io_instr[31],io_instr[19:12],io_instr[20],io_instr[30:21],1'h0}; // @[Cat.scala 33:92]
  wire [31:0] _GEN_0 = 7'h6f == opcode ? jImm : 32'h0; // @[ImmediateGenerator.scala 48:10 50:18 81:14]
  wire [31:0] _GEN_1 = 7'h17 == opcode ? uImm : _GEN_0; // @[ImmediateGenerator.scala 50:18 77:14]
  wire [31:0] _GEN_2 = 7'h37 == opcode ? uImm : _GEN_1; // @[ImmediateGenerator.scala 50:18 73:14]
  wire [31:0] _GEN_3 = 7'h63 == opcode ? bImm : _GEN_2; // @[ImmediateGenerator.scala 50:18 69:14]
  wire [31:0] _GEN_4 = 7'h23 == opcode ? sImm : _GEN_3; // @[ImmediateGenerator.scala 50:18 65:14]
  wire [31:0] _GEN_5 = 7'h67 == opcode ? iImm : _GEN_4; // @[ImmediateGenerator.scala 50:18 61:14]
  wire [31:0] _GEN_6 = 7'h13 == opcode ? iImm : _GEN_5; // @[ImmediateGenerator.scala 50:18 57:14]
  assign io_imm = 7'h3 == opcode ? iImm : _GEN_6; // @[ImmediateGenerator.scala 50:18 53:14]
endmodule
module RegisterFile(
  input         clock,
  input         reset,
  input  [4:0]  io_rs1,
  input  [4:0]  io_rs2,
  output [31:0] io_readData1,
  output [31:0] io_readData2,
  input  [4:0]  io_rd,
  input  [31:0] io_writeData,
  input         io_writeEnable,
  output [31:0] io_debugRead_1,
  output [31:0] io_debugRead_2,
  output [31:0] io_debugRead_3,
  output [31:0] io_debugRead_4,
  output [31:0] io_debugRead_5,
  output [31:0] io_debugRead_6
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
`endif // RANDOMIZE_REG_INIT
  reg [31:0] regs_0; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_1; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_2; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_3; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_4; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_5; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_6; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_7; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_8; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_9; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_10; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_11; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_12; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_13; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_14; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_15; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_16; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_17; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_18; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_19; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_20; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_21; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_22; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_23; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_24; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_25; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_26; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_27; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_28; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_29; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_30; // @[RegisterFile.scala 84:12]
  reg [31:0] regs_31; // @[RegisterFile.scala 84:12]
  wire  _io_readData1_T = io_rs1 == 5'h0; // @[RegisterFile.scala 105:14]
  wire [31:0] _GEN_1 = 5'h1 == io_rs1 ? regs_1 : regs_0; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_2 = 5'h2 == io_rs1 ? regs_2 : _GEN_1; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_3 = 5'h3 == io_rs1 ? regs_3 : _GEN_2; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_4 = 5'h4 == io_rs1 ? regs_4 : _GEN_3; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_5 = 5'h5 == io_rs1 ? regs_5 : _GEN_4; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_6 = 5'h6 == io_rs1 ? regs_6 : _GEN_5; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_7 = 5'h7 == io_rs1 ? regs_7 : _GEN_6; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_8 = 5'h8 == io_rs1 ? regs_8 : _GEN_7; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_9 = 5'h9 == io_rs1 ? regs_9 : _GEN_8; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_10 = 5'ha == io_rs1 ? regs_10 : _GEN_9; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_11 = 5'hb == io_rs1 ? regs_11 : _GEN_10; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_12 = 5'hc == io_rs1 ? regs_12 : _GEN_11; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_13 = 5'hd == io_rs1 ? regs_13 : _GEN_12; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_14 = 5'he == io_rs1 ? regs_14 : _GEN_13; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_15 = 5'hf == io_rs1 ? regs_15 : _GEN_14; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_16 = 5'h10 == io_rs1 ? regs_16 : _GEN_15; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_17 = 5'h11 == io_rs1 ? regs_17 : _GEN_16; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_18 = 5'h12 == io_rs1 ? regs_18 : _GEN_17; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_19 = 5'h13 == io_rs1 ? regs_19 : _GEN_18; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_20 = 5'h14 == io_rs1 ? regs_20 : _GEN_19; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_21 = 5'h15 == io_rs1 ? regs_21 : _GEN_20; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_22 = 5'h16 == io_rs1 ? regs_22 : _GEN_21; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_23 = 5'h17 == io_rs1 ? regs_23 : _GEN_22; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_24 = 5'h18 == io_rs1 ? regs_24 : _GEN_23; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_25 = 5'h19 == io_rs1 ? regs_25 : _GEN_24; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_26 = 5'h1a == io_rs1 ? regs_26 : _GEN_25; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_27 = 5'h1b == io_rs1 ? regs_27 : _GEN_26; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_28 = 5'h1c == io_rs1 ? regs_28 : _GEN_27; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_29 = 5'h1d == io_rs1 ? regs_29 : _GEN_28; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_30 = 5'h1e == io_rs1 ? regs_30 : _GEN_29; // @[RegisterFile.scala 104:{8,8}]
  wire [31:0] _GEN_31 = 5'h1f == io_rs1 ? regs_31 : _GEN_30; // @[RegisterFile.scala 104:{8,8}]
  wire  _io_readData2_T = io_rs2 == 5'h0; // @[RegisterFile.scala 117:14]
  wire [31:0] _GEN_33 = 5'h1 == io_rs2 ? regs_1 : regs_0; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_34 = 5'h2 == io_rs2 ? regs_2 : _GEN_33; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_35 = 5'h3 == io_rs2 ? regs_3 : _GEN_34; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_36 = 5'h4 == io_rs2 ? regs_4 : _GEN_35; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_37 = 5'h5 == io_rs2 ? regs_5 : _GEN_36; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_38 = 5'h6 == io_rs2 ? regs_6 : _GEN_37; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_39 = 5'h7 == io_rs2 ? regs_7 : _GEN_38; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_40 = 5'h8 == io_rs2 ? regs_8 : _GEN_39; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_41 = 5'h9 == io_rs2 ? regs_9 : _GEN_40; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_42 = 5'ha == io_rs2 ? regs_10 : _GEN_41; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_43 = 5'hb == io_rs2 ? regs_11 : _GEN_42; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_44 = 5'hc == io_rs2 ? regs_12 : _GEN_43; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_45 = 5'hd == io_rs2 ? regs_13 : _GEN_44; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_46 = 5'he == io_rs2 ? regs_14 : _GEN_45; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_47 = 5'hf == io_rs2 ? regs_15 : _GEN_46; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_48 = 5'h10 == io_rs2 ? regs_16 : _GEN_47; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_49 = 5'h11 == io_rs2 ? regs_17 : _GEN_48; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_50 = 5'h12 == io_rs2 ? regs_18 : _GEN_49; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_51 = 5'h13 == io_rs2 ? regs_19 : _GEN_50; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_52 = 5'h14 == io_rs2 ? regs_20 : _GEN_51; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_53 = 5'h15 == io_rs2 ? regs_21 : _GEN_52; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_54 = 5'h16 == io_rs2 ? regs_22 : _GEN_53; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_55 = 5'h17 == io_rs2 ? regs_23 : _GEN_54; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_56 = 5'h18 == io_rs2 ? regs_24 : _GEN_55; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_57 = 5'h19 == io_rs2 ? regs_25 : _GEN_56; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_58 = 5'h1a == io_rs2 ? regs_26 : _GEN_57; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_59 = 5'h1b == io_rs2 ? regs_27 : _GEN_58; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_60 = 5'h1c == io_rs2 ? regs_28 : _GEN_59; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_61 = 5'h1d == io_rs2 ? regs_29 : _GEN_60; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_62 = 5'h1e == io_rs2 ? regs_30 : _GEN_61; // @[RegisterFile.scala 116:{8,8}]
  wire [31:0] _GEN_63 = 5'h1f == io_rs2 ? regs_31 : _GEN_62; // @[RegisterFile.scala 116:{8,8}]
  wire  _T = io_rd != 5'h0; // @[RegisterFile.scala 150:12]
  wire  _T_1 = io_writeEnable & _T; // @[RegisterFile.scala 149:20]
  assign io_readData1 = _io_readData1_T ? 32'h0 : _GEN_31; // @[RegisterFile.scala 104:8]
  assign io_readData2 = _io_readData2_T ? 32'h0 : _GEN_63; // @[RegisterFile.scala 116:8]
  assign io_debugRead_1 = regs_1; // @[RegisterFile.scala 165:10]
  assign io_debugRead_2 = regs_2; // @[RegisterFile.scala 165:10]
  assign io_debugRead_3 = regs_3; // @[RegisterFile.scala 165:10]
  assign io_debugRead_4 = regs_4; // @[RegisterFile.scala 165:10]
  assign io_debugRead_5 = regs_5; // @[RegisterFile.scala 165:10]
  assign io_debugRead_6 = regs_6; // @[RegisterFile.scala 165:10]
  always @(posedge clock) begin
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_0 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h0 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_0 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_1 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h1 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_1 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_2 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h2 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_2 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_3 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h3 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_3 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_4 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h4 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_4 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_5 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h5 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_5 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_6 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h6 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_6 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_7 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h7 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_7 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_8 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h8 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_8 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_9 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h9 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_9 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_10 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'ha == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_10 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_11 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'hb == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_11 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_12 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'hc == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_12 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_13 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'hd == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_13 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_14 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'he == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_14 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_15 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'hf == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_15 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_16 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h10 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_16 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_17 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h11 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_17 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_18 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h12 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_18 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_19 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h13 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_19 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_20 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h14 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_20 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_21 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h15 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_21 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_22 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h16 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_22 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_23 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h17 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_23 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_24 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h18 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_24 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_25 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h19 == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_25 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_26 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h1a == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_26 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_27 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h1b == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_27 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_28 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h1c == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_28 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_29 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h1d == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_29 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_30 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h1e == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_30 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 84:12]
      regs_31 <= 32'h0; // @[RegisterFile.scala 84:12]
    end else if (_T_1) begin // @[RegisterFile.scala 151:5]
      if (5'h1f == io_rd) begin // @[RegisterFile.scala 153:17]
        regs_31 <= io_writeData; // @[RegisterFile.scala 153:17]
      end
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  regs_0 = _RAND_0[31:0];
  _RAND_1 = {1{`RANDOM}};
  regs_1 = _RAND_1[31:0];
  _RAND_2 = {1{`RANDOM}};
  regs_2 = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  regs_3 = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  regs_4 = _RAND_4[31:0];
  _RAND_5 = {1{`RANDOM}};
  regs_5 = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  regs_6 = _RAND_6[31:0];
  _RAND_7 = {1{`RANDOM}};
  regs_7 = _RAND_7[31:0];
  _RAND_8 = {1{`RANDOM}};
  regs_8 = _RAND_8[31:0];
  _RAND_9 = {1{`RANDOM}};
  regs_9 = _RAND_9[31:0];
  _RAND_10 = {1{`RANDOM}};
  regs_10 = _RAND_10[31:0];
  _RAND_11 = {1{`RANDOM}};
  regs_11 = _RAND_11[31:0];
  _RAND_12 = {1{`RANDOM}};
  regs_12 = _RAND_12[31:0];
  _RAND_13 = {1{`RANDOM}};
  regs_13 = _RAND_13[31:0];
  _RAND_14 = {1{`RANDOM}};
  regs_14 = _RAND_14[31:0];
  _RAND_15 = {1{`RANDOM}};
  regs_15 = _RAND_15[31:0];
  _RAND_16 = {1{`RANDOM}};
  regs_16 = _RAND_16[31:0];
  _RAND_17 = {1{`RANDOM}};
  regs_17 = _RAND_17[31:0];
  _RAND_18 = {1{`RANDOM}};
  regs_18 = _RAND_18[31:0];
  _RAND_19 = {1{`RANDOM}};
  regs_19 = _RAND_19[31:0];
  _RAND_20 = {1{`RANDOM}};
  regs_20 = _RAND_20[31:0];
  _RAND_21 = {1{`RANDOM}};
  regs_21 = _RAND_21[31:0];
  _RAND_22 = {1{`RANDOM}};
  regs_22 = _RAND_22[31:0];
  _RAND_23 = {1{`RANDOM}};
  regs_23 = _RAND_23[31:0];
  _RAND_24 = {1{`RANDOM}};
  regs_24 = _RAND_24[31:0];
  _RAND_25 = {1{`RANDOM}};
  regs_25 = _RAND_25[31:0];
  _RAND_26 = {1{`RANDOM}};
  regs_26 = _RAND_26[31:0];
  _RAND_27 = {1{`RANDOM}};
  regs_27 = _RAND_27[31:0];
  _RAND_28 = {1{`RANDOM}};
  regs_28 = _RAND_28[31:0];
  _RAND_29 = {1{`RANDOM}};
  regs_29 = _RAND_29[31:0];
  _RAND_30 = {1{`RANDOM}};
  regs_30 = _RAND_30[31:0];
  _RAND_31 = {1{`RANDOM}};
  regs_31 = _RAND_31[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module IDStage(
  input         clock,
  input         reset,
  input         io_valid,
  input  [31:0] io_instr,
  input  [4:0]  io_wbRd,
  input  [31:0] io_wbWriteData,
  input         io_wbWriteEnable,
  output [4:0]  io_rs1,
  output [4:0]  io_rs2,
  output [4:0]  io_rd,
  output [31:0] io_rs1Data,
  output [31:0] io_rs2Data,
  output [31:0] io_imm,
  output [2:0]  io_funct3,
  output [4:0]  io_aluOp,
  output [1:0]  io_aluASel,
  output        io_aluSrc,
  output        io_regWrite,
  output        io_memRead,
  output        io_memWrite,
  output        io_memToReg,
  output        io_branch,
  output        io_jump,
  output        io_jalr,
  output        io_usesRs1,
  output        io_usesRs2,
  output [31:0] io_debugX1,
  output [31:0] io_debugX2,
  output [31:0] io_debugX3,
  output [31:0] io_debugX4,
  output [31:0] io_debugX5,
  output [31:0] io_debugX6
);
  wire [31:0] decoder_io_instr; // @[IDStage.scala 124:11]
  wire [4:0] decoder_io_rs1; // @[IDStage.scala 124:11]
  wire [4:0] decoder_io_rs2; // @[IDStage.scala 124:11]
  wire [4:0] decoder_io_rd; // @[IDStage.scala 124:11]
  wire [2:0] decoder_io_funct3; // @[IDStage.scala 124:11]
  wire [31:0] control_io_instr; // @[IDStage.scala 127:11]
  wire [4:0] control_io_aluOp; // @[IDStage.scala 127:11]
  wire [1:0] control_io_aluASel; // @[IDStage.scala 127:11]
  wire  control_io_aluSrc; // @[IDStage.scala 127:11]
  wire  control_io_memRead; // @[IDStage.scala 127:11]
  wire  control_io_memWrite; // @[IDStage.scala 127:11]
  wire  control_io_memToReg; // @[IDStage.scala 127:11]
  wire  control_io_regWrite; // @[IDStage.scala 127:11]
  wire  control_io_branch; // @[IDStage.scala 127:11]
  wire  control_io_jump; // @[IDStage.scala 127:11]
  wire  control_io_jalr; // @[IDStage.scala 127:11]
  wire  control_io_usesRs1; // @[IDStage.scala 127:11]
  wire  control_io_usesRs2; // @[IDStage.scala 127:11]
  wire [31:0] immGen_io_instr; // @[IDStage.scala 130:11]
  wire [31:0] immGen_io_imm; // @[IDStage.scala 130:11]
  wire  regFile_clock; // @[IDStage.scala 133:11]
  wire  regFile_reset; // @[IDStage.scala 133:11]
  wire [4:0] regFile_io_rs1; // @[IDStage.scala 133:11]
  wire [4:0] regFile_io_rs2; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_readData1; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_readData2; // @[IDStage.scala 133:11]
  wire [4:0] regFile_io_rd; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_writeData; // @[IDStage.scala 133:11]
  wire  regFile_io_writeEnable; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_debugRead_1; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_debugRead_2; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_debugRead_3; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_debugRead_4; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_debugRead_5; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_debugRead_6; // @[IDStage.scala 133:11]
  wire  _wbBypassRs1_T = io_wbRd != 5'h0; // @[IDStage.scala 205:14]
  wire  _wbBypassRs1_T_1 = io_wbWriteEnable & _wbBypassRs1_T; // @[IDStage.scala 204:22]
  wire  _wbBypassRs1_T_2 = io_wbRd == decoder_io_rs1; // @[IDStage.scala 206:14]
  wire  wbBypassRs1 = _wbBypassRs1_T_1 & _wbBypassRs1_T_2; // @[IDStage.scala 205:23]
  wire  _wbBypassRs2_T_2 = io_wbRd == decoder_io_rs2; // @[IDStage.scala 211:14]
  wire  wbBypassRs2 = _wbBypassRs1_T_1 & _wbBypassRs2_T_2; // @[IDStage.scala 210:23]
  Decoder decoder ( // @[IDStage.scala 124:11]
    .io_instr(decoder_io_instr),
    .io_rs1(decoder_io_rs1),
    .io_rs2(decoder_io_rs2),
    .io_rd(decoder_io_rd),
    .io_funct3(decoder_io_funct3)
  );
  Control control ( // @[IDStage.scala 127:11]
    .io_instr(control_io_instr),
    .io_aluOp(control_io_aluOp),
    .io_aluASel(control_io_aluASel),
    .io_aluSrc(control_io_aluSrc),
    .io_memRead(control_io_memRead),
    .io_memWrite(control_io_memWrite),
    .io_memToReg(control_io_memToReg),
    .io_regWrite(control_io_regWrite),
    .io_branch(control_io_branch),
    .io_jump(control_io_jump),
    .io_jalr(control_io_jalr),
    .io_usesRs1(control_io_usesRs1),
    .io_usesRs2(control_io_usesRs2)
  );
  ImmediateGenerator immGen ( // @[IDStage.scala 130:11]
    .io_instr(immGen_io_instr),
    .io_imm(immGen_io_imm)
  );
  RegisterFile regFile ( // @[IDStage.scala 133:11]
    .clock(regFile_clock),
    .reset(regFile_reset),
    .io_rs1(regFile_io_rs1),
    .io_rs2(regFile_io_rs2),
    .io_readData1(regFile_io_readData1),
    .io_readData2(regFile_io_readData2),
    .io_rd(regFile_io_rd),
    .io_writeData(regFile_io_writeData),
    .io_writeEnable(regFile_io_writeEnable),
    .io_debugRead_1(regFile_io_debugRead_1),
    .io_debugRead_2(regFile_io_debugRead_2),
    .io_debugRead_3(regFile_io_debugRead_3),
    .io_debugRead_4(regFile_io_debugRead_4),
    .io_debugRead_5(regFile_io_debugRead_5),
    .io_debugRead_6(regFile_io_debugRead_6)
  );
  assign io_rs1 = decoder_io_rs1; // @[IDStage.scala 232:10]
  assign io_rs2 = decoder_io_rs2; // @[IDStage.scala 235:10]
  assign io_rd = decoder_io_rd; // @[IDStage.scala 238:9]
  assign io_rs1Data = wbBypassRs1 ? io_wbWriteData : regFile_io_readData1; // @[IDStage.scala 214:8]
  assign io_rs2Data = wbBypassRs2 ? io_wbWriteData : regFile_io_readData2; // @[IDStage.scala 221:8]
  assign io_imm = immGen_io_imm; // @[IDStage.scala 246:10]
  assign io_funct3 = decoder_io_funct3; // @[IDStage.scala 249:13]
  assign io_aluOp = control_io_aluOp; // @[IDStage.scala 257:12]
  assign io_aluASel = control_io_aluASel; // @[IDStage.scala 260:14]
  assign io_aluSrc = control_io_aluSrc; // @[IDStage.scala 263:13]
  assign io_regWrite = control_io_regWrite & io_valid; // @[IDStage.scala 272:25]
  assign io_memRead = control_io_memRead & io_valid; // @[IDStage.scala 276:24]
  assign io_memWrite = control_io_memWrite & io_valid; // @[IDStage.scala 280:25]
  assign io_memToReg = control_io_memToReg; // @[IDStage.scala 283:15]
  assign io_branch = control_io_branch & io_valid; // @[IDStage.scala 287:23]
  assign io_jump = control_io_jump & io_valid; // @[IDStage.scala 291:21]
  assign io_jalr = control_io_jalr & io_valid; // @[IDStage.scala 295:21]
  assign io_usesRs1 = control_io_usesRs1 & io_valid; // @[IDStage.scala 304:24]
  assign io_usesRs2 = control_io_usesRs2 & io_valid; // @[IDStage.scala 308:24]
  assign io_debugX1 = regFile_io_debugRead_1; // @[IDStage.scala 316:14]
  assign io_debugX2 = regFile_io_debugRead_2; // @[IDStage.scala 319:14]
  assign io_debugX3 = regFile_io_debugRead_3; // @[IDStage.scala 322:14]
  assign io_debugX4 = regFile_io_debugRead_4; // @[IDStage.scala 325:14]
  assign io_debugX5 = regFile_io_debugRead_5; // @[IDStage.scala 328:14]
  assign io_debugX6 = regFile_io_debugRead_6; // @[IDStage.scala 331:14]
  assign decoder_io_instr = io_instr; // @[IDStage.scala 140:20]
  assign control_io_instr = io_instr; // @[IDStage.scala 143:20]
  assign immGen_io_instr = io_instr; // @[IDStage.scala 146:19]
  assign regFile_clock = clock;
  assign regFile_reset = reset;
  assign regFile_io_rs1 = decoder_io_rs1; // @[IDStage.scala 154:18]
  assign regFile_io_rs2 = decoder_io_rs2; // @[IDStage.scala 157:18]
  assign regFile_io_rd = io_wbRd; // @[IDStage.scala 171:17]
  assign regFile_io_writeData = io_wbWriteData; // @[IDStage.scala 174:24]
  assign regFile_io_writeEnable = io_wbWriteEnable; // @[IDStage.scala 177:26]
endmodule
module ALU(
  input  [31:0] io_a,
  input  [31:0] io_b,
  input  [4:0]  io_op,
  output [31:0] io_y
);
  wire [4:0] shamt = io_b[4:0]; // @[ALU.scala 64:19]
  wire [31:0] _aSigned64_T_2 = io_a[31] ? 32'hffffffff : 32'h0; // @[Bitwise.scala 77:12]
  wire [63:0] aSigned64 = {_aSigned64_T_2,io_a}; // @[ALU.scala 78:35]
  wire [31:0] _bSigned64_T_2 = io_b[31] ? 32'hffffffff : 32'h0; // @[Bitwise.scala 77:12]
  wire [63:0] bSigned64 = {_bSigned64_T_2,io_b}; // @[ALU.scala 81:35]
  wire [63:0] aUnsigned64 = {32'h0,io_a}; // @[Cat.scala 33:92]
  wire [63:0] bUnsigned64 = {32'h0,io_b}; // @[Cat.scala 33:92]
  wire [127:0] mulSS = $signed(aSigned64) * $signed(bSigned64); // @[ALU.scala 93:26]
  wire [127:0] mulUU = aUnsigned64 * bUnsigned64; // @[ALU.scala 94:28]
  wire [63:0] _mulHSU_T = {32'h0,io_b}; // @[ALU.scala 95:40]
  wire [127:0] mulHSU = $signed(aSigned64) * $signed(_mulHSU_T); // @[ALU.scala 95:26]
  wire [31:0] mulLow = mulSS[31:0]; // @[ALU.scala 98:10]
  wire [31:0] mulHighSS = mulSS[63:32]; // @[ALU.scala 101:10]
  wire [31:0] mulHighSU = mulHSU[63:32]; // @[ALU.scala 104:11]
  wire [31:0] mulHighUU = mulUU[63:32]; // @[ALU.scala 107:10]
  wire  _T = io_b == 32'h0; // @[ALU.scala 147:14]
  wire  _T_2 = io_b == 32'hffffffff; // @[ALU.scala 152:11]
  wire  _T_3 = io_a == 32'h80000000 & _T_2; // @[ALU.scala 151:23]
  wire [32:0] _divResult_T_1 = $signed(io_a) / $signed(io_b); // @[ALU.scala 157:38]
  wire [32:0] _GEN_0 = _T_3 ? 33'h80000000 : _divResult_T_1; // @[ALU.scala 153:5 155:15 157:15]
  wire [32:0] _GEN_1 = io_b == 32'h0 ? 33'hffffffff : _GEN_0; // @[ALU.scala 147:23 149:15]
  wire [31:0] _divuResult_T = io_a / io_b; // @[ALU.scala 170:24]
  wire [31:0] divuResult = _T ? 32'hffffffff : _divuResult_T; // @[ALU.scala 166:23 168:16 170:16]
  wire [31:0] _remResult_T_1 = $signed(io_a) % $signed(io_b); // @[ALU.scala 189:38]
  wire [31:0] _GEN_3 = _T_3 ? 32'h0 : _remResult_T_1; // @[ALU.scala 185:5 187:15 189:15]
  wire [31:0] remResult = _T ? io_a : _GEN_3; // @[ALU.scala 179:23 181:15]
  wire [31:0] _remuResult_T = io_a % io_b; // @[ALU.scala 202:24]
  wire [31:0] remuResult = _T ? io_a : _remuResult_T; // @[ALU.scala 198:23 200:16 202:16]
  wire  equal = io_a == io_b; // @[ALU.scala 210:10]
  wire  notEqual = io_a != io_b; // @[ALU.scala 213:10]
  wire [31:0] _io_y_T_1 = io_a + io_b; // @[ALU.scala 229:15]
  wire [31:0] _io_y_T_3 = io_a - io_b; // @[ALU.scala 232:15]
  wire [62:0] _GEN_2 = {{31'd0}, io_a}; // @[ALU.scala 235:15]
  wire [62:0] _io_y_T_4 = _GEN_2 << shamt; // @[ALU.scala 235:15]
  wire  _io_y_T_5 = $signed(io_a) < $signed(io_b); // @[ALU.scala 239:19]
  wire [31:0] _io_y_T_6 = _io_y_T_5 ? 32'h1 : 32'h0; // @[ALU.scala 238:12]
  wire  _io_y_T_7 = io_a < io_b; // @[ALU.scala 246:16]
  wire [31:0] _io_y_T_8 = _io_y_T_7 ? 32'h1 : 32'h0; // @[ALU.scala 245:12]
  wire [31:0] _io_y_T_9 = io_a ^ io_b; // @[ALU.scala 252:15]
  wire [31:0] _io_y_T_10 = io_a >> shamt; // @[ALU.scala 255:15]
  wire [31:0] _io_y_T_12 = $signed(io_a) >>> shamt; // @[ALU.scala 258:28]
  wire [31:0] _io_y_T_13 = io_a | io_b; // @[ALU.scala 261:15]
  wire [31:0] _io_y_T_14 = io_a & io_b; // @[ALU.scala 264:15]
  wire [31:0] _io_y_T_15 = equal ? 32'h1 : 32'h0; // @[ALU.scala 287:12]
  wire [31:0] _io_y_T_16 = notEqual ? 32'h1 : 32'h0; // @[ALU.scala 294:12]
  wire [31:0] _io_y_T_18 = 5'h0 == io_op ? _io_y_T_1 : 32'h0; // @[Mux.scala 81:58]
  wire [31:0] _io_y_T_20 = 5'h1 == io_op ? _io_y_T_3 : _io_y_T_18; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_22 = 5'h2 == io_op ? _io_y_T_4 : {{31'd0}, _io_y_T_20}; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_24 = 5'h3 == io_op ? {{31'd0}, _io_y_T_6} : _io_y_T_22; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_26 = 5'h4 == io_op ? {{31'd0}, _io_y_T_8} : _io_y_T_24; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_28 = 5'h5 == io_op ? {{31'd0}, _io_y_T_9} : _io_y_T_26; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_30 = 5'h6 == io_op ? {{31'd0}, _io_y_T_10} : _io_y_T_28; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_32 = 5'h7 == io_op ? {{31'd0}, _io_y_T_12} : _io_y_T_30; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_34 = 5'h8 == io_op ? {{31'd0}, _io_y_T_13} : _io_y_T_32; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_36 = 5'h9 == io_op ? {{31'd0}, _io_y_T_14} : _io_y_T_34; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_38 = 5'ha == io_op ? {{31'd0}, mulLow} : _io_y_T_36; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_40 = 5'hb == io_op ? {{31'd0}, mulHighSS} : _io_y_T_38; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_42 = 5'hc == io_op ? {{31'd0}, mulHighSU} : _io_y_T_40; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_44 = 5'hd == io_op ? {{31'd0}, mulHighUU} : _io_y_T_42; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_46 = 5'he == io_op ? {{31'd0}, _io_y_T_15} : _io_y_T_44; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_48 = 5'hf == io_op ? {{31'd0}, _io_y_T_16} : _io_y_T_46; // @[Mux.scala 81:58]
  wire [31:0] divResult = _GEN_1[31:0]; // @[ALU.scala 145:23]
  wire [62:0] _io_y_T_50 = 5'h10 == io_op ? {{31'd0}, divResult} : _io_y_T_48; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_52 = 5'h11 == io_op ? {{31'd0}, divuResult} : _io_y_T_50; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_54 = 5'h12 == io_op ? {{31'd0}, remResult} : _io_y_T_52; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_56 = 5'h13 == io_op ? {{31'd0}, remuResult} : _io_y_T_54; // @[Mux.scala 81:58]
  assign io_y = _io_y_T_56[31:0]; // @[ALU.scala 219:8]
endmodule
module PCUpdate(
  input         io_valid,
  input  [31:0] io_pc,
  input  [31:0] io_rs1,
  input  [31:0] io_rs2,
  input  [31:0] io_imm,
  input  [2:0]  io_funct3,
  input         io_branch,
  input         io_jump,
  input         io_jalr,
  output        io_redirect,
  output [31:0] io_redirectPC
);
  wire [31:0] pcRelativeTarget = io_pc + io_imm; // @[PCUpdate.scala 83:11]
  wire [31:0] _jalrTarget_T_1 = io_rs1 + io_imm; // @[PCUpdate.scala 97:13]
  wire [31:0] jalrTarget = _jalrTarget_T_1 & 32'hfffffffe; // @[PCUpdate.scala 97:23]
  wire  _branchCondition_T = io_rs1 == io_rs2; // @[PCUpdate.scala 128:16]
  wire  _branchCondition_T_1 = io_rs1 != io_rs2; // @[PCUpdate.scala 137:16]
  wire  _branchCondition_T_4 = $signed(io_rs1) < $signed(io_rs2); // @[PCUpdate.scala 146:23]
  wire  _branchCondition_T_7 = $signed(io_rs1) >= $signed(io_rs2); // @[PCUpdate.scala 155:23]
  wire  _branchCondition_T_8 = io_rs1 < io_rs2; // @[PCUpdate.scala 164:16]
  wire  _branchCondition_T_9 = io_rs1 >= io_rs2; // @[PCUpdate.scala 173:16]
  wire  _GEN_0 = 3'h7 == io_funct3 & _branchCondition_T_9; // @[PCUpdate.scala 118:16 120:21 172:23]
  wire  _GEN_1 = 3'h6 == io_funct3 ? _branchCondition_T_8 : _GEN_0; // @[PCUpdate.scala 120:21 163:23]
  wire  _GEN_2 = 3'h5 == io_funct3 ? _branchCondition_T_7 : _GEN_1; // @[PCUpdate.scala 120:21 154:23]
  wire  _GEN_3 = 3'h4 == io_funct3 ? _branchCondition_T_4 : _GEN_2; // @[PCUpdate.scala 120:21 145:23]
  wire  _GEN_4 = 3'h1 == io_funct3 ? _branchCondition_T_1 : _GEN_3; // @[PCUpdate.scala 120:21 136:23]
  wire  branchCondition = 3'h0 == io_funct3 ? _branchCondition_T : _GEN_4; // @[PCUpdate.scala 120:21 127:23]
  wire  _takeBranch_T = io_valid & io_branch; // @[PCUpdate.scala 185:14]
  wire  takeBranch = _takeBranch_T & branchCondition; // @[PCUpdate.scala 186:15]
  wire  takeJal = io_valid & io_jump; // @[PCUpdate.scala 194:14]
  wire  takeJalr = io_valid & io_jalr; // @[PCUpdate.scala 202:14]
  wire  _io_redirect_T = takeBranch | takeJal; // @[PCUpdate.scala 218:16]
  assign io_redirect = _io_redirect_T | takeJalr; // @[PCUpdate.scala 219:13]
  assign io_redirectPC = takeJalr ? jalrTarget : pcRelativeTarget; // @[PCUpdate.scala 227:8]
endmodule
module EXStage(
  input         io_valid,
  input  [31:0] io_pc,
  input  [4:0]  io_rd,
  input  [31:0] io_rs1Data,
  input  [31:0] io_rs2Data,
  input  [31:0] io_imm,
  input  [2:0]  io_funct3,
  input  [4:0]  io_aluOp,
  input  [1:0]  io_aluASel,
  input         io_aluSrc,
  input         io_regWrite,
  input         io_memRead,
  input         io_memWrite,
  input         io_memToReg,
  input         io_branch,
  input         io_jump,
  input         io_jalr,
  input  [1:0]  io_forwardA,
  input  [1:0]  io_forwardB,
  input  [31:0] io_exmemForwardData,
  input  [31:0] io_memwbForwardData,
  output [31:0] io_aluResult,
  output [31:0] io_storeData,
  output [4:0]  io_rdOut,
  output [2:0]  io_funct3Out,
  output [31:0] io_pcPlus4,
  output        io_regWriteOut,
  output        io_memReadOut,
  output        io_memWriteOut,
  output        io_memToRegOut,
  output        io_linkOut,
  output        io_redirect,
  output [31:0] io_redirectPC,
  output [31:0] io_debugALU
);
  wire [31:0] alu_io_a; // @[EXStage.scala 201:11]
  wire [31:0] alu_io_b; // @[EXStage.scala 201:11]
  wire [4:0] alu_io_op; // @[EXStage.scala 201:11]
  wire [31:0] alu_io_y; // @[EXStage.scala 201:11]
  wire  pcUpdate_io_valid; // @[EXStage.scala 204:11]
  wire [31:0] pcUpdate_io_pc; // @[EXStage.scala 204:11]
  wire [31:0] pcUpdate_io_rs1; // @[EXStage.scala 204:11]
  wire [31:0] pcUpdate_io_rs2; // @[EXStage.scala 204:11]
  wire [31:0] pcUpdate_io_imm; // @[EXStage.scala 204:11]
  wire [2:0] pcUpdate_io_funct3; // @[EXStage.scala 204:11]
  wire  pcUpdate_io_branch; // @[EXStage.scala 204:11]
  wire  pcUpdate_io_jump; // @[EXStage.scala 204:11]
  wire  pcUpdate_io_jalr; // @[EXStage.scala 204:11]
  wire  pcUpdate_io_redirect; // @[EXStage.scala 204:11]
  wire [31:0] pcUpdate_io_redirectPC; // @[EXStage.scala 204:11]
  wire [31:0] _forwardedA_T_1 = 2'h1 == io_forwardA ? io_memwbForwardData : io_rs1Data; // @[Mux.scala 81:58]
  wire [31:0] forwardedA = 2'h2 == io_forwardA ? io_exmemForwardData : _forwardedA_T_1; // @[Mux.scala 81:58]
  wire [31:0] _forwardedRs2_T_1 = 2'h1 == io_forwardB ? io_memwbForwardData : io_rs2Data; // @[Mux.scala 81:58]
  wire [31:0] forwardedRs2 = 2'h2 == io_forwardB ? io_exmemForwardData : _forwardedRs2_T_1; // @[Mux.scala 81:58]
  wire [31:0] _aluA_T_3 = 2'h1 == io_aluASel ? 32'h0 : forwardedA; // @[Mux.scala 81:58]
  wire  _io_linkOut_T = io_jump | io_jalr; // @[EXStage.scala 520:14]
  ALU alu ( // @[EXStage.scala 201:11]
    .io_a(alu_io_a),
    .io_b(alu_io_b),
    .io_op(alu_io_op),
    .io_y(alu_io_y)
  );
  PCUpdate pcUpdate ( // @[EXStage.scala 204:11]
    .io_valid(pcUpdate_io_valid),
    .io_pc(pcUpdate_io_pc),
    .io_rs1(pcUpdate_io_rs1),
    .io_rs2(pcUpdate_io_rs2),
    .io_imm(pcUpdate_io_imm),
    .io_funct3(pcUpdate_io_funct3),
    .io_branch(pcUpdate_io_branch),
    .io_jump(pcUpdate_io_jump),
    .io_jalr(pcUpdate_io_jalr),
    .io_redirect(pcUpdate_io_redirect),
    .io_redirectPC(pcUpdate_io_redirectPC)
  );
  assign io_aluResult = alu_io_y; // @[EXStage.scala 401:16]
  assign io_storeData = 2'h2 == io_forwardB ? io_exmemForwardData : _forwardedRs2_T_1; // @[Mux.scala 81:58]
  assign io_rdOut = io_rd; // @[EXStage.scala 432:12]
  assign io_funct3Out = io_funct3; // @[EXStage.scala 450:16]
  assign io_pcPlus4 = io_pc + 32'h4; // @[EXStage.scala 465:11]
  assign io_regWriteOut = io_regWrite & io_valid; // @[EXStage.scala 483:17]
  assign io_memReadOut = io_memRead & io_valid; // @[EXStage.scala 487:16]
  assign io_memWriteOut = io_memWrite & io_valid; // @[EXStage.scala 491:17]
  assign io_memToRegOut = io_memToReg; // @[EXStage.scala 494:18]
  assign io_linkOut = io_valid & _io_linkOut_T; // @[EXStage.scala 519:14]
  assign io_redirect = pcUpdate_io_redirect; // @[EXStage.scala 387:15]
  assign io_redirectPC = pcUpdate_io_redirectPC; // @[EXStage.scala 390:17]
  assign io_debugALU = alu_io_y; // @[EXStage.scala 527:15]
  assign alu_io_a = 2'h2 == io_aluASel ? io_pc : _aluA_T_3; // @[Mux.scala 81:58]
  assign alu_io_b = io_aluSrc ? io_imm : forwardedRs2; // @[EXStage.scala 314:8]
  assign alu_io_op = io_aluOp; // @[EXStage.scala 331:13]
  assign pcUpdate_io_valid = io_valid; // @[EXStage.scala 355:21]
  assign pcUpdate_io_pc = io_pc; // @[EXStage.scala 358:18]
  assign pcUpdate_io_rs1 = 2'h2 == io_forwardA ? io_exmemForwardData : _forwardedA_T_1; // @[Mux.scala 81:58]
  assign pcUpdate_io_rs2 = 2'h2 == io_forwardB ? io_exmemForwardData : _forwardedRs2_T_1; // @[Mux.scala 81:58]
  assign pcUpdate_io_imm = io_imm; // @[EXStage.scala 367:19]
  assign pcUpdate_io_funct3 = io_funct3; // @[EXStage.scala 370:22]
  assign pcUpdate_io_branch = io_branch; // @[EXStage.scala 373:22]
  assign pcUpdate_io_jump = io_jump; // @[EXStage.scala 376:20]
  assign pcUpdate_io_jalr = io_jalr; // @[EXStage.scala 379:20]
endmodule
module MEMStage(
  input         io_valid,
  input  [31:0] io_aluResult,
  input  [31:0] io_storeData,
  input  [4:0]  io_rd,
  input  [2:0]  io_funct3,
  input  [31:0] io_pcPlus4,
  input         io_regWrite,
  input         io_memRead,
  input         io_memWrite,
  input         io_memToReg,
  input         io_link,
  output [31:0] io_memAddr,
  output [31:0] io_memWdata,
  output        io_memReadOut,
  output        io_memWriteOut,
  output [2:0]  io_memFunct3,
  input  [31:0] io_memRdata,
  output [31:0] io_memDataOut,
  output [31:0] io_aluResultOut,
  output [31:0] io_pcPlus4Out,
  output [4:0]  io_rdOut,
  output        io_regWriteOut,
  output        io_memToRegOut,
  output        io_linkOut
);
  assign io_memAddr = io_aluResult; // @[MEMStage.scala 98:14]
  assign io_memWdata = io_storeData; // @[MEMStage.scala 101:15]
  assign io_memReadOut = io_memRead & io_valid; // @[MEMStage.scala 108:16]
  assign io_memWriteOut = io_memWrite & io_valid; // @[MEMStage.scala 111:17]
  assign io_memFunct3 = io_funct3; // @[MEMStage.scala 104:16]
  assign io_memDataOut = io_memRdata; // @[MEMStage.scala 117:17]
  assign io_aluResultOut = io_aluResult; // @[MEMStage.scala 120:19]
  assign io_pcPlus4Out = io_pcPlus4; // @[MEMStage.scala 123:17]
  assign io_rdOut = io_rd; // @[MEMStage.scala 126:12]
  assign io_regWriteOut = io_regWrite & io_valid; // @[MEMStage.scala 130:17]
  assign io_memToRegOut = io_memToReg; // @[MEMStage.scala 132:18]
  assign io_linkOut = io_link; // @[MEMStage.scala 135:14]
endmodule
module WBStage(
  input         io_valid,
  input  [31:0] io_aluResult,
  input  [31:0] io_memData,
  input  [31:0] io_pcPlus4,
  input  [4:0]  io_rd,
  input         io_regWrite,
  input         io_memToReg,
  input         io_link,
  output [4:0]  io_writeRd,
  output [31:0] io_writeData,
  output        io_writeEnable
);
  wire [31:0] _wbData_T = io_memToReg ? io_memData : io_aluResult; // @[WBStage.scala 59:10]
  wire  _io_writeEnable_T = io_valid & io_regWrite; // @[WBStage.scala 73:14]
  wire  _io_writeEnable_T_1 = io_rd != 5'h0; // @[WBStage.scala 75:12]
  assign io_writeRd = io_rd; // @[WBStage.scala 66:14]
  assign io_writeData = io_link ? io_pcPlus4 : _wbData_T; // @[WBStage.scala 56:8]
  assign io_writeEnable = _io_writeEnable_T & _io_writeEnable_T_1; // @[WBStage.scala 74:17]
endmodule
module ForwardingUnit(
  input  [4:0] io_idexRs1,
  input  [4:0] io_idexRs2,
  input  [4:0] io_exmemRd,
  input        io_exmemRegWrite,
  input        io_exmemValid,
  input  [4:0] io_memwbRd,
  input        io_memwbRegWrite,
  input        io_memwbValid,
  output [1:0] io_forwardA,
  output [1:0] io_forwardB
);
  wire  _T = io_exmemValid & io_exmemRegWrite; // @[ForwardingUnit.scala 43:19]
  wire  _T_1 = io_exmemRd != 5'h0; // @[ForwardingUnit.scala 45:17]
  wire  _T_2 = _T & _T_1; // @[ForwardingUnit.scala 44:22]
  wire  _T_3 = io_exmemRd == io_idexRs1; // @[ForwardingUnit.scala 46:17]
  wire  _T_4 = _T_2 & _T_3; // @[ForwardingUnit.scala 45:26]
  wire  _T_5 = io_memwbValid & io_memwbRegWrite; // @[ForwardingUnit.scala 53:19]
  wire  _T_6 = io_memwbRd != 5'h0; // @[ForwardingUnit.scala 55:17]
  wire  _T_7 = _T_5 & _T_6; // @[ForwardingUnit.scala 54:22]
  wire  _T_8 = io_memwbRd == io_idexRs1; // @[ForwardingUnit.scala 56:17]
  wire  _T_9 = _T_7 & _T_8; // @[ForwardingUnit.scala 55:26]
  wire  _T_13 = io_exmemRd == io_idexRs2; // @[ForwardingUnit.scala 70:17]
  wire  _T_14 = _T_2 & _T_13; // @[ForwardingUnit.scala 69:26]
  wire  _T_18 = io_memwbRd == io_idexRs2; // @[ForwardingUnit.scala 79:17]
  wire  _T_19 = _T_7 & _T_18; // @[ForwardingUnit.scala 78:26]
  assign io_forwardA = _T_4 ? 2'h2 : {{1'd0}, _T_9}; // @[ForwardingUnit.scala 47:5 50:17]
  assign io_forwardB = _T_14 ? 2'h2 : {{1'd0}, _T_19}; // @[ForwardingUnit.scala 71:5 73:17]
endmodule
module HazardDetectionUnit(
  input  [4:0] io_ifidRs1,
  input  [4:0] io_ifidRs2,
  input        io_ifidUsesRs1,
  input        io_ifidUsesRs2,
  input  [4:0] io_idexRd,
  input        io_idexMemRead,
  input        io_idexValid,
  output       io_stallPC,
  output       io_stallIFID,
  output       io_bubbleIDEX
);
  wire  _rs1Hazard_T = io_idexRd == io_ifidRs1; // @[HazardDetectionUnit.scala 49:16]
  wire  rs1Hazard = io_ifidUsesRs1 & _rs1Hazard_T; // @[HazardDetectionUnit.scala 48:20]
  wire  _rs2Hazard_T = io_idexRd == io_ifidRs2; // @[HazardDetectionUnit.scala 53:16]
  wire  rs2Hazard = io_ifidUsesRs2 & _rs2Hazard_T; // @[HazardDetectionUnit.scala 52:20]
  wire  _loadUseHazard_T = io_idexValid & io_idexMemRead; // @[HazardDetectionUnit.scala 56:18]
  wire  _loadUseHazard_T_1 = io_idexRd != 5'h0; // @[HazardDetectionUnit.scala 58:16]
  wire  _loadUseHazard_T_2 = _loadUseHazard_T & _loadUseHazard_T_1; // @[HazardDetectionUnit.scala 57:20]
  wire  _loadUseHazard_T_3 = rs1Hazard | rs2Hazard; // @[HazardDetectionUnit.scala 59:16]
  assign io_stallPC = _loadUseHazard_T_2 & _loadUseHazard_T_3; // @[HazardDetectionUnit.scala 58:25]
  assign io_stallIFID = _loadUseHazard_T_2 & _loadUseHazard_T_3; // @[HazardDetectionUnit.scala 58:25]
  assign io_bubbleIDEX = _loadUseHazard_T_2 & _loadUseHazard_T_3; // @[HazardDetectionUnit.scala 58:25]
endmodule
module RV32ICore(
  input         clock,
  input         reset,
  output [31:0] io_pc,
  output [31:0] io_nextPc,
  output [31:0] io_writeBack,
  output [31:0] io_debugInstr,
  output [31:0] io_debugALU,
  output [31:0] io_debugImm,
  output [31:0] io_debugX1,
  output [31:0] io_debugX2,
  output [31:0] io_debugX3,
  output [31:0] io_debugX4,
  output [31:0] io_debugX5,
  output [31:0] io_debugX6,
  output [31:0] io_debugFetchPC,
  output [31:0] io_debugDecodePC,
  output [31:0] io_debugExecPC,
  output [31:0] io_debugMemPC,
  output [31:0] io_debugWBPC,
  output        io_debugValid,
  output        io_debugFlush,
  output        io_debugStall,
  output        io_debugIFIDValid,
  output        io_debugIDEXValid,
  output        io_debugEXMEMValid,
  output        io_debugMEMWBValid
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
  reg [31:0] _RAND_32;
  reg [31:0] _RAND_33;
  reg [31:0] _RAND_34;
  reg [31:0] _RAND_35;
  reg [31:0] _RAND_36;
  reg [31:0] _RAND_37;
  reg [31:0] _RAND_38;
  reg [31:0] _RAND_39;
  reg [31:0] _RAND_40;
  reg [31:0] _RAND_41;
  reg [31:0] _RAND_42;
  reg [31:0] _RAND_43;
  reg [31:0] _RAND_44;
`endif // RANDOMIZE_REG_INIT
  wire  imem_clock; // @[RV32ICore.scala 20:20]
  wire [31:0] imem_io_addr; // @[RV32ICore.scala 20:20]
  wire [31:0] imem_io_instr; // @[RV32ICore.scala 20:20]
  wire  dmem_clock; // @[RV32ICore.scala 21:20]
  wire [31:0] dmem_io_addr; // @[RV32ICore.scala 21:20]
  wire [31:0] dmem_io_wdata; // @[RV32ICore.scala 21:20]
  wire [31:0] dmem_io_rdata; // @[RV32ICore.scala 21:20]
  wire  dmem_io_memRead; // @[RV32ICore.scala 21:20]
  wire  dmem_io_memWrite; // @[RV32ICore.scala 21:20]
  wire [2:0] dmem_io_funct3; // @[RV32ICore.scala 21:20]
  wire  id_clock; // @[RV32ICore.scala 22:20]
  wire  id_reset; // @[RV32ICore.scala 22:20]
  wire  id_io_valid; // @[RV32ICore.scala 22:20]
  wire [31:0] id_io_instr; // @[RV32ICore.scala 22:20]
  wire [4:0] id_io_wbRd; // @[RV32ICore.scala 22:20]
  wire [31:0] id_io_wbWriteData; // @[RV32ICore.scala 22:20]
  wire  id_io_wbWriteEnable; // @[RV32ICore.scala 22:20]
  wire [4:0] id_io_rs1; // @[RV32ICore.scala 22:20]
  wire [4:0] id_io_rs2; // @[RV32ICore.scala 22:20]
  wire [4:0] id_io_rd; // @[RV32ICore.scala 22:20]
  wire [31:0] id_io_rs1Data; // @[RV32ICore.scala 22:20]
  wire [31:0] id_io_rs2Data; // @[RV32ICore.scala 22:20]
  wire [31:0] id_io_imm; // @[RV32ICore.scala 22:20]
  wire [2:0] id_io_funct3; // @[RV32ICore.scala 22:20]
  wire [4:0] id_io_aluOp; // @[RV32ICore.scala 22:20]
  wire [1:0] id_io_aluASel; // @[RV32ICore.scala 22:20]
  wire  id_io_aluSrc; // @[RV32ICore.scala 22:20]
  wire  id_io_regWrite; // @[RV32ICore.scala 22:20]
  wire  id_io_memRead; // @[RV32ICore.scala 22:20]
  wire  id_io_memWrite; // @[RV32ICore.scala 22:20]
  wire  id_io_memToReg; // @[RV32ICore.scala 22:20]
  wire  id_io_branch; // @[RV32ICore.scala 22:20]
  wire  id_io_jump; // @[RV32ICore.scala 22:20]
  wire  id_io_jalr; // @[RV32ICore.scala 22:20]
  wire  id_io_usesRs1; // @[RV32ICore.scala 22:20]
  wire  id_io_usesRs2; // @[RV32ICore.scala 22:20]
  wire [31:0] id_io_debugX1; // @[RV32ICore.scala 22:20]
  wire [31:0] id_io_debugX2; // @[RV32ICore.scala 22:20]
  wire [31:0] id_io_debugX3; // @[RV32ICore.scala 22:20]
  wire [31:0] id_io_debugX4; // @[RV32ICore.scala 22:20]
  wire [31:0] id_io_debugX5; // @[RV32ICore.scala 22:20]
  wire [31:0] id_io_debugX6; // @[RV32ICore.scala 22:20]
  wire  ex_io_valid; // @[RV32ICore.scala 23:20]
  wire [31:0] ex_io_pc; // @[RV32ICore.scala 23:20]
  wire [4:0] ex_io_rd; // @[RV32ICore.scala 23:20]
  wire [31:0] ex_io_rs1Data; // @[RV32ICore.scala 23:20]
  wire [31:0] ex_io_rs2Data; // @[RV32ICore.scala 23:20]
  wire [31:0] ex_io_imm; // @[RV32ICore.scala 23:20]
  wire [2:0] ex_io_funct3; // @[RV32ICore.scala 23:20]
  wire [4:0] ex_io_aluOp; // @[RV32ICore.scala 23:20]
  wire [1:0] ex_io_aluASel; // @[RV32ICore.scala 23:20]
  wire  ex_io_aluSrc; // @[RV32ICore.scala 23:20]
  wire  ex_io_regWrite; // @[RV32ICore.scala 23:20]
  wire  ex_io_memRead; // @[RV32ICore.scala 23:20]
  wire  ex_io_memWrite; // @[RV32ICore.scala 23:20]
  wire  ex_io_memToReg; // @[RV32ICore.scala 23:20]
  wire  ex_io_branch; // @[RV32ICore.scala 23:20]
  wire  ex_io_jump; // @[RV32ICore.scala 23:20]
  wire  ex_io_jalr; // @[RV32ICore.scala 23:20]
  wire [1:0] ex_io_forwardA; // @[RV32ICore.scala 23:20]
  wire [1:0] ex_io_forwardB; // @[RV32ICore.scala 23:20]
  wire [31:0] ex_io_exmemForwardData; // @[RV32ICore.scala 23:20]
  wire [31:0] ex_io_memwbForwardData; // @[RV32ICore.scala 23:20]
  wire [31:0] ex_io_aluResult; // @[RV32ICore.scala 23:20]
  wire [31:0] ex_io_storeData; // @[RV32ICore.scala 23:20]
  wire [4:0] ex_io_rdOut; // @[RV32ICore.scala 23:20]
  wire [2:0] ex_io_funct3Out; // @[RV32ICore.scala 23:20]
  wire [31:0] ex_io_pcPlus4; // @[RV32ICore.scala 23:20]
  wire  ex_io_regWriteOut; // @[RV32ICore.scala 23:20]
  wire  ex_io_memReadOut; // @[RV32ICore.scala 23:20]
  wire  ex_io_memWriteOut; // @[RV32ICore.scala 23:20]
  wire  ex_io_memToRegOut; // @[RV32ICore.scala 23:20]
  wire  ex_io_linkOut; // @[RV32ICore.scala 23:20]
  wire  ex_io_redirect; // @[RV32ICore.scala 23:20]
  wire [31:0] ex_io_redirectPC; // @[RV32ICore.scala 23:20]
  wire [31:0] ex_io_debugALU; // @[RV32ICore.scala 23:20]
  wire  mem_io_valid; // @[RV32ICore.scala 24:20]
  wire [31:0] mem_io_aluResult; // @[RV32ICore.scala 24:20]
  wire [31:0] mem_io_storeData; // @[RV32ICore.scala 24:20]
  wire [4:0] mem_io_rd; // @[RV32ICore.scala 24:20]
  wire [2:0] mem_io_funct3; // @[RV32ICore.scala 24:20]
  wire [31:0] mem_io_pcPlus4; // @[RV32ICore.scala 24:20]
  wire  mem_io_regWrite; // @[RV32ICore.scala 24:20]
  wire  mem_io_memRead; // @[RV32ICore.scala 24:20]
  wire  mem_io_memWrite; // @[RV32ICore.scala 24:20]
  wire  mem_io_memToReg; // @[RV32ICore.scala 24:20]
  wire  mem_io_link; // @[RV32ICore.scala 24:20]
  wire [31:0] mem_io_memAddr; // @[RV32ICore.scala 24:20]
  wire [31:0] mem_io_memWdata; // @[RV32ICore.scala 24:20]
  wire  mem_io_memReadOut; // @[RV32ICore.scala 24:20]
  wire  mem_io_memWriteOut; // @[RV32ICore.scala 24:20]
  wire [2:0] mem_io_memFunct3; // @[RV32ICore.scala 24:20]
  wire [31:0] mem_io_memRdata; // @[RV32ICore.scala 24:20]
  wire [31:0] mem_io_memDataOut; // @[RV32ICore.scala 24:20]
  wire [31:0] mem_io_aluResultOut; // @[RV32ICore.scala 24:20]
  wire [31:0] mem_io_pcPlus4Out; // @[RV32ICore.scala 24:20]
  wire [4:0] mem_io_rdOut; // @[RV32ICore.scala 24:20]
  wire  mem_io_regWriteOut; // @[RV32ICore.scala 24:20]
  wire  mem_io_memToRegOut; // @[RV32ICore.scala 24:20]
  wire  mem_io_linkOut; // @[RV32ICore.scala 24:20]
  wire  wb_io_valid; // @[RV32ICore.scala 25:20]
  wire [31:0] wb_io_aluResult; // @[RV32ICore.scala 25:20]
  wire [31:0] wb_io_memData; // @[RV32ICore.scala 25:20]
  wire [31:0] wb_io_pcPlus4; // @[RV32ICore.scala 25:20]
  wire [4:0] wb_io_rd; // @[RV32ICore.scala 25:20]
  wire  wb_io_regWrite; // @[RV32ICore.scala 25:20]
  wire  wb_io_memToReg; // @[RV32ICore.scala 25:20]
  wire  wb_io_link; // @[RV32ICore.scala 25:20]
  wire [4:0] wb_io_writeRd; // @[RV32ICore.scala 25:20]
  wire [31:0] wb_io_writeData; // @[RV32ICore.scala 25:20]
  wire  wb_io_writeEnable; // @[RV32ICore.scala 25:20]
  wire [4:0] fwd_io_idexRs1; // @[RV32ICore.scala 26:20]
  wire [4:0] fwd_io_idexRs2; // @[RV32ICore.scala 26:20]
  wire [4:0] fwd_io_exmemRd; // @[RV32ICore.scala 26:20]
  wire  fwd_io_exmemRegWrite; // @[RV32ICore.scala 26:20]
  wire  fwd_io_exmemValid; // @[RV32ICore.scala 26:20]
  wire [4:0] fwd_io_memwbRd; // @[RV32ICore.scala 26:20]
  wire  fwd_io_memwbRegWrite; // @[RV32ICore.scala 26:20]
  wire  fwd_io_memwbValid; // @[RV32ICore.scala 26:20]
  wire [1:0] fwd_io_forwardA; // @[RV32ICore.scala 26:20]
  wire [1:0] fwd_io_forwardB; // @[RV32ICore.scala 26:20]
  wire [4:0] haz_io_ifidRs1; // @[RV32ICore.scala 27:20]
  wire [4:0] haz_io_ifidRs2; // @[RV32ICore.scala 27:20]
  wire  haz_io_ifidUsesRs1; // @[RV32ICore.scala 27:20]
  wire  haz_io_ifidUsesRs2; // @[RV32ICore.scala 27:20]
  wire [4:0] haz_io_idexRd; // @[RV32ICore.scala 27:20]
  wire  haz_io_idexMemRead; // @[RV32ICore.scala 27:20]
  wire  haz_io_idexValid; // @[RV32ICore.scala 27:20]
  wire  haz_io_stallPC; // @[RV32ICore.scala 27:20]
  wire  haz_io_stallIFID; // @[RV32ICore.scala 27:20]
  wire  haz_io_bubbleIDEX; // @[RV32ICore.scala 27:20]
  reg [31:0] pc; // @[RV32ICore.scala 29:19]
  reg  ifidValid; // @[RV32ICore.scala 32:26]
  reg [31:0] ifidPC; // @[RV32ICore.scala 33:26]
  reg [31:0] ifidInstr; // @[RV32ICore.scala 34:26]
  reg  idexValid; // @[RV32ICore.scala 37:26]
  reg [31:0] idexPC; // @[RV32ICore.scala 38:23]
  reg [31:0] idexInstr; // @[RV32ICore.scala 39:26]
  reg [4:0] idexRs1; // @[RV32ICore.scala 40:41]
  reg [4:0] idexRs2; // @[RV32ICore.scala 40:41]
  reg [4:0] idexRd; // @[RV32ICore.scala 40:41]
  reg [31:0] idexRs1Data; // @[RV32ICore.scala 41:50]
  reg [31:0] idexRs2Data; // @[RV32ICore.scala 41:50]
  reg [31:0] idexImm; // @[RV32ICore.scala 41:50]
  reg [2:0] idexFunct3; // @[RV32ICore.scala 42:27]
  reg [4:0] idexAluOp; // @[RV32ICore.scala 43:26]
  reg [1:0] idexAluASel; // @[RV32ICore.scala 44:28]
  reg  idexAluSrc; // @[RV32ICore.scala 46:61]
  reg  idexRegWrite; // @[RV32ICore.scala 46:61]
  reg  idexMemRead; // @[RV32ICore.scala 46:61]
  reg  idexMemWrite; // @[RV32ICore.scala 46:61]
  reg  idexMemToReg; // @[RV32ICore.scala 46:61]
  reg  idexBranch; // @[RV32ICore.scala 46:61]
  reg  idexJump; // @[RV32ICore.scala 46:61]
  reg  idexJalr; // @[RV32ICore.scala 46:61]
  reg  exmemValid; // @[RV32ICore.scala 49:27]
  reg [31:0] exmemPC; // @[RV32ICore.scala 51:12]
  reg [31:0] exmemAluResult; // @[RV32ICore.scala 51:12]
  reg [31:0] exmemStoreData; // @[RV32ICore.scala 51:12]
  reg [31:0] exmemPCPlus4; // @[RV32ICore.scala 51:12]
  reg [4:0] exmemRd; // @[RV32ICore.scala 52:24]
  reg [2:0] exmemFunct3; // @[RV32ICore.scala 53:28]
  reg  exmemRegWrite; // @[RV32ICore.scala 55:41]
  reg  exmemMemRead; // @[RV32ICore.scala 55:41]
  reg  exmemMemWrite; // @[RV32ICore.scala 55:41]
  reg  exmemMemToReg; // @[RV32ICore.scala 55:41]
  reg  exmemLink; // @[RV32ICore.scala 55:41]
  reg  memwbValid; // @[RV32ICore.scala 58:27]
  reg [31:0] memwbPC; // @[RV32ICore.scala 60:12]
  reg [31:0] memwbAluResult; // @[RV32ICore.scala 60:12]
  reg [31:0] memwbMemData; // @[RV32ICore.scala 60:12]
  reg [31:0] memwbPCPlus4; // @[RV32ICore.scala 60:12]
  reg [4:0] memwbRd; // @[RV32ICore.scala 61:24]
  reg  memwbRegWrite; // @[RV32ICore.scala 62:56]
  reg  memwbMemToReg; // @[RV32ICore.scala 62:56]
  reg  memwbLink; // @[RV32ICore.scala 62:56]
  wire [31:0] _nextPC_T_1 = pc + 32'h4; // @[RV32ICore.scala 160:60]
  wire [31:0] _nextPC_T_2 = haz_io_stallPC ? pc : _nextPC_T_1; // @[RV32ICore.scala 160:45]
  wire  _GEN_2 = ~haz_io_stallIFID | ifidValid; // @[RV32ICore.scala 172:33 173:15 32:26]
  InstructionMemory imem ( // @[RV32ICore.scala 20:20]
    .clock(imem_clock),
    .io_addr(imem_io_addr),
    .io_instr(imem_io_instr)
  );
  DataMemory dmem ( // @[RV32ICore.scala 21:20]
    .clock(dmem_clock),
    .io_addr(dmem_io_addr),
    .io_wdata(dmem_io_wdata),
    .io_rdata(dmem_io_rdata),
    .io_memRead(dmem_io_memRead),
    .io_memWrite(dmem_io_memWrite),
    .io_funct3(dmem_io_funct3)
  );
  IDStage id ( // @[RV32ICore.scala 22:20]
    .clock(id_clock),
    .reset(id_reset),
    .io_valid(id_io_valid),
    .io_instr(id_io_instr),
    .io_wbRd(id_io_wbRd),
    .io_wbWriteData(id_io_wbWriteData),
    .io_wbWriteEnable(id_io_wbWriteEnable),
    .io_rs1(id_io_rs1),
    .io_rs2(id_io_rs2),
    .io_rd(id_io_rd),
    .io_rs1Data(id_io_rs1Data),
    .io_rs2Data(id_io_rs2Data),
    .io_imm(id_io_imm),
    .io_funct3(id_io_funct3),
    .io_aluOp(id_io_aluOp),
    .io_aluASel(id_io_aluASel),
    .io_aluSrc(id_io_aluSrc),
    .io_regWrite(id_io_regWrite),
    .io_memRead(id_io_memRead),
    .io_memWrite(id_io_memWrite),
    .io_memToReg(id_io_memToReg),
    .io_branch(id_io_branch),
    .io_jump(id_io_jump),
    .io_jalr(id_io_jalr),
    .io_usesRs1(id_io_usesRs1),
    .io_usesRs2(id_io_usesRs2),
    .io_debugX1(id_io_debugX1),
    .io_debugX2(id_io_debugX2),
    .io_debugX3(id_io_debugX3),
    .io_debugX4(id_io_debugX4),
    .io_debugX5(id_io_debugX5),
    .io_debugX6(id_io_debugX6)
  );
  EXStage ex ( // @[RV32ICore.scala 23:20]
    .io_valid(ex_io_valid),
    .io_pc(ex_io_pc),
    .io_rd(ex_io_rd),
    .io_rs1Data(ex_io_rs1Data),
    .io_rs2Data(ex_io_rs2Data),
    .io_imm(ex_io_imm),
    .io_funct3(ex_io_funct3),
    .io_aluOp(ex_io_aluOp),
    .io_aluASel(ex_io_aluASel),
    .io_aluSrc(ex_io_aluSrc),
    .io_regWrite(ex_io_regWrite),
    .io_memRead(ex_io_memRead),
    .io_memWrite(ex_io_memWrite),
    .io_memToReg(ex_io_memToReg),
    .io_branch(ex_io_branch),
    .io_jump(ex_io_jump),
    .io_jalr(ex_io_jalr),
    .io_forwardA(ex_io_forwardA),
    .io_forwardB(ex_io_forwardB),
    .io_exmemForwardData(ex_io_exmemForwardData),
    .io_memwbForwardData(ex_io_memwbForwardData),
    .io_aluResult(ex_io_aluResult),
    .io_storeData(ex_io_storeData),
    .io_rdOut(ex_io_rdOut),
    .io_funct3Out(ex_io_funct3Out),
    .io_pcPlus4(ex_io_pcPlus4),
    .io_regWriteOut(ex_io_regWriteOut),
    .io_memReadOut(ex_io_memReadOut),
    .io_memWriteOut(ex_io_memWriteOut),
    .io_memToRegOut(ex_io_memToRegOut),
    .io_linkOut(ex_io_linkOut),
    .io_redirect(ex_io_redirect),
    .io_redirectPC(ex_io_redirectPC),
    .io_debugALU(ex_io_debugALU)
  );
  MEMStage mem ( // @[RV32ICore.scala 24:20]
    .io_valid(mem_io_valid),
    .io_aluResult(mem_io_aluResult),
    .io_storeData(mem_io_storeData),
    .io_rd(mem_io_rd),
    .io_funct3(mem_io_funct3),
    .io_pcPlus4(mem_io_pcPlus4),
    .io_regWrite(mem_io_regWrite),
    .io_memRead(mem_io_memRead),
    .io_memWrite(mem_io_memWrite),
    .io_memToReg(mem_io_memToReg),
    .io_link(mem_io_link),
    .io_memAddr(mem_io_memAddr),
    .io_memWdata(mem_io_memWdata),
    .io_memReadOut(mem_io_memReadOut),
    .io_memWriteOut(mem_io_memWriteOut),
    .io_memFunct3(mem_io_memFunct3),
    .io_memRdata(mem_io_memRdata),
    .io_memDataOut(mem_io_memDataOut),
    .io_aluResultOut(mem_io_aluResultOut),
    .io_pcPlus4Out(mem_io_pcPlus4Out),
    .io_rdOut(mem_io_rdOut),
    .io_regWriteOut(mem_io_regWriteOut),
    .io_memToRegOut(mem_io_memToRegOut),
    .io_linkOut(mem_io_linkOut)
  );
  WBStage wb ( // @[RV32ICore.scala 25:20]
    .io_valid(wb_io_valid),
    .io_aluResult(wb_io_aluResult),
    .io_memData(wb_io_memData),
    .io_pcPlus4(wb_io_pcPlus4),
    .io_rd(wb_io_rd),
    .io_regWrite(wb_io_regWrite),
    .io_memToReg(wb_io_memToReg),
    .io_link(wb_io_link),
    .io_writeRd(wb_io_writeRd),
    .io_writeData(wb_io_writeData),
    .io_writeEnable(wb_io_writeEnable)
  );
  ForwardingUnit fwd ( // @[RV32ICore.scala 26:20]
    .io_idexRs1(fwd_io_idexRs1),
    .io_idexRs2(fwd_io_idexRs2),
    .io_exmemRd(fwd_io_exmemRd),
    .io_exmemRegWrite(fwd_io_exmemRegWrite),
    .io_exmemValid(fwd_io_exmemValid),
    .io_memwbRd(fwd_io_memwbRd),
    .io_memwbRegWrite(fwd_io_memwbRegWrite),
    .io_memwbValid(fwd_io_memwbValid),
    .io_forwardA(fwd_io_forwardA),
    .io_forwardB(fwd_io_forwardB)
  );
  HazardDetectionUnit haz ( // @[RV32ICore.scala 27:20]
    .io_ifidRs1(haz_io_ifidRs1),
    .io_ifidRs2(haz_io_ifidRs2),
    .io_ifidUsesRs1(haz_io_ifidUsesRs1),
    .io_ifidUsesRs2(haz_io_ifidUsesRs2),
    .io_idexRd(haz_io_idexRd),
    .io_idexMemRead(haz_io_idexMemRead),
    .io_idexValid(haz_io_idexValid),
    .io_stallPC(haz_io_stallPC),
    .io_stallIFID(haz_io_stallIFID),
    .io_bubbleIDEX(haz_io_bubbleIDEX)
  );
  assign io_pc = pc; // @[RV32ICore.scala 249:9]
  assign io_nextPc = ex_io_redirect ? ex_io_redirectPC : _nextPC_T_2; // @[RV32ICore.scala 160:19]
  assign io_writeBack = wb_io_writeData; // @[RV32ICore.scala 251:16]
  assign io_debugInstr = idexInstr; // @[RV32ICore.scala 252:17]
  assign io_debugALU = ex_io_debugALU; // @[RV32ICore.scala 253:15]
  assign io_debugImm = idexImm; // @[RV32ICore.scala 254:15]
  assign io_debugX1 = id_io_debugX1; // @[RV32ICore.scala 256:14]
  assign io_debugX2 = id_io_debugX2; // @[RV32ICore.scala 257:14]
  assign io_debugX3 = id_io_debugX3; // @[RV32ICore.scala 258:14]
  assign io_debugX4 = id_io_debugX4; // @[RV32ICore.scala 259:14]
  assign io_debugX5 = id_io_debugX5; // @[RV32ICore.scala 260:14]
  assign io_debugX6 = id_io_debugX6; // @[RV32ICore.scala 261:14]
  assign io_debugFetchPC = pc; // @[RV32ICore.scala 264:19]
  assign io_debugDecodePC = ifidPC; // @[RV32ICore.scala 265:20]
  assign io_debugExecPC = idexPC; // @[RV32ICore.scala 266:18]
  assign io_debugMemPC = exmemPC; // @[RV32ICore.scala 267:17]
  assign io_debugWBPC = memwbPC; // @[RV32ICore.scala 268:16]
  assign io_debugValid = idexValid; // @[RV32ICore.scala 275:17]
  assign io_debugFlush = ex_io_redirect; // @[RV32ICore.scala 276:17]
  assign io_debugStall = haz_io_stallPC; // @[RV32ICore.scala 277:17]
  assign io_debugIFIDValid = ifidValid; // @[RV32ICore.scala 270:21]
  assign io_debugIDEXValid = idexValid; // @[RV32ICore.scala 271:21]
  assign io_debugEXMEMValid = exmemValid; // @[RV32ICore.scala 272:22]
  assign io_debugMEMWBValid = memwbValid; // @[RV32ICore.scala 273:22]
  assign imem_clock = clock;
  assign imem_io_addr = pc; // @[RV32ICore.scala 75:16]
  assign dmem_clock = clock;
  assign dmem_io_addr = mem_io_memAddr; // @[RV32ICore.scala 152:16]
  assign dmem_io_wdata = mem_io_memWdata; // @[RV32ICore.scala 153:17]
  assign dmem_io_memRead = mem_io_memReadOut; // @[RV32ICore.scala 154:19]
  assign dmem_io_memWrite = mem_io_memWriteOut; // @[RV32ICore.scala 155:20]
  assign dmem_io_funct3 = mem_io_memFunct3; // @[RV32ICore.scala 156:18]
  assign id_clock = clock;
  assign id_reset = reset;
  assign id_io_valid = ifidValid; // @[RV32ICore.scala 79:15]
  assign id_io_instr = ifidInstr; // @[RV32ICore.scala 81:15]
  assign id_io_wbRd = wb_io_writeRd; // @[RV32ICore.scala 82:14]
  assign id_io_wbWriteData = wb_io_writeData; // @[RV32ICore.scala 83:21]
  assign id_io_wbWriteEnable = wb_io_writeEnable; // @[RV32ICore.scala 84:23]
  assign ex_io_valid = idexValid; // @[RV32ICore.scala 111:15]
  assign ex_io_pc = idexPC; // @[RV32ICore.scala 112:12]
  assign ex_io_rd = idexRd; // @[RV32ICore.scala 115:12]
  assign ex_io_rs1Data = idexRs1Data; // @[RV32ICore.scala 116:17]
  assign ex_io_rs2Data = idexRs2Data; // @[RV32ICore.scala 117:17]
  assign ex_io_imm = idexImm; // @[RV32ICore.scala 118:13]
  assign ex_io_funct3 = idexFunct3; // @[RV32ICore.scala 119:16]
  assign ex_io_aluOp = idexAluOp; // @[RV32ICore.scala 120:15]
  assign ex_io_aluASel = idexAluASel; // @[RV32ICore.scala 121:17]
  assign ex_io_aluSrc = idexAluSrc; // @[RV32ICore.scala 122:16]
  assign ex_io_regWrite = idexRegWrite; // @[RV32ICore.scala 123:18]
  assign ex_io_memRead = idexMemRead; // @[RV32ICore.scala 124:17]
  assign ex_io_memWrite = idexMemWrite; // @[RV32ICore.scala 125:18]
  assign ex_io_memToReg = idexMemToReg; // @[RV32ICore.scala 126:18]
  assign ex_io_branch = idexBranch; // @[RV32ICore.scala 127:16]
  assign ex_io_jump = idexJump; // @[RV32ICore.scala 128:14]
  assign ex_io_jalr = idexJalr; // @[RV32ICore.scala 129:14]
  assign ex_io_forwardA = fwd_io_forwardA; // @[RV32ICore.scala 130:18]
  assign ex_io_forwardB = fwd_io_forwardB; // @[RV32ICore.scala 131:18]
  assign ex_io_exmemForwardData = exmemLink ? exmemPCPlus4 : exmemAluResult; // @[RV32ICore.scala 108:8]
  assign ex_io_memwbForwardData = wb_io_writeData; // @[RV32ICore.scala 133:26]
  assign mem_io_valid = exmemValid; // @[RV32ICore.scala 139:16]
  assign mem_io_aluResult = exmemAluResult; // @[RV32ICore.scala 140:20]
  assign mem_io_storeData = exmemStoreData; // @[RV32ICore.scala 141:20]
  assign mem_io_rd = exmemRd; // @[RV32ICore.scala 142:13]
  assign mem_io_funct3 = exmemFunct3; // @[RV32ICore.scala 143:17]
  assign mem_io_pcPlus4 = exmemPCPlus4; // @[RV32ICore.scala 144:18]
  assign mem_io_regWrite = exmemRegWrite; // @[RV32ICore.scala 145:19]
  assign mem_io_memRead = exmemMemRead; // @[RV32ICore.scala 146:18]
  assign mem_io_memWrite = exmemMemWrite; // @[RV32ICore.scala 147:19]
  assign mem_io_memToReg = exmemMemToReg; // @[RV32ICore.scala 148:19]
  assign mem_io_link = exmemLink; // @[RV32ICore.scala 149:15]
  assign mem_io_memRdata = dmem_io_rdata; // @[RV32ICore.scala 157:19]
  assign wb_io_valid = memwbValid; // @[RV32ICore.scala 65:15]
  assign wb_io_aluResult = memwbAluResult; // @[RV32ICore.scala 66:19]
  assign wb_io_memData = memwbMemData; // @[RV32ICore.scala 67:17]
  assign wb_io_pcPlus4 = memwbPCPlus4; // @[RV32ICore.scala 68:17]
  assign wb_io_rd = memwbRd; // @[RV32ICore.scala 69:12]
  assign wb_io_regWrite = memwbRegWrite; // @[RV32ICore.scala 70:18]
  assign wb_io_memToReg = memwbMemToReg; // @[RV32ICore.scala 71:18]
  assign wb_io_link = memwbLink; // @[RV32ICore.scala 72:14]
  assign fwd_io_idexRs1 = idexRs1; // @[RV32ICore.scala 98:18]
  assign fwd_io_idexRs2 = idexRs2; // @[RV32ICore.scala 99:18]
  assign fwd_io_exmemRd = exmemRd; // @[RV32ICore.scala 100:18]
  assign fwd_io_exmemRegWrite = exmemRegWrite; // @[RV32ICore.scala 101:24]
  assign fwd_io_exmemValid = exmemValid; // @[RV32ICore.scala 102:21]
  assign fwd_io_memwbRd = memwbRd; // @[RV32ICore.scala 103:18]
  assign fwd_io_memwbRegWrite = memwbRegWrite; // @[RV32ICore.scala 104:24]
  assign fwd_io_memwbValid = memwbValid; // @[RV32ICore.scala 105:21]
  assign haz_io_ifidRs1 = id_io_rs1; // @[RV32ICore.scala 87:18]
  assign haz_io_ifidRs2 = id_io_rs2; // @[RV32ICore.scala 88:18]
  assign haz_io_ifidUsesRs1 = id_io_usesRs1; // @[RV32ICore.scala 89:22]
  assign haz_io_ifidUsesRs2 = id_io_usesRs2; // @[RV32ICore.scala 90:22]
  assign haz_io_idexRd = idexRd; // @[RV32ICore.scala 91:17]
  assign haz_io_idexMemRead = idexMemRead; // @[RV32ICore.scala 92:22]
  assign haz_io_idexValid = idexValid; // @[RV32ICore.scala 93:20]
  always @(posedge clock) begin
    if (reset) begin // @[RV32ICore.scala 29:19]
      pc <= 32'h0; // @[RV32ICore.scala 29:19]
    end else if (ex_io_redirect) begin // @[RV32ICore.scala 161:18]
      pc <= ex_io_redirectPC; // @[RV32ICore.scala 162:8]
    end else if (~haz_io_stallPC) begin // @[RV32ICore.scala 163:22]
      pc <= _nextPC_T_1; // @[RV32ICore.scala 164:8]
    end
    if (reset) begin // @[RV32ICore.scala 32:26]
      ifidValid <= 1'h0; // @[RV32ICore.scala 32:26]
    end else if (ex_io_redirect) begin // @[RV32ICore.scala 168:18]
      ifidValid <= 1'h0; // @[RV32ICore.scala 169:15]
    end else begin
      ifidValid <= _GEN_2;
    end
    if (reset) begin // @[RV32ICore.scala 33:26]
      ifidPC <= 32'h0; // @[RV32ICore.scala 33:26]
    end else if (ex_io_redirect) begin // @[RV32ICore.scala 168:18]
      ifidPC <= 32'h0; // @[RV32ICore.scala 170:12]
    end else if (~haz_io_stallIFID) begin // @[RV32ICore.scala 172:33]
      ifidPC <= pc; // @[RV32ICore.scala 174:12]
    end
    if (reset) begin // @[RV32ICore.scala 34:26]
      ifidInstr <= 32'h13; // @[RV32ICore.scala 34:26]
    end else if (ex_io_redirect) begin // @[RV32ICore.scala 168:18]
      ifidInstr <= 32'h13; // @[RV32ICore.scala 171:15]
    end else if (~haz_io_stallIFID) begin // @[RV32ICore.scala 172:33]
      ifidInstr <= imem_io_instr; // @[RV32ICore.scala 175:15]
    end
    if (reset) begin // @[RV32ICore.scala 37:26]
      idexValid <= 1'h0; // @[RV32ICore.scala 37:26]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexValid <= 1'h0; // @[RV32ICore.scala 180:15]
    end else begin
      idexValid <= ifidValid; // @[RV32ICore.scala 201:15]
    end
    if (reset) begin // @[RV32ICore.scala 38:23]
      idexPC <= 32'h0; // @[RV32ICore.scala 38:23]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexPC <= 32'h0; // @[RV32ICore.scala 181:12]
    end else begin
      idexPC <= ifidPC; // @[RV32ICore.scala 202:12]
    end
    if (reset) begin // @[RV32ICore.scala 39:26]
      idexInstr <= 32'h13; // @[RV32ICore.scala 39:26]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexInstr <= 32'h13; // @[RV32ICore.scala 182:15]
    end else begin
      idexInstr <= ifidInstr; // @[RV32ICore.scala 203:15]
    end
    if (reset) begin // @[RV32ICore.scala 40:41]
      idexRs1 <= 5'h0; // @[RV32ICore.scala 40:41]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexRs1 <= 5'h0; // @[RV32ICore.scala 183:13]
    end else begin
      idexRs1 <= id_io_rs1; // @[RV32ICore.scala 204:13]
    end
    if (reset) begin // @[RV32ICore.scala 40:41]
      idexRs2 <= 5'h0; // @[RV32ICore.scala 40:41]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexRs2 <= 5'h0; // @[RV32ICore.scala 184:13]
    end else begin
      idexRs2 <= id_io_rs2; // @[RV32ICore.scala 205:13]
    end
    if (reset) begin // @[RV32ICore.scala 40:41]
      idexRd <= 5'h0; // @[RV32ICore.scala 40:41]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexRd <= 5'h0; // @[RV32ICore.scala 185:12]
    end else begin
      idexRd <= id_io_rd; // @[RV32ICore.scala 206:12]
    end
    if (reset) begin // @[RV32ICore.scala 41:50]
      idexRs1Data <= 32'h0; // @[RV32ICore.scala 41:50]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexRs1Data <= 32'h0; // @[RV32ICore.scala 186:17]
    end else begin
      idexRs1Data <= id_io_rs1Data; // @[RV32ICore.scala 207:17]
    end
    if (reset) begin // @[RV32ICore.scala 41:50]
      idexRs2Data <= 32'h0; // @[RV32ICore.scala 41:50]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexRs2Data <= 32'h0; // @[RV32ICore.scala 187:17]
    end else begin
      idexRs2Data <= id_io_rs2Data; // @[RV32ICore.scala 208:17]
    end
    if (reset) begin // @[RV32ICore.scala 41:50]
      idexImm <= 32'h0; // @[RV32ICore.scala 41:50]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexImm <= 32'h0; // @[RV32ICore.scala 188:13]
    end else begin
      idexImm <= id_io_imm; // @[RV32ICore.scala 209:13]
    end
    if (reset) begin // @[RV32ICore.scala 42:27]
      idexFunct3 <= 3'h0; // @[RV32ICore.scala 42:27]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexFunct3 <= 3'h0; // @[RV32ICore.scala 189:16]
    end else begin
      idexFunct3 <= id_io_funct3; // @[RV32ICore.scala 210:16]
    end
    if (reset) begin // @[RV32ICore.scala 43:26]
      idexAluOp <= 5'h0; // @[RV32ICore.scala 43:26]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexAluOp <= 5'h0; // @[RV32ICore.scala 190:15]
    end else begin
      idexAluOp <= id_io_aluOp; // @[RV32ICore.scala 211:15]
    end
    if (reset) begin // @[RV32ICore.scala 44:28]
      idexAluASel <= 2'h0; // @[RV32ICore.scala 44:28]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexAluASel <= 2'h0; // @[RV32ICore.scala 191:17]
    end else begin
      idexAluASel <= id_io_aluASel; // @[RV32ICore.scala 212:17]
    end
    if (reset) begin // @[RV32ICore.scala 46:61]
      idexAluSrc <= 1'h0; // @[RV32ICore.scala 46:61]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexAluSrc <= 1'h0; // @[RV32ICore.scala 192:16]
    end else begin
      idexAluSrc <= id_io_aluSrc; // @[RV32ICore.scala 213:16]
    end
    if (reset) begin // @[RV32ICore.scala 46:61]
      idexRegWrite <= 1'h0; // @[RV32ICore.scala 46:61]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexRegWrite <= 1'h0; // @[RV32ICore.scala 193:18]
    end else begin
      idexRegWrite <= id_io_regWrite; // @[RV32ICore.scala 214:18]
    end
    if (reset) begin // @[RV32ICore.scala 46:61]
      idexMemRead <= 1'h0; // @[RV32ICore.scala 46:61]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexMemRead <= 1'h0; // @[RV32ICore.scala 194:17]
    end else begin
      idexMemRead <= id_io_memRead; // @[RV32ICore.scala 215:17]
    end
    if (reset) begin // @[RV32ICore.scala 46:61]
      idexMemWrite <= 1'h0; // @[RV32ICore.scala 46:61]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexMemWrite <= 1'h0; // @[RV32ICore.scala 195:18]
    end else begin
      idexMemWrite <= id_io_memWrite; // @[RV32ICore.scala 216:18]
    end
    if (reset) begin // @[RV32ICore.scala 46:61]
      idexMemToReg <= 1'h0; // @[RV32ICore.scala 46:61]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexMemToReg <= 1'h0; // @[RV32ICore.scala 196:18]
    end else begin
      idexMemToReg <= id_io_memToReg; // @[RV32ICore.scala 217:18]
    end
    if (reset) begin // @[RV32ICore.scala 46:61]
      idexBranch <= 1'h0; // @[RV32ICore.scala 46:61]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexBranch <= 1'h0; // @[RV32ICore.scala 197:16]
    end else begin
      idexBranch <= id_io_branch; // @[RV32ICore.scala 218:16]
    end
    if (reset) begin // @[RV32ICore.scala 46:61]
      idexJump <= 1'h0; // @[RV32ICore.scala 46:61]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexJump <= 1'h0; // @[RV32ICore.scala 198:14]
    end else begin
      idexJump <= id_io_jump; // @[RV32ICore.scala 219:14]
    end
    if (reset) begin // @[RV32ICore.scala 46:61]
      idexJalr <= 1'h0; // @[RV32ICore.scala 46:61]
    end else if (ex_io_redirect | haz_io_bubbleIDEX) begin // @[RV32ICore.scala 179:39]
      idexJalr <= 1'h0; // @[RV32ICore.scala 199:14]
    end else begin
      idexJalr <= id_io_jalr; // @[RV32ICore.scala 220:14]
    end
    if (reset) begin // @[RV32ICore.scala 49:27]
      exmemValid <= 1'h0; // @[RV32ICore.scala 49:27]
    end else begin
      exmemValid <= idexValid; // @[RV32ICore.scala 224:14]
    end
    if (reset) begin // @[RV32ICore.scala 51:12]
      exmemPC <= 32'h0; // @[RV32ICore.scala 51:12]
    end else begin
      exmemPC <= idexPC; // @[RV32ICore.scala 225:11]
    end
    if (reset) begin // @[RV32ICore.scala 51:12]
      exmemAluResult <= 32'h0; // @[RV32ICore.scala 51:12]
    end else begin
      exmemAluResult <= ex_io_aluResult; // @[RV32ICore.scala 226:18]
    end
    if (reset) begin // @[RV32ICore.scala 51:12]
      exmemStoreData <= 32'h0; // @[RV32ICore.scala 51:12]
    end else begin
      exmemStoreData <= ex_io_storeData; // @[RV32ICore.scala 227:18]
    end
    if (reset) begin // @[RV32ICore.scala 51:12]
      exmemPCPlus4 <= 32'h0; // @[RV32ICore.scala 51:12]
    end else begin
      exmemPCPlus4 <= ex_io_pcPlus4; // @[RV32ICore.scala 230:16]
    end
    if (reset) begin // @[RV32ICore.scala 52:24]
      exmemRd <= 5'h0; // @[RV32ICore.scala 52:24]
    end else begin
      exmemRd <= ex_io_rdOut; // @[RV32ICore.scala 228:11]
    end
    if (reset) begin // @[RV32ICore.scala 53:28]
      exmemFunct3 <= 3'h0; // @[RV32ICore.scala 53:28]
    end else begin
      exmemFunct3 <= ex_io_funct3Out; // @[RV32ICore.scala 229:15]
    end
    if (reset) begin // @[RV32ICore.scala 55:41]
      exmemRegWrite <= 1'h0; // @[RV32ICore.scala 55:41]
    end else begin
      exmemRegWrite <= ex_io_regWriteOut; // @[RV32ICore.scala 231:17]
    end
    if (reset) begin // @[RV32ICore.scala 55:41]
      exmemMemRead <= 1'h0; // @[RV32ICore.scala 55:41]
    end else begin
      exmemMemRead <= ex_io_memReadOut; // @[RV32ICore.scala 232:16]
    end
    if (reset) begin // @[RV32ICore.scala 55:41]
      exmemMemWrite <= 1'h0; // @[RV32ICore.scala 55:41]
    end else begin
      exmemMemWrite <= ex_io_memWriteOut; // @[RV32ICore.scala 233:17]
    end
    if (reset) begin // @[RV32ICore.scala 55:41]
      exmemMemToReg <= 1'h0; // @[RV32ICore.scala 55:41]
    end else begin
      exmemMemToReg <= ex_io_memToRegOut; // @[RV32ICore.scala 234:17]
    end
    if (reset) begin // @[RV32ICore.scala 55:41]
      exmemLink <= 1'h0; // @[RV32ICore.scala 55:41]
    end else begin
      exmemLink <= ex_io_linkOut; // @[RV32ICore.scala 235:13]
    end
    if (reset) begin // @[RV32ICore.scala 58:27]
      memwbValid <= 1'h0; // @[RV32ICore.scala 58:27]
    end else begin
      memwbValid <= exmemValid; // @[RV32ICore.scala 238:14]
    end
    if (reset) begin // @[RV32ICore.scala 60:12]
      memwbPC <= 32'h0; // @[RV32ICore.scala 60:12]
    end else begin
      memwbPC <= exmemPC; // @[RV32ICore.scala 239:11]
    end
    if (reset) begin // @[RV32ICore.scala 60:12]
      memwbAluResult <= 32'h0; // @[RV32ICore.scala 60:12]
    end else begin
      memwbAluResult <= mem_io_aluResultOut; // @[RV32ICore.scala 240:18]
    end
    if (reset) begin // @[RV32ICore.scala 60:12]
      memwbMemData <= 32'h0; // @[RV32ICore.scala 60:12]
    end else begin
      memwbMemData <= mem_io_memDataOut; // @[RV32ICore.scala 241:16]
    end
    if (reset) begin // @[RV32ICore.scala 60:12]
      memwbPCPlus4 <= 32'h0; // @[RV32ICore.scala 60:12]
    end else begin
      memwbPCPlus4 <= mem_io_pcPlus4Out; // @[RV32ICore.scala 242:16]
    end
    if (reset) begin // @[RV32ICore.scala 61:24]
      memwbRd <= 5'h0; // @[RV32ICore.scala 61:24]
    end else begin
      memwbRd <= mem_io_rdOut; // @[RV32ICore.scala 243:11]
    end
    if (reset) begin // @[RV32ICore.scala 62:56]
      memwbRegWrite <= 1'h0; // @[RV32ICore.scala 62:56]
    end else begin
      memwbRegWrite <= mem_io_regWriteOut; // @[RV32ICore.scala 244:17]
    end
    if (reset) begin // @[RV32ICore.scala 62:56]
      memwbMemToReg <= 1'h0; // @[RV32ICore.scala 62:56]
    end else begin
      memwbMemToReg <= mem_io_memToRegOut; // @[RV32ICore.scala 245:17]
    end
    if (reset) begin // @[RV32ICore.scala 62:56]
      memwbLink <= 1'h0; // @[RV32ICore.scala 62:56]
    end else begin
      memwbLink <= mem_io_linkOut; // @[RV32ICore.scala 246:13]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  pc = _RAND_0[31:0];
  _RAND_1 = {1{`RANDOM}};
  ifidValid = _RAND_1[0:0];
  _RAND_2 = {1{`RANDOM}};
  ifidPC = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  ifidInstr = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  idexValid = _RAND_4[0:0];
  _RAND_5 = {1{`RANDOM}};
  idexPC = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  idexInstr = _RAND_6[31:0];
  _RAND_7 = {1{`RANDOM}};
  idexRs1 = _RAND_7[4:0];
  _RAND_8 = {1{`RANDOM}};
  idexRs2 = _RAND_8[4:0];
  _RAND_9 = {1{`RANDOM}};
  idexRd = _RAND_9[4:0];
  _RAND_10 = {1{`RANDOM}};
  idexRs1Data = _RAND_10[31:0];
  _RAND_11 = {1{`RANDOM}};
  idexRs2Data = _RAND_11[31:0];
  _RAND_12 = {1{`RANDOM}};
  idexImm = _RAND_12[31:0];
  _RAND_13 = {1{`RANDOM}};
  idexFunct3 = _RAND_13[2:0];
  _RAND_14 = {1{`RANDOM}};
  idexAluOp = _RAND_14[4:0];
  _RAND_15 = {1{`RANDOM}};
  idexAluASel = _RAND_15[1:0];
  _RAND_16 = {1{`RANDOM}};
  idexAluSrc = _RAND_16[0:0];
  _RAND_17 = {1{`RANDOM}};
  idexRegWrite = _RAND_17[0:0];
  _RAND_18 = {1{`RANDOM}};
  idexMemRead = _RAND_18[0:0];
  _RAND_19 = {1{`RANDOM}};
  idexMemWrite = _RAND_19[0:0];
  _RAND_20 = {1{`RANDOM}};
  idexMemToReg = _RAND_20[0:0];
  _RAND_21 = {1{`RANDOM}};
  idexBranch = _RAND_21[0:0];
  _RAND_22 = {1{`RANDOM}};
  idexJump = _RAND_22[0:0];
  _RAND_23 = {1{`RANDOM}};
  idexJalr = _RAND_23[0:0];
  _RAND_24 = {1{`RANDOM}};
  exmemValid = _RAND_24[0:0];
  _RAND_25 = {1{`RANDOM}};
  exmemPC = _RAND_25[31:0];
  _RAND_26 = {1{`RANDOM}};
  exmemAluResult = _RAND_26[31:0];
  _RAND_27 = {1{`RANDOM}};
  exmemStoreData = _RAND_27[31:0];
  _RAND_28 = {1{`RANDOM}};
  exmemPCPlus4 = _RAND_28[31:0];
  _RAND_29 = {1{`RANDOM}};
  exmemRd = _RAND_29[4:0];
  _RAND_30 = {1{`RANDOM}};
  exmemFunct3 = _RAND_30[2:0];
  _RAND_31 = {1{`RANDOM}};
  exmemRegWrite = _RAND_31[0:0];
  _RAND_32 = {1{`RANDOM}};
  exmemMemRead = _RAND_32[0:0];
  _RAND_33 = {1{`RANDOM}};
  exmemMemWrite = _RAND_33[0:0];
  _RAND_34 = {1{`RANDOM}};
  exmemMemToReg = _RAND_34[0:0];
  _RAND_35 = {1{`RANDOM}};
  exmemLink = _RAND_35[0:0];
  _RAND_36 = {1{`RANDOM}};
  memwbValid = _RAND_36[0:0];
  _RAND_37 = {1{`RANDOM}};
  memwbPC = _RAND_37[31:0];
  _RAND_38 = {1{`RANDOM}};
  memwbAluResult = _RAND_38[31:0];
  _RAND_39 = {1{`RANDOM}};
  memwbMemData = _RAND_39[31:0];
  _RAND_40 = {1{`RANDOM}};
  memwbPCPlus4 = _RAND_40[31:0];
  _RAND_41 = {1{`RANDOM}};
  memwbRd = _RAND_41[4:0];
  _RAND_42 = {1{`RANDOM}};
  memwbRegWrite = _RAND_42[0:0];
  _RAND_43 = {1{`RANDOM}};
  memwbMemToReg = _RAND_43[0:0];
  _RAND_44 = {1{`RANDOM}};
  memwbLink = _RAND_44[0:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
