module InstructionMemory(
  input         clock,
  input  [31:0] io_addr,
  output [31:0] io_instr
);
  reg [31:0] mem [0:255]; // @[InstructionMemory.scala 18:16]
  wire  mem_io_instr_MPORT_en; // @[InstructionMemory.scala 18:16]
  wire [7:0] mem_io_instr_MPORT_addr; // @[InstructionMemory.scala 18:16]
  wire [31:0] mem_io_instr_MPORT_data; // @[InstructionMemory.scala 18:16]
  wire [31:0] wordAddr = {{2'd0}, io_addr[31:2]}; // @[InstructionMemory.scala 27:26]
  wire  _io_instr_T = wordAddr < 32'h100; // @[InstructionMemory.scala 31:14]
  assign mem_io_instr_MPORT_en = 1'h1;
  assign mem_io_instr_MPORT_addr = wordAddr[7:0];
  assign mem_io_instr_MPORT_data = mem[mem_io_instr_MPORT_addr]; // @[InstructionMemory.scala 18:16]
  assign io_instr = _io_instr_T ? mem_io_instr_MPORT_data : 32'h0; // @[InstructionMemory.scala 30:18]
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
  integer initvar;
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
  `endif // RANDOMIZE
  $readmemh("memory.hex", mem);
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module DataMemory(
  input         clock,
  input  [31:0] io_addr,
  input  [31:0] io_wdata,
  output [31:0] io_rdata,
  input         io_memRead,
  input         io_memWrite,
  input  [2:0]  io_funct3
);
`ifdef RANDOMIZE_MEM_INIT
  reg [31:0] _RAND_0;
`endif // RANDOMIZE_MEM_INIT
  reg [7:0] mem [0:1023]; // @[DataMemory.scala 18:16]
  wire  mem_byte0_en; // @[DataMemory.scala 18:16]
  wire [9:0] mem_byte0_addr; // @[DataMemory.scala 18:16]
  wire [7:0] mem_byte0_data; // @[DataMemory.scala 18:16]
  wire  mem_byte1_en; // @[DataMemory.scala 18:16]
  wire [9:0] mem_byte1_addr; // @[DataMemory.scala 18:16]
  wire [7:0] mem_byte1_data; // @[DataMemory.scala 18:16]
  wire  mem_byte2_en; // @[DataMemory.scala 18:16]
  wire [9:0] mem_byte2_addr; // @[DataMemory.scala 18:16]
  wire [7:0] mem_byte2_data; // @[DataMemory.scala 18:16]
  wire  mem_byte3_en; // @[DataMemory.scala 18:16]
  wire [9:0] mem_byte3_addr; // @[DataMemory.scala 18:16]
  wire [7:0] mem_byte3_data; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_1_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_1_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_1_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_1_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_2_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_2_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_2_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_2_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_3_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_3_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_3_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_3_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_4_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_4_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_4_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_4_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_5_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_5_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_5_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_5_en; // @[DataMemory.scala 18:16]
  wire [7:0] mem_MPORT_6_data; // @[DataMemory.scala 18:16]
  wire [9:0] mem_MPORT_6_addr; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_6_mask; // @[DataMemory.scala 18:16]
  wire  mem_MPORT_6_en; // @[DataMemory.scala 18:16]
  wire [31:0] _byte1_T_1 = io_addr + 32'h1; // @[DataMemory.scala 21:27]
  wire [31:0] _byte2_T_1 = io_addr + 32'h2; // @[DataMemory.scala 22:27]
  wire [31:0] _byte3_T_1 = io_addr + 32'h3; // @[DataMemory.scala 23:27]
  wire [31:0] loadData = {mem_byte3_data,mem_byte2_data,mem_byte1_data,mem_byte0_data}; // @[Cat.scala 33:92]
  wire  _T = 3'h0 == io_funct3; // @[DataMemory.scala 30:23]
  wire [23:0] _io_rdata_T_2 = mem_byte0_data[7] ? 24'hffffff : 24'h0; // @[Bitwise.scala 77:12]
  wire [31:0] _io_rdata_T_3 = {_io_rdata_T_2,mem_byte0_data}; // @[Cat.scala 33:92]
  wire  _T_1 = 3'h1 == io_funct3; // @[DataMemory.scala 30:23]
  wire [15:0] _io_rdata_T_6 = mem_byte1_data[7] ? 16'hffff : 16'h0; // @[Bitwise.scala 77:12]
  wire [31:0] _io_rdata_T_7 = {_io_rdata_T_6,mem_byte1_data,mem_byte0_data}; // @[Cat.scala 33:92]
  wire  _T_2 = 3'h2 == io_funct3; // @[DataMemory.scala 30:23]
  wire [31:0] _io_rdata_T_8 = {24'h0,mem_byte0_data}; // @[Cat.scala 33:92]
  wire [31:0] _io_rdata_T_9 = {16'h0,mem_byte1_data,mem_byte0_data}; // @[Cat.scala 33:92]
  wire [31:0] _GEN_0 = 3'h5 == io_funct3 ? _io_rdata_T_9 : 32'h0; // @[DataMemory.scala 27:12 30:23 52:18]
  wire [31:0] _GEN_1 = 3'h4 == io_funct3 ? _io_rdata_T_8 : _GEN_0; // @[DataMemory.scala 30:23 48:18]
  wire [31:0] _GEN_2 = 3'h2 == io_funct3 ? loadData : _GEN_1; // @[DataMemory.scala 30:23 44:18]
  wire [31:0] _GEN_3 = 3'h1 == io_funct3 ? _io_rdata_T_7 : _GEN_2; // @[DataMemory.scala 30:23 36:18]
  wire [31:0] _GEN_4 = 3'h0 == io_funct3 ? _io_rdata_T_3 : _GEN_3; // @[DataMemory.scala 30:23 32:18]
  wire  _GEN_26 = _T_1 ? 1'h0 : _T_2; // @[DataMemory.scala 18:16 62:23]
  wire  _GEN_42 = _T ? 1'h0 : _T_1; // @[DataMemory.scala 18:16 62:23]
  wire  _GEN_49 = _T ? 1'h0 : _GEN_26; // @[DataMemory.scala 18:16 62:23]
  assign mem_byte0_en = 1'h1;
  assign mem_byte0_addr = io_addr[9:0];
  assign mem_byte0_data = mem[mem_byte0_addr]; // @[DataMemory.scala 18:16]
  assign mem_byte1_en = 1'h1;
  assign mem_byte1_addr = _byte1_T_1[9:0];
  assign mem_byte1_data = mem[mem_byte1_addr]; // @[DataMemory.scala 18:16]
  assign mem_byte2_en = 1'h1;
  assign mem_byte2_addr = _byte2_T_1[9:0];
  assign mem_byte2_data = mem[mem_byte2_addr]; // @[DataMemory.scala 18:16]
  assign mem_byte3_en = 1'h1;
  assign mem_byte3_addr = _byte3_T_1[9:0];
  assign mem_byte3_data = mem[mem_byte3_addr]; // @[DataMemory.scala 18:16]
  assign mem_MPORT_data = io_wdata[7:0];
  assign mem_MPORT_addr = io_addr[9:0];
  assign mem_MPORT_mask = 1'h1;
  assign mem_MPORT_en = io_memWrite & _T;
  assign mem_MPORT_1_data = io_wdata[7:0];
  assign mem_MPORT_1_addr = io_addr[9:0];
  assign mem_MPORT_1_mask = 1'h1;
  assign mem_MPORT_1_en = io_memWrite & _GEN_42;
  assign mem_MPORT_2_data = io_wdata[15:8];
  assign mem_MPORT_2_addr = _byte1_T_1[9:0];
  assign mem_MPORT_2_mask = 1'h1;
  assign mem_MPORT_2_en = io_memWrite & _GEN_42;
  assign mem_MPORT_3_data = io_wdata[7:0];
  assign mem_MPORT_3_addr = io_addr[9:0];
  assign mem_MPORT_3_mask = 1'h1;
  assign mem_MPORT_3_en = io_memWrite & _GEN_49;
  assign mem_MPORT_4_data = io_wdata[15:8];
  assign mem_MPORT_4_addr = _byte1_T_1[9:0];
  assign mem_MPORT_4_mask = 1'h1;
  assign mem_MPORT_4_en = io_memWrite & _GEN_49;
  assign mem_MPORT_5_data = io_wdata[23:16];
  assign mem_MPORT_5_addr = _byte2_T_1[9:0];
  assign mem_MPORT_5_mask = 1'h1;
  assign mem_MPORT_5_en = io_memWrite & _GEN_49;
  assign mem_MPORT_6_data = io_wdata[31:24];
  assign mem_MPORT_6_addr = _byte3_T_1[9:0];
  assign mem_MPORT_6_mask = 1'h1;
  assign mem_MPORT_6_en = io_memWrite & _GEN_49;
  assign io_rdata = io_memRead ? _GEN_4 : 32'h0; // @[DataMemory.scala 27:12 29:20]
  always @(posedge clock) begin
    if (mem_MPORT_en & mem_MPORT_mask) begin
      mem[mem_MPORT_addr] <= mem_MPORT_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_1_en & mem_MPORT_1_mask) begin
      mem[mem_MPORT_1_addr] <= mem_MPORT_1_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_2_en & mem_MPORT_2_mask) begin
      mem[mem_MPORT_2_addr] <= mem_MPORT_2_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_3_en & mem_MPORT_3_mask) begin
      mem[mem_MPORT_3_addr] <= mem_MPORT_3_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_4_en & mem_MPORT_4_mask) begin
      mem[mem_MPORT_4_addr] <= mem_MPORT_4_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_5_en & mem_MPORT_5_mask) begin
      mem[mem_MPORT_5_addr] <= mem_MPORT_5_data; // @[DataMemory.scala 18:16]
    end
    if (mem_MPORT_6_en & mem_MPORT_6_mask) begin
      mem[mem_MPORT_6_addr] <= mem_MPORT_6_data; // @[DataMemory.scala 18:16]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_MEM_INIT
  _RAND_0 = {1{`RANDOM}};
  for (initvar = 0; initvar < 1024; initvar = initvar+1)
    mem[initvar] = _RAND_0[7:0];
`endif // RANDOMIZE_MEM_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module Decoder(
  input  [31:0] io_instr,
  output [4:0]  io_rs1,
  output [4:0]  io_rs2,
  output [4:0]  io_rd,
  output [2:0]  io_funct3
);
  assign io_rs1 = io_instr[19:15]; // @[Decoder.scala 35:24]
  assign io_rs2 = io_instr[24:20]; // @[Decoder.scala 36:24]
  assign io_rd = io_instr[11:7]; // @[Decoder.scala 37:24]
  assign io_funct3 = io_instr[14:12]; // @[Decoder.scala 32:24]
endmodule
module Control(
  input  [31:0] io_instr,
  output [4:0]  io_aluOp,
  output [1:0]  io_aluASel,
  output        io_aluSrc,
  output        io_memRead,
  output        io_memWrite,
  output        io_memToReg,
  output        io_regWrite,
  output        io_branch,
  output        io_jump,
  output        io_jalr,
  output        io_usesRs1,
  output        io_usesRs2
);
  wire [6:0] opcode = io_instr[6:0]; // @[Control.scala 41:24]
  wire [2:0] funct3 = io_instr[14:12]; // @[Control.scala 42:24]
  wire [6:0] funct7 = io_instr[31:25]; // @[Control.scala 43:24]
  wire  _T_1 = 3'h0 == funct3; // @[Control.scala 82:22]
  wire  _io_aluOp_T = funct7 == 7'h1; // @[Control.scala 84:34]
  wire  _io_aluOp_T_1 = funct7 == 7'h20; // @[Control.scala 85:34]
  wire [4:0] _io_aluOp_T_2 = funct7 == 7'h20 ? 5'h1 : 5'h0; // @[Control.scala 85:26]
  wire [4:0] _io_aluOp_T_3 = funct7 == 7'h1 ? 5'ha : _io_aluOp_T_2; // @[Control.scala 84:26]
  wire  _T_2 = 3'h1 == funct3; // @[Control.scala 82:22]
  wire [4:0] _io_aluOp_T_5 = _io_aluOp_T ? 5'hb : 5'h2; // @[Control.scala 88:26]
  wire  _T_3 = 3'h2 == funct3; // @[Control.scala 82:22]
  wire [4:0] _io_aluOp_T_7 = _io_aluOp_T ? 5'hc : 5'h3; // @[Control.scala 91:26]
  wire  _T_4 = 3'h3 == funct3; // @[Control.scala 82:22]
  wire [4:0] _io_aluOp_T_9 = _io_aluOp_T ? 5'hd : 5'h4; // @[Control.scala 94:26]
  wire  _T_5 = 3'h4 == funct3; // @[Control.scala 82:22]
  wire [4:0] _io_aluOp_T_11 = _io_aluOp_T ? 5'h10 : 5'h5; // @[Control.scala 97:26]
  wire  _T_6 = 3'h5 == funct3; // @[Control.scala 82:22]
  wire [4:0] _io_aluOp_T_14 = _io_aluOp_T_1 ? 5'h7 : 5'h6; // @[Control.scala 101:26]
  wire [4:0] _io_aluOp_T_15 = _io_aluOp_T ? 5'h11 : _io_aluOp_T_14; // @[Control.scala 100:26]
  wire  _T_7 = 3'h6 == funct3; // @[Control.scala 82:22]
  wire [4:0] _io_aluOp_T_17 = _io_aluOp_T ? 5'h12 : 5'h8; // @[Control.scala 104:26]
  wire  _T_8 = 3'h7 == funct3; // @[Control.scala 82:22]
  wire [4:0] _io_aluOp_T_19 = _io_aluOp_T ? 5'h13 : 5'h9; // @[Control.scala 107:26]
  wire [4:0] _GEN_0 = 3'h7 == funct3 ? _io_aluOp_T_19 : 5'h0; // @[Control.scala 107:20 58:16 82:22]
  wire [4:0] _GEN_1 = 3'h6 == funct3 ? _io_aluOp_T_17 : _GEN_0; // @[Control.scala 104:20 82:22]
  wire [4:0] _GEN_2 = 3'h5 == funct3 ? _io_aluOp_T_15 : _GEN_1; // @[Control.scala 100:20 82:22]
  wire [4:0] _GEN_3 = 3'h4 == funct3 ? _io_aluOp_T_11 : _GEN_2; // @[Control.scala 82:22 97:20]
  wire [4:0] _GEN_4 = 3'h3 == funct3 ? _io_aluOp_T_9 : _GEN_3; // @[Control.scala 82:22 94:20]
  wire [4:0] _GEN_5 = 3'h2 == funct3 ? _io_aluOp_T_7 : _GEN_4; // @[Control.scala 82:22 91:20]
  wire [4:0] _GEN_6 = 3'h1 == funct3 ? _io_aluOp_T_5 : _GEN_5; // @[Control.scala 82:22 88:20]
  wire [4:0] _GEN_7 = 3'h0 == funct3 ? _io_aluOp_T_3 : _GEN_6; // @[Control.scala 82:22 84:20]
  wire [4:0] _GEN_8 = _T_6 ? _io_aluOp_T_14 : 5'h0; // @[Control.scala 119:22 128:20 58:16]
  wire [4:0] _GEN_9 = _T_2 ? 5'h2 : _GEN_8; // @[Control.scala 119:22 126:33]
  wire [4:0] _GEN_10 = _T_8 ? 5'h9 : _GEN_9; // @[Control.scala 119:22 125:33]
  wire [4:0] _GEN_11 = _T_7 ? 5'h8 : _GEN_10; // @[Control.scala 119:22 124:33]
  wire [4:0] _GEN_12 = _T_5 ? 5'h5 : _GEN_11; // @[Control.scala 119:22 123:33]
  wire [4:0] _GEN_13 = _T_4 ? 5'h4 : _GEN_12; // @[Control.scala 119:22 122:33]
  wire [4:0] _GEN_14 = _T_3 ? 5'h3 : _GEN_13; // @[Control.scala 119:22 121:33]
  wire [4:0] _GEN_15 = _T_1 ? 5'h0 : _GEN_14; // @[Control.scala 119:22 120:33]
  wire [1:0] _GEN_17 = 7'h17 == opcode ? 2'h2 : 2'h0; // @[Control.scala 73:18 194:19 59:16]
  wire  _GEN_19 = 7'h37 == opcode | 7'h17 == opcode; // @[Control.scala 73:18 184:19]
  wire [1:0] _GEN_20 = 7'h37 == opcode ? 2'h1 : _GEN_17; // @[Control.scala 73:18 185:19]
  wire  _GEN_22 = 7'h67 == opcode | _GEN_19; // @[Control.scala 73:18 173:19]
  wire [1:0] _GEN_26 = 7'h67 == opcode ? 2'h0 : _GEN_20; // @[Control.scala 59:16 73:18]
  wire  _GEN_27 = 7'h6f == opcode | _GEN_22; // @[Control.scala 73:18 165:19]
  wire  _GEN_30 = 7'h6f == opcode ? 1'h0 : 7'h67 == opcode; // @[Control.scala 69:16 73:18]
  wire  _GEN_31 = 7'h6f == opcode ? 1'h0 : _GEN_22; // @[Control.scala 60:16 73:18]
  wire [1:0] _GEN_33 = 7'h6f == opcode ? 2'h0 : _GEN_26; // @[Control.scala 59:16 73:18]
  wire  _GEN_35 = 7'h63 == opcode | _GEN_30; // @[Control.scala 158:18 73:18]
  wire  _GEN_37 = 7'h63 == opcode ? 1'h0 : 7'h6f == opcode; // @[Control.scala 67:16 73:18]
  wire  _GEN_38 = 7'h63 == opcode ? 1'h0 : _GEN_27; // @[Control.scala 64:16 73:18]
  wire  _GEN_40 = 7'h63 == opcode ? 1'h0 : _GEN_30; // @[Control.scala 68:16 73:18]
  wire  _GEN_41 = 7'h63 == opcode ? 1'h0 : _GEN_31; // @[Control.scala 60:16 73:18]
  wire [1:0] _GEN_43 = 7'h63 == opcode ? 2'h0 : _GEN_33; // @[Control.scala 59:16 73:18]
  wire  _GEN_45 = 7'h23 == opcode | _GEN_35; // @[Control.scala 73:18 148:19]
  wire  _GEN_46 = 7'h23 == opcode | 7'h63 == opcode; // @[Control.scala 73:18 149:19]
  wire  _GEN_47 = 7'h23 == opcode | _GEN_41; // @[Control.scala 73:18 150:19]
  wire  _GEN_50 = 7'h23 == opcode ? 1'h0 : 7'h63 == opcode; // @[Control.scala 66:16 73:18]
  wire  _GEN_51 = 7'h23 == opcode ? 1'h0 : _GEN_37; // @[Control.scala 67:16 73:18]
  wire  _GEN_52 = 7'h23 == opcode ? 1'h0 : _GEN_38; // @[Control.scala 64:16 73:18]
  wire  _GEN_54 = 7'h23 == opcode ? 1'h0 : _GEN_40; // @[Control.scala 68:16 73:18]
  wire [1:0] _GEN_55 = 7'h23 == opcode ? 2'h0 : _GEN_43; // @[Control.scala 59:16 73:18]
  wire  _GEN_57 = 7'h3 == opcode | _GEN_45; // @[Control.scala 73:18 136:19]
  wire  _GEN_58 = 7'h3 == opcode | _GEN_47; // @[Control.scala 73:18 137:19]
  wire  _GEN_61 = 7'h3 == opcode | _GEN_52; // @[Control.scala 73:18 141:19]
  wire  _GEN_63 = 7'h3 == opcode ? 1'h0 : _GEN_46; // @[Control.scala 70:16 73:18]
  wire  _GEN_64 = 7'h3 == opcode ? 1'h0 : 7'h23 == opcode; // @[Control.scala 62:16 73:18]
  wire  _GEN_65 = 7'h3 == opcode ? 1'h0 : _GEN_50; // @[Control.scala 66:16 73:18]
  wire  _GEN_66 = 7'h3 == opcode ? 1'h0 : _GEN_51; // @[Control.scala 67:16 73:18]
  wire  _GEN_67 = 7'h3 == opcode ? 1'h0 : _GEN_54; // @[Control.scala 68:16 73:18]
  wire [1:0] _GEN_68 = 7'h3 == opcode ? 2'h0 : _GEN_55; // @[Control.scala 59:16 73:18]
  wire  _GEN_70 = 7'h13 == opcode | _GEN_57; // @[Control.scala 73:18 115:19]
  wire  _GEN_71 = 7'h13 == opcode | _GEN_58; // @[Control.scala 73:18 116:19]
  wire  _GEN_72 = 7'h13 == opcode | _GEN_61; // @[Control.scala 73:18 117:19]
  wire [4:0] _GEN_73 = 7'h13 == opcode ? _GEN_15 : 5'h0; // @[Control.scala 73:18]
  wire  _GEN_74 = 7'h13 == opcode ? 1'h0 : 7'h3 == opcode; // @[Control.scala 61:16 73:18]
  wire  _GEN_76 = 7'h13 == opcode ? 1'h0 : _GEN_63; // @[Control.scala 70:16 73:18]
  wire  _GEN_77 = 7'h13 == opcode ? 1'h0 : _GEN_64; // @[Control.scala 62:16 73:18]
  wire  _GEN_78 = 7'h13 == opcode ? 1'h0 : _GEN_65; // @[Control.scala 66:16 73:18]
  wire  _GEN_79 = 7'h13 == opcode ? 1'h0 : _GEN_66; // @[Control.scala 67:16 73:18]
  wire  _GEN_80 = 7'h13 == opcode ? 1'h0 : _GEN_67; // @[Control.scala 68:16 73:18]
  wire [1:0] _GEN_81 = 7'h13 == opcode ? 2'h0 : _GEN_68; // @[Control.scala 59:16 73:18]
  assign io_aluOp = 7'h33 == opcode ? _GEN_7 : _GEN_73; // @[Control.scala 73:18]
  assign io_aluASel = 7'h33 == opcode ? 2'h0 : _GEN_81; // @[Control.scala 59:16 73:18]
  assign io_aluSrc = 7'h33 == opcode ? 1'h0 : _GEN_71; // @[Control.scala 60:16 73:18]
  assign io_memRead = 7'h33 == opcode ? 1'h0 : _GEN_74; // @[Control.scala 61:16 73:18]
  assign io_memWrite = 7'h33 == opcode ? 1'h0 : _GEN_77; // @[Control.scala 62:16 73:18]
  assign io_memToReg = 7'h33 == opcode ? 1'h0 : _GEN_74; // @[Control.scala 61:16 73:18]
  assign io_regWrite = 7'h33 == opcode | _GEN_72; // @[Control.scala 73:18 80:19]
  assign io_branch = 7'h33 == opcode ? 1'h0 : _GEN_78; // @[Control.scala 66:16 73:18]
  assign io_jump = 7'h33 == opcode ? 1'h0 : _GEN_79; // @[Control.scala 67:16 73:18]
  assign io_jalr = 7'h33 == opcode ? 1'h0 : _GEN_80; // @[Control.scala 68:16 73:18]
  assign io_usesRs1 = 7'h33 == opcode | _GEN_70; // @[Control.scala 73:18 78:19]
  assign io_usesRs2 = 7'h33 == opcode | _GEN_76; // @[Control.scala 73:18 79:19]
endmodule
module ImmediateGenerator(
  input  [31:0] io_instr,
  output [31:0] io_imm
);
  wire [6:0] opcode = io_instr[6:0]; // @[ImmediateGenerator.scala 12:24]
  wire [19:0] _iImm_T_2 = io_instr[31] ? 20'hfffff : 20'h0; // @[Bitwise.scala 77:12]
  wire [31:0] iImm = {_iImm_T_2,io_instr[31:20]}; // @[Cat.scala 33:92]
  wire [31:0] sImm = {_iImm_T_2,io_instr[31:25],io_instr[11:7]}; // @[Cat.scala 33:92]
  wire [18:0] _bImm_T_2 = io_instr[31] ? 19'h7ffff : 19'h0; // @[Bitwise.scala 77:12]
  wire [31:0] bImm = {_bImm_T_2,io_instr[31],io_instr[7],io_instr[30:25],io_instr[11:8],1'h0}; // @[Cat.scala 33:92]
  wire [31:0] uImm = {io_instr[31:12],12'h0}; // @[Cat.scala 33:92]
  wire [10:0] _jImm_T_2 = io_instr[31] ? 11'h7ff : 11'h0; // @[Bitwise.scala 77:12]
  wire [31:0] jImm = {_jImm_T_2,io_instr[31],io_instr[19:12],io_instr[20],io_instr[30:21],1'h0}; // @[Cat.scala 33:92]
  wire [31:0] _GEN_0 = 7'h6f == opcode ? jImm : 32'h0; // @[ImmediateGenerator.scala 48:10 50:18 81:14]
  wire [31:0] _GEN_1 = 7'h17 == opcode ? uImm : _GEN_0; // @[ImmediateGenerator.scala 50:18 77:14]
  wire [31:0] _GEN_2 = 7'h37 == opcode ? uImm : _GEN_1; // @[ImmediateGenerator.scala 50:18 73:14]
  wire [31:0] _GEN_3 = 7'h63 == opcode ? bImm : _GEN_2; // @[ImmediateGenerator.scala 50:18 69:14]
  wire [31:0] _GEN_4 = 7'h23 == opcode ? sImm : _GEN_3; // @[ImmediateGenerator.scala 50:18 65:14]
  wire [31:0] _GEN_5 = 7'h67 == opcode ? iImm : _GEN_4; // @[ImmediateGenerator.scala 50:18 61:14]
  wire [31:0] _GEN_6 = 7'h13 == opcode ? iImm : _GEN_5; // @[ImmediateGenerator.scala 50:18 57:14]
  assign io_imm = 7'h3 == opcode ? iImm : _GEN_6; // @[ImmediateGenerator.scala 50:18 53:14]
endmodule
module RegisterFile(
  input         clock,
  input         reset,
  input  [4:0]  io_rs1,
  input  [4:0]  io_rs2,
  output [31:0] io_readData1,
  output [31:0] io_readData2,
  input  [4:0]  io_rd,
  input  [31:0] io_writeData,
  input         io_writeEnable,
  output [31:0] io_debugRead_1,
  output [31:0] io_debugRead_2,
  output [31:0] io_debugRead_3,
  output [31:0] io_debugRead_4,
  output [31:0] io_debugRead_5,
  output [31:0] io_debugRead_6
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
`endif // RANDOMIZE_REG_INIT
  reg [31:0] regs_0; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_1; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_2; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_3; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_4; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_5; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_6; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_7; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_8; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_9; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_10; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_11; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_12; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_13; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_14; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_15; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_16; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_17; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_18; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_19; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_20; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_21; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_22; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_23; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_24; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_25; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_26; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_27; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_28; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_29; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_30; // @[RegisterFile.scala 39:21]
  reg [31:0] regs_31; // @[RegisterFile.scala 39:21]
  wire [31:0] _GEN_1 = 5'h1 == io_rs1 ? regs_1 : regs_0; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_2 = 5'h2 == io_rs1 ? regs_2 : _GEN_1; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_3 = 5'h3 == io_rs1 ? regs_3 : _GEN_2; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_4 = 5'h4 == io_rs1 ? regs_4 : _GEN_3; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_5 = 5'h5 == io_rs1 ? regs_5 : _GEN_4; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_6 = 5'h6 == io_rs1 ? regs_6 : _GEN_5; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_7 = 5'h7 == io_rs1 ? regs_7 : _GEN_6; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_8 = 5'h8 == io_rs1 ? regs_8 : _GEN_7; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_9 = 5'h9 == io_rs1 ? regs_9 : _GEN_8; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_10 = 5'ha == io_rs1 ? regs_10 : _GEN_9; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_11 = 5'hb == io_rs1 ? regs_11 : _GEN_10; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_12 = 5'hc == io_rs1 ? regs_12 : _GEN_11; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_13 = 5'hd == io_rs1 ? regs_13 : _GEN_12; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_14 = 5'he == io_rs1 ? regs_14 : _GEN_13; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_15 = 5'hf == io_rs1 ? regs_15 : _GEN_14; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_16 = 5'h10 == io_rs1 ? regs_16 : _GEN_15; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_17 = 5'h11 == io_rs1 ? regs_17 : _GEN_16; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_18 = 5'h12 == io_rs1 ? regs_18 : _GEN_17; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_19 = 5'h13 == io_rs1 ? regs_19 : _GEN_18; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_20 = 5'h14 == io_rs1 ? regs_20 : _GEN_19; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_21 = 5'h15 == io_rs1 ? regs_21 : _GEN_20; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_22 = 5'h16 == io_rs1 ? regs_22 : _GEN_21; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_23 = 5'h17 == io_rs1 ? regs_23 : _GEN_22; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_24 = 5'h18 == io_rs1 ? regs_24 : _GEN_23; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_25 = 5'h19 == io_rs1 ? regs_25 : _GEN_24; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_26 = 5'h1a == io_rs1 ? regs_26 : _GEN_25; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_27 = 5'h1b == io_rs1 ? regs_27 : _GEN_26; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_28 = 5'h1c == io_rs1 ? regs_28 : _GEN_27; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_29 = 5'h1d == io_rs1 ? regs_29 : _GEN_28; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_30 = 5'h1e == io_rs1 ? regs_30 : _GEN_29; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_31 = 5'h1f == io_rs1 ? regs_31 : _GEN_30; // @[RegisterFile.scala 42:{22,22}]
  wire [31:0] _GEN_33 = 5'h1 == io_rs2 ? regs_1 : regs_0; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_34 = 5'h2 == io_rs2 ? regs_2 : _GEN_33; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_35 = 5'h3 == io_rs2 ? regs_3 : _GEN_34; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_36 = 5'h4 == io_rs2 ? regs_4 : _GEN_35; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_37 = 5'h5 == io_rs2 ? regs_5 : _GEN_36; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_38 = 5'h6 == io_rs2 ? regs_6 : _GEN_37; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_39 = 5'h7 == io_rs2 ? regs_7 : _GEN_38; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_40 = 5'h8 == io_rs2 ? regs_8 : _GEN_39; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_41 = 5'h9 == io_rs2 ? regs_9 : _GEN_40; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_42 = 5'ha == io_rs2 ? regs_10 : _GEN_41; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_43 = 5'hb == io_rs2 ? regs_11 : _GEN_42; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_44 = 5'hc == io_rs2 ? regs_12 : _GEN_43; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_45 = 5'hd == io_rs2 ? regs_13 : _GEN_44; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_46 = 5'he == io_rs2 ? regs_14 : _GEN_45; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_47 = 5'hf == io_rs2 ? regs_15 : _GEN_46; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_48 = 5'h10 == io_rs2 ? regs_16 : _GEN_47; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_49 = 5'h11 == io_rs2 ? regs_17 : _GEN_48; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_50 = 5'h12 == io_rs2 ? regs_18 : _GEN_49; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_51 = 5'h13 == io_rs2 ? regs_19 : _GEN_50; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_52 = 5'h14 == io_rs2 ? regs_20 : _GEN_51; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_53 = 5'h15 == io_rs2 ? regs_21 : _GEN_52; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_54 = 5'h16 == io_rs2 ? regs_22 : _GEN_53; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_55 = 5'h17 == io_rs2 ? regs_23 : _GEN_54; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_56 = 5'h18 == io_rs2 ? regs_24 : _GEN_55; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_57 = 5'h19 == io_rs2 ? regs_25 : _GEN_56; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_58 = 5'h1a == io_rs2 ? regs_26 : _GEN_57; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_59 = 5'h1b == io_rs2 ? regs_27 : _GEN_58; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_60 = 5'h1c == io_rs2 ? regs_28 : _GEN_59; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_61 = 5'h1d == io_rs2 ? regs_29 : _GEN_60; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_62 = 5'h1e == io_rs2 ? regs_30 : _GEN_61; // @[RegisterFile.scala 43:{22,22}]
  wire [31:0] _GEN_63 = 5'h1f == io_rs2 ? regs_31 : _GEN_62; // @[RegisterFile.scala 43:{22,22}]
  assign io_readData1 = io_rs1 == 5'h0 ? 32'h0 : _GEN_31; // @[RegisterFile.scala 42:22]
  assign io_readData2 = io_rs2 == 5'h0 ? 32'h0 : _GEN_63; // @[RegisterFile.scala 43:22]
  assign io_debugRead_1 = regs_1; // @[RegisterFile.scala 52:21]
  assign io_debugRead_2 = regs_2; // @[RegisterFile.scala 52:21]
  assign io_debugRead_3 = regs_3; // @[RegisterFile.scala 52:21]
  assign io_debugRead_4 = regs_4; // @[RegisterFile.scala 52:21]
  assign io_debugRead_5 = regs_5; // @[RegisterFile.scala 52:21]
  assign io_debugRead_6 = regs_6; // @[RegisterFile.scala 52:21]
  always @(posedge clock) begin
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_0 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h0 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_0 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_1 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h1 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_1 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_2 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h2 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_2 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_3 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h3 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_3 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_4 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h4 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_4 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_5 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h5 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_5 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_6 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h6 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_6 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_7 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h7 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_7 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_8 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h8 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_8 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_9 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h9 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_9 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_10 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'ha == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_10 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_11 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'hb == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_11 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_12 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'hc == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_12 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_13 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'hd == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_13 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_14 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'he == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_14 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_15 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'hf == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_15 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_16 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h10 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_16 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_17 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h11 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_17 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_18 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h12 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_18 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_19 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h13 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_19 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_20 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h14 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_20 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_21 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h15 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_21 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_22 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h16 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_22 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_23 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h17 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_23 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_24 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h18 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_24 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_25 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h19 == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_25 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_26 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h1a == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_26 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_27 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h1b == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_27 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_28 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h1c == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_28 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_29 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h1d == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_29 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_30 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h1e == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_30 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
    if (reset) begin // @[RegisterFile.scala 39:21]
      regs_31 <= 32'h0; // @[RegisterFile.scala 39:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[RegisterFile.scala 46:43]
      if (5'h1f == io_rd) begin // @[RegisterFile.scala 47:17]
        regs_31 <= io_writeData; // @[RegisterFile.scala 47:17]
      end
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  regs_0 = _RAND_0[31:0];
  _RAND_1 = {1{`RANDOM}};
  regs_1 = _RAND_1[31:0];
  _RAND_2 = {1{`RANDOM}};
  regs_2 = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  regs_3 = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  regs_4 = _RAND_4[31:0];
  _RAND_5 = {1{`RANDOM}};
  regs_5 = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  regs_6 = _RAND_6[31:0];
  _RAND_7 = {1{`RANDOM}};
  regs_7 = _RAND_7[31:0];
  _RAND_8 = {1{`RANDOM}};
  regs_8 = _RAND_8[31:0];
  _RAND_9 = {1{`RANDOM}};
  regs_9 = _RAND_9[31:0];
  _RAND_10 = {1{`RANDOM}};
  regs_10 = _RAND_10[31:0];
  _RAND_11 = {1{`RANDOM}};
  regs_11 = _RAND_11[31:0];
  _RAND_12 = {1{`RANDOM}};
  regs_12 = _RAND_12[31:0];
  _RAND_13 = {1{`RANDOM}};
  regs_13 = _RAND_13[31:0];
  _RAND_14 = {1{`RANDOM}};
  regs_14 = _RAND_14[31:0];
  _RAND_15 = {1{`RANDOM}};
  regs_15 = _RAND_15[31:0];
  _RAND_16 = {1{`RANDOM}};
  regs_16 = _RAND_16[31:0];
  _RAND_17 = {1{`RANDOM}};
  regs_17 = _RAND_17[31:0];
  _RAND_18 = {1{`RANDOM}};
  regs_18 = _RAND_18[31:0];
  _RAND_19 = {1{`RANDOM}};
  regs_19 = _RAND_19[31:0];
  _RAND_20 = {1{`RANDOM}};
  regs_20 = _RAND_20[31:0];
  _RAND_21 = {1{`RANDOM}};
  regs_21 = _RAND_21[31:0];
  _RAND_22 = {1{`RANDOM}};
  regs_22 = _RAND_22[31:0];
  _RAND_23 = {1{`RANDOM}};
  regs_23 = _RAND_23[31:0];
  _RAND_24 = {1{`RANDOM}};
  regs_24 = _RAND_24[31:0];
  _RAND_25 = {1{`RANDOM}};
  regs_25 = _RAND_25[31:0];
  _RAND_26 = {1{`RANDOM}};
  regs_26 = _RAND_26[31:0];
  _RAND_27 = {1{`RANDOM}};
  regs_27 = _RAND_27[31:0];
  _RAND_28 = {1{`RANDOM}};
  regs_28 = _RAND_28[31:0];
  _RAND_29 = {1{`RANDOM}};
  regs_29 = _RAND_29[31:0];
  _RAND_30 = {1{`RANDOM}};
  regs_30 = _RAND_30[31:0];
  _RAND_31 = {1{`RANDOM}};
  regs_31 = _RAND_31[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module IDStage(
  input         clock,
  input         reset,
  input         io_valid,
  input  [31:0] io_instr,
  input  [4:0]  io_wbRd,
  input  [31:0] io_wbWriteData,
  input         io_wbWriteEnable,
  output [4:0]  io_rs1,
  output [4:0]  io_rs2,
  output [4:0]  io_rd,
  output [31:0] io_rs1Data,
  output [31:0] io_rs2Data,
  output [31:0] io_imm,
  output [2:0]  io_funct3,
  output [4:0]  io_aluOp,
  output [1:0]  io_aluASel,
  output        io_aluSrc,
  output        io_regWrite,
  output        io_memRead,
  output        io_memWrite,
  output        io_memToReg,
  output        io_branch,
  output        io_jump,
  output        io_jalr,
  output        io_usesRs1,
  output        io_usesRs2,
  output [31:0] io_debugX1,
  output [31:0] io_debugX2,
  output [31:0] io_debugX3,
  output [31:0] io_debugX4,
  output [31:0] io_debugX5,
  output [31:0] io_debugX6
);
  wire [31:0] decoder_io_instr; // @[IDStage.scala 124:11]
  wire [4:0] decoder_io_rs1; // @[IDStage.scala 124:11]
  wire [4:0] decoder_io_rs2; // @[IDStage.scala 124:11]
  wire [4:0] decoder_io_rd; // @[IDStage.scala 124:11]
  wire [2:0] decoder_io_funct3; // @[IDStage.scala 124:11]
  wire [31:0] control_io_instr; // @[IDStage.scala 127:11]
  wire [4:0] control_io_aluOp; // @[IDStage.scala 127:11]
  wire [1:0] control_io_aluASel; // @[IDStage.scala 127:11]
  wire  control_io_aluSrc; // @[IDStage.scala 127:11]
  wire  control_io_memRead; // @[IDStage.scala 127:11]
  wire  control_io_memWrite; // @[IDStage.scala 127:11]
  wire  control_io_memToReg; // @[IDStage.scala 127:11]
  wire  control_io_regWrite; // @[IDStage.scala 127:11]
  wire  control_io_branch; // @[IDStage.scala 127:11]
  wire  control_io_jump; // @[IDStage.scala 127:11]
  wire  control_io_jalr; // @[IDStage.scala 127:11]
  wire  control_io_usesRs1; // @[IDStage.scala 127:11]
  wire  control_io_usesRs2; // @[IDStage.scala 127:11]
  wire [31:0] immGen_io_instr; // @[IDStage.scala 130:11]
  wire [31:0] immGen_io_imm; // @[IDStage.scala 130:11]
  wire  regFile_clock; // @[IDStage.scala 133:11]
  wire  regFile_reset; // @[IDStage.scala 133:11]
  wire [4:0] regFile_io_rs1; // @[IDStage.scala 133:11]
  wire [4:0] regFile_io_rs2; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_readData1; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_readData2; // @[IDStage.scala 133:11]
  wire [4:0] regFile_io_rd; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_writeData; // @[IDStage.scala 133:11]
  wire  regFile_io_writeEnable; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_debugRead_1; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_debugRead_2; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_debugRead_3; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_debugRead_4; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_debugRead_5; // @[IDStage.scala 133:11]
  wire [31:0] regFile_io_debugRead_6; // @[IDStage.scala 133:11]
  wire  _wbBypassRs1_T = io_wbRd != 5'h0; // @[IDStage.scala 205:14]
  wire  _wbBypassRs1_T_1 = io_wbWriteEnable & _wbBypassRs1_T; // @[IDStage.scala 204:22]
  wire  _wbBypassRs1_T_2 = io_wbRd == decoder_io_rs1; // @[IDStage.scala 206:14]
  wire  wbBypassRs1 = _wbBypassRs1_T_1 & _wbBypassRs1_T_2; // @[IDStage.scala 205:23]
  wire  _wbBypassRs2_T_2 = io_wbRd == decoder_io_rs2; // @[IDStage.scala 211:14]
  wire  wbBypassRs2 = _wbBypassRs1_T_1 & _wbBypassRs2_T_2; // @[IDStage.scala 210:23]
  Decoder decoder ( // @[IDStage.scala 124:11]
    .io_instr(decoder_io_instr),
    .io_rs1(decoder_io_rs1),
    .io_rs2(decoder_io_rs2),
    .io_rd(decoder_io_rd),
    .io_funct3(decoder_io_funct3)
  );
  Control control ( // @[IDStage.scala 127:11]
    .io_instr(control_io_instr),
    .io_aluOp(control_io_aluOp),
    .io_aluASel(control_io_aluASel),
    .io_aluSrc(control_io_aluSrc),
    .io_memRead(control_io_memRead),
    .io_memWrite(control_io_memWrite),
    .io_memToReg(control_io_memToReg),
    .io_regWrite(control_io_regWrite),
    .io_branch(control_io_branch),
    .io_jump(control_io_jump),
    .io_jalr(control_io_jalr),
    .io_usesRs1(control_io_usesRs1),
    .io_usesRs2(control_io_usesRs2)
  );
  ImmediateGenerator immGen ( // @[IDStage.scala 130:11]
    .io_instr(immGen_io_instr),
    .io_imm(immGen_io_imm)
  );
  RegisterFile regFile ( // @[IDStage.scala 133:11]
    .clock(regFile_clock),
    .reset(regFile_reset),
    .io_rs1(regFile_io_rs1),
    .io_rs2(regFile_io_rs2),
    .io_readData1(regFile_io_readData1),
    .io_readData2(regFile_io_readData2),
    .io_rd(regFile_io_rd),
    .io_writeData(regFile_io_writeData),
    .io_writeEnable(regFile_io_writeEnable),
    .io_debugRead_1(regFile_io_debugRead_1),
    .io_debugRead_2(regFile_io_debugRead_2),
    .io_debugRead_3(regFile_io_debugRead_3),
    .io_debugRead_4(regFile_io_debugRead_4),
    .io_debugRead_5(regFile_io_debugRead_5),
    .io_debugRead_6(regFile_io_debugRead_6)
  );
  assign io_rs1 = decoder_io_rs1; // @[IDStage.scala 232:10]
  assign io_rs2 = decoder_io_rs2; // @[IDStage.scala 235:10]
  assign io_rd = decoder_io_rd; // @[IDStage.scala 238:9]
  assign io_rs1Data = wbBypassRs1 ? io_wbWriteData : regFile_io_readData1; // @[IDStage.scala 214:8]
  assign io_rs2Data = wbBypassRs2 ? io_wbWriteData : regFile_io_readData2; // @[IDStage.scala 221:8]
  assign io_imm = immGen_io_imm; // @[IDStage.scala 246:10]
  assign io_funct3 = decoder_io_funct3; // @[IDStage.scala 249:13]
  assign io_aluOp = control_io_aluOp; // @[IDStage.scala 257:12]
  assign io_aluASel = control_io_aluASel; // @[IDStage.scala 260:14]
  assign io_aluSrc = control_io_aluSrc; // @[IDStage.scala 263:13]
  assign io_regWrite = control_io_regWrite & io_valid; // @[IDStage.scala 272:25]
  assign io_memRead = control_io_memRead & io_valid; // @[IDStage.scala 276:24]
  assign io_memWrite = control_io_memWrite & io_valid; // @[IDStage.scala 280:25]
  assign io_memToReg = control_io_memToReg; // @[IDStage.scala 283:15]
  assign io_branch = control_io_branch & io_valid; // @[IDStage.scala 287:23]
  assign io_jump = control_io_jump & io_valid; // @[IDStage.scala 291:21]
  assign io_jalr = control_io_jalr & io_valid; // @[IDStage.scala 295:21]
  assign io_usesRs1 = control_io_usesRs1 & io_valid; // @[IDStage.scala 304:24]
  assign io_usesRs2 = control_io_usesRs2 & io_valid; // @[IDStage.scala 308:24]
  assign io_debugX1 = regFile_io_debugRead_1; // @[IDStage.scala 316:14]
  assign io_debugX2 = regFile_io_debugRead_2; // @[IDStage.scala 319:14]
  assign io_debugX3 = regFile_io_debugRead_3; // @[IDStage.scala 322:14]
  assign io_debugX4 = regFile_io_debugRead_4; // @[IDStage.scala 325:14]
  assign io_debugX5 = regFile_io_debugRead_5; // @[IDStage.scala 328:14]
  assign io_debugX6 = regFile_io_debugRead_6; // @[IDStage.scala 331:14]
  assign decoder_io_instr = io_instr; // @[IDStage.scala 140:20]
  assign control_io_instr = io_instr; // @[IDStage.scala 143:20]
  assign immGen_io_instr = io_instr; // @[IDStage.scala 146:19]
  assign regFile_clock = clock;
  assign regFile_reset = reset;
  assign regFile_io_rs1 = decoder_io_rs1; // @[IDStage.scala 154:18]
  assign regFile_io_rs2 = decoder_io_rs2; // @[IDStage.scala 157:18]
  assign regFile_io_rd = io_wbRd; // @[IDStage.scala 171:17]
  assign regFile_io_writeData = io_wbWriteData; // @[IDStage.scala 174:24]
  assign regFile_io_writeEnable = io_wbWriteEnable; // @[IDStage.scala 177:26]
endmodule
module ALU(
  input  [31:0] io_a,
  input  [31:0] io_b,
  input  [4:0]  io_op,
  output [31:0] io_y
);
  wire [4:0] shamt = io_b[4:0]; // @[ALU.scala 64:19]
  wire [31:0] _aSigned64_T_2 = io_a[31] ? 32'hffffffff : 32'h0; // @[Bitwise.scala 77:12]
  wire [63:0] aSigned64 = {_aSigned64_T_2,io_a}; // @[ALU.scala 78:35]
  wire [31:0] _bSigned64_T_2 = io_b[31] ? 32'hffffffff : 32'h0; // @[Bitwise.scala 77:12]
  wire [63:0] bSigned64 = {_bSigned64_T_2,io_b}; // @[ALU.scala 81:35]
  wire [63:0] aUnsigned64 = {32'h0,io_a}; // @[Cat.scala 33:92]
  wire [63:0] bUnsigned64 = {32'h0,io_b}; // @[Cat.scala 33:92]
  wire [127:0] mulSS = $signed(aSigned64) * $signed(bSigned64); // @[ALU.scala 93:26]
  wire [127:0] mulUU = aUnsigned64 * bUnsigned64; // @[ALU.scala 94:28]
  wire [63:0] _mulHSU_T = {32'h0,io_b}; // @[ALU.scala 95:40]
  wire [127:0] mulHSU = $signed(aSigned64) * $signed(_mulHSU_T); // @[ALU.scala 95:26]
  wire [31:0] mulLow = mulSS[31:0]; // @[ALU.scala 98:10]
  wire [31:0] mulHighSS = mulSS[63:32]; // @[ALU.scala 101:10]
  wire [31:0] mulHighSU = mulHSU[63:32]; // @[ALU.scala 104:11]
  wire [31:0] mulHighUU = mulUU[63:32]; // @[ALU.scala 107:10]
  wire  _T = io_b == 32'h0; // @[ALU.scala 147:14]
  wire  _T_2 = io_b == 32'hffffffff; // @[ALU.scala 152:11]
  wire  _T_3 = io_a == 32'h80000000 & _T_2; // @[ALU.scala 151:23]
  wire [32:0] _divResult_T_1 = $signed(io_a) / $signed(io_b); // @[ALU.scala 157:38]
  wire [32:0] _GEN_0 = _T_3 ? 33'h80000000 : _divResult_T_1; // @[ALU.scala 153:5 155:15 157:15]
  wire [32:0] _GEN_1 = io_b == 32'h0 ? 33'hffffffff : _GEN_0; // @[ALU.scala 147:23 149:15]
  wire [31:0] _divuResult_T = io_a / io_b; // @[ALU.scala 170:24]
  wire [31:0] divuResult = _T ? 32'hffffffff : _divuResult_T; // @[ALU.scala 166:23 168:16 170:16]
  wire [31:0] _remResult_T_1 = $signed(io_a) % $signed(io_b); // @[ALU.scala 189:38]
  wire [31:0] _GEN_3 = _T_3 ? 32'h0 : _remResult_T_1; // @[ALU.scala 185:5 187:15 189:15]
  wire [31:0] remResult = _T ? io_a : _GEN_3; // @[ALU.scala 179:23 181:15]
  wire [31:0] _remuResult_T = io_a % io_b; // @[ALU.scala 202:24]
  wire [31:0] remuResult = _T ? io_a : _remuResult_T; // @[ALU.scala 198:23 200:16 202:16]
  wire  equal = io_a == io_b; // @[ALU.scala 210:10]
  wire  notEqual = io_a != io_b; // @[ALU.scala 213:10]
  wire [31:0] _io_y_T_1 = io_a + io_b; // @[ALU.scala 229:15]
  wire [31:0] _io_y_T_3 = io_a - io_b; // @[ALU.scala 232:15]
  wire [62:0] _GEN_2 = {{31'd0}, io_a}; // @[ALU.scala 235:15]
  wire [62:0] _io_y_T_4 = _GEN_2 << shamt; // @[ALU.scala 235:15]
  wire  _io_y_T_5 = $signed(io_a) < $signed(io_b); // @[ALU.scala 239:19]
  wire [31:0] _io_y_T_6 = _io_y_T_5 ? 32'h1 : 32'h0; // @[ALU.scala 238:12]
  wire  _io_y_T_7 = io_a < io_b; // @[ALU.scala 246:16]
  wire [31:0] _io_y_T_8 = _io_y_T_7 ? 32'h1 : 32'h0; // @[ALU.scala 245:12]
  wire [31:0] _io_y_T_9 = io_a ^ io_b; // @[ALU.scala 252:15]
  wire [31:0] _io_y_T_10 = io_a >> shamt; // @[ALU.scala 255:15]
  wire [31:0] _io_y_T_12 = $signed(io_a) >>> shamt; // @[ALU.scala 258:28]
  wire [31:0] _io_y_T_13 = io_a | io_b; // @[ALU.scala 261:15]
  wire [31:0] _io_y_T_14 = io_a & io_b; // @[ALU.scala 264:15]
  wire [31:0] _io_y_T_15 = equal ? 32'h1 : 32'h0; // @[ALU.scala 287:12]
  wire [31:0] _io_y_T_16 = notEqual ? 32'h1 : 32'h0; // @[ALU.scala 294:12]
  wire [31:0] _io_y_T_18 = 5'h0 == io_op ? _io_y_T_1 : 32'h0; // @[Mux.scala 81:58]
  wire [31:0] _io_y_T_20 = 5'h1 == io_op ? _io_y_T_3 : _io_y_T_18; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_22 = 5'h2 == io_op ? _io_y_T_4 : {{31'd0}, _io_y_T_20}; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_24 = 5'h3 == io_op ? {{31'd0}, _io_y_T_6} : _io_y_T_22; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_26 = 5'h4 == io_op ? {{31'd0}, _io_y_T_8} : _io_y_T_24; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_28 = 5'h5 == io_op ? {{31'd0}, _io_y_T_9} : _io_y_T_26; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_30 = 5'h6 == io_op ? {{31'd0}, _io_y_T_10} : _io_y_T_28; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_32 = 5'h7 == io_op ? {{31'd0}, _io_y_T_12} : _io_y_T_30; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_34 = 5'h8 == io_op ? {{31'd0}, _io_y_T_13} : _io_y_T_32; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_36 = 5'h9 == io_op ? {{31'd0}, _io_y_T_14} : _io_y_T_34; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_38 = 5'ha == io_op ? {{31'd0}, mulLow} : _io_y_T_36; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_40 = 5'hb == io_op ? {{31'd0}, mulHighSS} : _io_y_T_38; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_42 = 5'hc == io_op ? {{31'd0}, mulHighSU} : _io_y_T_40; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_44 = 5'hd == io_op ? {{31'd0}, mulHighUU} : _io_y_T_42; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_46 = 5'he == io_op ? {{31'd0}, _io_y_T_15} : _io_y_T_44; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_48 = 5'hf == io_op ? {{31'd0}, _io_y_T_16} : _io_y_T_46; // @[Mux.scala 81:58]
  wire [31:0] divResult = _GEN_1[31:0]; // @[ALU.scala 145:23]
  wire [62:0] _io_y_T_50 = 5'h10 == io_op ? {{31'd0}, divResult} : _io_y_T_48; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_52 = 5'h11 == io_op ? {{31'd0}, divuResult} : _io_y_T_50; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_54 = 5'h12 == io_op ? {{31'd0}, remResult} : _io_y_T_52; // @[Mux.scala 81:58]
  wire [62:0] _io_y_T_56 = 5'h13 == io_op ? {{31'd0}, remuResult} : _io_y_T_54; // @[Mux.scala 81:58]
  assign io_y = _io_y_T_56[31:0]; // @[ALU.scala 219:8]
endmodule
module PCUpdate(
  input         io_valid,
  input  [31:0] io_pc,
  input  [31:0] io_rs1,
  input  [31:0] io_rs2,
  input  [31:0] io_imm,
  input  [2:0]  io_funct3,
  input         io_branch,
  input         io_jump,
  input         io_jalr,
  output        io_redirect,
  output [31:0] io_redirectPC
);
  wire  _branchCondition_T = io_rs1 == io_rs2; // @[PCUpdate.scala 31:25]
  wire  _branchCondition_T_1 = io_rs1 != io_rs2; // @[PCUpdate.scala 32:25]
  wire  _branchCondition_T_4 = $signed(io_rs1) < $signed(io_rs2); // @[PCUpdate.scala 33:32]
  wire  _branchCondition_T_7 = $signed(io_rs1) >= $signed(io_rs2); // @[PCUpdate.scala 34:32]
  wire  _branchCondition_T_8 = io_rs1 < io_rs2; // @[PCUpdate.scala 35:25]
  wire  _branchCondition_T_9 = io_rs1 >= io_rs2; // @[PCUpdate.scala 36:25]
  wire  _branchCondition_T_13 = 3'h1 == io_funct3 ? _branchCondition_T_1 : 3'h0 == io_funct3 & _branchCondition_T; // @[Mux.scala 81:58]
  wire  _branchCondition_T_15 = 3'h4 == io_funct3 ? _branchCondition_T_4 : _branchCondition_T_13; // @[Mux.scala 81:58]
  wire  _branchCondition_T_17 = 3'h5 == io_funct3 ? _branchCondition_T_7 : _branchCondition_T_15; // @[Mux.scala 81:58]
  wire  _branchCondition_T_19 = 3'h6 == io_funct3 ? _branchCondition_T_8 : _branchCondition_T_17; // @[Mux.scala 81:58]
  wire  branchCondition = 3'h7 == io_funct3 ? _branchCondition_T_9 : _branchCondition_T_19; // @[Mux.scala 81:58]
  wire  takeBranch = io_valid & io_branch & branchCondition; // @[PCUpdate.scala 40:42]
  wire  takeJal = io_valid & io_jump; // @[PCUpdate.scala 41:29]
  wire  takeJalr = io_valid & io_jalr; // @[PCUpdate.scala 42:29]
  wire [31:0] pcTarget = io_pc + io_imm; // @[PCUpdate.scala 45:26]
  wire [31:0] _jalrTarget_T_1 = io_rs1 + io_imm; // @[PCUpdate.scala 46:28]
  wire [31:0] jalrTarget = _jalrTarget_T_1 & 32'hfffffffe; // @[PCUpdate.scala 46:38]
  assign io_redirect = takeBranch | takeJal | takeJalr; // @[PCUpdate.scala 49:43]
  assign io_redirectPC = takeJalr ? jalrTarget : pcTarget; // @[PCUpdate.scala 50:24]
endmodule
module EXStage(
  input         io_valid,
  input  [31:0] io_pc,
  input  [4:0]  io_rd,
  input  [31:0] io_rs1Data,
  input  [31:0] io_rs2Data,
  input  [31:0] io_imm,
  input  [2:0]  io_funct3,
  input  [4:0]  io_aluOp,
  input  [1:0]  io_aluASel,
  input         io_aluSrc,
  input         io_regWrite,
  input         io_memRead,
  input         io_memWrite,
  input         io_memToReg,
  input         io_branch,
  input         io_jump,
  input         io_jalr,
  input  [1:0]  io_forwardA,
  input  [1:0]  io_forwardB,
  input  [31:0] io_exmemForwardData,
  input  [31:0] io_memwbForwardData,
  output [31:0] io_aluResult,
  output [31:0] io_storeData,
  output [4:0]  io_rdOut,
  output [2:0]  io_funct3Out,
  output [31:0] io_pcPlus4,
  output        io_regWriteOut,
  output        io_memReadOut,
  output        io_memWriteOut,
  output        io_memToRegOut,
  output        io_linkOut,
  output        io_redirect,
  output [31:0] io_redirectPC,
  output [31:0] io_debugALU
);
  wire [31:0] alu_io_a; // @[EXStage.scala 65:24]
  wire [31:0] alu_io_b; // @[EXStage.scala 65:24]
  wire [4:0] alu_io_op; // @[EXStage.scala 65:24]
  wire [31:0] alu_io_y; // @[EXStage.scala 65:24]
  wire  pcUpdate_io_valid; // @[EXStage.scala 66:24]
  wire [31:0] pcUpdate_io_pc; // @[EXStage.scala 66:24]
  wire [31:0] pcUpdate_io_rs1; // @[EXStage.scala 66:24]
  wire [31:0] pcUpdate_io_rs2; // @[EXStage.scala 66:24]
  wire [31:0] pcUpdate_io_imm; // @[EXStage.scala 66:24]
  wire [2:0] pcUpdate_io_funct3; // @[EXStage.scala 66:24]
  wire  pcUpdate_io_branch; // @[EXStage.scala 66:24]
  wire  pcUpdate_io_jump; // @[EXStage.scala 66:24]
  wire  pcUpdate_io_jalr; // @[EXStage.scala 66:24]
  wire  pcUpdate_io_redirect; // @[EXStage.scala 66:24]
  wire [31:0] pcUpdate_io_redirectPC; // @[EXStage.scala 66:24]
  wire [31:0] _rs1Forwarded_T_1 = 2'h1 == io_forwardA ? io_memwbForwardData : io_rs1Data; // @[Mux.scala 81:58]
  wire [31:0] rs1Forwarded = 2'h2 == io_forwardA ? io_exmemForwardData : _rs1Forwarded_T_1; // @[Mux.scala 81:58]
  wire [31:0] _rs2Forwarded_T_1 = 2'h1 == io_forwardB ? io_memwbForwardData : io_rs2Data; // @[Mux.scala 81:58]
  wire [31:0] rs2Forwarded = 2'h2 == io_forwardB ? io_exmemForwardData : _rs2Forwarded_T_1; // @[Mux.scala 81:58]
  wire [31:0] _operandA_T_1 = 2'h1 == io_aluASel ? io_pc : rs1Forwarded; // @[Mux.scala 81:58]
  ALU alu ( // @[EXStage.scala 65:24]
    .io_a(alu_io_a),
    .io_b(alu_io_b),
    .io_op(alu_io_op),
    .io_y(alu_io_y)
  );
  PCUpdate pcUpdate ( // @[EXStage.scala 66:24]
    .io_valid(pcUpdate_io_valid),
    .io_pc(pcUpdate_io_pc),
    .io_rs1(pcUpdate_io_rs1),
    .io_rs2(pcUpdate_io_rs2),
    .io_imm(pcUpdate_io_imm),
    .io_funct3(pcUpdate_io_funct3),
    .io_branch(pcUpdate_io_branch),
    .io_jump(pcUpdate_io_jump),
    .io_jalr(pcUpdate_io_jalr),
    .io_redirect(pcUpdate_io_redirect),
    .io_redirectPC(pcUpdate_io_redirectPC)
  );
  assign io_aluResult = alu_io_y; // @[EXStage.scala 109:16]
  assign io_storeData = 2'h2 == io_forwardB ? io_exmemForwardData : _rs2Forwarded_T_1; // @[Mux.scala 81:58]
  assign io_rdOut = io_rd; // @[EXStage.scala 111:16]
  assign io_funct3Out = io_funct3; // @[EXStage.scala 112:16]
  assign io_pcPlus4 = io_pc + 32'h4; // @[EXStage.scala 113:25]
  assign io_regWriteOut = io_regWrite & io_valid; // @[EXStage.scala 116:33]
  assign io_memReadOut = io_memRead & io_valid; // @[EXStage.scala 117:33]
  assign io_memWriteOut = io_memWrite & io_valid; // @[EXStage.scala 118:33]
  assign io_memToRegOut = io_memToReg; // @[EXStage.scala 119:18]
  assign io_linkOut = (io_jump | io_jalr) & io_valid; // @[EXStage.scala 120:42]
  assign io_redirect = pcUpdate_io_redirect; // @[EXStage.scala 104:18]
  assign io_redirectPC = pcUpdate_io_redirectPC; // @[EXStage.scala 105:18]
  assign io_debugALU = alu_io_y; // @[EXStage.scala 123:20]
  assign alu_io_a = 2'h2 == io_aluASel ? 32'h0 : _operandA_T_1; // @[Mux.scala 81:58]
  assign alu_io_b = io_aluSrc ? io_imm : rs2Forwarded; // @[EXStage.scala 85:21]
  assign alu_io_op = io_aluOp; // @[EXStage.scala 90:13]
  assign pcUpdate_io_valid = io_valid; // @[EXStage.scala 93:22]
  assign pcUpdate_io_pc = io_pc; // @[EXStage.scala 94:22]
  assign pcUpdate_io_rs1 = 2'h2 == io_forwardA ? io_exmemForwardData : _rs1Forwarded_T_1; // @[Mux.scala 81:58]
  assign pcUpdate_io_rs2 = 2'h2 == io_forwardB ? io_exmemForwardData : _rs2Forwarded_T_1; // @[Mux.scala 81:58]
  assign pcUpdate_io_imm = io_imm; // @[EXStage.scala 97:22]
  assign pcUpdate_io_funct3 = io_funct3; // @[EXStage.scala 98:22]
  assign pcUpdate_io_branch = io_branch; // @[EXStage.scala 99:22]
  assign pcUpdate_io_jump = io_jump; // @[EXStage.scala 100:22]
  assign pcUpdate_io_jalr = io_jalr; // @[EXStage.scala 101:22]
endmodule
module MEMStage(
  input         io_valid,
  input  [31:0] io_aluResult,
  input  [31:0] io_storeData,
  input  [4:0]  io_rd,
  input  [2:0]  io_funct3,
  input  [31:0] io_pcPlus4,
  input         io_regWrite,
  input         io_memRead,
  input         io_memWrite,
  input         io_memToReg,
  input         io_link,
  output [31:0] io_memAddr,
  output [31:0] io_memWdata,
  output        io_memReadOut,
  output        io_memWriteOut,
  output [2:0]  io_memFunct3,
  input  [31:0] io_memRdata,
  output [31:0] io_memDataOut,
  output [31:0] io_aluResultOut,
  output [31:0] io_pcPlus4Out,
  output [4:0]  io_rdOut,
  output        io_regWriteOut,
  output        io_memToRegOut,
  output        io_linkOut
);
  assign io_memAddr = io_aluResult; // @[MEMStage.scala 35:18]
  assign io_memWdata = io_storeData; // @[MEMStage.scala 36:18]
  assign io_memReadOut = io_memRead & io_valid; // @[MEMStage.scala 38:32]
  assign io_memWriteOut = io_memWrite & io_valid; // @[MEMStage.scala 39:33]
  assign io_memFunct3 = io_funct3; // @[MEMStage.scala 37:18]
  assign io_memDataOut = io_memRdata; // @[MEMStage.scala 41:19]
  assign io_aluResultOut = io_aluResult; // @[MEMStage.scala 42:19]
  assign io_pcPlus4Out = io_pcPlus4; // @[MEMStage.scala 43:19]
  assign io_rdOut = io_rd; // @[MEMStage.scala 44:19]
  assign io_regWriteOut = io_regWrite & io_valid; // @[MEMStage.scala 45:34]
  assign io_memToRegOut = io_memToReg; // @[MEMStage.scala 46:19]
  assign io_linkOut = io_link; // @[MEMStage.scala 47:19]
endmodule
module WBStage(
  input         io_valid,
  input  [31:0] io_aluResult,
  input  [31:0] io_memData,
  input  [31:0] io_pcPlus4,
  input  [4:0]  io_rd,
  input         io_regWrite,
  input         io_memToReg,
  input         io_link,
  output [4:0]  io_writeRd,
  output [31:0] io_writeData,
  output        io_writeEnable
);
  wire [31:0] _io_writeData_T = io_memToReg ? io_memData : io_aluResult; // @[WBStage.scala 22:22]
  assign io_writeRd = io_rd; // @[WBStage.scala 24:18]
  assign io_writeData = io_link ? io_pcPlus4 : _io_writeData_T; // @[WBStage.scala 21:22]
  assign io_writeEnable = io_valid & io_regWrite & io_rd != 5'h0; // @[WBStage.scala 25:45]
endmodule
module ForwardingUnit(
  input  [4:0] io_idexRs1,
  input  [4:0] io_idexRs2,
  input  [4:0] io_exmemRd,
  input        io_exmemRegWrite,
  input        io_exmemValid,
  input  [4:0] io_memwbRd,
  input        io_memwbRegWrite,
  input        io_memwbValid,
  output [1:0] io_forwardA,
  output [1:0] io_forwardB
);
  wire  _T = io_exmemValid & io_exmemRegWrite; // @[ForwardingUnit.scala 43:19]
  wire  _T_1 = io_exmemRd != 5'h0; // @[ForwardingUnit.scala 45:17]
  wire  _T_2 = _T & _T_1; // @[ForwardingUnit.scala 44:22]
  wire  _T_3 = io_exmemRd == io_idexRs1; // @[ForwardingUnit.scala 46:17]
  wire  _T_4 = _T_2 & _T_3; // @[ForwardingUnit.scala 45:26]
  wire  _T_5 = io_memwbValid & io_memwbRegWrite; // @[ForwardingUnit.scala 53:19]
  wire  _T_6 = io_memwbRd != 5'h0; // @[ForwardingUnit.scala 55:17]
  wire  _T_7 = _T_5 & _T_6; // @[ForwardingUnit.scala 54:22]
  wire  _T_8 = io_memwbRd == io_idexRs1; // @[ForwardingUnit.scala 56:17]
  wire  _T_9 = _T_7 & _T_8; // @[ForwardingUnit.scala 55:26]
  wire  _T_13 = io_exmemRd == io_idexRs2; // @[ForwardingUnit.scala 70:17]
  wire  _T_14 = _T_2 & _T_13; // @[ForwardingUnit.scala 69:26]
  wire  _T_18 = io_memwbRd == io_idexRs2; // @[ForwardingUnit.scala 79:17]
  wire  _T_19 = _T_7 & _T_18; // @[ForwardingUnit.scala 78:26]
  assign io_forwardA = _T_4 ? 2'h2 : {{1'd0}, _T_9}; // @[ForwardingUnit.scala 47:5 50:17]
  assign io_forwardB = _T_14 ? 2'h2 : {{1'd0}, _T_19}; // @[ForwardingUnit.scala 71:5 73:17]
endmodule
module HazardDetectionUnit(
  input  [4:0] io_ifidRs1,
  input  [4:0] io_ifidRs2,
  input        io_ifidUsesRs1,
  input        io_ifidUsesRs2,
  input  [4:0] io_idexRd,
  input        io_idexMemRead,
  input        io_idexValid,
  output       io_stallPC,
  output       io_stallIFID,
  output       io_bubbleIDEX
);
  wire  _rs1Hazard_T = io_idexRd == io_ifidRs1; // @[HazardDetectionUnit.scala 49:16]
  wire  rs1Hazard = io_ifidUsesRs1 & _rs1Hazard_T; // @[HazardDetectionUnit.scala 48:20]
  wire  _rs2Hazard_T = io_idexRd == io_ifidRs2; // @[HazardDetectionUnit.scala 53:16]
  wire  rs2Hazard = io_ifidUsesRs2 & _rs2Hazard_T; // @[HazardDetectionUnit.scala 52:20]
  wire  _loadUseHazard_T = io_idexValid & io_idexMemRead; // @[HazardDetectionUnit.scala 56:18]
  wire  _loadUseHazard_T_1 = io_idexRd != 5'h0; // @[HazardDetectionUnit.scala 58:16]
  wire  _loadUseHazard_T_2 = _loadUseHazard_T & _loadUseHazard_T_1; // @[HazardDetectionUnit.scala 57:20]
  wire  _loadUseHazard_T_3 = rs1Hazard | rs2Hazard; // @[HazardDetectionUnit.scala 59:16]
  assign io_stallPC = _loadUseHazard_T_2 & _loadUseHazard_T_3; // @[HazardDetectionUnit.scala 58:25]
  assign io_stallIFID = _loadUseHazard_T_2 & _loadUseHazard_T_3; // @[HazardDetectionUnit.scala 58:25]
  assign io_bubbleIDEX = _loadUseHazard_T_2 & _loadUseHazard_T_3; // @[HazardDetectionUnit.scala 58:25]
endmodule
module RV32ICore(
  input         clock,
  input         reset,
  output [31:0] io_pc,
  output [31:0] io_nextPc,
  output [31:0] io_writeBack,
  output [31:0] io_debugInstr,
  output [31:0] io_debugX1,
  output [31:0] io_debugX2,
  output [31:0] io_debugX3,
  output [31:0] io_debugX4,
  output [31:0] io_debugX5,
  output [31:0] io_debugX6,
  output [31:0] io_debugALU,
  output [31:0] io_debugImm,
  output [31:0] io_debugFetchPC,
  output [31:0] io_debugDecodePC,
  output [31:0] io_debugExecPC,
  output [31:0] io_debugMemPC,
  output        io_debugValid,
  output        io_debugFlush,
  output        io_debugStall,
  output        io_debugIFIDValid,
  output        io_debugIDEXValid,
  output        io_debugEXMEMValid,
  output        io_debugMEMWBValid
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
  reg [31:0] _RAND_32;
  reg [31:0] _RAND_33;
  reg [31:0] _RAND_34;
  reg [31:0] _RAND_35;
  reg [31:0] _RAND_36;
  reg [31:0] _RAND_37;
  reg [31:0] _RAND_38;
  reg [31:0] _RAND_39;
  reg [31:0] _RAND_40;
  reg [31:0] _RAND_41;
  reg [31:0] _RAND_42;
  reg [31:0] _RAND_43;
`endif // RANDOMIZE_REG_INIT
  wire  instructionMemory_clock; // @[RV32ICore.scala 35:33]
  wire [31:0] instructionMemory_io_addr; // @[RV32ICore.scala 35:33]
  wire [31:0] instructionMemory_io_instr; // @[RV32ICore.scala 35:33]
  wire  dataMemory_clock; // @[RV32ICore.scala 36:33]
  wire [31:0] dataMemory_io_addr; // @[RV32ICore.scala 36:33]
  wire [31:0] dataMemory_io_wdata; // @[RV32ICore.scala 36:33]
  wire [31:0] dataMemory_io_rdata; // @[RV32ICore.scala 36:33]
  wire  dataMemory_io_memRead; // @[RV32ICore.scala 36:33]
  wire  dataMemory_io_memWrite; // @[RV32ICore.scala 36:33]
  wire [2:0] dataMemory_io_funct3; // @[RV32ICore.scala 36:33]
  wire  idStage_clock; // @[RV32ICore.scala 37:33]
  wire  idStage_reset; // @[RV32ICore.scala 37:33]
  wire  idStage_io_valid; // @[RV32ICore.scala 37:33]
  wire [31:0] idStage_io_instr; // @[RV32ICore.scala 37:33]
  wire [4:0] idStage_io_wbRd; // @[RV32ICore.scala 37:33]
  wire [31:0] idStage_io_wbWriteData; // @[RV32ICore.scala 37:33]
  wire  idStage_io_wbWriteEnable; // @[RV32ICore.scala 37:33]
  wire [4:0] idStage_io_rs1; // @[RV32ICore.scala 37:33]
  wire [4:0] idStage_io_rs2; // @[RV32ICore.scala 37:33]
  wire [4:0] idStage_io_rd; // @[RV32ICore.scala 37:33]
  wire [31:0] idStage_io_rs1Data; // @[RV32ICore.scala 37:33]
  wire [31:0] idStage_io_rs2Data; // @[RV32ICore.scala 37:33]
  wire [31:0] idStage_io_imm; // @[RV32ICore.scala 37:33]
  wire [2:0] idStage_io_funct3; // @[RV32ICore.scala 37:33]
  wire [4:0] idStage_io_aluOp; // @[RV32ICore.scala 37:33]
  wire [1:0] idStage_io_aluASel; // @[RV32ICore.scala 37:33]
  wire  idStage_io_aluSrc; // @[RV32ICore.scala 37:33]
  wire  idStage_io_regWrite; // @[RV32ICore.scala 37:33]
  wire  idStage_io_memRead; // @[RV32ICore.scala 37:33]
  wire  idStage_io_memWrite; // @[RV32ICore.scala 37:33]
  wire  idStage_io_memToReg; // @[RV32ICore.scala 37:33]
  wire  idStage_io_branch; // @[RV32ICore.scala 37:33]
  wire  idStage_io_jump; // @[RV32ICore.scala 37:33]
  wire  idStage_io_jalr; // @[RV32ICore.scala 37:33]
  wire  idStage_io_usesRs1; // @[RV32ICore.scala 37:33]
  wire  idStage_io_usesRs2; // @[RV32ICore.scala 37:33]
  wire [31:0] idStage_io_debugX1; // @[RV32ICore.scala 37:33]
  wire [31:0] idStage_io_debugX2; // @[RV32ICore.scala 37:33]
  wire [31:0] idStage_io_debugX3; // @[RV32ICore.scala 37:33]
  wire [31:0] idStage_io_debugX4; // @[RV32ICore.scala 37:33]
  wire [31:0] idStage_io_debugX5; // @[RV32ICore.scala 37:33]
  wire [31:0] idStage_io_debugX6; // @[RV32ICore.scala 37:33]
  wire  exStage_io_valid; // @[RV32ICore.scala 38:33]
  wire [31:0] exStage_io_pc; // @[RV32ICore.scala 38:33]
  wire [4:0] exStage_io_rd; // @[RV32ICore.scala 38:33]
  wire [31:0] exStage_io_rs1Data; // @[RV32ICore.scala 38:33]
  wire [31:0] exStage_io_rs2Data; // @[RV32ICore.scala 38:33]
  wire [31:0] exStage_io_imm; // @[RV32ICore.scala 38:33]
  wire [2:0] exStage_io_funct3; // @[RV32ICore.scala 38:33]
  wire [4:0] exStage_io_aluOp; // @[RV32ICore.scala 38:33]
  wire [1:0] exStage_io_aluASel; // @[RV32ICore.scala 38:33]
  wire  exStage_io_aluSrc; // @[RV32ICore.scala 38:33]
  wire  exStage_io_regWrite; // @[RV32ICore.scala 38:33]
  wire  exStage_io_memRead; // @[RV32ICore.scala 38:33]
  wire  exStage_io_memWrite; // @[RV32ICore.scala 38:33]
  wire  exStage_io_memToReg; // @[RV32ICore.scala 38:33]
  wire  exStage_io_branch; // @[RV32ICore.scala 38:33]
  wire  exStage_io_jump; // @[RV32ICore.scala 38:33]
  wire  exStage_io_jalr; // @[RV32ICore.scala 38:33]
  wire [1:0] exStage_io_forwardA; // @[RV32ICore.scala 38:33]
  wire [1:0] exStage_io_forwardB; // @[RV32ICore.scala 38:33]
  wire [31:0] exStage_io_exmemForwardData; // @[RV32ICore.scala 38:33]
  wire [31:0] exStage_io_memwbForwardData; // @[RV32ICore.scala 38:33]
  wire [31:0] exStage_io_aluResult; // @[RV32ICore.scala 38:33]
  wire [31:0] exStage_io_storeData; // @[RV32ICore.scala 38:33]
  wire [4:0] exStage_io_rdOut; // @[RV32ICore.scala 38:33]
  wire [2:0] exStage_io_funct3Out; // @[RV32ICore.scala 38:33]
  wire [31:0] exStage_io_pcPlus4; // @[RV32ICore.scala 38:33]
  wire  exStage_io_regWriteOut; // @[RV32ICore.scala 38:33]
  wire  exStage_io_memReadOut; // @[RV32ICore.scala 38:33]
  wire  exStage_io_memWriteOut; // @[RV32ICore.scala 38:33]
  wire  exStage_io_memToRegOut; // @[RV32ICore.scala 38:33]
  wire  exStage_io_linkOut; // @[RV32ICore.scala 38:33]
  wire  exStage_io_redirect; // @[RV32ICore.scala 38:33]
  wire [31:0] exStage_io_redirectPC; // @[RV32ICore.scala 38:33]
  wire [31:0] exStage_io_debugALU; // @[RV32ICore.scala 38:33]
  wire  memStage_io_valid; // @[RV32ICore.scala 39:33]
  wire [31:0] memStage_io_aluResult; // @[RV32ICore.scala 39:33]
  wire [31:0] memStage_io_storeData; // @[RV32ICore.scala 39:33]
  wire [4:0] memStage_io_rd; // @[RV32ICore.scala 39:33]
  wire [2:0] memStage_io_funct3; // @[RV32ICore.scala 39:33]
  wire [31:0] memStage_io_pcPlus4; // @[RV32ICore.scala 39:33]
  wire  memStage_io_regWrite; // @[RV32ICore.scala 39:33]
  wire  memStage_io_memRead; // @[RV32ICore.scala 39:33]
  wire  memStage_io_memWrite; // @[RV32ICore.scala 39:33]
  wire  memStage_io_memToReg; // @[RV32ICore.scala 39:33]
  wire  memStage_io_link; // @[RV32ICore.scala 39:33]
  wire [31:0] memStage_io_memAddr; // @[RV32ICore.scala 39:33]
  wire [31:0] memStage_io_memWdata; // @[RV32ICore.scala 39:33]
  wire  memStage_io_memReadOut; // @[RV32ICore.scala 39:33]
  wire  memStage_io_memWriteOut; // @[RV32ICore.scala 39:33]
  wire [2:0] memStage_io_memFunct3; // @[RV32ICore.scala 39:33]
  wire [31:0] memStage_io_memRdata; // @[RV32ICore.scala 39:33]
  wire [31:0] memStage_io_memDataOut; // @[RV32ICore.scala 39:33]
  wire [31:0] memStage_io_aluResultOut; // @[RV32ICore.scala 39:33]
  wire [31:0] memStage_io_pcPlus4Out; // @[RV32ICore.scala 39:33]
  wire [4:0] memStage_io_rdOut; // @[RV32ICore.scala 39:33]
  wire  memStage_io_regWriteOut; // @[RV32ICore.scala 39:33]
  wire  memStage_io_memToRegOut; // @[RV32ICore.scala 39:33]
  wire  memStage_io_linkOut; // @[RV32ICore.scala 39:33]
  wire  wbStage_io_valid; // @[RV32ICore.scala 40:33]
  wire [31:0] wbStage_io_aluResult; // @[RV32ICore.scala 40:33]
  wire [31:0] wbStage_io_memData; // @[RV32ICore.scala 40:33]
  wire [31:0] wbStage_io_pcPlus4; // @[RV32ICore.scala 40:33]
  wire [4:0] wbStage_io_rd; // @[RV32ICore.scala 40:33]
  wire  wbStage_io_regWrite; // @[RV32ICore.scala 40:33]
  wire  wbStage_io_memToReg; // @[RV32ICore.scala 40:33]
  wire  wbStage_io_link; // @[RV32ICore.scala 40:33]
  wire [4:0] wbStage_io_writeRd; // @[RV32ICore.scala 40:33]
  wire [31:0] wbStage_io_writeData; // @[RV32ICore.scala 40:33]
  wire  wbStage_io_writeEnable; // @[RV32ICore.scala 40:33]
  wire [4:0] forwardingUnit_io_idexRs1; // @[RV32ICore.scala 41:33]
  wire [4:0] forwardingUnit_io_idexRs2; // @[RV32ICore.scala 41:33]
  wire [4:0] forwardingUnit_io_exmemRd; // @[RV32ICore.scala 41:33]
  wire  forwardingUnit_io_exmemRegWrite; // @[RV32ICore.scala 41:33]
  wire  forwardingUnit_io_exmemValid; // @[RV32ICore.scala 41:33]
  wire [4:0] forwardingUnit_io_memwbRd; // @[RV32ICore.scala 41:33]
  wire  forwardingUnit_io_memwbRegWrite; // @[RV32ICore.scala 41:33]
  wire  forwardingUnit_io_memwbValid; // @[RV32ICore.scala 41:33]
  wire [1:0] forwardingUnit_io_forwardA; // @[RV32ICore.scala 41:33]
  wire [1:0] forwardingUnit_io_forwardB; // @[RV32ICore.scala 41:33]
  wire [4:0] hazardUnit_io_ifidRs1; // @[RV32ICore.scala 42:33]
  wire [4:0] hazardUnit_io_ifidRs2; // @[RV32ICore.scala 42:33]
  wire  hazardUnit_io_ifidUsesRs1; // @[RV32ICore.scala 42:33]
  wire  hazardUnit_io_ifidUsesRs2; // @[RV32ICore.scala 42:33]
  wire [4:0] hazardUnit_io_idexRd; // @[RV32ICore.scala 42:33]
  wire  hazardUnit_io_idexMemRead; // @[RV32ICore.scala 42:33]
  wire  hazardUnit_io_idexValid; // @[RV32ICore.scala 42:33]
  wire  hazardUnit_io_stallPC; // @[RV32ICore.scala 42:33]
  wire  hazardUnit_io_stallIFID; // @[RV32ICore.scala 42:33]
  wire  hazardUnit_io_bubbleIDEX; // @[RV32ICore.scala 42:33]
  reg [31:0] pcReg; // @[RV32ICore.scala 45:22]
  wire [31:0] sequentialPC = pcReg + 32'h4; // @[RV32ICore.scala 46:28]
  reg  ifidValid; // @[RV32ICore.scala 49:26]
  reg [31:0] ifidPC; // @[RV32ICore.scala 50:26]
  reg [31:0] ifidInstr; // @[RV32ICore.scala 51:26]
  reg  idexValid; // @[RV32ICore.scala 54:30]
  reg [31:0] idexPC; // @[RV32ICore.scala 55:30]
  reg [31:0] idexInstr; // @[RV32ICore.scala 56:30]
  reg [4:0] idexRs1; // @[RV32ICore.scala 57:30]
  reg [4:0] idexRs2; // @[RV32ICore.scala 58:30]
  reg [4:0] idexRd; // @[RV32ICore.scala 59:30]
  reg [31:0] idexRs1Data; // @[RV32ICore.scala 60:30]
  reg [31:0] idexRs2Data; // @[RV32ICore.scala 61:30]
  reg [31:0] idexImm; // @[RV32ICore.scala 62:30]
  reg [2:0] idexFunct3; // @[RV32ICore.scala 63:30]
  reg [4:0] idexAluOp; // @[RV32ICore.scala 64:30]
  reg [1:0] idexAluASel; // @[RV32ICore.scala 65:30]
  reg  idexAluSrc; // @[RV32ICore.scala 66:30]
  reg  idexRegWrite; // @[RV32ICore.scala 67:30]
  reg  idexMemRead; // @[RV32ICore.scala 68:30]
  reg  idexMemWrite; // @[RV32ICore.scala 69:30]
  reg  idexMemToReg; // @[RV32ICore.scala 70:30]
  reg  idexBranch; // @[RV32ICore.scala 71:30]
  reg  idexJump; // @[RV32ICore.scala 72:30]
  reg  idexJalr; // @[RV32ICore.scala 73:30]
  reg  exmemValid; // @[RV32ICore.scala 76:31]
  reg [31:0] exmemPC; // @[RV32ICore.scala 77:31]
  reg [31:0] exmemAluResult; // @[RV32ICore.scala 78:31]
  reg [31:0] exmemStoreData; // @[RV32ICore.scala 79:31]
  reg [4:0] exmemRd; // @[RV32ICore.scala 80:31]
  reg [2:0] exmemFunct3; // @[RV32ICore.scala 81:31]
  reg [31:0] exmemPCPlus4; // @[RV32ICore.scala 82:31]
  reg  exmemRegWrite; // @[RV32ICore.scala 83:31]
  reg  exmemMemRead; // @[RV32ICore.scala 84:31]
  reg  exmemMemWrite; // @[RV32ICore.scala 85:31]
  reg  exmemMemToReg; // @[RV32ICore.scala 86:31]
  reg  exmemLink; // @[RV32ICore.scala 87:31]
  reg  memwbValid; // @[RV32ICore.scala 90:31]
  reg [31:0] memwbAluResult; // @[RV32ICore.scala 91:31]
  reg [31:0] memwbMemData; // @[RV32ICore.scala 92:31]
  reg [31:0] memwbPCPlus4; // @[RV32ICore.scala 93:31]
  reg [4:0] memwbRd; // @[RV32ICore.scala 94:31]
  reg  memwbRegWrite; // @[RV32ICore.scala 95:31]
  reg  memwbMemToReg; // @[RV32ICore.scala 96:31]
  reg  memwbLink; // @[RV32ICore.scala 97:31]
  wire  _GEN_2 = ~hazardUnit_io_stallIFID | ifidValid; // @[RV32ICore.scala 205:40 206:15 49:26]
  wire [31:0] _io_nextPc_T = hazardUnit_io_stallPC ? pcReg : sequentialPC; // @[RV32ICore.scala 283:24]
  InstructionMemory instructionMemory ( // @[RV32ICore.scala 35:33]
    .clock(instructionMemory_clock),
    .io_addr(instructionMemory_io_addr),
    .io_instr(instructionMemory_io_instr)
  );
  DataMemory dataMemory ( // @[RV32ICore.scala 36:33]
    .clock(dataMemory_clock),
    .io_addr(dataMemory_io_addr),
    .io_wdata(dataMemory_io_wdata),
    .io_rdata(dataMemory_io_rdata),
    .io_memRead(dataMemory_io_memRead),
    .io_memWrite(dataMemory_io_memWrite),
    .io_funct3(dataMemory_io_funct3)
  );
  IDStage idStage ( // @[RV32ICore.scala 37:33]
    .clock(idStage_clock),
    .reset(idStage_reset),
    .io_valid(idStage_io_valid),
    .io_instr(idStage_io_instr),
    .io_wbRd(idStage_io_wbRd),
    .io_wbWriteData(idStage_io_wbWriteData),
    .io_wbWriteEnable(idStage_io_wbWriteEnable),
    .io_rs1(idStage_io_rs1),
    .io_rs2(idStage_io_rs2),
    .io_rd(idStage_io_rd),
    .io_rs1Data(idStage_io_rs1Data),
    .io_rs2Data(idStage_io_rs2Data),
    .io_imm(idStage_io_imm),
    .io_funct3(idStage_io_funct3),
    .io_aluOp(idStage_io_aluOp),
    .io_aluASel(idStage_io_aluASel),
    .io_aluSrc(idStage_io_aluSrc),
    .io_regWrite(idStage_io_regWrite),
    .io_memRead(idStage_io_memRead),
    .io_memWrite(idStage_io_memWrite),
    .io_memToReg(idStage_io_memToReg),
    .io_branch(idStage_io_branch),
    .io_jump(idStage_io_jump),
    .io_jalr(idStage_io_jalr),
    .io_usesRs1(idStage_io_usesRs1),
    .io_usesRs2(idStage_io_usesRs2),
    .io_debugX1(idStage_io_debugX1),
    .io_debugX2(idStage_io_debugX2),
    .io_debugX3(idStage_io_debugX3),
    .io_debugX4(idStage_io_debugX4),
    .io_debugX5(idStage_io_debugX5),
    .io_debugX6(idStage_io_debugX6)
  );
  EXStage exStage ( // @[RV32ICore.scala 38:33]
    .io_valid(exStage_io_valid),
    .io_pc(exStage_io_pc),
    .io_rd(exStage_io_rd),
    .io_rs1Data(exStage_io_rs1Data),
    .io_rs2Data(exStage_io_rs2Data),
    .io_imm(exStage_io_imm),
    .io_funct3(exStage_io_funct3),
    .io_aluOp(exStage_io_aluOp),
    .io_aluASel(exStage_io_aluASel),
    .io_aluSrc(exStage_io_aluSrc),
    .io_regWrite(exStage_io_regWrite),
    .io_memRead(exStage_io_memRead),
    .io_memWrite(exStage_io_memWrite),
    .io_memToReg(exStage_io_memToReg),
    .io_branch(exStage_io_branch),
    .io_jump(exStage_io_jump),
    .io_jalr(exStage_io_jalr),
    .io_forwardA(exStage_io_forwardA),
    .io_forwardB(exStage_io_forwardB),
    .io_exmemForwardData(exStage_io_exmemForwardData),
    .io_memwbForwardData(exStage_io_memwbForwardData),
    .io_aluResult(exStage_io_aluResult),
    .io_storeData(exStage_io_storeData),
    .io_rdOut(exStage_io_rdOut),
    .io_funct3Out(exStage_io_funct3Out),
    .io_pcPlus4(exStage_io_pcPlus4),
    .io_regWriteOut(exStage_io_regWriteOut),
    .io_memReadOut(exStage_io_memReadOut),
    .io_memWriteOut(exStage_io_memWriteOut),
    .io_memToRegOut(exStage_io_memToRegOut),
    .io_linkOut(exStage_io_linkOut),
    .io_redirect(exStage_io_redirect),
    .io_redirectPC(exStage_io_redirectPC),
    .io_debugALU(exStage_io_debugALU)
  );
  MEMStage memStage ( // @[RV32ICore.scala 39:33]
    .io_valid(memStage_io_valid),
    .io_aluResult(memStage_io_aluResult),
    .io_storeData(memStage_io_storeData),
    .io_rd(memStage_io_rd),
    .io_funct3(memStage_io_funct3),
    .io_pcPlus4(memStage_io_pcPlus4),
    .io_regWrite(memStage_io_regWrite),
    .io_memRead(memStage_io_memRead),
    .io_memWrite(memStage_io_memWrite),
    .io_memToReg(memStage_io_memToReg),
    .io_link(memStage_io_link),
    .io_memAddr(memStage_io_memAddr),
    .io_memWdata(memStage_io_memWdata),
    .io_memReadOut(memStage_io_memReadOut),
    .io_memWriteOut(memStage_io_memWriteOut),
    .io_memFunct3(memStage_io_memFunct3),
    .io_memRdata(memStage_io_memRdata),
    .io_memDataOut(memStage_io_memDataOut),
    .io_aluResultOut(memStage_io_aluResultOut),
    .io_pcPlus4Out(memStage_io_pcPlus4Out),
    .io_rdOut(memStage_io_rdOut),
    .io_regWriteOut(memStage_io_regWriteOut),
    .io_memToRegOut(memStage_io_memToRegOut),
    .io_linkOut(memStage_io_linkOut)
  );
  WBStage wbStage ( // @[RV32ICore.scala 40:33]
    .io_valid(wbStage_io_valid),
    .io_aluResult(wbStage_io_aluResult),
    .io_memData(wbStage_io_memData),
    .io_pcPlus4(wbStage_io_pcPlus4),
    .io_rd(wbStage_io_rd),
    .io_regWrite(wbStage_io_regWrite),
    .io_memToReg(wbStage_io_memToReg),
    .io_link(wbStage_io_link),
    .io_writeRd(wbStage_io_writeRd),
    .io_writeData(wbStage_io_writeData),
    .io_writeEnable(wbStage_io_writeEnable)
  );
  ForwardingUnit forwardingUnit ( // @[RV32ICore.scala 41:33]
    .io_idexRs1(forwardingUnit_io_idexRs1),
    .io_idexRs2(forwardingUnit_io_idexRs2),
    .io_exmemRd(forwardingUnit_io_exmemRd),
    .io_exmemRegWrite(forwardingUnit_io_exmemRegWrite),
    .io_exmemValid(forwardingUnit_io_exmemValid),
    .io_memwbRd(forwardingUnit_io_memwbRd),
    .io_memwbRegWrite(forwardingUnit_io_memwbRegWrite),
    .io_memwbValid(forwardingUnit_io_memwbValid),
    .io_forwardA(forwardingUnit_io_forwardA),
    .io_forwardB(forwardingUnit_io_forwardB)
  );
  HazardDetectionUnit hazardUnit ( // @[RV32ICore.scala 42:33]
    .io_ifidRs1(hazardUnit_io_ifidRs1),
    .io_ifidRs2(hazardUnit_io_ifidRs2),
    .io_ifidUsesRs1(hazardUnit_io_ifidUsesRs1),
    .io_ifidUsesRs2(hazardUnit_io_ifidUsesRs2),
    .io_idexRd(hazardUnit_io_idexRd),
    .io_idexMemRead(hazardUnit_io_idexMemRead),
    .io_idexValid(hazardUnit_io_idexValid),
    .io_stallPC(hazardUnit_io_stallPC),
    .io_stallIFID(hazardUnit_io_stallIFID),
    .io_bubbleIDEX(hazardUnit_io_bubbleIDEX)
  );
  assign io_pc = pcReg; // @[RV32ICore.scala 281:16]
  assign io_nextPc = exStage_io_redirect ? exStage_io_redirectPC : _io_nextPc_T; // @[RV32ICore.scala 282:22]
  assign io_writeBack = wbStage_io_writeEnable ? wbStage_io_writeData : 32'h0; // @[RV32ICore.scala 284:22]
  assign io_debugInstr = idexInstr; // @[RV32ICore.scala 287:17]
  assign io_debugX1 = idStage_io_debugX1; // @[RV32ICore.scala 288:17]
  assign io_debugX2 = idStage_io_debugX2; // @[RV32ICore.scala 289:17]
  assign io_debugX3 = idStage_io_debugX3; // @[RV32ICore.scala 290:17]
  assign io_debugX4 = idStage_io_debugX4; // @[RV32ICore.scala 291:17]
  assign io_debugX5 = idStage_io_debugX5; // @[RV32ICore.scala 292:17]
  assign io_debugX6 = idStage_io_debugX6; // @[RV32ICore.scala 293:17]
  assign io_debugALU = exStage_io_debugALU; // @[RV32ICore.scala 294:17]
  assign io_debugImm = idexImm; // @[RV32ICore.scala 295:17]
  assign io_debugFetchPC = pcReg; // @[RV32ICore.scala 297:22]
  assign io_debugDecodePC = ifidPC; // @[RV32ICore.scala 298:22]
  assign io_debugExecPC = idexPC; // @[RV32ICore.scala 299:22]
  assign io_debugMemPC = exmemPC; // @[RV32ICore.scala 300:22]
  assign io_debugValid = idexValid; // @[RV32ICore.scala 301:22]
  assign io_debugFlush = exStage_io_redirect; // @[RV32ICore.scala 302:22]
  assign io_debugStall = hazardUnit_io_stallPC; // @[RV32ICore.scala 303:22]
  assign io_debugIFIDValid = ifidValid; // @[RV32ICore.scala 304:22]
  assign io_debugIDEXValid = idexValid; // @[RV32ICore.scala 305:22]
  assign io_debugEXMEMValid = exmemValid; // @[RV32ICore.scala 306:22]
  assign io_debugMEMWBValid = memwbValid; // @[RV32ICore.scala 307:22]
  assign instructionMemory_clock = clock;
  assign instructionMemory_io_addr = pcReg; // @[RV32ICore.scala 100:29]
  assign dataMemory_clock = clock;
  assign dataMemory_io_addr = memStage_io_memAddr; // @[RV32ICore.scala 186:26]
  assign dataMemory_io_wdata = memStage_io_memWdata; // @[RV32ICore.scala 187:26]
  assign dataMemory_io_memRead = memStage_io_memReadOut; // @[RV32ICore.scala 188:26]
  assign dataMemory_io_memWrite = memStage_io_memWriteOut; // @[RV32ICore.scala 189:26]
  assign dataMemory_io_funct3 = memStage_io_memFunct3; // @[RV32ICore.scala 190:26]
  assign idStage_clock = clock;
  assign idStage_reset = reset;
  assign idStage_io_valid = ifidValid; // @[RV32ICore.scala 116:28]
  assign idStage_io_instr = ifidInstr; // @[RV32ICore.scala 118:28]
  assign idStage_io_wbRd = wbStage_io_writeRd; // @[RV32ICore.scala 119:28]
  assign idStage_io_wbWriteData = wbStage_io_writeData; // @[RV32ICore.scala 120:28]
  assign idStage_io_wbWriteEnable = wbStage_io_writeEnable; // @[RV32ICore.scala 121:28]
  assign exStage_io_valid = idexValid; // @[RV32ICore.scala 143:24]
  assign exStage_io_pc = idexPC; // @[RV32ICore.scala 144:24]
  assign exStage_io_rd = idexRd; // @[RV32ICore.scala 147:24]
  assign exStage_io_rs1Data = idexRs1Data; // @[RV32ICore.scala 148:24]
  assign exStage_io_rs2Data = idexRs2Data; // @[RV32ICore.scala 149:24]
  assign exStage_io_imm = idexImm; // @[RV32ICore.scala 150:24]
  assign exStage_io_funct3 = idexFunct3; // @[RV32ICore.scala 151:24]
  assign exStage_io_aluOp = idexAluOp; // @[RV32ICore.scala 152:24]
  assign exStage_io_aluASel = idexAluASel; // @[RV32ICore.scala 153:24]
  assign exStage_io_aluSrc = idexAluSrc; // @[RV32ICore.scala 154:24]
  assign exStage_io_regWrite = idexRegWrite; // @[RV32ICore.scala 155:24]
  assign exStage_io_memRead = idexMemRead; // @[RV32ICore.scala 156:24]
  assign exStage_io_memWrite = idexMemWrite; // @[RV32ICore.scala 157:24]
  assign exStage_io_memToReg = idexMemToReg; // @[RV32ICore.scala 158:24]
  assign exStage_io_branch = idexBranch; // @[RV32ICore.scala 159:24]
  assign exStage_io_jump = idexJump; // @[RV32ICore.scala 160:24]
  assign exStage_io_jalr = idexJalr; // @[RV32ICore.scala 161:24]
  assign exStage_io_forwardA = forwardingUnit_io_forwardA; // @[RV32ICore.scala 162:24]
  assign exStage_io_forwardB = forwardingUnit_io_forwardB; // @[RV32ICore.scala 163:24]
  assign exStage_io_exmemForwardData = exmemLink ? exmemPCPlus4 : exmemAluResult; // @[RV32ICore.scala 166:8]
  assign exStage_io_memwbForwardData = wbStage_io_writeData; // @[RV32ICore.scala 167:31]
  assign memStage_io_valid = exmemValid; // @[RV32ICore.scala 173:25]
  assign memStage_io_aluResult = exmemAluResult; // @[RV32ICore.scala 174:25]
  assign memStage_io_storeData = exmemStoreData; // @[RV32ICore.scala 175:25]
  assign memStage_io_rd = exmemRd; // @[RV32ICore.scala 176:25]
  assign memStage_io_funct3 = exmemFunct3; // @[RV32ICore.scala 177:25]
  assign memStage_io_pcPlus4 = exmemPCPlus4; // @[RV32ICore.scala 178:25]
  assign memStage_io_regWrite = exmemRegWrite; // @[RV32ICore.scala 179:25]
  assign memStage_io_memRead = exmemMemRead; // @[RV32ICore.scala 180:25]
  assign memStage_io_memWrite = exmemMemWrite; // @[RV32ICore.scala 181:25]
  assign memStage_io_memToReg = exmemMemToReg; // @[RV32ICore.scala 182:25]
  assign memStage_io_link = exmemLink; // @[RV32ICore.scala 183:25]
  assign memStage_io_memRdata = dataMemory_io_rdata; // @[RV32ICore.scala 191:26]
  assign wbStage_io_valid = memwbValid; // @[RV32ICore.scala 104:24]
  assign wbStage_io_aluResult = memwbAluResult; // @[RV32ICore.scala 105:24]
  assign wbStage_io_memData = memwbMemData; // @[RV32ICore.scala 106:24]
  assign wbStage_io_pcPlus4 = memwbPCPlus4; // @[RV32ICore.scala 107:24]
  assign wbStage_io_rd = memwbRd; // @[RV32ICore.scala 108:24]
  assign wbStage_io_regWrite = memwbRegWrite; // @[RV32ICore.scala 109:24]
  assign wbStage_io_memToReg = memwbMemToReg; // @[RV32ICore.scala 110:24]
  assign wbStage_io_link = memwbLink; // @[RV32ICore.scala 111:24]
  assign forwardingUnit_io_idexRs1 = idexRs1; // @[RV32ICore.scala 133:36]
  assign forwardingUnit_io_idexRs2 = idexRs2; // @[RV32ICore.scala 134:36]
  assign forwardingUnit_io_exmemRd = exmemRd; // @[RV32ICore.scala 135:36]
  assign forwardingUnit_io_exmemRegWrite = exmemRegWrite; // @[RV32ICore.scala 136:36]
  assign forwardingUnit_io_exmemValid = exmemValid; // @[RV32ICore.scala 137:36]
  assign forwardingUnit_io_memwbRd = memwbRd; // @[RV32ICore.scala 138:36]
  assign forwardingUnit_io_memwbRegWrite = memwbRegWrite; // @[RV32ICore.scala 139:36]
  assign forwardingUnit_io_memwbValid = memwbValid; // @[RV32ICore.scala 140:36]
  assign hazardUnit_io_ifidRs1 = idStage_io_rs1; // @[RV32ICore.scala 124:29]
  assign hazardUnit_io_ifidRs2 = idStage_io_rs2; // @[RV32ICore.scala 125:29]
  assign hazardUnit_io_ifidUsesRs1 = idStage_io_usesRs1; // @[RV32ICore.scala 126:29]
  assign hazardUnit_io_ifidUsesRs2 = idStage_io_usesRs2; // @[RV32ICore.scala 127:29]
  assign hazardUnit_io_idexRd = idexRd; // @[RV32ICore.scala 128:29]
  assign hazardUnit_io_idexMemRead = idexMemRead; // @[RV32ICore.scala 129:29]
  assign hazardUnit_io_idexValid = idexValid; // @[RV32ICore.scala 130:29]
  always @(posedge clock) begin
    if (reset) begin // @[RV32ICore.scala 45:22]
      pcReg <= 32'h0; // @[RV32ICore.scala 45:22]
    end else if (exStage_io_redirect) begin // @[RV32ICore.scala 194:18]
      pcReg <= exStage_io_redirectPC; // @[RV32ICore.scala 195:11]
    end else if (~hazardUnit_io_stallPC) begin // @[RV32ICore.scala 196:38]
      pcReg <= sequentialPC; // @[RV32ICore.scala 197:11]
    end
    if (reset) begin // @[RV32ICore.scala 49:26]
      ifidValid <= 1'h0; // @[RV32ICore.scala 49:26]
    end else if (exStage_io_redirect) begin // @[RV32ICore.scala 201:18]
      ifidValid <= 1'h0; // @[RV32ICore.scala 202:15]
    end else begin
      ifidValid <= _GEN_2;
    end
    if (reset) begin // @[RV32ICore.scala 50:26]
      ifidPC <= 32'h0; // @[RV32ICore.scala 50:26]
    end else if (exStage_io_redirect) begin // @[RV32ICore.scala 201:18]
      ifidPC <= 32'h0; // @[RV32ICore.scala 203:15]
    end else if (~hazardUnit_io_stallIFID) begin // @[RV32ICore.scala 205:40]
      ifidPC <= pcReg; // @[RV32ICore.scala 207:15]
    end
    if (reset) begin // @[RV32ICore.scala 51:26]
      ifidInstr <= 32'h13; // @[RV32ICore.scala 51:26]
    end else if (exStage_io_redirect) begin // @[RV32ICore.scala 201:18]
      ifidInstr <= 32'h13; // @[RV32ICore.scala 204:15]
    end else if (~hazardUnit_io_stallIFID) begin // @[RV32ICore.scala 205:40]
      ifidInstr <= instructionMemory_io_instr; // @[RV32ICore.scala 208:15]
    end
    if (reset) begin // @[RV32ICore.scala 54:30]
      idexValid <= 1'h0; // @[RV32ICore.scala 54:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexValid <= 1'h0; // @[RV32ICore.scala 213:18]
    end else begin
      idexValid <= ifidValid & idStage_io_valid; // @[RV32ICore.scala 234:18]
    end
    if (reset) begin // @[RV32ICore.scala 55:30]
      idexPC <= 32'h0; // @[RV32ICore.scala 55:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexPC <= 32'h0; // @[RV32ICore.scala 214:18]
    end else begin
      idexPC <= ifidPC; // @[RV32ICore.scala 235:18]
    end
    if (reset) begin // @[RV32ICore.scala 56:30]
      idexInstr <= 32'h13; // @[RV32ICore.scala 56:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexInstr <= 32'h13; // @[RV32ICore.scala 215:18]
    end else begin
      idexInstr <= ifidInstr; // @[RV32ICore.scala 236:18]
    end
    if (reset) begin // @[RV32ICore.scala 57:30]
      idexRs1 <= 5'h0; // @[RV32ICore.scala 57:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexRs1 <= 5'h0; // @[RV32ICore.scala 216:18]
    end else begin
      idexRs1 <= idStage_io_rs1; // @[RV32ICore.scala 237:18]
    end
    if (reset) begin // @[RV32ICore.scala 58:30]
      idexRs2 <= 5'h0; // @[RV32ICore.scala 58:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexRs2 <= 5'h0; // @[RV32ICore.scala 217:18]
    end else begin
      idexRs2 <= idStage_io_rs2; // @[RV32ICore.scala 238:18]
    end
    if (reset) begin // @[RV32ICore.scala 59:30]
      idexRd <= 5'h0; // @[RV32ICore.scala 59:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexRd <= 5'h0; // @[RV32ICore.scala 218:18]
    end else begin
      idexRd <= idStage_io_rd; // @[RV32ICore.scala 239:18]
    end
    if (reset) begin // @[RV32ICore.scala 60:30]
      idexRs1Data <= 32'h0; // @[RV32ICore.scala 60:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexRs1Data <= 32'h0; // @[RV32ICore.scala 219:18]
    end else begin
      idexRs1Data <= idStage_io_rs1Data; // @[RV32ICore.scala 240:18]
    end
    if (reset) begin // @[RV32ICore.scala 61:30]
      idexRs2Data <= 32'h0; // @[RV32ICore.scala 61:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexRs2Data <= 32'h0; // @[RV32ICore.scala 220:18]
    end else begin
      idexRs2Data <= idStage_io_rs2Data; // @[RV32ICore.scala 241:18]
    end
    if (reset) begin // @[RV32ICore.scala 62:30]
      idexImm <= 32'h0; // @[RV32ICore.scala 62:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexImm <= 32'h0; // @[RV32ICore.scala 221:18]
    end else begin
      idexImm <= idStage_io_imm; // @[RV32ICore.scala 242:18]
    end
    if (reset) begin // @[RV32ICore.scala 63:30]
      idexFunct3 <= 3'h0; // @[RV32ICore.scala 63:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexFunct3 <= 3'h0; // @[RV32ICore.scala 222:18]
    end else begin
      idexFunct3 <= idStage_io_funct3; // @[RV32ICore.scala 243:18]
    end
    if (reset) begin // @[RV32ICore.scala 64:30]
      idexAluOp <= 5'h0; // @[RV32ICore.scala 64:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexAluOp <= 5'h0; // @[RV32ICore.scala 223:18]
    end else begin
      idexAluOp <= idStage_io_aluOp; // @[RV32ICore.scala 244:18]
    end
    if (reset) begin // @[RV32ICore.scala 65:30]
      idexAluASel <= 2'h0; // @[RV32ICore.scala 65:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexAluASel <= 2'h0; // @[RV32ICore.scala 224:18]
    end else begin
      idexAluASel <= idStage_io_aluASel; // @[RV32ICore.scala 245:18]
    end
    if (reset) begin // @[RV32ICore.scala 66:30]
      idexAluSrc <= 1'h0; // @[RV32ICore.scala 66:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexAluSrc <= 1'h0; // @[RV32ICore.scala 225:18]
    end else begin
      idexAluSrc <= idStage_io_aluSrc; // @[RV32ICore.scala 246:18]
    end
    if (reset) begin // @[RV32ICore.scala 67:30]
      idexRegWrite <= 1'h0; // @[RV32ICore.scala 67:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexRegWrite <= 1'h0; // @[RV32ICore.scala 226:18]
    end else begin
      idexRegWrite <= idStage_io_regWrite; // @[RV32ICore.scala 247:18]
    end
    if (reset) begin // @[RV32ICore.scala 68:30]
      idexMemRead <= 1'h0; // @[RV32ICore.scala 68:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexMemRead <= 1'h0; // @[RV32ICore.scala 227:18]
    end else begin
      idexMemRead <= idStage_io_memRead; // @[RV32ICore.scala 248:18]
    end
    if (reset) begin // @[RV32ICore.scala 69:30]
      idexMemWrite <= 1'h0; // @[RV32ICore.scala 69:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexMemWrite <= 1'h0; // @[RV32ICore.scala 228:18]
    end else begin
      idexMemWrite <= idStage_io_memWrite; // @[RV32ICore.scala 249:18]
    end
    if (reset) begin // @[RV32ICore.scala 70:30]
      idexMemToReg <= 1'h0; // @[RV32ICore.scala 70:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexMemToReg <= 1'h0; // @[RV32ICore.scala 229:18]
    end else begin
      idexMemToReg <= idStage_io_memToReg; // @[RV32ICore.scala 250:18]
    end
    if (reset) begin // @[RV32ICore.scala 71:30]
      idexBranch <= 1'h0; // @[RV32ICore.scala 71:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexBranch <= 1'h0; // @[RV32ICore.scala 230:18]
    end else begin
      idexBranch <= idStage_io_branch; // @[RV32ICore.scala 251:18]
    end
    if (reset) begin // @[RV32ICore.scala 72:30]
      idexJump <= 1'h0; // @[RV32ICore.scala 72:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexJump <= 1'h0; // @[RV32ICore.scala 231:18]
    end else begin
      idexJump <= idStage_io_jump; // @[RV32ICore.scala 252:18]
    end
    if (reset) begin // @[RV32ICore.scala 73:30]
      idexJalr <= 1'h0; // @[RV32ICore.scala 73:30]
    end else if (exStage_io_redirect | hazardUnit_io_bubbleIDEX) begin // @[RV32ICore.scala 212:46]
      idexJalr <= 1'h0; // @[RV32ICore.scala 232:18]
    end else begin
      idexJalr <= idStage_io_jalr; // @[RV32ICore.scala 253:18]
    end
    if (reset) begin // @[RV32ICore.scala 76:31]
      exmemValid <= 1'h0; // @[RV32ICore.scala 76:31]
    end else begin
      exmemValid <= idexValid; // @[RV32ICore.scala 257:18]
    end
    if (reset) begin // @[RV32ICore.scala 77:31]
      exmemPC <= 32'h0; // @[RV32ICore.scala 77:31]
    end else begin
      exmemPC <= idexPC; // @[RV32ICore.scala 258:18]
    end
    if (reset) begin // @[RV32ICore.scala 78:31]
      exmemAluResult <= 32'h0; // @[RV32ICore.scala 78:31]
    end else begin
      exmemAluResult <= exStage_io_aluResult; // @[RV32ICore.scala 259:18]
    end
    if (reset) begin // @[RV32ICore.scala 79:31]
      exmemStoreData <= 32'h0; // @[RV32ICore.scala 79:31]
    end else begin
      exmemStoreData <= exStage_io_storeData; // @[RV32ICore.scala 260:18]
    end
    if (reset) begin // @[RV32ICore.scala 80:31]
      exmemRd <= 5'h0; // @[RV32ICore.scala 80:31]
    end else begin
      exmemRd <= exStage_io_rdOut; // @[RV32ICore.scala 261:18]
    end
    if (reset) begin // @[RV32ICore.scala 81:31]
      exmemFunct3 <= 3'h0; // @[RV32ICore.scala 81:31]
    end else begin
      exmemFunct3 <= exStage_io_funct3Out; // @[RV32ICore.scala 262:18]
    end
    if (reset) begin // @[RV32ICore.scala 82:31]
      exmemPCPlus4 <= 32'h0; // @[RV32ICore.scala 82:31]
    end else begin
      exmemPCPlus4 <= exStage_io_pcPlus4; // @[RV32ICore.scala 263:18]
    end
    if (reset) begin // @[RV32ICore.scala 83:31]
      exmemRegWrite <= 1'h0; // @[RV32ICore.scala 83:31]
    end else begin
      exmemRegWrite <= exStage_io_regWriteOut; // @[RV32ICore.scala 264:18]
    end
    if (reset) begin // @[RV32ICore.scala 84:31]
      exmemMemRead <= 1'h0; // @[RV32ICore.scala 84:31]
    end else begin
      exmemMemRead <= exStage_io_memReadOut; // @[RV32ICore.scala 265:18]
    end
    if (reset) begin // @[RV32ICore.scala 85:31]
      exmemMemWrite <= 1'h0; // @[RV32ICore.scala 85:31]
    end else begin
      exmemMemWrite <= exStage_io_memWriteOut; // @[RV32ICore.scala 266:18]
    end
    if (reset) begin // @[RV32ICore.scala 86:31]
      exmemMemToReg <= 1'h0; // @[RV32ICore.scala 86:31]
    end else begin
      exmemMemToReg <= exStage_io_memToRegOut; // @[RV32ICore.scala 267:18]
    end
    if (reset) begin // @[RV32ICore.scala 87:31]
      exmemLink <= 1'h0; // @[RV32ICore.scala 87:31]
    end else begin
      exmemLink <= exStage_io_linkOut; // @[RV32ICore.scala 268:18]
    end
    if (reset) begin // @[RV32ICore.scala 90:31]
      memwbValid <= 1'h0; // @[RV32ICore.scala 90:31]
    end else begin
      memwbValid <= exmemValid; // @[RV32ICore.scala 271:18]
    end
    if (reset) begin // @[RV32ICore.scala 91:31]
      memwbAluResult <= 32'h0; // @[RV32ICore.scala 91:31]
    end else begin
      memwbAluResult <= memStage_io_aluResultOut; // @[RV32ICore.scala 272:18]
    end
    if (reset) begin // @[RV32ICore.scala 92:31]
      memwbMemData <= 32'h0; // @[RV32ICore.scala 92:31]
    end else begin
      memwbMemData <= memStage_io_memDataOut; // @[RV32ICore.scala 273:18]
    end
    if (reset) begin // @[RV32ICore.scala 93:31]
      memwbPCPlus4 <= 32'h0; // @[RV32ICore.scala 93:31]
    end else begin
      memwbPCPlus4 <= memStage_io_pcPlus4Out; // @[RV32ICore.scala 274:18]
    end
    if (reset) begin // @[RV32ICore.scala 94:31]
      memwbRd <= 5'h0; // @[RV32ICore.scala 94:31]
    end else begin
      memwbRd <= memStage_io_rdOut; // @[RV32ICore.scala 275:18]
    end
    if (reset) begin // @[RV32ICore.scala 95:31]
      memwbRegWrite <= 1'h0; // @[RV32ICore.scala 95:31]
    end else begin
      memwbRegWrite <= memStage_io_regWriteOut; // @[RV32ICore.scala 276:18]
    end
    if (reset) begin // @[RV32ICore.scala 96:31]
      memwbMemToReg <= 1'h0; // @[RV32ICore.scala 96:31]
    end else begin
      memwbMemToReg <= memStage_io_memToRegOut; // @[RV32ICore.scala 277:18]
    end
    if (reset) begin // @[RV32ICore.scala 97:31]
      memwbLink <= 1'h0; // @[RV32ICore.scala 97:31]
    end else begin
      memwbLink <= memStage_io_linkOut; // @[RV32ICore.scala 278:18]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  pcReg = _RAND_0[31:0];
  _RAND_1 = {1{`RANDOM}};
  ifidValid = _RAND_1[0:0];
  _RAND_2 = {1{`RANDOM}};
  ifidPC = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  ifidInstr = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  idexValid = _RAND_4[0:0];
  _RAND_5 = {1{`RANDOM}};
  idexPC = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  idexInstr = _RAND_6[31:0];
  _RAND_7 = {1{`RANDOM}};
  idexRs1 = _RAND_7[4:0];
  _RAND_8 = {1{`RANDOM}};
  idexRs2 = _RAND_8[4:0];
  _RAND_9 = {1{`RANDOM}};
  idexRd = _RAND_9[4:0];
  _RAND_10 = {1{`RANDOM}};
  idexRs1Data = _RAND_10[31:0];
  _RAND_11 = {1{`RANDOM}};
  idexRs2Data = _RAND_11[31:0];
  _RAND_12 = {1{`RANDOM}};
  idexImm = _RAND_12[31:0];
  _RAND_13 = {1{`RANDOM}};
  idexFunct3 = _RAND_13[2:0];
  _RAND_14 = {1{`RANDOM}};
  idexAluOp = _RAND_14[4:0];
  _RAND_15 = {1{`RANDOM}};
  idexAluASel = _RAND_15[1:0];
  _RAND_16 = {1{`RANDOM}};
  idexAluSrc = _RAND_16[0:0];
  _RAND_17 = {1{`RANDOM}};
  idexRegWrite = _RAND_17[0:0];
  _RAND_18 = {1{`RANDOM}};
  idexMemRead = _RAND_18[0:0];
  _RAND_19 = {1{`RANDOM}};
  idexMemWrite = _RAND_19[0:0];
  _RAND_20 = {1{`RANDOM}};
  idexMemToReg = _RAND_20[0:0];
  _RAND_21 = {1{`RANDOM}};
  idexBranch = _RAND_21[0:0];
  _RAND_22 = {1{`RANDOM}};
  idexJump = _RAND_22[0:0];
  _RAND_23 = {1{`RANDOM}};
  idexJalr = _RAND_23[0:0];
  _RAND_24 = {1{`RANDOM}};
  exmemValid = _RAND_24[0:0];
  _RAND_25 = {1{`RANDOM}};
  exmemPC = _RAND_25[31:0];
  _RAND_26 = {1{`RANDOM}};
  exmemAluResult = _RAND_26[31:0];
  _RAND_27 = {1{`RANDOM}};
  exmemStoreData = _RAND_27[31:0];
  _RAND_28 = {1{`RANDOM}};
  exmemRd = _RAND_28[4:0];
  _RAND_29 = {1{`RANDOM}};
  exmemFunct3 = _RAND_29[2:0];
  _RAND_30 = {1{`RANDOM}};
  exmemPCPlus4 = _RAND_30[31:0];
  _RAND_31 = {1{`RANDOM}};
  exmemRegWrite = _RAND_31[0:0];
  _RAND_32 = {1{`RANDOM}};
  exmemMemRead = _RAND_32[0:0];
  _RAND_33 = {1{`RANDOM}};
  exmemMemWrite = _RAND_33[0:0];
  _RAND_34 = {1{`RANDOM}};
  exmemMemToReg = _RAND_34[0:0];
  _RAND_35 = {1{`RANDOM}};
  exmemLink = _RAND_35[0:0];
  _RAND_36 = {1{`RANDOM}};
  memwbValid = _RAND_36[0:0];
  _RAND_37 = {1{`RANDOM}};
  memwbAluResult = _RAND_37[31:0];
  _RAND_38 = {1{`RANDOM}};
  memwbMemData = _RAND_38[31:0];
  _RAND_39 = {1{`RANDOM}};
  memwbPCPlus4 = _RAND_39[31:0];
  _RAND_40 = {1{`RANDOM}};
  memwbRd = _RAND_40[4:0];
  _RAND_41 = {1{`RANDOM}};
  memwbRegWrite = _RAND_41[0:0];
  _RAND_42 = {1{`RANDOM}};
  memwbMemToReg = _RAND_42[0:0];
  _RAND_43 = {1{`RANDOM}};
  memwbLink = _RAND_43[0:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
