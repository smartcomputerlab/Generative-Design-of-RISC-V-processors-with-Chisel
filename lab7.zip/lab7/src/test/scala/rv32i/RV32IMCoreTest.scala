package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class RV32IMCoreTest extends AnyFlatSpec with ChiselScalatestTester {

  behavior of "RV32ICore 5-Stage Pipeline"

  // Factorial(5): x1 = 0, x2 = 120
  it should "calculate factorial of 5 using RV32IM MUL" in {
    test(new RV32IMCore(CoreParams()))
      .withAnnotations(Seq(WriteVcdAnnotation)) { dut =>

      dut.reset.poke(true.B)
      dut.clock.step(2)
      dut.reset.poke(false.B)

      println("\n" + "=" * 112)
      println(" RV32IM 5-STAGE PIPELINE - FACTORIAL(5)")
      println("=" * 112)
      println("Cycle | FetchPC   | DecodePC  | ExecPC    | MemPC     | " +
        "IFID | IDEX | EXMEM | MEMWB | Stall | Flush | Instr(EX)  | x1 | x2  | ALU")
      println("-" * 112)

      for (cycle <- 0 until 100) {
        val fetchPC  = dut.io.debugFetchPC.peek().litValue
        val decodePC = dut.io.debugDecodePC.peek().litValue
        val execPC   = dut.io.debugExecPC.peek().litValue
        val memPC    = dut.io.debugMemPC.peek().litValue

        val ifidValid  = dut.io.debugIFIDValid.peek().litToBoolean
        val idexValid  = dut.io.debugIDEXValid.peek().litToBoolean
        val exmemValid = dut.io.debugEXMEMValid.peek().litToBoolean
        val memwbValid = dut.io.debugMEMWBValid.peek().litToBoolean

        val stall = dut.io.debugStall.peek().litToBoolean
        val flush = dut.io.debugFlush.peek().litToBoolean
        val instr = dut.io.debugInstr.peek().litValue
        val x1    = dut.io.debugX1.peek().litValue
        val x2    = dut.io.debugX2.peek().litValue
        val alu   = dut.io.debugALU.peek().litValue

        println(
          f"$cycle%5d | 0x$fetchPC%08x | 0x$decodePC%08x | " +
          f"0x$execPC%08x | 0x$memPC%08x | " +
          f"$ifidValid%4s | $idexValid%4s | $exmemValid%5s | " +
          f"$memwbValid%5s | $stall%5s | $flush%5s | " +
          f"0x$instr%08x | $x1%2d | $x2%3d | 0x$alu%08x"
        )

        dut.clock.step()
      }

      val finalX1 = dut.io.debugX1.peek().litValue
      val finalX2 = dut.io.debugX2.peek().litValue

      println("\n" + "=" * 112)
      println(" FINAL RESULTS")
      println("=" * 112)
      println(s"x1 = $finalX1 (expected 0)")
      println(s"x2 = $finalX2 (expected 120)")

      dut.io.debugX1.expect(0.U, "Loop counter x1 should be zero")
      dut.io.debugX2.expect(120.U, "Factorial failed: expected 5! = 120")

      println("\nFACTORIAL(5) PASSED")
      println("=" * 112)
    }
  }
}

