package rv32i

import chisel3._
import chisel3.util._

class PCUpdate(p: CoreParams) extends Module {

  val io = IO(new Bundle {
    // EX stage inputs
    val valid  = Input(Bool())
    val pc     = Input(UInt(p.xlen.W))
    val rs1    = Input(UInt(p.xlen.W))
    val rs2    = Input(UInt(p.xlen.W))
    val imm    = Input(UInt(p.xlen.W))
    val funct3 = Input(UInt(3.W))

    // Control signals
    val branch = Input(Bool())
    val jump   = Input(Bool())
    val jalr   = Input(Bool())

    // Outputs
    val redirect    = Output(Bool())
    val redirectPC  = Output(UInt(p.xlen.W))
    val nextPc      = Output(UInt(p.xlen.W))
    val branchTaken = Output(Bool())
  })

  // Branch comparison
  val branchCondition = MuxLookup(io.funct3, false.B, Seq(
    "b000".U -> (io.rs1 === io.rs2),             // BEQ
    "b001".U -> (io.rs1 =/= io.rs2),             // BNE
    "b100".U -> (io.rs1.asSInt < io.rs2.asSInt), // BLT
    "b101".U -> (io.rs1.asSInt >= io.rs2.asSInt),// BGE
    "b110".U -> (io.rs1 < io.rs2),               // BLTU
    "b111".U -> (io.rs1 >= io.rs2)               // BGEU
  ))

  // Branch and jump decisions
  val takeBranch = io.valid && io.branch && branchCondition
  val takeJal    = io.valid && io.jump
  val takeJalr   = io.valid && io.jalr

  // Target addresses
  val pcTarget   = io.pc + io.imm
  val jalrTarget = (io.rs1 + io.imm) & (~1.U(p.xlen.W))

  // PC redirection
  io.redirect    := takeBranch || takeJal || takeJalr
  io.redirectPC  := Mux(takeJalr, jalrTarget, pcTarget)
  io.nextPc      := Mux(io.redirect, io.redirectPC, io.pc + 4.U)
  io.branchTaken := takeBranch
}

