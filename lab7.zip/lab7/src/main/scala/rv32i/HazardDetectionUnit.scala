package rv32i

import chisel3._

class HazardDetectionUnit extends Module {

  val io = IO(new Bundle {

    // Instruction currently in ID
    val ifidRs1 = Input(UInt(5.W))
    val ifidRs2 = Input(UInt(5.W))

    // Does the ID instruction actually use these registers?
    val ifidUsesRs1 = Input(Bool())
    val ifidUsesRs2 = Input(Bool())

    // Instruction currently in EX
    val idexRd      = Input(UInt(5.W))
    val idexMemRead = Input(Bool())
    val idexValid   = Input(Bool())

    // Pipeline control
    val stallPC    = Output(Bool())
    val stallIFID  = Output(Bool())
    val bubbleIDEX = Output(Bool())
  })

  // ============================================================
  // LOAD-USE HAZARD
  // ============================================================
  //
  // Example:
  //
  //     lw  x5, 0(x1)
  //     add x6, x5, x2
  //
  // When LW is in EX and ADD is in ID, x5 is not available yet.
  //
  // Action:
  //
  //     PC     -> hold
  //     IF/ID  -> hold
  //     ID/EX  -> bubble
  //
  // ============================================================

  val rs1Hazard =
    io.ifidUsesRs1 &&
    (io.idexRd === io.ifidRs1)

  val rs2Hazard =
    io.ifidUsesRs2 &&
    (io.idexRd === io.ifidRs2)

  val loadUseHazard =
    io.idexValid &&
    io.idexMemRead &&
    (io.idexRd =/= 0.U) &&
    (rs1Hazard || rs2Hazard)

  io.stallPC :=
    loadUseHazard

  io.stallIFID :=
    loadUseHazard

  io.bubbleIDEX :=
    loadUseHazard
}

