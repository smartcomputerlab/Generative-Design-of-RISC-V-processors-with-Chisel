package rv32i

import chisel3._
import chisel3.util._

class EXStage(p: CoreParams) extends Module {

  val io = IO(new Bundle {

    // ID/EX inputs
    val valid   = Input(Bool())
    val pc      = Input(UInt(p.xlen.W))
    val rs1     = Input(UInt(5.W))
    val rs2     = Input(UInt(5.W))
    val rd      = Input(UInt(5.W))
    val rs1Data = Input(UInt(p.xlen.W))
    val rs2Data = Input(UInt(p.xlen.W))
    val imm     = Input(UInt(p.xlen.W))
    val funct3  = Input(UInt(3.W))

    // ALU and pipeline controls
    val aluOp    = Input(UInt(ALUOp.width.W))
    val aluASel  = Input(UInt(2.W))
    val aluSrc   = Input(Bool())
    val regWrite = Input(Bool())
    val memRead  = Input(Bool())
    val memWrite = Input(Bool())
    val memToReg = Input(Bool())
    val branch   = Input(Bool())
    val jump     = Input(Bool())
    val jalr     = Input(Bool())

    // Forwarding
    val forwardA         = Input(UInt(2.W))
    val forwardB         = Input(UInt(2.W))
    val exmemForwardData = Input(UInt(p.xlen.W))
    val memwbForwardData = Input(UInt(p.xlen.W))

    // EX/MEM outputs
    val aluResult = Output(UInt(p.xlen.W))
    val storeData = Output(UInt(p.xlen.W))
    val rdOut     = Output(UInt(5.W))
    val funct3Out = Output(UInt(3.W))
    val pcPlus4   = Output(UInt(p.xlen.W))

    // Pipeline control outputs
    val regWriteOut = Output(Bool())
    val memReadOut  = Output(Bool())
    val memWriteOut = Output(Bool())
    val memToRegOut = Output(Bool())
    val linkOut     = Output(Bool())

    // Control-flow outputs
    val redirect    = Output(Bool())
    val redirectPC  = Output(UInt(p.xlen.W))
    val branchTaken = Output(Bool())

    // Debug outputs
    val debugALU      = Output(UInt(p.xlen.W))
    val debugOperandA = Output(UInt(p.xlen.W))
    val debugOperandB = Output(UInt(p.xlen.W))
  })

  // Submodules
  val alu      = Module(new ALU(p))
  val pcUpdate = Module(new PCUpdate(p))

  // Forwarding: 00=ID/EX, 01=MEM/WB, 10=EX/MEM
  def forward(sel: UInt, data: UInt): UInt =
    MuxLookup(sel, data, Seq(
      1.U -> io.memwbForwardData,
      2.U -> io.exmemForwardData
    ))

  val rs1Forwarded = forward(io.forwardA, io.rs1Data)
  val rs2Forwarded = forward(io.forwardB, io.rs2Data)

  // ALU A: 00=RS1, 01=PC, 10=zero
  val operandA = MuxLookup(io.aluASel, rs1Forwarded, Seq(
    1.U -> io.pc,
    2.U -> 0.U(p.xlen.W)
  ))

  // ALU B: register or immediate
  val operandB = Mux(io.aluSrc, io.imm, rs2Forwarded)

  // ALU
  alu.io.a  := operandA
  alu.io.b  := operandB
  alu.io.op := io.aluOp

  // Branch / jump unit: always use forwarded register values
  pcUpdate.io.valid  := io.valid
  pcUpdate.io.pc     := io.pc
  pcUpdate.io.rs1    := rs1Forwarded
  pcUpdate.io.rs2    := rs2Forwarded
  pcUpdate.io.imm    := io.imm
  pcUpdate.io.funct3 := io.funct3
  pcUpdate.io.branch := io.branch
  pcUpdate.io.jump   := io.jump
  pcUpdate.io.jalr   := io.jalr

  // Control-flow outputs
  io.redirect    := pcUpdate.io.redirect
  io.redirectPC  := pcUpdate.io.redirectPC
  io.branchTaken := pcUpdate.io.branchTaken

  // EX/MEM outputs
  io.aluResult := alu.io.y
  io.storeData := rs2Forwarded
  io.rdOut     := io.rd
  io.funct3Out := io.funct3
  io.pcPlus4   := io.pc + 4.U

  // Pipeline controls: suppress side effects for invalid instructions
  io.regWriteOut := io.regWrite && io.valid
  io.memReadOut  := io.memRead  && io.valid
  io.memWriteOut := io.memWrite && io.valid
  io.memToRegOut := io.memToReg
  io.linkOut     := (io.jump || io.jalr) && io.valid

  // Debug
  io.debugALU      := alu.io.y
  io.debugOperandA := operandA
  io.debugOperandB := operandB
}

