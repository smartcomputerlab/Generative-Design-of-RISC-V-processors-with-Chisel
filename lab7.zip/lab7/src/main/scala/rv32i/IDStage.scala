package rv32i

import chisel3._

class IDStage(p: CoreParams) extends Module {

  val io = IO(new Bundle {

    // ==========================================================
    // INPUT FROM IF/ID
    // ==========================================================

    val valid = Input(Bool())
    val pc    = Input(UInt(p.xlen.W))
    val instr = Input(UInt(32.W))

    // ==========================================================
    // INPUT FROM WB
    // ==========================================================

    val wbRd =
      Input(UInt(5.W))

    val wbWriteData =
      Input(UInt(p.xlen.W))

    val wbWriteEnable =
      Input(Bool())

    // ==========================================================
    // DECODED REGISTER FIELDS
    // ==========================================================

    val rs1 = Output(UInt(5.W))
    val rs2 = Output(UInt(5.W))
    val rd  = Output(UInt(5.W))

    // ==========================================================
    // REGISTER VALUES
    // ==========================================================

    val rs1Data =
      Output(UInt(p.xlen.W))

    val rs2Data =
      Output(UInt(p.xlen.W))

    // ==========================================================
    // IMMEDIATE / FUNCT3
    // ==========================================================

    val imm =
      Output(UInt(p.xlen.W))

    val funct3 =
      Output(UInt(3.W))

    // ==========================================================
    // ALU CONTROL
    // ==========================================================

    val aluOp =
      Output(UInt(ALUOp.width.W))

    val aluASel =
      Output(UInt(ALUASel.width.W))

    val aluSrc =
      Output(Bool())

    // ==========================================================
    // PIPELINE CONTROL
    // ==========================================================

    val regWrite =
      Output(Bool())

    val memRead =
      Output(Bool())

    val memWrite =
      Output(Bool())

    val memToReg =
      Output(Bool())

    val branch =
      Output(Bool())

    val jump =
      Output(Bool())

    val jalr =
      Output(Bool())

    // ==========================================================
    // SOURCE REGISTER USAGE
    // ==========================================================

    val usesRs1 =
      Output(Bool())

    val usesRs2 =
      Output(Bool())

    // ==========================================================
    // DEBUG
    // ==========================================================

    val debugX1 = Output(UInt(p.xlen.W))
    val debugX2 = Output(UInt(p.xlen.W))
    val debugX3 = Output(UInt(p.xlen.W))
    val debugX4 = Output(UInt(p.xlen.W))
    val debugX5 = Output(UInt(p.xlen.W))
    val debugX6 = Output(UInt(p.xlen.W))
  })


  // ============================================================
  // MODULES
  // ============================================================

  val decoder =
    Module(new Decoder)

  val control =
    Module(new Control)

  val immGen =
    Module(new ImmediateGenerator(p))

  val regFile =
    Module(new RegisterFile(p))


  // ============================================================
  // DECODE
  // ============================================================

  decoder.io.instr :=
    io.instr

  control.io.instr :=
    io.instr

  immGen.io.instr :=
    io.instr


  // ============================================================
  // REGISTER FILE READ PORTS
  // ============================================================

  regFile.io.rs1 :=
    decoder.io.rs1

  regFile.io.rs2 :=
    decoder.io.rs2


  // ============================================================
  // REGISTER FILE WRITE PORT
  // ============================================================
  //
  // IMPORTANT:
  //
  // rd comes from WB, NOT from the instruction currently in ID.
  //
  // ============================================================

  regFile.io.rd :=
    io.wbRd

  regFile.io.writeData :=
    io.wbWriteData

  regFile.io.writeEnable :=
    io.wbWriteEnable


  // ============================================================
  // WB -> ID BYPASS
  // ============================================================
  //
  // This is safe in the five-stage architecture because WB data
  // comes from the registered MEM/WB stage.
  //
  // It solves:
  //
  // WB:  writes x5
  // ID:  reads  x5
  //
  // in the same cycle.
  //
  // ============================================================

  val rawRs1 =
    regFile.io.readData1

  val rawRs2 =
    regFile.io.readData2

  val wbBypassRs1 =
    io.wbWriteEnable &&
    (io.wbRd =/= 0.U) &&
    (io.wbRd === decoder.io.rs1)

  val wbBypassRs2 =
    io.wbWriteEnable &&
    (io.wbRd =/= 0.U) &&
    (io.wbRd === decoder.io.rs2)

  io.rs1Data :=
    Mux(
      wbBypassRs1,
      io.wbWriteData,
      rawRs1
    )

  io.rs2Data :=
    Mux(
      wbBypassRs2,
      io.wbWriteData,
      rawRs2
    )


  // ============================================================
  // REGISTER NUMBERS
  // ============================================================

  io.rs1 :=
    decoder.io.rs1

  io.rs2 :=
    decoder.io.rs2

  io.rd :=
    decoder.io.rd


  // ============================================================
  // IMMEDIATE / FUNCT3
  // ============================================================

  io.imm :=
    immGen.io.imm

  io.funct3 :=
    decoder.io.funct3


  // ============================================================
  // ALU CONTROL
  // ============================================================

  io.aluOp :=
    control.io.aluOp

  io.aluASel :=
    control.io.aluASel

  io.aluSrc :=
    control.io.aluSrc


  // ============================================================
  // PIPELINE CONTROL
  // ============================================================

  io.regWrite :=
    control.io.regWrite &&
    io.valid

  io.memRead :=
    control.io.memRead &&
    io.valid

  io.memWrite :=
    control.io.memWrite &&
    io.valid

  io.memToReg :=
    control.io.memToReg

  io.branch :=
    control.io.branch &&
    io.valid

  io.jump :=
    control.io.jump &&
    io.valid

  io.jalr :=
    control.io.jalr &&
    io.valid


  // ============================================================
  // SOURCE REGISTER USAGE
  // ============================================================

  io.usesRs1 :=
    control.io.usesRs1 &&
    io.valid

  io.usesRs2 :=
    control.io.usesRs2 &&
    io.valid


  // ============================================================
  // DEBUG
  // ============================================================

  io.debugX1 :=
    regFile.io.debugRead(1)

  io.debugX2 :=
    regFile.io.debugRead(2)

  io.debugX3 :=
    regFile.io.debugRead(3)

  io.debugX4 :=
    regFile.io.debugRead(4)

  io.debugX5 :=
    regFile.io.debugRead(5)

  io.debugX6 :=
    regFile.io.debugRead(6)
}

