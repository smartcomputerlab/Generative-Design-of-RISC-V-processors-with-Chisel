package rv32i

import chisel3._
import chisel3.util._

class RegisterFile(
  p: CoreParams,
  initialValues: Seq[BigInt] = Seq.empty
) extends Module {

  require(
    initialValues.isEmpty || initialValues.length == p.numRegs,
    "initialValues must be empty or contain exactly numRegs entries"
  )

  val io = IO(new Bundle {
    // Read ports
    val rs1       = Input(UInt(log2Ceil(p.numRegs).W))
    val rs2       = Input(UInt(log2Ceil(p.numRegs).W))
    val readData1 = Output(UInt(p.xlen.W))
    val readData2 = Output(UInt(p.xlen.W))

    // Write port
    val rd          = Input(UInt(log2Ceil(p.numRegs).W))
    val writeData   = Input(UInt(p.xlen.W))
    val writeEnable = Input(Bool())

    // Debug outputs
    val debugRead = Output(Vec(p.numRegs, UInt(p.xlen.W)))
  })

  // Register initialization
  val resetValues =
    if (initialValues.nonEmpty)
      initialValues.map(_.U(p.xlen.W))
    else
      Seq.fill(p.numRegs)(0.U(p.xlen.W))

  val regs = RegInit(VecInit(resetValues))

  // Asynchronous read ports (x0 always returns zero)
  io.readData1 := Mux(io.rs1 === 0.U, 0.U(p.xlen.W), regs(io.rs1))
  io.readData2 := Mux(io.rs2 === 0.U, 0.U(p.xlen.W), regs(io.rs2))

  // Synchronous write port (x0 is read-only)
  when(io.writeEnable && (io.rd =/= 0.U)) {
    regs(io.rd) := io.writeData
  }

  // Debug outputs
  for (i <- 0 until p.numRegs) {
    io.debugRead(i) := (if (i == 0) 0.U(p.xlen.W) else regs(i))
  }
}

