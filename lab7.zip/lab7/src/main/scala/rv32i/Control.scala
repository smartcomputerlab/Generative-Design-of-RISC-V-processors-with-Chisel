package rv32i
import chisel3._
import chisel3.util._

object WBSel {
  val width = 2
  val ALU = 0.U(width.W); val MEM = 1.U(width.W); val PC4 = 2.U(width.W)
}
object ALUASel {
  val width = 2
  val RS1 = 0.U(width.W); val ZERO = 1.U(width.W); val PC = 2.U(width.W)
}

class Control extends Module {
  val io = IO(new Bundle {
    val instr = Input(UInt(32.W))
    val valid = Output(Bool())
    val aluOp = Output(UInt(ALUOp.width.W))
    val aluASel = Output(UInt(ALUASel.width.W))
    val aluSrc = Output(Bool())
    val memRead = Output(Bool()); val memWrite = Output(Bool())
    val memToReg = Output(Bool()); val regWrite = Output(Bool())
    val wbSel = Output(UInt(WBSel.width.W))
    val branch = Output(Bool()); val jump = Output(Bool()); val jalr = Output(Bool())
    val usesRs1 = Output(Bool()); val usesRs2 = Output(Bool())
  })

  val opcode = io.instr(6,0); val funct3 = io.instr(14,12); val funct7 = io.instr(31,25)
  val R_TYPE = "b0110011".U; val I_TYPE = "b0010011".U
  val LOAD = "b0000011".U; val STORE = "b0100011".U
  val BRANCH = "b1100011".U; val JAL = "b1101111".U
  val JALR = "b1100111".U; val LUI = "b0110111".U; val AUIPC = "b0010111".U

  io.valid := false.B; io.aluOp := ALUOp.NOP; io.aluASel := ALUASel.RS1
  io.aluSrc := false.B; io.memRead := false.B; io.memWrite := false.B
  io.memToReg := false.B; io.regWrite := false.B; io.wbSel := WBSel.ALU
  io.branch := false.B; io.jump := false.B; io.jalr := false.B
  io.usesRs1 := false.B; io.usesRs2 := false.B

  switch(opcode) {
    is(R_TYPE) {
      io.valid := true.B; io.usesRs1 := true.B; io.usesRs2 := true.B; io.regWrite := true.B
      switch(funct3) {
        is(0.U) { io.aluOp := Mux(funct7===1.U, ALUOp.MUL, Mux(funct7===32.U, ALUOp.SUB, ALUOp.ADD)) }
        is(1.U) { io.aluOp := Mux(funct7===1.U, ALUOp.MULH, ALUOp.SLL) }
        is(2.U) { io.aluOp := Mux(funct7===1.U, ALUOp.MULHSU, ALUOp.SLT) }
        is(3.U) { io.aluOp := Mux(funct7===1.U, ALUOp.MULHU, ALUOp.SLTU) }
        is(4.U) { io.aluOp := Mux(funct7===1.U, ALUOp.DIV, ALUOp.XOR) }
        is(5.U) { io.aluOp := Mux(funct7===1.U, ALUOp.DIVU, Mux(funct7===32.U, ALUOp.SRA, ALUOp.SRL)) }
        is(6.U) { io.aluOp := Mux(funct7===1.U, ALUOp.REM, ALUOp.OR) }
        is(7.U) { io.aluOp := Mux(funct7===1.U, ALUOp.REMU, ALUOp.AND) }
      }
    }
    is(I_TYPE) {
      io.valid := true.B; io.usesRs1 := true.B; io.aluSrc := true.B; io.regWrite := true.B
      switch(funct3) {
        is(0.U) { io.aluOp := ALUOp.ADD };  is(2.U) { io.aluOp := ALUOp.SLT }
        is(3.U) { io.aluOp := ALUOp.SLTU }; is(4.U) { io.aluOp := ALUOp.XOR }
        is(6.U) { io.aluOp := ALUOp.OR };   is(7.U) { io.aluOp := ALUOp.AND }
        is(1.U) { io.aluOp := ALUOp.SLL }
        is(5.U) { io.aluOp := Mux(funct7===32.U, ALUOp.SRA, ALUOp.SRL) }
      }
    }
    is(LOAD) {
      io.valid := true.B; io.usesRs1 := true.B; io.aluSrc := true.B
      io.aluOp := ALUOp.ADD; io.memRead := true.B; io.memToReg := true.B
      io.regWrite := true.B; io.wbSel := WBSel.MEM
    }
    is(STORE) {
      io.valid := true.B; io.usesRs1 := true.B; io.usesRs2 := true.B
      io.aluSrc := true.B; io.aluOp := ALUOp.ADD; io.memWrite := true.B
    }
    is(BRANCH) {
      io.valid := true.B; io.usesRs1 := true.B; io.usesRs2 := true.B; io.branch := true.B
    }
    is(JAL) {
      io.valid := true.B; io.jump := true.B; io.regWrite := true.B; io.wbSel := WBSel.PC4
    }
    is(JALR) {
      io.valid := true.B; io.usesRs1 := true.B; io.jalr := true.B
      io.regWrite := true.B; io.aluSrc := true.B
      io.aluOp := ALUOp.ADD; io.wbSel := WBSel.PC4
    }
    is(LUI) {
      io.valid := true.B; io.aluASel := ALUASel.ZERO
      io.aluSrc := true.B; io.aluOp := ALUOp.ADD; io.regWrite := true.B
    }
    is(AUIPC) {
      io.valid := true.B; io.aluASel := ALUASel.PC
      io.aluSrc := true.B; io.aluOp := ALUOp.ADD; io.regWrite := true.B
    }
  }
}

