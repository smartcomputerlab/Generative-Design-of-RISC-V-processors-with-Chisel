package rv32i
import chisel3._

class MEMStage(p: CoreParams) extends Module {
  val io = IO(new Bundle {
    // EX/MEM inputs
    val valid      = Input(Bool())
    val aluResult  = Input(UInt(p.xlen.W))
    val storeData  = Input(UInt(p.xlen.W))
    val rd         = Input(UInt(5.W))
    val funct3     = Input(UInt(3.W))
    val pcPlus4    = Input(UInt(p.xlen.W))
    val regWrite   = Input(Bool())
    val memRead    = Input(Bool())
    val memWrite   = Input(Bool())
    val memToReg   = Input(Bool())
    val link       = Input(Bool())
    // Data memory interface
    val memAddr     = Output(UInt(p.xlen.W))
    val memWdata    = Output(UInt(p.xlen.W))
    val memReadOut  = Output(Bool())
    val memWriteOut = Output(Bool())
    val memFunct3   = Output(UInt(3.W))
    val memRdata    = Input(UInt(p.xlen.W))
    // MEM/WB outputs
    val memDataOut   = Output(UInt(p.xlen.W))
    val aluResultOut = Output(UInt(p.xlen.W))
    val pcPlus4Out   = Output(UInt(p.xlen.W))
    val rdOut        = Output(UInt(5.W))
    val regWriteOut  = Output(Bool())
    val memToRegOut  = Output(Bool())
    val linkOut      = Output(Bool())
  })
  // Memory interface
  io.memAddr     := io.aluResult
  io.memWdata    := io.storeData
  io.memFunct3   := io.funct3
  io.memReadOut  := io.memRead && io.valid
  io.memWriteOut := io.memWrite && io.valid
  // MEM/WB outputs
  io.memDataOut   := io.memRdata
  io.aluResultOut := io.aluResult
  io.pcPlus4Out   := io.pcPlus4
  io.rdOut        := io.rd
  io.regWriteOut  := io.regWrite && io.valid
  io.memToRegOut  := io.memToReg
  io.linkOut      := io.link
}

