package rv32i
import chisel3._

class WBStage(p: CoreParams) extends Module {
  val io = IO(new Bundle {
    // MEM/WB inputs
    val valid     = Input(Bool())
    val aluResult = Input(UInt(p.xlen.W))
    val memData   = Input(UInt(p.xlen.W))
    val pcPlus4   = Input(UInt(p.xlen.W))
    val rd        = Input(UInt(5.W))
    val regWrite  = Input(Bool())
    val memToReg  = Input(Bool())
    val link      = Input(Bool())
    // Register file outputs
    val writeRd     = Output(UInt(5.W))
    val writeData   = Output(UInt(p.xlen.W))
    val writeEnable = Output(Bool())
  })
  // Write-back selection
  io.writeData := Mux(io.link, io.pcPlus4,
                  Mux(io.memToReg, io.memData, io.aluResult))
  // Register file write control
  io.writeRd     := io.rd
  io.writeEnable := io.valid && io.regWrite && (io.rd =/= 0.U)
}

