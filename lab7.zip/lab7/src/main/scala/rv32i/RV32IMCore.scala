package rv32i
import chisel3._
import chisel3.util._

class RV32IMCore(p: CoreParams) extends Module {
  val io = IO(new Bundle {
    val pc = Output(UInt(p.xlen.W)); val nextPc = Output(UInt(p.xlen.W))
    val writeBack = Output(UInt(p.xlen.W)); val debugInstr = Output(UInt(32.W))
    val debugX1 = Output(UInt(p.xlen.W)); val debugX2 = Output(UInt(p.xlen.W))
    val debugX3 = Output(UInt(p.xlen.W)); val debugX4 = Output(UInt(p.xlen.W))
    val debugX5 = Output(UInt(p.xlen.W)); val debugX6 = Output(UInt(p.xlen.W))
    val debugALU = Output(UInt(p.xlen.W)); val debugImm = Output(UInt(p.xlen.W))
    val debugFetchPC = Output(UInt(p.xlen.W)); val debugDecodePC = Output(UInt(p.xlen.W))
    val debugExecPC = Output(UInt(p.xlen.W)); val debugMemPC = Output(UInt(p.xlen.W))
    val debugValid = Output(Bool()); val debugFlush = Output(Bool())
    val debugStall = Output(Bool()); val debugIFIDValid = Output(Bool())
    val debugIDEXValid = Output(Bool()); val debugEXMEMValid = Output(Bool())
    val debugMEMWBValid = Output(Bool())
  })

  val instructionMemory = Module(new InstructionMemory(p))
  val dataMemory = Module(new DataMemory(p))
  val idStage = Module(new IDStage(p)); val exStage = Module(new EXStage(p))
  val memStage = Module(new MEMStage(p)); val wbStage = Module(new WBStage(p))
  val forwardingUnit = Module(new ForwardingUnit)
  val hazardUnit = Module(new HazardDetectionUnit)

  val NOP = "h00000013".U(32.W)
  val pcReg = RegInit(0.U(p.xlen.W))
  val sequentialPC = pcReg + 4.U

  // IF/ID
  val ifidValid = RegInit(false.B)
  val ifidPC = RegInit(0.U(p.xlen.W)); val ifidInstr = RegInit(NOP)

  // ID/EX
  val idexValid = RegInit(false.B)
  val idexPC = RegInit(0.U(p.xlen.W)); val idexInstr = RegInit(NOP)
  val idexRs1 = RegInit(0.U(5.W)); val idexRs2 = RegInit(0.U(5.W))
  val idexRd = RegInit(0.U(5.W))
  val idexRs1Data = RegInit(0.U(p.xlen.W))
  val idexRs2Data = RegInit(0.U(p.xlen.W))
  val idexImm = RegInit(0.U(p.xlen.W))
  val idexFunct3 = RegInit(0.U(3.W))
  val idexAluOp = RegInit(ALUOp.NOP)
  val idexAluASel = RegInit(ALUASel.RS1)
  val idexAluSrc = RegInit(false.B); val idexRegWrite = RegInit(false.B)
  val idexMemRead = RegInit(false.B); val idexMemWrite = RegInit(false.B)
  val idexMemToReg = RegInit(false.B); val idexBranch = RegInit(false.B)
  val idexJump = RegInit(false.B); val idexJalr = RegInit(false.B)

  // EX/MEM
  val exmemValid = RegInit(false.B)
  val exmemPC = RegInit(0.U(p.xlen.W))
  val exmemAluResult = RegInit(0.U(p.xlen.W))
  val exmemStoreData = RegInit(0.U(p.xlen.W))
  val exmemRd = RegInit(0.U(5.W)); val exmemFunct3 = RegInit(0.U(3.W))
  val exmemPCPlus4 = RegInit(0.U(p.xlen.W))
  val exmemRegWrite = RegInit(false.B); val exmemMemRead = RegInit(false.B)
  val exmemMemWrite = RegInit(false.B); val exmemMemToReg = RegInit(false.B)
  val exmemLink = RegInit(false.B)

  // MEM/WB
  val memwbValid = RegInit(false.B)
  val memwbAluResult = RegInit(0.U(p.xlen.W))
  val memwbMemData = RegInit(0.U(p.xlen.W))
  val memwbPCPlus4 = RegInit(0.U(p.xlen.W))
  val memwbRd = RegInit(0.U(5.W))
  val memwbRegWrite = RegInit(false.B)
  val memwbMemToReg = RegInit(false.B); val memwbLink = RegInit(false.B)

  // Instruction fetch
  instructionMemory.io.addr := pcReg
  val fetchedInstr = instructionMemory.io.instr

  // Write-back
  wbStage.io.valid := memwbValid
  wbStage.io.aluResult := memwbAluResult; wbStage.io.memData := memwbMemData
  wbStage.io.pcPlus4 := memwbPCPlus4; wbStage.io.rd := memwbRd
  wbStage.io.regWrite := memwbRegWrite; wbStage.io.memToReg := memwbMemToReg
  wbStage.io.link := memwbLink
  val wbData = wbStage.io.writeData

  // Decode
  idStage.io.valid := ifidValid; idStage.io.pc := ifidPC
  idStage.io.instr := ifidInstr
  idStage.io.wbRd := wbStage.io.writeRd
  idStage.io.wbWriteData := wbData
  idStage.io.wbWriteEnable := wbStage.io.writeEnable

  // Hazard detection
  hazardUnit.io.ifidRs1 := idStage.io.rs1; hazardUnit.io.ifidRs2 := idStage.io.rs2
  hazardUnit.io.ifidUsesRs1 := idStage.io.usesRs1
  hazardUnit.io.ifidUsesRs2 := idStage.io.usesRs2
  hazardUnit.io.idexRd := idexRd; hazardUnit.io.idexMemRead := idexMemRead
  hazardUnit.io.idexValid := idexValid

  // Forwarding
  forwardingUnit.io.idexRs1 := idexRs1; forwardingUnit.io.idexRs2 := idexRs2
  forwardingUnit.io.exmemRd := exmemRd
  forwardingUnit.io.exmemRegWrite := exmemRegWrite
  forwardingUnit.io.exmemValid := exmemValid
  forwardingUnit.io.memwbRd := memwbRd
  forwardingUnit.io.memwbRegWrite := memwbRegWrite
  forwardingUnit.io.memwbValid := memwbValid

  // Execute
  exStage.io.valid := idexValid; exStage.io.pc := idexPC
  exStage.io.rs1 := idexRs1; exStage.io.rs2 := idexRs2; exStage.io.rd := idexRd
  exStage.io.rs1Data := idexRs1Data; exStage.io.rs2Data := idexRs2Data
  exStage.io.imm := idexImm; exStage.io.funct3 := idexFunct3
  exStage.io.aluOp := idexAluOp; exStage.io.aluASel := idexAluASel
  exStage.io.aluSrc := idexAluSrc; exStage.io.regWrite := idexRegWrite
  exStage.io.memRead := idexMemRead; exStage.io.memWrite := idexMemWrite
  exStage.io.memToReg := idexMemToReg; exStage.io.branch := idexBranch
  exStage.io.jump := idexJump; exStage.io.jalr := idexJalr
  exStage.io.forwardA := forwardingUnit.io.forwardA
  exStage.io.forwardB := forwardingUnit.io.forwardB
  exStage.io.exmemForwardData := Mux(exmemLink, exmemPCPlus4, exmemAluResult)
  exStage.io.memwbForwardData := wbData

  val redirect = exStage.io.redirect
  val redirectPC = exStage.io.redirectPC

  // Memory stage
  memStage.io.valid := exmemValid
  memStage.io.aluResult := exmemAluResult; memStage.io.storeData := exmemStoreData
  memStage.io.rd := exmemRd; memStage.io.funct3 := exmemFunct3
  memStage.io.pcPlus4 := exmemPCPlus4
  memStage.io.regWrite := exmemRegWrite; memStage.io.memRead := exmemMemRead
  memStage.io.memWrite := exmemMemWrite; memStage.io.memToReg := exmemMemToReg
  memStage.io.link := exmemLink

  dataMemory.io.addr := memStage.io.memAddr
  dataMemory.io.wdata := memStage.io.memWdata
  dataMemory.io.memRead := memStage.io.memReadOut
  dataMemory.io.memWrite := memStage.io.memWriteOut
  dataMemory.io.funct3 := memStage.io.memFunct3
  memStage.io.memRdata := dataMemory.io.rdata

  // PC update
  when(redirect) { pcReg := redirectPC }
    .elsewhen(!hazardUnit.io.stallPC) { pcReg := sequentialPC }

  // IF/ID update
  when(redirect) {
    ifidValid := false.B; ifidPC := 0.U; ifidInstr := NOP
  }.elsewhen(!hazardUnit.io.stallIFID) {
    ifidValid := true.B; ifidPC := pcReg; ifidInstr := fetchedInstr
  }

  // ID/EX update
  when(redirect || hazardUnit.io.bubbleIDEX) {
    idexValid := false.B; idexPC := 0.U; idexInstr := NOP
    idexRs1 := 0.U; idexRs2 := 0.U; idexRd := 0.U
    idexRs1Data := 0.U; idexRs2Data := 0.U; idexImm := 0.U
    idexFunct3 := 0.U; idexAluOp := ALUOp.NOP
    idexAluASel := ALUASel.RS1; idexAluSrc := false.B
    idexRegWrite := false.B; idexMemRead := false.B
    idexMemWrite := false.B; idexMemToReg := false.B
    idexBranch := false.B; idexJump := false.B; idexJalr := false.B
  }.otherwise {
    idexValid := ifidValid && idStage.io.valid
    idexPC := ifidPC; idexInstr := ifidInstr
    idexRs1 := idStage.io.rs1; idexRs2 := idStage.io.rs2
    idexRd := idStage.io.rd
    idexRs1Data := idStage.io.rs1Data; idexRs2Data := idStage.io.rs2Data
    idexImm := idStage.io.imm; idexFunct3 := idStage.io.funct3
    idexAluOp := idStage.io.aluOp; idexAluASel := idStage.io.aluASel
    idexAluSrc := idStage.io.aluSrc; idexRegWrite := idStage.io.regWrite
    idexMemRead := idStage.io.memRead; idexMemWrite := idStage.io.memWrite
    idexMemToReg := idStage.io.memToReg; idexBranch := idStage.io.branch
    idexJump := idStage.io.jump; idexJalr := idStage.io.jalr
  }

  // EX/MEM update
  exmemValid := idexValid; exmemPC := idexPC
  exmemAluResult := exStage.io.aluResult
  exmemStoreData := exStage.io.storeData
  exmemRd := exStage.io.rdOut; exmemFunct3 := exStage.io.funct3Out
  exmemPCPlus4 := exStage.io.pcPlus4
  exmemRegWrite := exStage.io.regWriteOut
  exmemMemRead := exStage.io.memReadOut
  exmemMemWrite := exStage.io.memWriteOut
  exmemMemToReg := exStage.io.memToRegOut
  exmemLink := exStage.io.linkOut

  // MEM/WB update
  memwbValid := exmemValid
  memwbAluResult := memStage.io.aluResultOut
  memwbMemData := memStage.io.memDataOut
  memwbPCPlus4 := memStage.io.pcPlus4Out
  memwbRd := memStage.io.rdOut
  memwbRegWrite := memStage.io.regWriteOut
  memwbMemToReg := memStage.io.memToRegOut
  memwbLink := memStage.io.linkOut

  // Top-level outputs
  io.pc := pcReg
  io.nextPc := Mux(redirect, redirectPC,
               Mux(hazardUnit.io.stallPC, pcReg, sequentialPC))
  io.writeBack := Mux(wbStage.io.writeEnable, wbData, 0.U)

  // Debug outputs
  io.debugInstr := idexInstr
  io.debugX1 := idStage.io.debugX1; io.debugX2 := idStage.io.debugX2
  io.debugX3 := idStage.io.debugX3; io.debugX4 := idStage.io.debugX4
  io.debugX5 := idStage.io.debugX5; io.debugX6 := idStage.io.debugX6
  io.debugALU := exStage.io.debugALU; io.debugImm := idexImm
  io.debugFetchPC := pcReg; io.debugDecodePC := ifidPC
  io.debugExecPC := idexPC; io.debugMemPC := exmemPC
  io.debugValid := idexValid; io.debugFlush := redirect
  io.debugStall := hazardUnit.io.stallPC
  io.debugIFIDValid := ifidValid; io.debugIDEXValid := idexValid
  io.debugEXMEMValid := exmemValid; io.debugMEMWBValid := memwbValid
}

