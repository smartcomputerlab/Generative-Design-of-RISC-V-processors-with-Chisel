package rv32i

import chisel3._

class IFIDBundle(p: CoreParams) extends Bundle {
  val valid = Bool()
  val pc    = UInt(p.xlen.W)
  val instr = UInt(32.W)
}

class IDEXBundle(p: CoreParams) extends Bundle {
  val valid = Bool()

  val pc = UInt(p.xlen.W)

  val rs1 = UInt(5.W)
  val rs2 = UInt(5.W)
  val rd  = UInt(5.W)

  val rs1Data = UInt(p.xlen.W)
  val rs2Data = UInt(p.xlen.W)

  val imm    = UInt(p.xlen.W)
  val funct3 = UInt(3.W)

  val aluOp  = UInt(ALUOp.width.W)
  val aluSrc = Bool()

  val regWrite = Bool()
  val memRead  = Bool()
  val memWrite = Bool()
  val memToReg = Bool()

  val branch = Bool()
  val jump   = Bool()
  val jalr   = Bool()
}

class EXMEMBundle(p: CoreParams) extends Bundle {
  val valid = Bool()

  val pcPlus4 = UInt(p.xlen.W)

  val aluResult = UInt(p.xlen.W)
  val storeData = UInt(p.xlen.W)

  val rd     = UInt(5.W)
  val funct3 = UInt(3.W)

  val regWrite = Bool()
  val memRead  = Bool()
  val memWrite = Bool()
  val memToReg = Bool()

  // Needed to select PC+4 for JAL/JALR write-back.
  val link = Bool()
}

class MEMWBBundle(p: CoreParams) extends Bundle {
  val valid = Bool()

  val aluResult = UInt(p.xlen.W)
  val memData   = UInt(p.xlen.W)
  val pcPlus4   = UInt(p.xlen.W)

  val rd = UInt(5.W)

  val regWrite = Bool()
  val memToReg = Bool()
  val link     = Bool()
}

