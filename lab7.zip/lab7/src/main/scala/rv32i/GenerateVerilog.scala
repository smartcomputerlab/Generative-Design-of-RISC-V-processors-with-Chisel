package rv32i

import chisel3.stage.ChiselStage

object GenerateVerilog extends App {
  val p = CoreParams()

  (new ChiselStage).emitVerilog(
    new RV32IMCore(p),
    Array("--target-dir", "generated")
  )
}

