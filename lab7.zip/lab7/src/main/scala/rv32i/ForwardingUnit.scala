package rv32i

import chisel3._

class ForwardingUnit extends Module {

  val io = IO(new Bundle {

    // Instruction currently in EX
    val idexRs1 = Input(UInt(5.W))
    val idexRs2 = Input(UInt(5.W))

    // Instruction currently in MEM
    val exmemRd       = Input(UInt(5.W))
    val exmemRegWrite = Input(Bool())
    val exmemValid    = Input(Bool())

    // Instruction currently in WB
    val memwbRd       = Input(UInt(5.W))
    val memwbRegWrite = Input(Bool())
    val memwbValid    = Input(Bool())

    // 00 = ID/EX register value
    // 01 = MEM/WB result
    // 10 = EX/MEM result

    val forwardA = Output(UInt(2.W))
    val forwardB = Output(UInt(2.W))
  })

  // ============================================================
  // Defaults: no forwarding
  // ============================================================

  io.forwardA := 0.U
  io.forwardB := 0.U

  // ============================================================
  // RS1 forwarding
  // ============================================================

  when(
    io.exmemValid &&
    io.exmemRegWrite &&
    (io.exmemRd =/= 0.U) &&
    (io.exmemRd === io.idexRs1)
  ) {

    // EX/MEM has highest priority.
    io.forwardA := 2.U

  }.elsewhen(
    io.memwbValid &&
    io.memwbRegWrite &&
    (io.memwbRd =/= 0.U) &&
    (io.memwbRd === io.idexRs1)
  ) {

    io.forwardA := 1.U
  }

  // ============================================================
  // RS2 forwarding
  // ============================================================

  when(
    io.exmemValid &&
    io.exmemRegWrite &&
    (io.exmemRd =/= 0.U) &&
    (io.exmemRd === io.idexRs2)
  ) {

    io.forwardB := 2.U

  }.elsewhen(
    io.memwbValid &&
    io.memwbRegWrite &&
    (io.memwbRd =/= 0.U) &&
    (io.memwbRd === io.idexRs2)
  ) {

    io.forwardB := 1.U
  }
}

