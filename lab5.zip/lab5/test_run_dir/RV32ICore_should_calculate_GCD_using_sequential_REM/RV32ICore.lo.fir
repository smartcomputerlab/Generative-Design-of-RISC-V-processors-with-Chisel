FIRRTL version 1.1.0
circuit RV32ICore :
  module InstructionMemory :
    input clock : Clock
    input reset : UInt<1>
    input io_addr : UInt<32>
    output io_instr : UInt<32>

    mem mem : @[InstructionMemory.scala 18:16]
      data-type => UInt<32>
      depth => 256
      read-latency => 0
      write-latency => 1
      reader => io_instr_MPORT
      read-under-write => undefined
    node wordAddr = dshr(io_addr, UInt<2>("h2")) @[InstructionMemory.scala 27:26]
    node _io_instr_T = lt(wordAddr, UInt<9>("h100")) @[InstructionMemory.scala 31:14]
    node _io_instr_T_1 = bits(wordAddr, 7, 0) @[InstructionMemory.scala 32:8]
    node _io_instr_T_2 = mux(_io_instr_T, mem.io_instr_MPORT.data, UInt<32>("h0")) @[InstructionMemory.scala 30:18]
    io_instr <= _io_instr_T_2 @[InstructionMemory.scala 30:12]
    mem.io_instr_MPORT.addr <= _io_instr_T_1 @[InstructionMemory.scala 32:8]
    mem.io_instr_MPORT.en <= UInt<1>("h1") @[InstructionMemory.scala 32:8]
    mem.io_instr_MPORT.clk <= clock @[InstructionMemory.scala 32:8]

  module Decoder :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    output io_rs1 : UInt<5>
    output io_rs2 : UInt<5>
    output io_rd : UInt<5>
    output io_funct3 : UInt<3>
    output io_funct7 : UInt<7>
    output io_aluSrc : UInt<1>
    output io_regWrite : UInt<1>
    output io_valid : UInt<1>
    output io_aluOp : UInt<5>

    node opcode = bits(io_instr, 6, 0) @[Decoder.scala 31:24]
    node funct3 = bits(io_instr, 14, 12) @[Decoder.scala 32:24]
    node funct7 = bits(io_instr, 31, 25) @[Decoder.scala 33:24]
    node _io_rs1_T = bits(io_instr, 19, 15) @[Decoder.scala 35:24]
    node _io_rs2_T = bits(io_instr, 24, 20) @[Decoder.scala 36:24]
    node _io_rd_T = bits(io_instr, 11, 7) @[Decoder.scala 37:24]
    node _T = eq(UInt<6>("h33"), opcode) @[Decoder.scala 73:18]
    node _T_1 = eq(UInt<1>("h0"), funct3) @[Decoder.scala 84:22]
    node _T_2 = eq(funct7, UInt<1>("h1")) @[Decoder.scala 88:23]
    node _T_3 = eq(funct7, UInt<6>("h20")) @[Decoder.scala 90:29]
    node _GEN_0 = mux(_T_3, UInt<5>("h1"), UInt<5>("h0")) @[Decoder.scala 90:47 91:22 93:22]
    node _GEN_1 = mux(_T_2, UInt<5>("ha"), _GEN_0) @[Decoder.scala 88:41 89:22]
    node _T_4 = eq(UInt<1>("h1"), funct3) @[Decoder.scala 84:22]
    node _T_5 = eq(funct7, UInt<1>("h1")) @[Decoder.scala 99:23]
    node _GEN_2 = mux(_T_5, UInt<5>("hb"), UInt<5>("h2")) @[Decoder.scala 100:22 102:22 99:41]
    node _T_6 = eq(UInt<2>("h2"), funct3) @[Decoder.scala 84:22]
    node _T_7 = eq(funct7, UInt<1>("h1")) @[Decoder.scala 108:23]
    node _GEN_3 = mux(_T_7, UInt<5>("hc"), UInt<5>("h3")) @[Decoder.scala 108:41 109:22 111:22]
    node _T_8 = eq(UInt<2>("h3"), funct3) @[Decoder.scala 84:22]
    node _T_9 = eq(funct7, UInt<1>("h1")) @[Decoder.scala 117:23]
    node _GEN_4 = mux(_T_9, UInt<5>("hd"), UInt<5>("h4")) @[Decoder.scala 117:41 118:22 120:22]
    node _T_10 = eq(UInt<3>("h4"), funct3) @[Decoder.scala 84:22]
    node _T_11 = eq(UInt<3>("h5"), funct3) @[Decoder.scala 84:22]
    node _T_12 = eq(funct7, UInt<6>("h20")) @[Decoder.scala 131:23]
    node _GEN_5 = mux(_T_12, UInt<5>("h7"), UInt<5>("h6")) @[Decoder.scala 131:41 132:22 134:22]
    node _T_13 = eq(UInt<3>("h6"), funct3) @[Decoder.scala 84:22]
    node _T_14 = eq(UInt<3>("h7"), funct3) @[Decoder.scala 84:22]
    node _GEN_6 = mux(_T_14, UInt<5>("h9"), UInt<5>("h1f")) @[Decoder.scala 145:20 67:12 84:22]
    node _GEN_7 = mux(_T_13, UInt<5>("h8"), _GEN_6) @[Decoder.scala 140:20 84:22]
    node _GEN_8 = mux(_T_11, _GEN_5, _GEN_7) @[Decoder.scala 84:22]
    node _GEN_9 = mux(_T_10, UInt<5>("h5"), _GEN_8) @[Decoder.scala 126:20 84:22]
    node _GEN_10 = mux(_T_8, _GEN_4, _GEN_9) @[Decoder.scala 84:22]
    node _GEN_11 = mux(_T_6, _GEN_3, _GEN_10) @[Decoder.scala 84:22]
    node _GEN_12 = mux(_T_4, _GEN_2, _GEN_11) @[Decoder.scala 84:22]
    node _GEN_13 = mux(_T_1, _GEN_1, _GEN_12) @[Decoder.scala 84:22]
    node _T_15 = eq(UInt<5>("h13"), opcode) @[Decoder.scala 73:18]
    node _T_16 = eq(UInt<1>("h0"), funct3) @[Decoder.scala 159:22]
    node _T_17 = eq(UInt<1>("h1"), funct3) @[Decoder.scala 159:22]
    node _T_18 = eq(UInt<2>("h2"), funct3) @[Decoder.scala 159:22]
    node _T_19 = eq(UInt<2>("h3"), funct3) @[Decoder.scala 159:22]
    node _T_20 = eq(UInt<3>("h4"), funct3) @[Decoder.scala 159:22]
    node _T_21 = eq(UInt<3>("h5"), funct3) @[Decoder.scala 159:22]
    node _T_22 = eq(funct7, UInt<6>("h20")) @[Decoder.scala 188:23]
    node _GEN_14 = mux(_T_22, UInt<5>("h7"), UInt<5>("h6")) @[Decoder.scala 188:41 189:22 191:22]
    node _T_23 = eq(UInt<3>("h6"), funct3) @[Decoder.scala 159:22]
    node _T_24 = eq(UInt<3>("h7"), funct3) @[Decoder.scala 159:22]
    node _GEN_15 = mux(_T_24, UInt<5>("h9"), UInt<5>("h1f")) @[Decoder.scala 159:22 202:20 67:12]
    node _GEN_16 = mux(_T_23, UInt<5>("h8"), _GEN_15) @[Decoder.scala 159:22 197:20]
    node _GEN_17 = mux(_T_21, _GEN_14, _GEN_16) @[Decoder.scala 159:22]
    node _GEN_18 = mux(_T_20, UInt<5>("h5"), _GEN_17) @[Decoder.scala 159:22 183:20]
    node _GEN_19 = mux(_T_19, UInt<5>("h4"), _GEN_18) @[Decoder.scala 159:22 178:20]
    node _GEN_20 = mux(_T_18, UInt<5>("h3"), _GEN_19) @[Decoder.scala 159:22 173:20]
    node _GEN_21 = mux(_T_17, UInt<5>("h2"), _GEN_20) @[Decoder.scala 159:22 168:20]
    node _GEN_22 = mux(_T_16, UInt<5>("h0"), _GEN_21) @[Decoder.scala 159:22 163:20]
    node _T_25 = eq(UInt<2>("h3"), opcode) @[Decoder.scala 73:18]
    node _T_26 = eq(UInt<6>("h23"), opcode) @[Decoder.scala 73:18]
    node _T_27 = eq(UInt<7>("h63"), opcode) @[Decoder.scala 73:18]
    node _T_28 = eq(UInt<1>("h0"), funct3) @[Decoder.scala 238:22]
    node _T_29 = eq(UInt<1>("h1"), funct3) @[Decoder.scala 238:22]
    node _T_30 = eq(UInt<3>("h4"), funct3) @[Decoder.scala 238:22]
    node _T_31 = eq(UInt<3>("h5"), funct3) @[Decoder.scala 238:22]
    node _T_32 = eq(UInt<3>("h6"), funct3) @[Decoder.scala 238:22]
    node _T_33 = eq(UInt<3>("h7"), funct3) @[Decoder.scala 238:22]
    node _GEN_23 = mux(_T_33, UInt<5>("h4"), UInt<5>("h1f")) @[Decoder.scala 238:22 267:20 67:12]
    node _GEN_24 = mux(_T_32, UInt<5>("h4"), _GEN_23) @[Decoder.scala 238:22 262:20]
    node _GEN_25 = mux(_T_31, UInt<5>("h3"), _GEN_24) @[Decoder.scala 238:22 257:20]
    node _GEN_26 = mux(_T_30, UInt<5>("h3"), _GEN_25) @[Decoder.scala 238:22 252:20]
    node _GEN_27 = mux(_T_29, UInt<5>("hf"), _GEN_26) @[Decoder.scala 238:22 247:20]
    node _GEN_28 = mux(_T_28, UInt<5>("he"), _GEN_27) @[Decoder.scala 238:22 242:20]
    node _T_34 = eq(UInt<7>("h6f"), opcode) @[Decoder.scala 73:18]
    node _T_35 = eq(UInt<7>("h67"), opcode) @[Decoder.scala 73:18]
    node _T_36 = eq(UInt<6>("h37"), opcode) @[Decoder.scala 73:18]
    node _T_37 = eq(UInt<5>("h17"), opcode) @[Decoder.scala 73:18]
    node _GEN_29 = mux(_T_37, UInt<1>("h1"), UInt<1>("h0")) @[Decoder.scala 73:18 310:19 60:15]
    node _GEN_30 = mux(_T_37, UInt<5>("h0"), UInt<5>("h1f")) @[Decoder.scala 73:18 313:19 67:12]
    node _GEN_31 = mux(_T_36, UInt<1>("h1"), _GEN_29) @[Decoder.scala 73:18 299:19]
    node _GEN_32 = mux(_T_36, UInt<5>("h0"), _GEN_30) @[Decoder.scala 73:18 302:19]
    node _GEN_33 = mux(_T_35, UInt<1>("h1"), _GEN_31) @[Decoder.scala 73:18 288:19]
    node _GEN_34 = mux(_T_35, UInt<5>("h0"), _GEN_32) @[Decoder.scala 73:18 291:19]
    node _GEN_35 = mux(_T_34, UInt<1>("h1"), _GEN_33) @[Decoder.scala 73:18 277:19]
    node _GEN_36 = mux(_T_34, UInt<1>("h0"), _GEN_33) @[Decoder.scala 73:18 278:19]
    node _GEN_37 = mux(_T_34, UInt<5>("h1f"), _GEN_34) @[Decoder.scala 73:18 280:19]
    node _GEN_38 = mux(_T_27, UInt<1>("h1"), _GEN_35) @[Decoder.scala 73:18 234:19]
    node _GEN_39 = mux(_T_27, UInt<1>("h0"), _GEN_36) @[Decoder.scala 73:18 235:19]
    node _GEN_40 = mux(_T_27, UInt<1>("h0"), _GEN_35) @[Decoder.scala 73:18 236:19]
    node _GEN_41 = mux(_T_27, _GEN_28, _GEN_37) @[Decoder.scala 73:18]
    node _GEN_42 = mux(_T_26, UInt<1>("h1"), _GEN_38) @[Decoder.scala 73:18 223:19]
    node _GEN_43 = mux(_T_26, UInt<1>("h1"), _GEN_39) @[Decoder.scala 73:18 224:19]
    node _GEN_44 = mux(_T_26, UInt<1>("h0"), _GEN_40) @[Decoder.scala 73:18 225:19]
    node _GEN_45 = mux(_T_26, UInt<5>("h0"), _GEN_41) @[Decoder.scala 73:18 226:19]
    node _GEN_46 = mux(_T_25, UInt<1>("h1"), _GEN_42) @[Decoder.scala 73:18 212:19]
    node _GEN_47 = mux(_T_25, UInt<1>("h1"), _GEN_43) @[Decoder.scala 73:18 213:19]
    node _GEN_48 = mux(_T_25, UInt<1>("h1"), _GEN_44) @[Decoder.scala 73:18 214:19]
    node _GEN_49 = mux(_T_25, UInt<5>("h0"), _GEN_45) @[Decoder.scala 73:18 215:19]
    node _GEN_50 = mux(_T_15, UInt<1>("h1"), _GEN_46) @[Decoder.scala 73:18 155:19]
    node _GEN_51 = mux(_T_15, UInt<1>("h1"), _GEN_47) @[Decoder.scala 73:18 156:19]
    node _GEN_52 = mux(_T_15, UInt<1>("h1"), _GEN_48) @[Decoder.scala 73:18 157:19]
    node _GEN_53 = mux(_T_15, _GEN_22, _GEN_49) @[Decoder.scala 73:18]
    node _GEN_54 = mux(_T, UInt<1>("h1"), _GEN_50) @[Decoder.scala 73:18 80:19]
    node _GEN_55 = mux(_T, UInt<1>("h0"), _GEN_51) @[Decoder.scala 73:18 81:19]
    node _GEN_56 = mux(_T, UInt<1>("h1"), _GEN_52) @[Decoder.scala 73:18 82:19]
    node _GEN_57 = mux(_T, _GEN_13, _GEN_53) @[Decoder.scala 73:18]
    io_rs1 <= _io_rs1_T @[Decoder.scala 35:13]
    io_rs2 <= _io_rs2_T @[Decoder.scala 36:13]
    io_rd <= _io_rd_T @[Decoder.scala 37:13]
    io_funct3 <= funct3 @[Decoder.scala 39:13]
    io_funct7 <= funct7 @[Decoder.scala 40:13]
    io_aluSrc <= _GEN_55
    io_regWrite <= _GEN_56
    io_valid <= _GEN_54
    io_aluOp <= _GEN_57

  module Control :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    output io_valid : UInt<1>
    output io_aluOp : UInt<5>
    output io_aluSrc : UInt<1>
    output io_memRead : UInt<1>
    output io_memWrite : UInt<1>
    output io_memToReg : UInt<1>
    output io_regWrite : UInt<1>
    output io_branch : UInt<1>
    output io_jump : UInt<1>
    output io_jalr : UInt<1>

    node op = bits(io_instr, 6, 0) @[Control.scala 21:20]
    node f3 = bits(io_instr, 14, 12) @[Control.scala 22:20]
    node f7 = bits(io_instr, 31, 25) @[Control.scala 23:20]
    node _rOp_T = cat(f7, f3) @[Cat.scala 33:92]
    node _rOp_T_1 = eq(UInt<1>("h0"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_2 = mux(_rOp_T_1, UInt<5>("h0"), UInt<5>("h1f")) @[Mux.scala 81:58]
    node _rOp_T_3 = eq(UInt<9>("h100"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_4 = mux(_rOp_T_3, UInt<5>("h1"), _rOp_T_2) @[Mux.scala 81:58]
    node _rOp_T_5 = eq(UInt<1>("h1"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_6 = mux(_rOp_T_5, UInt<5>("h2"), _rOp_T_4) @[Mux.scala 81:58]
    node _rOp_T_7 = eq(UInt<2>("h2"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_8 = mux(_rOp_T_7, UInt<5>("h3"), _rOp_T_6) @[Mux.scala 81:58]
    node _rOp_T_9 = eq(UInt<2>("h3"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_10 = mux(_rOp_T_9, UInt<5>("h4"), _rOp_T_8) @[Mux.scala 81:58]
    node _rOp_T_11 = eq(UInt<3>("h4"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_12 = mux(_rOp_T_11, UInt<5>("h5"), _rOp_T_10) @[Mux.scala 81:58]
    node _rOp_T_13 = eq(UInt<3>("h5"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_14 = mux(_rOp_T_13, UInt<5>("h6"), _rOp_T_12) @[Mux.scala 81:58]
    node _rOp_T_15 = eq(UInt<9>("h105"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_16 = mux(_rOp_T_15, UInt<5>("h7"), _rOp_T_14) @[Mux.scala 81:58]
    node _rOp_T_17 = eq(UInt<3>("h6"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_18 = mux(_rOp_T_17, UInt<5>("h8"), _rOp_T_16) @[Mux.scala 81:58]
    node _rOp_T_19 = eq(UInt<3>("h7"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_20 = mux(_rOp_T_19, UInt<5>("h9"), _rOp_T_18) @[Mux.scala 81:58]
    node _rOp_T_21 = eq(UInt<4>("h8"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_22 = mux(_rOp_T_21, UInt<5>("ha"), _rOp_T_20) @[Mux.scala 81:58]
    node _rOp_T_23 = eq(UInt<4>("h9"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_24 = mux(_rOp_T_23, UInt<5>("hb"), _rOp_T_22) @[Mux.scala 81:58]
    node _rOp_T_25 = eq(UInt<4>("ha"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_26 = mux(_rOp_T_25, UInt<5>("hc"), _rOp_T_24) @[Mux.scala 81:58]
    node _rOp_T_27 = eq(UInt<4>("hb"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_28 = mux(_rOp_T_27, UInt<5>("hd"), _rOp_T_26) @[Mux.scala 81:58]
    node _rOp_T_29 = eq(UInt<4>("hc"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_30 = mux(_rOp_T_29, UInt<5>("h10"), _rOp_T_28) @[Mux.scala 81:58]
    node _rOp_T_31 = eq(UInt<4>("hd"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_32 = mux(_rOp_T_31, UInt<5>("h11"), _rOp_T_30) @[Mux.scala 81:58]
    node _rOp_T_33 = eq(UInt<4>("he"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_34 = mux(_rOp_T_33, UInt<5>("h12"), _rOp_T_32) @[Mux.scala 81:58]
    node _rOp_T_35 = eq(UInt<4>("hf"), _rOp_T) @[Mux.scala 81:61]
    node rOp = mux(_rOp_T_35, UInt<5>("h13"), _rOp_T_34) @[Mux.scala 81:58]
    node _iOp_T = eq(f7, UInt<1>("h0")) @[Control.scala 84:16]
    node _iOp_T_1 = mux(_iOp_T, UInt<5>("h2"), UInt<5>("h1f")) @[Control.scala 84:12]
    node _iOp_T_2 = eq(f7, UInt<1>("h0")) @[Control.scala 88:16]
    node _iOp_T_3 = eq(f7, UInt<6>("h20")) @[Control.scala 90:18]
    node _iOp_T_4 = mux(_iOp_T_3, UInt<5>("h7"), UInt<5>("h1f")) @[Control.scala 90:14]
    node _iOp_T_5 = mux(_iOp_T_2, UInt<5>("h6"), _iOp_T_4) @[Control.scala 88:12]
    node _iOp_T_6 = eq(UInt<2>("h2"), f3) @[Mux.scala 81:61]
    node _iOp_T_7 = mux(_iOp_T_6, UInt<5>("h3"), UInt<5>("h0")) @[Mux.scala 81:58]
    node _iOp_T_8 = eq(UInt<2>("h3"), f3) @[Mux.scala 81:61]
    node _iOp_T_9 = mux(_iOp_T_8, UInt<5>("h4"), _iOp_T_7) @[Mux.scala 81:58]
    node _iOp_T_10 = eq(UInt<3>("h4"), f3) @[Mux.scala 81:61]
    node _iOp_T_11 = mux(_iOp_T_10, UInt<5>("h5"), _iOp_T_9) @[Mux.scala 81:58]
    node _iOp_T_12 = eq(UInt<3>("h6"), f3) @[Mux.scala 81:61]
    node _iOp_T_13 = mux(_iOp_T_12, UInt<5>("h8"), _iOp_T_11) @[Mux.scala 81:58]
    node _iOp_T_14 = eq(UInt<3>("h7"), f3) @[Mux.scala 81:61]
    node _iOp_T_15 = mux(_iOp_T_14, UInt<5>("h9"), _iOp_T_13) @[Mux.scala 81:58]
    node _iOp_T_16 = eq(UInt<1>("h1"), f3) @[Mux.scala 81:61]
    node _iOp_T_17 = mux(_iOp_T_16, _iOp_T_1, _iOp_T_15) @[Mux.scala 81:58]
    node _iOp_T_18 = eq(UInt<3>("h5"), f3) @[Mux.scala 81:61]
    node iOp = mux(_iOp_T_18, _iOp_T_5, _iOp_T_17) @[Mux.scala 81:58]
    node _bOp_T = eq(UInt<1>("h0"), f3) @[Mux.scala 81:61]
    node _bOp_T_1 = mux(_bOp_T, UInt<5>("he"), UInt<5>("h1f")) @[Mux.scala 81:58]
    node _bOp_T_2 = eq(UInt<1>("h1"), f3) @[Mux.scala 81:61]
    node _bOp_T_3 = mux(_bOp_T_2, UInt<5>("hf"), _bOp_T_1) @[Mux.scala 81:58]
    node _bOp_T_4 = eq(UInt<3>("h4"), f3) @[Mux.scala 81:61]
    node _bOp_T_5 = mux(_bOp_T_4, UInt<5>("h3"), _bOp_T_3) @[Mux.scala 81:58]
    node _bOp_T_6 = eq(UInt<3>("h5"), f3) @[Mux.scala 81:61]
    node _bOp_T_7 = mux(_bOp_T_6, UInt<5>("h3"), _bOp_T_5) @[Mux.scala 81:58]
    node _bOp_T_8 = eq(UInt<3>("h6"), f3) @[Mux.scala 81:61]
    node _bOp_T_9 = mux(_bOp_T_8, UInt<5>("h4"), _bOp_T_7) @[Mux.scala 81:58]
    node _bOp_T_10 = eq(UInt<3>("h7"), f3) @[Mux.scala 81:61]
    node bOp = mux(_bOp_T_10, UInt<5>("h4"), _bOp_T_9) @[Mux.scala 81:58]
    node _T = eq(UInt<6>("h33"), op) @[Control.scala 131:14]
    node _T_1 = eq(UInt<5>("h13"), op) @[Control.scala 131:14]
    node _T_2 = eq(UInt<2>("h3"), op) @[Control.scala 131:14]
    node _T_3 = eq(UInt<6>("h23"), op) @[Control.scala 131:14]
    node _T_4 = eq(UInt<7>("h63"), op) @[Control.scala 131:14]
    node _T_5 = eq(UInt<7>("h6f"), op) @[Control.scala 131:14]
    node _T_6 = eq(UInt<7>("h67"), op) @[Control.scala 131:14]
    node _T_7 = eq(UInt<6>("h37"), op) @[Control.scala 131:14]
    node _T_8 = eq(UInt<5>("h17"), op) @[Control.scala 131:14]
    node _T_9 = or(_T_7, _T_8) @[Control.scala 131:14]
    node _GEN_0 = mux(_T_9, UInt<5>("h0"), UInt<5>("h1f")) @[Control.scala 131:14 117:15 183:19]
    node _GEN_1 = mux(_T_9, UInt<1>("h1"), UInt<1>("h0")) @[Control.scala 131:14 118:15 184:19]
    node _GEN_2 = mux(_T_6, UInt<5>("h0"), _GEN_0) @[Control.scala 131:14 175:19]
    node _GEN_3 = mux(_T_6, UInt<1>("h1"), _GEN_1) @[Control.scala 131:14 176:19]
    node _GEN_4 = mux(_T_6, UInt<1>("h1"), UInt<1>("h0")) @[Control.scala 131:14 125:15 177:19]
    node _GEN_5 = mux(_T_5, UInt<1>("h1"), UInt<1>("h0")) @[Control.scala 131:14 124:15 169:19]
    node _GEN_6 = mux(_T_5, UInt<1>("h1"), _GEN_3) @[Control.scala 131:14 170:19]
    node _GEN_7 = mux(_T_5, UInt<5>("h1f"), _GEN_2) @[Control.scala 131:14 117:15]
    node _GEN_8 = mux(_T_5, UInt<1>("h0"), _GEN_3) @[Control.scala 131:14 118:15]
    node _GEN_9 = mux(_T_5, UInt<1>("h0"), _GEN_4) @[Control.scala 131:14 125:15]
    node _GEN_10 = mux(_T_4, bOp, _GEN_7) @[Control.scala 131:14 163:17]
    node _GEN_11 = mux(_T_4, UInt<1>("h1"), UInt<1>("h0")) @[Control.scala 131:14 123:15 164:17]
    node _GEN_12 = mux(_T_4, UInt<1>("h1"), _GEN_6) @[Control.scala 131:14 165:17]
    node _GEN_13 = mux(_T_4, UInt<1>("h0"), _GEN_5) @[Control.scala 131:14 124:15]
    node _GEN_14 = mux(_T_4, UInt<1>("h0"), _GEN_6) @[Control.scala 131:14 122:15]
    node _GEN_15 = mux(_T_4, UInt<1>("h0"), _GEN_8) @[Control.scala 131:14 118:15]
    node _GEN_16 = mux(_T_4, UInt<1>("h0"), _GEN_9) @[Control.scala 131:14 125:15]
    node _GEN_17 = mux(_T_3, UInt<5>("h0"), _GEN_10) @[Control.scala 131:14 156:19]
    node _GEN_18 = mux(_T_3, UInt<1>("h1"), _GEN_15) @[Control.scala 131:14 157:19]
    node _GEN_19 = mux(_T_3, UInt<1>("h1"), UInt<1>("h0")) @[Control.scala 131:14 120:15 158:19]
    node _GEN_20 = mux(_T_3, UInt<1>("h1"), _GEN_12) @[Control.scala 131:14 159:19]
    node _GEN_21 = mux(_T_3, UInt<1>("h0"), _GEN_11) @[Control.scala 131:14 123:15]
    node _GEN_22 = mux(_T_3, UInt<1>("h0"), _GEN_13) @[Control.scala 131:14 124:15]
    node _GEN_23 = mux(_T_3, UInt<1>("h0"), _GEN_14) @[Control.scala 131:14 122:15]
    node _GEN_24 = mux(_T_3, UInt<1>("h0"), _GEN_16) @[Control.scala 131:14 125:15]
    node _GEN_25 = mux(_T_2, UInt<5>("h0"), _GEN_17) @[Control.scala 131:14 147:19]
    node _GEN_26 = mux(_T_2, UInt<1>("h1"), _GEN_18) @[Control.scala 131:14 148:19]
    node _GEN_27 = mux(_T_2, UInt<1>("h1"), UInt<1>("h0")) @[Control.scala 131:14 119:15 149:19]
    node _GEN_28 = mux(_T_2, UInt<1>("h1"), _GEN_23) @[Control.scala 131:14 151:19]
    node _GEN_29 = mux(_T_2, UInt<1>("h1"), _GEN_20) @[Control.scala 131:14 152:19]
    node _GEN_30 = mux(_T_2, UInt<1>("h0"), _GEN_19) @[Control.scala 131:14 120:15]
    node _GEN_31 = mux(_T_2, UInt<1>("h0"), _GEN_21) @[Control.scala 131:14 123:15]
    node _GEN_32 = mux(_T_2, UInt<1>("h0"), _GEN_22) @[Control.scala 131:14 124:15]
    node _GEN_33 = mux(_T_2, UInt<1>("h0"), _GEN_24) @[Control.scala 131:14 125:15]
    node _GEN_34 = mux(_T_1, iOp, _GEN_25) @[Control.scala 131:14 140:19]
    node _GEN_35 = mux(_T_1, UInt<1>("h1"), _GEN_26) @[Control.scala 131:14 141:19]
    node _GEN_36 = mux(_T_1, UInt<1>("h1"), _GEN_29) @[Control.scala 131:14 142:19]
    node _GEN_37 = mux(_T_1, UInt<1>("h1"), _GEN_28) @[Control.scala 131:14 143:19]
    node _GEN_38 = mux(_T_1, UInt<1>("h0"), _GEN_27) @[Control.scala 131:14 119:15]
    node _GEN_39 = mux(_T_1, UInt<1>("h0"), _GEN_30) @[Control.scala 131:14 120:15]
    node _GEN_40 = mux(_T_1, UInt<1>("h0"), _GEN_31) @[Control.scala 131:14 123:15]
    node _GEN_41 = mux(_T_1, UInt<1>("h0"), _GEN_32) @[Control.scala 131:14 124:15]
    node _GEN_42 = mux(_T_1, UInt<1>("h0"), _GEN_33) @[Control.scala 131:14 125:15]
    node _GEN_43 = mux(_T, rOp, _GEN_34) @[Control.scala 131:14 134:19]
    node _GEN_44 = mux(_T, UInt<1>("h1"), _GEN_36) @[Control.scala 131:14 135:19]
    node _GEN_45 = mux(_T, UInt<1>("h1"), _GEN_37) @[Control.scala 131:14 136:19]
    node _GEN_46 = mux(_T, UInt<1>("h0"), _GEN_35) @[Control.scala 131:14 118:15]
    node _GEN_47 = mux(_T, UInt<1>("h0"), _GEN_38) @[Control.scala 131:14 119:15]
    node _GEN_48 = mux(_T, UInt<1>("h0"), _GEN_39) @[Control.scala 131:14 120:15]
    node _GEN_49 = mux(_T, UInt<1>("h0"), _GEN_40) @[Control.scala 131:14 123:15]
    node _GEN_50 = mux(_T, UInt<1>("h0"), _GEN_41) @[Control.scala 131:14 124:15]
    node _GEN_51 = mux(_T, UInt<1>("h0"), _GEN_42) @[Control.scala 131:14 125:15]
    io_valid <= _GEN_44
    io_aluOp <= _GEN_43
    io_aluSrc <= _GEN_46
    io_memRead <= _GEN_47
    io_memWrite <= _GEN_48
    io_memToReg <= _GEN_47
    io_regWrite <= _GEN_45
    io_branch <= _GEN_49
    io_jump <= _GEN_50
    io_jalr <= _GEN_51

  module ImmediateGenerator :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    output io_imm : UInt<32>

    node opcode = bits(io_instr, 6, 0) @[ImmediateGenerator.scala 12:24]
    node _iImm_T = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 15:22]
    node _iImm_T_1 = bits(_iImm_T, 0, 0) @[Bitwise.scala 77:15]
    node _iImm_T_2 = mux(_iImm_T_1, UInt<20>("hfffff"), UInt<20>("h0")) @[Bitwise.scala 77:12]
    node _iImm_T_3 = bits(io_instr, 31, 20) @[ImmediateGenerator.scala 16:13]
    node iImm = cat(_iImm_T_2, _iImm_T_3) @[Cat.scala 33:92]
    node _sImm_T = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 20:22]
    node _sImm_T_1 = bits(_sImm_T, 0, 0) @[Bitwise.scala 77:15]
    node _sImm_T_2 = mux(_sImm_T_1, UInt<20>("hfffff"), UInt<20>("h0")) @[Bitwise.scala 77:12]
    node _sImm_T_3 = bits(io_instr, 31, 25) @[ImmediateGenerator.scala 21:13]
    node _sImm_T_4 = bits(io_instr, 11, 7) @[ImmediateGenerator.scala 22:13]
    node sImm_hi = cat(_sImm_T_2, _sImm_T_3) @[Cat.scala 33:92]
    node sImm = cat(sImm_hi, _sImm_T_4) @[Cat.scala 33:92]
    node _bImm_T = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 26:22]
    node _bImm_T_1 = bits(_bImm_T, 0, 0) @[Bitwise.scala 77:15]
    node _bImm_T_2 = mux(_bImm_T_1, UInt<19>("h7ffff"), UInt<19>("h0")) @[Bitwise.scala 77:12]
    node _bImm_T_3 = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 27:13]
    node _bImm_T_4 = bits(io_instr, 7, 7) @[ImmediateGenerator.scala 28:13]
    node _bImm_T_5 = bits(io_instr, 30, 25) @[ImmediateGenerator.scala 29:13]
    node _bImm_T_6 = bits(io_instr, 11, 8) @[ImmediateGenerator.scala 30:13]
    node bImm_lo_hi = cat(_bImm_T_5, _bImm_T_6) @[Cat.scala 33:92]
    node bImm_lo = cat(bImm_lo_hi, UInt<1>("h0")) @[Cat.scala 33:92]
    node bImm_hi_hi = cat(_bImm_T_2, _bImm_T_3) @[Cat.scala 33:92]
    node bImm_hi = cat(bImm_hi_hi, _bImm_T_4) @[Cat.scala 33:92]
    node bImm = cat(bImm_hi, bImm_lo) @[Cat.scala 33:92]
    node _uImm_T = bits(io_instr, 31, 12) @[ImmediateGenerator.scala 35:13]
    node uImm = cat(_uImm_T, UInt<12>("h0")) @[Cat.scala 33:92]
    node _jImm_T = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 40:22]
    node _jImm_T_1 = bits(_jImm_T, 0, 0) @[Bitwise.scala 77:15]
    node _jImm_T_2 = mux(_jImm_T_1, UInt<11>("h7ff"), UInt<11>("h0")) @[Bitwise.scala 77:12]
    node _jImm_T_3 = bits(io_instr, 31, 31) @[ImmediateGenerator.scala 41:13]
    node _jImm_T_4 = bits(io_instr, 19, 12) @[ImmediateGenerator.scala 42:13]
    node _jImm_T_5 = bits(io_instr, 20, 20) @[ImmediateGenerator.scala 43:13]
    node _jImm_T_6 = bits(io_instr, 30, 21) @[ImmediateGenerator.scala 44:13]
    node jImm_lo_hi = cat(_jImm_T_5, _jImm_T_6) @[Cat.scala 33:92]
    node jImm_lo = cat(jImm_lo_hi, UInt<1>("h0")) @[Cat.scala 33:92]
    node jImm_hi_hi = cat(_jImm_T_2, _jImm_T_3) @[Cat.scala 33:92]
    node jImm_hi = cat(jImm_hi_hi, _jImm_T_4) @[Cat.scala 33:92]
    node jImm = cat(jImm_hi, jImm_lo) @[Cat.scala 33:92]
    node _T = eq(UInt<2>("h3"), opcode) @[ImmediateGenerator.scala 50:18]
    node _T_1 = eq(UInt<5>("h13"), opcode) @[ImmediateGenerator.scala 50:18]
    node _T_2 = eq(UInt<7>("h67"), opcode) @[ImmediateGenerator.scala 50:18]
    node _T_3 = eq(UInt<6>("h23"), opcode) @[ImmediateGenerator.scala 50:18]
    node _T_4 = eq(UInt<7>("h63"), opcode) @[ImmediateGenerator.scala 50:18]
    node _T_5 = eq(UInt<6>("h37"), opcode) @[ImmediateGenerator.scala 50:18]
    node _T_6 = eq(UInt<5>("h17"), opcode) @[ImmediateGenerator.scala 50:18]
    node _T_7 = eq(UInt<7>("h6f"), opcode) @[ImmediateGenerator.scala 50:18]
    node _GEN_0 = mux(_T_7, jImm, UInt<1>("h0")) @[ImmediateGenerator.scala 48:10 50:18 81:14]
    node _GEN_1 = mux(_T_6, uImm, _GEN_0) @[ImmediateGenerator.scala 50:18 77:14]
    node _GEN_2 = mux(_T_5, uImm, _GEN_1) @[ImmediateGenerator.scala 50:18 73:14]
    node _GEN_3 = mux(_T_4, bImm, _GEN_2) @[ImmediateGenerator.scala 50:18 69:14]
    node _GEN_4 = mux(_T_3, sImm, _GEN_3) @[ImmediateGenerator.scala 50:18 65:14]
    node _GEN_5 = mux(_T_2, iImm, _GEN_4) @[ImmediateGenerator.scala 50:18 61:14]
    node _GEN_6 = mux(_T_1, iImm, _GEN_5) @[ImmediateGenerator.scala 50:18 57:14]
    node _GEN_7 = mux(_T, iImm, _GEN_6) @[ImmediateGenerator.scala 50:18 53:14]
    io_imm <= _GEN_7

  module RegisterFile :
    input clock : Clock
    input reset : UInt<1>
    input io_rs1 : UInt<5>
    input io_rs2 : UInt<5>
    input io_rd : UInt<5>
    input io_writeData : UInt<32>
    input io_writeEnable : UInt<1>
    output io_readData1 : UInt<32>
    output io_readData2 : UInt<32>
    output io_debugRead_0 : UInt<32>
    output io_debugRead_1 : UInt<32>
    output io_debugRead_2 : UInt<32>
    output io_debugRead_3 : UInt<32>
    output io_debugRead_4 : UInt<32>
    output io_debugRead_5 : UInt<32>
    output io_debugRead_6 : UInt<32>
    output io_debugRead_7 : UInt<32>
    output io_debugRead_8 : UInt<32>
    output io_debugRead_9 : UInt<32>
    output io_debugRead_10 : UInt<32>
    output io_debugRead_11 : UInt<32>
    output io_debugRead_12 : UInt<32>
    output io_debugRead_13 : UInt<32>
    output io_debugRead_14 : UInt<32>
    output io_debugRead_15 : UInt<32>
    output io_debugRead_16 : UInt<32>
    output io_debugRead_17 : UInt<32>
    output io_debugRead_18 : UInt<32>
    output io_debugRead_19 : UInt<32>
    output io_debugRead_20 : UInt<32>
    output io_debugRead_21 : UInt<32>
    output io_debugRead_22 : UInt<32>
    output io_debugRead_23 : UInt<32>
    output io_debugRead_24 : UInt<32>
    output io_debugRead_25 : UInt<32>
    output io_debugRead_26 : UInt<32>
    output io_debugRead_27 : UInt<32>
    output io_debugRead_28 : UInt<32>
    output io_debugRead_29 : UInt<32>
    output io_debugRead_30 : UInt<32>
    output io_debugRead_31 : UInt<32>

    reg regs_0 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_0) @[RegisterFile.scala 30:21]
    reg regs_1 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_1) @[RegisterFile.scala 30:21]
    reg regs_2 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_2) @[RegisterFile.scala 30:21]
    reg regs_3 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_3) @[RegisterFile.scala 30:21]
    reg regs_4 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_4) @[RegisterFile.scala 30:21]
    reg regs_5 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_5) @[RegisterFile.scala 30:21]
    reg regs_6 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_6) @[RegisterFile.scala 30:21]
    reg regs_7 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_7) @[RegisterFile.scala 30:21]
    reg regs_8 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_8) @[RegisterFile.scala 30:21]
    reg regs_9 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_9) @[RegisterFile.scala 30:21]
    reg regs_10 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_10) @[RegisterFile.scala 30:21]
    reg regs_11 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_11) @[RegisterFile.scala 30:21]
    reg regs_12 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_12) @[RegisterFile.scala 30:21]
    reg regs_13 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_13) @[RegisterFile.scala 30:21]
    reg regs_14 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_14) @[RegisterFile.scala 30:21]
    reg regs_15 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_15) @[RegisterFile.scala 30:21]
    reg regs_16 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_16) @[RegisterFile.scala 30:21]
    reg regs_17 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_17) @[RegisterFile.scala 30:21]
    reg regs_18 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_18) @[RegisterFile.scala 30:21]
    reg regs_19 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_19) @[RegisterFile.scala 30:21]
    reg regs_20 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_20) @[RegisterFile.scala 30:21]
    reg regs_21 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_21) @[RegisterFile.scala 30:21]
    reg regs_22 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_22) @[RegisterFile.scala 30:21]
    reg regs_23 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_23) @[RegisterFile.scala 30:21]
    reg regs_24 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_24) @[RegisterFile.scala 30:21]
    reg regs_25 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_25) @[RegisterFile.scala 30:21]
    reg regs_26 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_26) @[RegisterFile.scala 30:21]
    reg regs_27 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_27) @[RegisterFile.scala 30:21]
    reg regs_28 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_28) @[RegisterFile.scala 30:21]
    reg regs_29 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_29) @[RegisterFile.scala 30:21]
    reg regs_30 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_30) @[RegisterFile.scala 30:21]
    reg regs_31 : UInt<32>, clock with :
      reset => (UInt<1>("h0"), regs_31) @[RegisterFile.scala 30:21]
    node _io_readData1_T = eq(io_rs1, UInt<1>("h0")) @[RegisterFile.scala 32:12]
    node _GEN_0 = validif(eq(UInt<1>("h0"), io_rs1), regs_0) @[RegisterFile.scala 31:{22,22}]
    node _GEN_1 = mux(eq(UInt<1>("h1"), io_rs1), regs_1, _GEN_0) @[RegisterFile.scala 31:{22,22}]
    node _GEN_2 = mux(eq(UInt<2>("h2"), io_rs1), regs_2, _GEN_1) @[RegisterFile.scala 31:{22,22}]
    node _GEN_3 = mux(eq(UInt<2>("h3"), io_rs1), regs_3, _GEN_2) @[RegisterFile.scala 31:{22,22}]
    node _GEN_4 = mux(eq(UInt<3>("h4"), io_rs1), regs_4, _GEN_3) @[RegisterFile.scala 31:{22,22}]
    node _GEN_5 = mux(eq(UInt<3>("h5"), io_rs1), regs_5, _GEN_4) @[RegisterFile.scala 31:{22,22}]
    node _GEN_6 = mux(eq(UInt<3>("h6"), io_rs1), regs_6, _GEN_5) @[RegisterFile.scala 31:{22,22}]
    node _GEN_7 = mux(eq(UInt<3>("h7"), io_rs1), regs_7, _GEN_6) @[RegisterFile.scala 31:{22,22}]
    node _GEN_8 = mux(eq(UInt<4>("h8"), io_rs1), regs_8, _GEN_7) @[RegisterFile.scala 31:{22,22}]
    node _GEN_9 = mux(eq(UInt<4>("h9"), io_rs1), regs_9, _GEN_8) @[RegisterFile.scala 31:{22,22}]
    node _GEN_10 = mux(eq(UInt<4>("ha"), io_rs1), regs_10, _GEN_9) @[RegisterFile.scala 31:{22,22}]
    node _GEN_11 = mux(eq(UInt<4>("hb"), io_rs1), regs_11, _GEN_10) @[RegisterFile.scala 31:{22,22}]
    node _GEN_12 = mux(eq(UInt<4>("hc"), io_rs1), regs_12, _GEN_11) @[RegisterFile.scala 31:{22,22}]
    node _GEN_13 = mux(eq(UInt<4>("hd"), io_rs1), regs_13, _GEN_12) @[RegisterFile.scala 31:{22,22}]
    node _GEN_14 = mux(eq(UInt<4>("he"), io_rs1), regs_14, _GEN_13) @[RegisterFile.scala 31:{22,22}]
    node _GEN_15 = mux(eq(UInt<4>("hf"), io_rs1), regs_15, _GEN_14) @[RegisterFile.scala 31:{22,22}]
    node _GEN_16 = mux(eq(UInt<5>("h10"), io_rs1), regs_16, _GEN_15) @[RegisterFile.scala 31:{22,22}]
    node _GEN_17 = mux(eq(UInt<5>("h11"), io_rs1), regs_17, _GEN_16) @[RegisterFile.scala 31:{22,22}]
    node _GEN_18 = mux(eq(UInt<5>("h12"), io_rs1), regs_18, _GEN_17) @[RegisterFile.scala 31:{22,22}]
    node _GEN_19 = mux(eq(UInt<5>("h13"), io_rs1), regs_19, _GEN_18) @[RegisterFile.scala 31:{22,22}]
    node _GEN_20 = mux(eq(UInt<5>("h14"), io_rs1), regs_20, _GEN_19) @[RegisterFile.scala 31:{22,22}]
    node _GEN_21 = mux(eq(UInt<5>("h15"), io_rs1), regs_21, _GEN_20) @[RegisterFile.scala 31:{22,22}]
    node _GEN_22 = mux(eq(UInt<5>("h16"), io_rs1), regs_22, _GEN_21) @[RegisterFile.scala 31:{22,22}]
    node _GEN_23 = mux(eq(UInt<5>("h17"), io_rs1), regs_23, _GEN_22) @[RegisterFile.scala 31:{22,22}]
    node _GEN_24 = mux(eq(UInt<5>("h18"), io_rs1), regs_24, _GEN_23) @[RegisterFile.scala 31:{22,22}]
    node _GEN_25 = mux(eq(UInt<5>("h19"), io_rs1), regs_25, _GEN_24) @[RegisterFile.scala 31:{22,22}]
    node _GEN_26 = mux(eq(UInt<5>("h1a"), io_rs1), regs_26, _GEN_25) @[RegisterFile.scala 31:{22,22}]
    node _GEN_27 = mux(eq(UInt<5>("h1b"), io_rs1), regs_27, _GEN_26) @[RegisterFile.scala 31:{22,22}]
    node _GEN_28 = mux(eq(UInt<5>("h1c"), io_rs1), regs_28, _GEN_27) @[RegisterFile.scala 31:{22,22}]
    node _GEN_29 = mux(eq(UInt<5>("h1d"), io_rs1), regs_29, _GEN_28) @[RegisterFile.scala 31:{22,22}]
    node _GEN_30 = mux(eq(UInt<5>("h1e"), io_rs1), regs_30, _GEN_29) @[RegisterFile.scala 31:{22,22}]
    node _GEN_31 = mux(eq(UInt<5>("h1f"), io_rs1), regs_31, _GEN_30) @[RegisterFile.scala 31:{22,22}]
    node _regs_io_rs1 = _GEN_31 @[RegisterFile.scala 31:22]
    node _io_readData1_T_1 = mux(_io_readData1_T, UInt<1>("h0"), _regs_io_rs1) @[RegisterFile.scala 31:22]
    node _io_readData2_T = eq(io_rs2, UInt<1>("h0")) @[RegisterFile.scala 37:12]
    node _GEN_32 = validif(eq(UInt<1>("h0"), io_rs2), regs_0) @[RegisterFile.scala 36:{22,22}]
    node _GEN_33 = mux(eq(UInt<1>("h1"), io_rs2), regs_1, _GEN_32) @[RegisterFile.scala 36:{22,22}]
    node _GEN_34 = mux(eq(UInt<2>("h2"), io_rs2), regs_2, _GEN_33) @[RegisterFile.scala 36:{22,22}]
    node _GEN_35 = mux(eq(UInt<2>("h3"), io_rs2), regs_3, _GEN_34) @[RegisterFile.scala 36:{22,22}]
    node _GEN_36 = mux(eq(UInt<3>("h4"), io_rs2), regs_4, _GEN_35) @[RegisterFile.scala 36:{22,22}]
    node _GEN_37 = mux(eq(UInt<3>("h5"), io_rs2), regs_5, _GEN_36) @[RegisterFile.scala 36:{22,22}]
    node _GEN_38 = mux(eq(UInt<3>("h6"), io_rs2), regs_6, _GEN_37) @[RegisterFile.scala 36:{22,22}]
    node _GEN_39 = mux(eq(UInt<3>("h7"), io_rs2), regs_7, _GEN_38) @[RegisterFile.scala 36:{22,22}]
    node _GEN_40 = mux(eq(UInt<4>("h8"), io_rs2), regs_8, _GEN_39) @[RegisterFile.scala 36:{22,22}]
    node _GEN_41 = mux(eq(UInt<4>("h9"), io_rs2), regs_9, _GEN_40) @[RegisterFile.scala 36:{22,22}]
    node _GEN_42 = mux(eq(UInt<4>("ha"), io_rs2), regs_10, _GEN_41) @[RegisterFile.scala 36:{22,22}]
    node _GEN_43 = mux(eq(UInt<4>("hb"), io_rs2), regs_11, _GEN_42) @[RegisterFile.scala 36:{22,22}]
    node _GEN_44 = mux(eq(UInt<4>("hc"), io_rs2), regs_12, _GEN_43) @[RegisterFile.scala 36:{22,22}]
    node _GEN_45 = mux(eq(UInt<4>("hd"), io_rs2), regs_13, _GEN_44) @[RegisterFile.scala 36:{22,22}]
    node _GEN_46 = mux(eq(UInt<4>("he"), io_rs2), regs_14, _GEN_45) @[RegisterFile.scala 36:{22,22}]
    node _GEN_47 = mux(eq(UInt<4>("hf"), io_rs2), regs_15, _GEN_46) @[RegisterFile.scala 36:{22,22}]
    node _GEN_48 = mux(eq(UInt<5>("h10"), io_rs2), regs_16, _GEN_47) @[RegisterFile.scala 36:{22,22}]
    node _GEN_49 = mux(eq(UInt<5>("h11"), io_rs2), regs_17, _GEN_48) @[RegisterFile.scala 36:{22,22}]
    node _GEN_50 = mux(eq(UInt<5>("h12"), io_rs2), regs_18, _GEN_49) @[RegisterFile.scala 36:{22,22}]
    node _GEN_51 = mux(eq(UInt<5>("h13"), io_rs2), regs_19, _GEN_50) @[RegisterFile.scala 36:{22,22}]
    node _GEN_52 = mux(eq(UInt<5>("h14"), io_rs2), regs_20, _GEN_51) @[RegisterFile.scala 36:{22,22}]
    node _GEN_53 = mux(eq(UInt<5>("h15"), io_rs2), regs_21, _GEN_52) @[RegisterFile.scala 36:{22,22}]
    node _GEN_54 = mux(eq(UInt<5>("h16"), io_rs2), regs_22, _GEN_53) @[RegisterFile.scala 36:{22,22}]
    node _GEN_55 = mux(eq(UInt<5>("h17"), io_rs2), regs_23, _GEN_54) @[RegisterFile.scala 36:{22,22}]
    node _GEN_56 = mux(eq(UInt<5>("h18"), io_rs2), regs_24, _GEN_55) @[RegisterFile.scala 36:{22,22}]
    node _GEN_57 = mux(eq(UInt<5>("h19"), io_rs2), regs_25, _GEN_56) @[RegisterFile.scala 36:{22,22}]
    node _GEN_58 = mux(eq(UInt<5>("h1a"), io_rs2), regs_26, _GEN_57) @[RegisterFile.scala 36:{22,22}]
    node _GEN_59 = mux(eq(UInt<5>("h1b"), io_rs2), regs_27, _GEN_58) @[RegisterFile.scala 36:{22,22}]
    node _GEN_60 = mux(eq(UInt<5>("h1c"), io_rs2), regs_28, _GEN_59) @[RegisterFile.scala 36:{22,22}]
    node _GEN_61 = mux(eq(UInt<5>("h1d"), io_rs2), regs_29, _GEN_60) @[RegisterFile.scala 36:{22,22}]
    node _GEN_62 = mux(eq(UInt<5>("h1e"), io_rs2), regs_30, _GEN_61) @[RegisterFile.scala 36:{22,22}]
    node _GEN_63 = mux(eq(UInt<5>("h1f"), io_rs2), regs_31, _GEN_62) @[RegisterFile.scala 36:{22,22}]
    node _regs_io_rs2 = _GEN_63 @[RegisterFile.scala 36:22]
    node _io_readData2_T_1 = mux(_io_readData2_T, UInt<1>("h0"), _regs_io_rs2) @[RegisterFile.scala 36:22]
    node _T = neq(io_rd, UInt<1>("h0")) @[RegisterFile.scala 41:32]
    node _T_1 = and(io_writeEnable, _T) @[RegisterFile.scala 41:23]
    node _regs_io_rd = io_writeData @[RegisterFile.scala 42:{17,17}]
    node _GEN_64 = mux(eq(UInt<1>("h0"), io_rd), _regs_io_rd, regs_0) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_65 = mux(eq(UInt<1>("h1"), io_rd), _regs_io_rd, regs_1) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_66 = mux(eq(UInt<2>("h2"), io_rd), _regs_io_rd, regs_2) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_67 = mux(eq(UInt<2>("h3"), io_rd), _regs_io_rd, regs_3) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_68 = mux(eq(UInt<3>("h4"), io_rd), _regs_io_rd, regs_4) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_69 = mux(eq(UInt<3>("h5"), io_rd), _regs_io_rd, regs_5) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_70 = mux(eq(UInt<3>("h6"), io_rd), _regs_io_rd, regs_6) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_71 = mux(eq(UInt<3>("h7"), io_rd), _regs_io_rd, regs_7) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_72 = mux(eq(UInt<4>("h8"), io_rd), _regs_io_rd, regs_8) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_73 = mux(eq(UInt<4>("h9"), io_rd), _regs_io_rd, regs_9) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_74 = mux(eq(UInt<4>("ha"), io_rd), _regs_io_rd, regs_10) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_75 = mux(eq(UInt<4>("hb"), io_rd), _regs_io_rd, regs_11) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_76 = mux(eq(UInt<4>("hc"), io_rd), _regs_io_rd, regs_12) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_77 = mux(eq(UInt<4>("hd"), io_rd), _regs_io_rd, regs_13) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_78 = mux(eq(UInt<4>("he"), io_rd), _regs_io_rd, regs_14) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_79 = mux(eq(UInt<4>("hf"), io_rd), _regs_io_rd, regs_15) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_80 = mux(eq(UInt<5>("h10"), io_rd), _regs_io_rd, regs_16) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_81 = mux(eq(UInt<5>("h11"), io_rd), _regs_io_rd, regs_17) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_82 = mux(eq(UInt<5>("h12"), io_rd), _regs_io_rd, regs_18) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_83 = mux(eq(UInt<5>("h13"), io_rd), _regs_io_rd, regs_19) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_84 = mux(eq(UInt<5>("h14"), io_rd), _regs_io_rd, regs_20) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_85 = mux(eq(UInt<5>("h15"), io_rd), _regs_io_rd, regs_21) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_86 = mux(eq(UInt<5>("h16"), io_rd), _regs_io_rd, regs_22) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_87 = mux(eq(UInt<5>("h17"), io_rd), _regs_io_rd, regs_23) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_88 = mux(eq(UInt<5>("h18"), io_rd), _regs_io_rd, regs_24) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_89 = mux(eq(UInt<5>("h19"), io_rd), _regs_io_rd, regs_25) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_90 = mux(eq(UInt<5>("h1a"), io_rd), _regs_io_rd, regs_26) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_91 = mux(eq(UInt<5>("h1b"), io_rd), _regs_io_rd, regs_27) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_92 = mux(eq(UInt<5>("h1c"), io_rd), _regs_io_rd, regs_28) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_93 = mux(eq(UInt<5>("h1d"), io_rd), _regs_io_rd, regs_29) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_94 = mux(eq(UInt<5>("h1e"), io_rd), _regs_io_rd, regs_30) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_95 = mux(eq(UInt<5>("h1f"), io_rd), _regs_io_rd, regs_31) @[RegisterFile.scala 42:{17,17} 30:21]
    node _GEN_96 = mux(_T_1, _GEN_64, regs_0) @[RegisterFile.scala 30:21 41:41]
    node _GEN_97 = mux(_T_1, _GEN_65, regs_1) @[RegisterFile.scala 30:21 41:41]
    node _GEN_98 = mux(_T_1, _GEN_66, regs_2) @[RegisterFile.scala 30:21 41:41]
    node _GEN_99 = mux(_T_1, _GEN_67, regs_3) @[RegisterFile.scala 30:21 41:41]
    node _GEN_100 = mux(_T_1, _GEN_68, regs_4) @[RegisterFile.scala 30:21 41:41]
    node _GEN_101 = mux(_T_1, _GEN_69, regs_5) @[RegisterFile.scala 30:21 41:41]
    node _GEN_102 = mux(_T_1, _GEN_70, regs_6) @[RegisterFile.scala 30:21 41:41]
    node _GEN_103 = mux(_T_1, _GEN_71, regs_7) @[RegisterFile.scala 30:21 41:41]
    node _GEN_104 = mux(_T_1, _GEN_72, regs_8) @[RegisterFile.scala 30:21 41:41]
    node _GEN_105 = mux(_T_1, _GEN_73, regs_9) @[RegisterFile.scala 30:21 41:41]
    node _GEN_106 = mux(_T_1, _GEN_74, regs_10) @[RegisterFile.scala 30:21 41:41]
    node _GEN_107 = mux(_T_1, _GEN_75, regs_11) @[RegisterFile.scala 30:21 41:41]
    node _GEN_108 = mux(_T_1, _GEN_76, regs_12) @[RegisterFile.scala 30:21 41:41]
    node _GEN_109 = mux(_T_1, _GEN_77, regs_13) @[RegisterFile.scala 30:21 41:41]
    node _GEN_110 = mux(_T_1, _GEN_78, regs_14) @[RegisterFile.scala 30:21 41:41]
    node _GEN_111 = mux(_T_1, _GEN_79, regs_15) @[RegisterFile.scala 30:21 41:41]
    node _GEN_112 = mux(_T_1, _GEN_80, regs_16) @[RegisterFile.scala 30:21 41:41]
    node _GEN_113 = mux(_T_1, _GEN_81, regs_17) @[RegisterFile.scala 30:21 41:41]
    node _GEN_114 = mux(_T_1, _GEN_82, regs_18) @[RegisterFile.scala 30:21 41:41]
    node _GEN_115 = mux(_T_1, _GEN_83, regs_19) @[RegisterFile.scala 30:21 41:41]
    node _GEN_116 = mux(_T_1, _GEN_84, regs_20) @[RegisterFile.scala 30:21 41:41]
    node _GEN_117 = mux(_T_1, _GEN_85, regs_21) @[RegisterFile.scala 30:21 41:41]
    node _GEN_118 = mux(_T_1, _GEN_86, regs_22) @[RegisterFile.scala 30:21 41:41]
    node _GEN_119 = mux(_T_1, _GEN_87, regs_23) @[RegisterFile.scala 30:21 41:41]
    node _GEN_120 = mux(_T_1, _GEN_88, regs_24) @[RegisterFile.scala 30:21 41:41]
    node _GEN_121 = mux(_T_1, _GEN_89, regs_25) @[RegisterFile.scala 30:21 41:41]
    node _GEN_122 = mux(_T_1, _GEN_90, regs_26) @[RegisterFile.scala 30:21 41:41]
    node _GEN_123 = mux(_T_1, _GEN_91, regs_27) @[RegisterFile.scala 30:21 41:41]
    node _GEN_124 = mux(_T_1, _GEN_92, regs_28) @[RegisterFile.scala 30:21 41:41]
    node _GEN_125 = mux(_T_1, _GEN_93, regs_29) @[RegisterFile.scala 30:21 41:41]
    node _GEN_126 = mux(_T_1, _GEN_94, regs_30) @[RegisterFile.scala 30:21 41:41]
    node _GEN_127 = mux(_T_1, _GEN_95, regs_31) @[RegisterFile.scala 30:21 41:41]
    node _io_debugRead_0_T = eq(UInt<1>("h0"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_0_T_1 = mux(_io_debugRead_0_T, UInt<1>("h0"), regs_0) @[RegisterFile.scala 45:27]
    node _io_debugRead_1_T = eq(UInt<1>("h1"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_1_T_1 = mux(_io_debugRead_1_T, UInt<1>("h0"), regs_1) @[RegisterFile.scala 45:27]
    node _io_debugRead_2_T = eq(UInt<2>("h2"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_2_T_1 = mux(_io_debugRead_2_T, UInt<1>("h0"), regs_2) @[RegisterFile.scala 45:27]
    node _io_debugRead_3_T = eq(UInt<2>("h3"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_3_T_1 = mux(_io_debugRead_3_T, UInt<1>("h0"), regs_3) @[RegisterFile.scala 45:27]
    node _io_debugRead_4_T = eq(UInt<3>("h4"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_4_T_1 = mux(_io_debugRead_4_T, UInt<1>("h0"), regs_4) @[RegisterFile.scala 45:27]
    node _io_debugRead_5_T = eq(UInt<3>("h5"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_5_T_1 = mux(_io_debugRead_5_T, UInt<1>("h0"), regs_5) @[RegisterFile.scala 45:27]
    node _io_debugRead_6_T = eq(UInt<3>("h6"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_6_T_1 = mux(_io_debugRead_6_T, UInt<1>("h0"), regs_6) @[RegisterFile.scala 45:27]
    node _io_debugRead_7_T = eq(UInt<3>("h7"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_7_T_1 = mux(_io_debugRead_7_T, UInt<1>("h0"), regs_7) @[RegisterFile.scala 45:27]
    node _io_debugRead_8_T = eq(UInt<4>("h8"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_8_T_1 = mux(_io_debugRead_8_T, UInt<1>("h0"), regs_8) @[RegisterFile.scala 45:27]
    node _io_debugRead_9_T = eq(UInt<4>("h9"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_9_T_1 = mux(_io_debugRead_9_T, UInt<1>("h0"), regs_9) @[RegisterFile.scala 45:27]
    node _io_debugRead_10_T = eq(UInt<4>("ha"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_10_T_1 = mux(_io_debugRead_10_T, UInt<1>("h0"), regs_10) @[RegisterFile.scala 45:27]
    node _io_debugRead_11_T = eq(UInt<4>("hb"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_11_T_1 = mux(_io_debugRead_11_T, UInt<1>("h0"), regs_11) @[RegisterFile.scala 45:27]
    node _io_debugRead_12_T = eq(UInt<4>("hc"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_12_T_1 = mux(_io_debugRead_12_T, UInt<1>("h0"), regs_12) @[RegisterFile.scala 45:27]
    node _io_debugRead_13_T = eq(UInt<4>("hd"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_13_T_1 = mux(_io_debugRead_13_T, UInt<1>("h0"), regs_13) @[RegisterFile.scala 45:27]
    node _io_debugRead_14_T = eq(UInt<4>("he"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_14_T_1 = mux(_io_debugRead_14_T, UInt<1>("h0"), regs_14) @[RegisterFile.scala 45:27]
    node _io_debugRead_15_T = eq(UInt<4>("hf"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_15_T_1 = mux(_io_debugRead_15_T, UInt<1>("h0"), regs_15) @[RegisterFile.scala 45:27]
    node _io_debugRead_16_T = eq(UInt<5>("h10"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_16_T_1 = mux(_io_debugRead_16_T, UInt<1>("h0"), regs_16) @[RegisterFile.scala 45:27]
    node _io_debugRead_17_T = eq(UInt<5>("h11"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_17_T_1 = mux(_io_debugRead_17_T, UInt<1>("h0"), regs_17) @[RegisterFile.scala 45:27]
    node _io_debugRead_18_T = eq(UInt<5>("h12"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_18_T_1 = mux(_io_debugRead_18_T, UInt<1>("h0"), regs_18) @[RegisterFile.scala 45:27]
    node _io_debugRead_19_T = eq(UInt<5>("h13"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_19_T_1 = mux(_io_debugRead_19_T, UInt<1>("h0"), regs_19) @[RegisterFile.scala 45:27]
    node _io_debugRead_20_T = eq(UInt<5>("h14"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_20_T_1 = mux(_io_debugRead_20_T, UInt<1>("h0"), regs_20) @[RegisterFile.scala 45:27]
    node _io_debugRead_21_T = eq(UInt<5>("h15"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_21_T_1 = mux(_io_debugRead_21_T, UInt<1>("h0"), regs_21) @[RegisterFile.scala 45:27]
    node _io_debugRead_22_T = eq(UInt<5>("h16"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_22_T_1 = mux(_io_debugRead_22_T, UInt<1>("h0"), regs_22) @[RegisterFile.scala 45:27]
    node _io_debugRead_23_T = eq(UInt<5>("h17"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_23_T_1 = mux(_io_debugRead_23_T, UInt<1>("h0"), regs_23) @[RegisterFile.scala 45:27]
    node _io_debugRead_24_T = eq(UInt<5>("h18"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_24_T_1 = mux(_io_debugRead_24_T, UInt<1>("h0"), regs_24) @[RegisterFile.scala 45:27]
    node _io_debugRead_25_T = eq(UInt<5>("h19"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_25_T_1 = mux(_io_debugRead_25_T, UInt<1>("h0"), regs_25) @[RegisterFile.scala 45:27]
    node _io_debugRead_26_T = eq(UInt<5>("h1a"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_26_T_1 = mux(_io_debugRead_26_T, UInt<1>("h0"), regs_26) @[RegisterFile.scala 45:27]
    node _io_debugRead_27_T = eq(UInt<5>("h1b"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_27_T_1 = mux(_io_debugRead_27_T, UInt<1>("h0"), regs_27) @[RegisterFile.scala 45:27]
    node _io_debugRead_28_T = eq(UInt<5>("h1c"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_28_T_1 = mux(_io_debugRead_28_T, UInt<1>("h0"), regs_28) @[RegisterFile.scala 45:27]
    node _io_debugRead_29_T = eq(UInt<5>("h1d"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_29_T_1 = mux(_io_debugRead_29_T, UInt<1>("h0"), regs_29) @[RegisterFile.scala 45:27]
    node _io_debugRead_30_T = eq(UInt<5>("h1e"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_30_T_1 = mux(_io_debugRead_30_T, UInt<1>("h0"), regs_30) @[RegisterFile.scala 45:27]
    node _io_debugRead_31_T = eq(UInt<5>("h1f"), UInt<1>("h0")) @[RegisterFile.scala 46:11]
    node _io_debugRead_31_T_1 = mux(_io_debugRead_31_T, UInt<1>("h0"), regs_31) @[RegisterFile.scala 45:27]
    node _regs_WIRE_0 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_1 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_2 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_3 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_4 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_5 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_6 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_7 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_8 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_9 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_10 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_11 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_12 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_13 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_14 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_15 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_16 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_17 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_18 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_19 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_20 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_21 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_22 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_23 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_24 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_25 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_26 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_27 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_28 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_29 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_30 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    node _regs_WIRE_31 = UInt<32>("h0") @[RegisterFile.scala 30:{29,29}]
    io_readData1 <= _io_readData1_T_1 @[RegisterFile.scala 31:16]
    io_readData2 <= _io_readData2_T_1 @[RegisterFile.scala 36:16]
    io_debugRead_0 <= _io_debugRead_0_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_1 <= _io_debugRead_1_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_2 <= _io_debugRead_2_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_3 <= _io_debugRead_3_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_4 <= _io_debugRead_4_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_5 <= _io_debugRead_5_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_6 <= _io_debugRead_6_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_7 <= _io_debugRead_7_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_8 <= _io_debugRead_8_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_9 <= _io_debugRead_9_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_10 <= _io_debugRead_10_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_11 <= _io_debugRead_11_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_12 <= _io_debugRead_12_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_13 <= _io_debugRead_13_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_14 <= _io_debugRead_14_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_15 <= _io_debugRead_15_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_16 <= _io_debugRead_16_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_17 <= _io_debugRead_17_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_18 <= _io_debugRead_18_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_19 <= _io_debugRead_19_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_20 <= _io_debugRead_20_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_21 <= _io_debugRead_21_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_22 <= _io_debugRead_22_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_23 <= _io_debugRead_23_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_24 <= _io_debugRead_24_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_25 <= _io_debugRead_25_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_26 <= _io_debugRead_26_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_27 <= _io_debugRead_27_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_28 <= _io_debugRead_28_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_29 <= _io_debugRead_29_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_30 <= _io_debugRead_30_T_1 @[RegisterFile.scala 45:21]
    io_debugRead_31 <= _io_debugRead_31_T_1 @[RegisterFile.scala 45:21]
    regs_0 <= mux(reset, _regs_WIRE_0, _GEN_96) @[RegisterFile.scala 30:{21,21}]
    regs_1 <= mux(reset, _regs_WIRE_1, _GEN_97) @[RegisterFile.scala 30:{21,21}]
    regs_2 <= mux(reset, _regs_WIRE_2, _GEN_98) @[RegisterFile.scala 30:{21,21}]
    regs_3 <= mux(reset, _regs_WIRE_3, _GEN_99) @[RegisterFile.scala 30:{21,21}]
    regs_4 <= mux(reset, _regs_WIRE_4, _GEN_100) @[RegisterFile.scala 30:{21,21}]
    regs_5 <= mux(reset, _regs_WIRE_5, _GEN_101) @[RegisterFile.scala 30:{21,21}]
    regs_6 <= mux(reset, _regs_WIRE_6, _GEN_102) @[RegisterFile.scala 30:{21,21}]
    regs_7 <= mux(reset, _regs_WIRE_7, _GEN_103) @[RegisterFile.scala 30:{21,21}]
    regs_8 <= mux(reset, _regs_WIRE_8, _GEN_104) @[RegisterFile.scala 30:{21,21}]
    regs_9 <= mux(reset, _regs_WIRE_9, _GEN_105) @[RegisterFile.scala 30:{21,21}]
    regs_10 <= mux(reset, _regs_WIRE_10, _GEN_106) @[RegisterFile.scala 30:{21,21}]
    regs_11 <= mux(reset, _regs_WIRE_11, _GEN_107) @[RegisterFile.scala 30:{21,21}]
    regs_12 <= mux(reset, _regs_WIRE_12, _GEN_108) @[RegisterFile.scala 30:{21,21}]
    regs_13 <= mux(reset, _regs_WIRE_13, _GEN_109) @[RegisterFile.scala 30:{21,21}]
    regs_14 <= mux(reset, _regs_WIRE_14, _GEN_110) @[RegisterFile.scala 30:{21,21}]
    regs_15 <= mux(reset, _regs_WIRE_15, _GEN_111) @[RegisterFile.scala 30:{21,21}]
    regs_16 <= mux(reset, _regs_WIRE_16, _GEN_112) @[RegisterFile.scala 30:{21,21}]
    regs_17 <= mux(reset, _regs_WIRE_17, _GEN_113) @[RegisterFile.scala 30:{21,21}]
    regs_18 <= mux(reset, _regs_WIRE_18, _GEN_114) @[RegisterFile.scala 30:{21,21}]
    regs_19 <= mux(reset, _regs_WIRE_19, _GEN_115) @[RegisterFile.scala 30:{21,21}]
    regs_20 <= mux(reset, _regs_WIRE_20, _GEN_116) @[RegisterFile.scala 30:{21,21}]
    regs_21 <= mux(reset, _regs_WIRE_21, _GEN_117) @[RegisterFile.scala 30:{21,21}]
    regs_22 <= mux(reset, _regs_WIRE_22, _GEN_118) @[RegisterFile.scala 30:{21,21}]
    regs_23 <= mux(reset, _regs_WIRE_23, _GEN_119) @[RegisterFile.scala 30:{21,21}]
    regs_24 <= mux(reset, _regs_WIRE_24, _GEN_120) @[RegisterFile.scala 30:{21,21}]
    regs_25 <= mux(reset, _regs_WIRE_25, _GEN_121) @[RegisterFile.scala 30:{21,21}]
    regs_26 <= mux(reset, _regs_WIRE_26, _GEN_122) @[RegisterFile.scala 30:{21,21}]
    regs_27 <= mux(reset, _regs_WIRE_27, _GEN_123) @[RegisterFile.scala 30:{21,21}]
    regs_28 <= mux(reset, _regs_WIRE_28, _GEN_124) @[RegisterFile.scala 30:{21,21}]
    regs_29 <= mux(reset, _regs_WIRE_29, _GEN_125) @[RegisterFile.scala 30:{21,21}]
    regs_30 <= mux(reset, _regs_WIRE_30, _GEN_126) @[RegisterFile.scala 30:{21,21}]
    regs_31 <= mux(reset, _regs_WIRE_31, _GEN_127) @[RegisterFile.scala 30:{21,21}]

  module ALU :
    input clock : Clock
    input reset : UInt<1>
    input io_a : UInt<32>
    input io_b : UInt<32>
    input io_op : UInt<5>
    input io_start : UInt<1>
    output io_y : UInt<32>
    output io_busy : UInt<1>
    output io_done : UInt<1>

    node shamt = bits(io_b, 4, 0) @[ALU.scala 28:19]
    node sa = asSInt(io_a) @[ALU.scala 29:17]
    node sb = asSInt(io_b) @[ALU.scala 29:39]
    node _as64_T = bits(io_a, 31, 31) @[ALU.scala 30:31]
    node _as64_T_1 = bits(_as64_T, 0, 0) @[Bitwise.scala 77:15]
    node _as64_T_2 = mux(_as64_T_1, UInt<32>("hffffffff"), UInt<32>("h0")) @[Bitwise.scala 77:12]
    node _as64_T_3 = cat(_as64_T_2, io_a) @[Cat.scala 33:92]
    node as64 = asSInt(_as64_T_3) @[ALU.scala 30:44]
    node _bs64_T = bits(io_b, 31, 31) @[ALU.scala 31:31]
    node _bs64_T_1 = bits(_bs64_T, 0, 0) @[Bitwise.scala 77:15]
    node _bs64_T_2 = mux(_bs64_T_1, UInt<32>("hffffffff"), UInt<32>("h0")) @[Bitwise.scala 77:12]
    node _bs64_T_3 = cat(_bs64_T_2, io_b) @[Cat.scala 33:92]
    node bs64 = asSInt(_bs64_T_3) @[ALU.scala 31:44]
    node au64 = cat(UInt<32>("h0"), io_a) @[Cat.scala 33:92]
    node bu64 = cat(UInt<32>("h0"), io_b) @[Cat.scala 33:92]
    node mulSS = mul(as64, bs64) @[ALU.scala 33:20]
    node mulUU = mul(au64, bu64) @[ALU.scala 33:45]
    node _mulSU_T = asSInt(bu64) @[ALU.scala 34:27]
    node mulSU = mul(as64, _mulSU_T) @[ALU.scala 34:20]
    node _divOp_T = eq(io_op, UInt<5>("h10")) @[ALU.scala 36:21]
    node _divOp_T_1 = eq(io_op, UInt<5>("h11")) @[ALU.scala 36:44]
    node divOp = or(_divOp_T, _divOp_T_1) @[ALU.scala 36:35]
    node _remOp_T = eq(io_op, UInt<5>("h12")) @[ALU.scala 37:21]
    node _remOp_T_1 = eq(io_op, UInt<5>("h13")) @[ALU.scala 37:44]
    node remOp = or(_remOp_T, _remOp_T_1) @[ALU.scala 37:35]
    node divRem = or(divOp, remOp) @[ALU.scala 38:22]
    node _signedOp_T = eq(io_op, UInt<5>("h10")) @[ALU.scala 39:24]
    node _signedOp_T_1 = eq(io_op, UInt<5>("h12")) @[ALU.scala 39:47]
    node signedOp = or(_signedOp_T, _signedOp_T_1) @[ALU.scala 39:38]
    node _absA_T = bits(io_a, 31, 31) @[ALU.scala 40:34]
    node _absA_T_1 = and(signedOp, _absA_T) @[ALU.scala 40:27]
    node _absA_T_2 = sub(UInt<1>("h0"), io_a) @[ALU.scala 40:40]
    node _absA_T_3 = tail(_absA_T_2, 1) @[ALU.scala 40:40]
    node absA = mux(_absA_T_1, _absA_T_3, io_a) @[ALU.scala 40:17]
    node _absB_T = bits(io_b, 31, 31) @[ALU.scala 41:34]
    node _absB_T_1 = and(signedOp, _absB_T) @[ALU.scala 41:27]
    node _absB_T_2 = sub(UInt<1>("h0"), io_b) @[ALU.scala 41:40]
    node _absB_T_3 = tail(_absB_T_2, 1) @[ALU.scala 41:40]
    node absB = mux(_absB_T_1, _absB_T_3, io_b) @[ALU.scala 41:17]
    reg state : UInt<2>, clock with :
      reset => (UInt<1>("h0"), state) @[ALU.scala 44:22]
    reg q : UInt<32>, clock with :
      reset => (UInt<1>("h0"), q) @[ALU.scala 45:18]
    reg r : UInt<33>, clock with :
      reset => (UInt<1>("h0"), r) @[ALU.scala 45:46]
    reg d : UInt<32>, clock with :
      reset => (UInt<1>("h0"), d) @[ALU.scala 46:18]
    reg originalA : UInt<32>, clock with :
      reset => (UInt<1>("h0"), originalA) @[ALU.scala 46:54]
    reg count : UInt<6>, clock with :
      reset => (UInt<1>("h0"), count) @[ALU.scala 47:22]
    reg result : UInt<32>, clock with :
      reset => (UInt<1>("h0"), result) @[ALU.scala 47:54]
    reg negQ : UInt<1>, clock with :
      reset => (UInt<1>("h0"), negQ) @[ALU.scala 48:21]
    reg negR : UInt<1>, clock with :
      reset => (UInt<1>("h0"), negR) @[ALU.scala 48:50]
    reg divZero : UInt<1>, clock with :
      reset => (UInt<1>("h0"), divZero) @[ALU.scala 49:24]
    reg overflow : UInt<1>, clock with :
      reset => (UInt<1>("h0"), overflow) @[ALU.scala 49:57]
    reg remSaved : UInt<1>, clock with :
      reset => (UInt<1>("h0"), remSaved) @[ALU.scala 50:25]
    node _shifted_T = bits(r, 31, 0) @[ALU.scala 52:22]
    node _shifted_T_1 = bits(q, 31, 31) @[ALU.scala 52:32]
    node shifted = cat(_shifted_T, _shifted_T_1) @[Cat.scala 33:92]
    node _subtract_T = cat(UInt<1>("h0"), d) @[Cat.scala 33:92]
    node subtract = geq(shifted, _subtract_T) @[ALU.scala 53:26]
    node _nextR_T = cat(UInt<1>("h0"), d) @[Cat.scala 33:92]
    node _nextR_T_1 = sub(shifted, _nextR_T) @[ALU.scala 54:37]
    node _nextR_T_2 = tail(_nextR_T_1, 1) @[ALU.scala 54:37]
    node nextR = mux(subtract, _nextR_T_2, shifted) @[ALU.scala 54:18]
    node _nextQ_T = bits(q, 30, 0) @[ALU.scala 55:20]
    node nextQ = cat(_nextQ_T, subtract) @[Cat.scala 33:92]
    node _T = eq(UInt<2>("h0"), state) @[ALU.scala 57:17]
    node _T_1 = and(io_start, divRem) @[ALU.scala 59:21]
    node _negQ_T = bits(io_a, 31, 31) @[ALU.scala 61:34]
    node _negQ_T_1 = bits(io_b, 31, 31) @[ALU.scala 61:45]
    node _negQ_T_2 = xor(_negQ_T, _negQ_T_1) @[ALU.scala 61:39]
    node _negQ_T_3 = and(signedOp, _negQ_T_2) @[ALU.scala 61:26]
    node _negR_T = bits(io_a, 31, 31) @[ALU.scala 62:33]
    node _negR_T_1 = and(signedOp, _negR_T) @[ALU.scala 62:26]
    node _divZero_T = eq(io_b, UInt<1>("h0")) @[ALU.scala 63:25]
    node _overflow_T = eq(io_a, UInt<32>("h80000000")) @[ALU.scala 64:38]
    node _overflow_T_1 = and(signedOp, _overflow_T) @[ALU.scala 64:30]
    node _overflow_T_2 = eq(io_b, UInt<32>("hffffffff")) @[ALU.scala 65:26]
    node _overflow_T_3 = and(_overflow_T_1, _overflow_T_2) @[ALU.scala 64:56]
    node _GEN_0 = mux(_T_1, absA, q) @[ALU.scala 59:32 60:11 45:18]
    node _GEN_1 = mux(_T_1, UInt<1>("h0"), r) @[ALU.scala 59:32 60:22 45:46]
    node _GEN_2 = mux(_T_1, absB, d) @[ALU.scala 46:18 59:32 60:32]
    node _GEN_3 = mux(_T_1, io_a, originalA) @[ALU.scala 59:32 60:51 46:54]
    node _GEN_4 = mux(_T_1, UInt<1>("h0"), count) @[ALU.scala 47:22 59:32 60:66]
    node _GEN_5 = mux(_T_1, _negQ_T_3, negQ) @[ALU.scala 59:32 61:14 48:21]
    node _GEN_6 = mux(_T_1, _negR_T_1, negR) @[ALU.scala 59:32 62:14 48:50]
    node _GEN_7 = mux(_T_1, _divZero_T, divZero) @[ALU.scala 59:32 63:17 49:24]
    node _GEN_8 = mux(_T_1, _overflow_T_3, overflow) @[ALU.scala 59:32 64:18 49:57]
    node _GEN_9 = mux(_T_1, remOp, remSaved) @[ALU.scala 59:32 66:18 50:25]
    node _GEN_10 = mux(_T_1, UInt<2>("h1"), state) @[ALU.scala 59:32 67:15 44:22]
    node _T_2 = eq(UInt<2>("h1"), state) @[ALU.scala 57:17]
    node _count_T = add(count, UInt<1>("h1")) @[ALU.scala 71:46]
    node _count_T_1 = tail(_count_T, 1) @[ALU.scala 71:46]
    node _T_3 = eq(count, UInt<5>("h1f")) @[ALU.scala 72:18]
    node _quotient_T = sub(UInt<1>("h0"), nextQ) @[ALU.scala 73:34]
    node _quotient_T_1 = tail(_quotient_T, 1) @[ALU.scala 73:34]
    node quotient = mux(negQ, _quotient_T_1, nextQ) @[ALU.scala 73:27]
    node _remainder_T = bits(nextR, 31, 0) @[ALU.scala 74:41]
    node _remainder_T_1 = sub(UInt<1>("h0"), _remainder_T) @[ALU.scala 74:35]
    node _remainder_T_2 = tail(_remainder_T_1, 1) @[ALU.scala 74:35]
    node _remainder_T_3 = bits(nextR, 31, 0) @[ALU.scala 74:55]
    node remainder = mux(negR, _remainder_T_2, _remainder_T_3) @[ALU.scala 74:28]
    node _finalQ_T = mux(overflow, UInt<32>("h80000000"), quotient) @[ALU.scala 76:25]
    node finalQ = mux(divZero, UInt<32>("hffffffff"), _finalQ_T) @[ALU.scala 75:25]
    node _finalR_T = mux(overflow, UInt<32>("h0"), remainder) @[ALU.scala 78:25]
    node finalR = mux(divZero, originalA, _finalR_T) @[ALU.scala 77:25]
    node _result_T = mux(remSaved, finalR, finalQ) @[ALU.scala 79:22]
    node _GEN_11 = mux(_T_3, _result_T, result) @[ALU.scala 72:28 79:16 47:54]
    node _GEN_12 = mux(_T_3, UInt<2>("h2"), state) @[ALU.scala 72:28 80:15 44:22]
    node _T_4 = eq(UInt<2>("h2"), state) @[ALU.scala 57:17]
    node _GEN_13 = mux(_T_4, UInt<2>("h0"), state) @[ALU.scala 57:17 44:22 83:23]
    node _GEN_14 = mux(_T_2, nextQ, q) @[ALU.scala 57:17 45:18 71:9]
    node _GEN_15 = mux(_T_2, nextR, r) @[ALU.scala 57:17 71:21 45:46]
    node _GEN_16 = mux(_T_2, _count_T_1, count) @[ALU.scala 57:17 47:22 71:37]
    node _GEN_17 = mux(_T_2, _GEN_11, result) @[ALU.scala 57:17 47:54]
    node _GEN_18 = mux(_T_2, _GEN_12, _GEN_13) @[ALU.scala 57:17]
    node _GEN_19 = mux(_T, _GEN_0, _GEN_14) @[ALU.scala 57:17]
    node _GEN_20 = mux(_T, _GEN_1, _GEN_15) @[ALU.scala 57:17]
    node _GEN_21 = mux(_T, _GEN_2, d) @[ALU.scala 57:17 46:18]
    node _GEN_22 = mux(_T, _GEN_3, originalA) @[ALU.scala 57:17 46:54]
    node _GEN_23 = mux(_T, _GEN_4, _GEN_16) @[ALU.scala 57:17]
    node _GEN_24 = mux(_T, _GEN_5, negQ) @[ALU.scala 57:17 48:21]
    node _GEN_25 = mux(_T, _GEN_6, negR) @[ALU.scala 57:17 48:50]
    node _GEN_26 = mux(_T, _GEN_7, divZero) @[ALU.scala 57:17 49:24]
    node _GEN_27 = mux(_T, _GEN_8, overflow) @[ALU.scala 57:17 49:57]
    node _GEN_28 = mux(_T, _GEN_9, remSaved) @[ALU.scala 57:17 50:25]
    node _GEN_29 = mux(_T, _GEN_10, _GEN_18) @[ALU.scala 57:17]
    node _GEN_30 = mux(_T, result, _GEN_17) @[ALU.scala 57:17 47:54]
    node _io_busy_T = eq(state, UInt<2>("h1")) @[ALU.scala 86:20]
    node _io_done_T = eq(state, UInt<2>("h2")) @[ALU.scala 87:20]
    node _comb_T = add(io_a, io_b) @[ALU.scala 90:24]
    node _comb_T_1 = tail(_comb_T, 1) @[ALU.scala 90:24]
    node _comb_T_2 = sub(io_a, io_b) @[ALU.scala 90:52]
    node _comb_T_3 = tail(_comb_T_2, 1) @[ALU.scala 90:52]
    node _comb_T_4 = dshl(io_a, shamt) @[ALU.scala 91:24]
    node _comb_T_5 = lt(sa, sb) @[ALU.scala 91:52]
    node _comb_T_6 = lt(io_a, io_b) @[ALU.scala 92:25]
    node _comb_T_7 = xor(io_a, io_b) @[ALU.scala 92:60]
    node _comb_T_8 = dshr(io_a, shamt) @[ALU.scala 93:24]
    node _comb_T_9 = dshr(sa, shamt) @[ALU.scala 93:52]
    node _comb_T_10 = asUInt(_comb_T_9) @[ALU.scala 93:62]
    node _comb_T_11 = or(io_a, io_b) @[ALU.scala 94:23]
    node _comb_T_12 = and(io_a, io_b) @[ALU.scala 94:51]
    node _comb_T_13 = bits(mulSS, 31, 0) @[ALU.scala 95:23]
    node _comb_T_14 = bits(mulSS, 63, 32) @[ALU.scala 95:51]
    node _comb_T_15 = bits(mulSU, 63, 32) @[ALU.scala 96:26]
    node _comb_T_16 = bits(mulUU, 63, 32) @[ALU.scala 96:56]
    node _comb_T_17 = eq(io_a, io_b) @[ALU.scala 97:23]
    node _comb_T_18 = neq(io_a, io_b) @[ALU.scala 97:59]
    node _comb_T_19 = eq(UInt<5>("h0"), io_op) @[Mux.scala 81:61]
    node _comb_T_20 = mux(_comb_T_19, _comb_T_1, UInt<32>("h0")) @[Mux.scala 81:58]
    node _comb_T_21 = eq(UInt<5>("h1"), io_op) @[Mux.scala 81:61]
    node _comb_T_22 = mux(_comb_T_21, _comb_T_3, _comb_T_20) @[Mux.scala 81:58]
    node _comb_T_23 = eq(UInt<5>("h2"), io_op) @[Mux.scala 81:61]
    node _comb_T_24 = mux(_comb_T_23, _comb_T_4, _comb_T_22) @[Mux.scala 81:58]
    node _comb_T_25 = eq(UInt<5>("h3"), io_op) @[Mux.scala 81:61]
    node _comb_T_26 = mux(_comb_T_25, _comb_T_5, _comb_T_24) @[Mux.scala 81:58]
    node _comb_T_27 = eq(UInt<5>("h4"), io_op) @[Mux.scala 81:61]
    node _comb_T_28 = mux(_comb_T_27, _comb_T_6, _comb_T_26) @[Mux.scala 81:58]
    node _comb_T_29 = eq(UInt<5>("h5"), io_op) @[Mux.scala 81:61]
    node _comb_T_30 = mux(_comb_T_29, _comb_T_7, _comb_T_28) @[Mux.scala 81:58]
    node _comb_T_31 = eq(UInt<5>("h6"), io_op) @[Mux.scala 81:61]
    node _comb_T_32 = mux(_comb_T_31, _comb_T_8, _comb_T_30) @[Mux.scala 81:58]
    node _comb_T_33 = eq(UInt<5>("h7"), io_op) @[Mux.scala 81:61]
    node _comb_T_34 = mux(_comb_T_33, _comb_T_10, _comb_T_32) @[Mux.scala 81:58]
    node _comb_T_35 = eq(UInt<5>("h8"), io_op) @[Mux.scala 81:61]
    node _comb_T_36 = mux(_comb_T_35, _comb_T_11, _comb_T_34) @[Mux.scala 81:58]
    node _comb_T_37 = eq(UInt<5>("h9"), io_op) @[Mux.scala 81:61]
    node _comb_T_38 = mux(_comb_T_37, _comb_T_12, _comb_T_36) @[Mux.scala 81:58]
    node _comb_T_39 = eq(UInt<5>("ha"), io_op) @[Mux.scala 81:61]
    node _comb_T_40 = mux(_comb_T_39, _comb_T_13, _comb_T_38) @[Mux.scala 81:58]
    node _comb_T_41 = eq(UInt<5>("hb"), io_op) @[Mux.scala 81:61]
    node _comb_T_42 = mux(_comb_T_41, _comb_T_14, _comb_T_40) @[Mux.scala 81:58]
    node _comb_T_43 = eq(UInt<5>("hc"), io_op) @[Mux.scala 81:61]
    node _comb_T_44 = mux(_comb_T_43, _comb_T_15, _comb_T_42) @[Mux.scala 81:58]
    node _comb_T_45 = eq(UInt<5>("hd"), io_op) @[Mux.scala 81:61]
    node _comb_T_46 = mux(_comb_T_45, _comb_T_16, _comb_T_44) @[Mux.scala 81:58]
    node _comb_T_47 = eq(UInt<5>("he"), io_op) @[Mux.scala 81:61]
    node _comb_T_48 = mux(_comb_T_47, _comb_T_17, _comb_T_46) @[Mux.scala 81:58]
    node _comb_T_49 = eq(UInt<5>("hf"), io_op) @[Mux.scala 81:61]
    node comb = mux(_comb_T_49, _comb_T_18, _comb_T_48) @[Mux.scala 81:58]
    node _io_y_T = mux(divRem, result, comb) @[ALU.scala 100:14]
    io_y <= bits(_io_y_T, 31, 0) @[ALU.scala 100:8]
    io_busy <= _io_busy_T @[ALU.scala 86:11]
    io_done <= _io_done_T @[ALU.scala 87:11]
    state <= mux(reset, UInt<2>("h0"), _GEN_29) @[ALU.scala 44:{22,22}]
    q <= mux(reset, UInt<32>("h0"), _GEN_19) @[ALU.scala 45:{18,18}]
    r <= mux(reset, UInt<33>("h0"), _GEN_20) @[ALU.scala 45:{46,46}]
    d <= mux(reset, UInt<32>("h0"), _GEN_21) @[ALU.scala 46:{18,18}]
    originalA <= mux(reset, UInt<32>("h0"), _GEN_22) @[ALU.scala 46:{54,54}]
    count <= mux(reset, UInt<6>("h0"), _GEN_23) @[ALU.scala 47:{22,22}]
    result <= mux(reset, UInt<32>("h0"), _GEN_30) @[ALU.scala 47:{54,54}]
    negQ <= mux(reset, UInt<1>("h0"), _GEN_24) @[ALU.scala 48:{21,21}]
    negR <= mux(reset, UInt<1>("h0"), _GEN_25) @[ALU.scala 48:{50,50}]
    divZero <= mux(reset, UInt<1>("h0"), _GEN_26) @[ALU.scala 49:{24,24}]
    overflow <= mux(reset, UInt<1>("h0"), _GEN_27) @[ALU.scala 49:{57,57}]
    remSaved <= mux(reset, UInt<1>("h0"), _GEN_28) @[ALU.scala 50:{25,25}]

  module PCUpdate :
    input clock : Clock
    input reset : UInt<1>
    input io_pc : UInt<32>
    input io_rs1 : UInt<32>
    input io_imm : UInt<32>
    input io_funct3 : UInt<3>
    input io_branch : UInt<1>
    input io_jump : UInt<1>
    input io_jalr : UInt<1>
    input io_aluResult : UInt<32>
    output io_nextPc : UInt<32>

    node _pcPlus4_T = add(io_pc, UInt<3>("h4")) @[PCUpdate.scala 23:23]
    node pcPlus4 = tail(_pcPlus4_T, 1) @[PCUpdate.scala 23:23]
    node _branchTarget_T = add(io_pc, io_imm) @[PCUpdate.scala 25:28]
    node branchTarget = tail(_branchTarget_T, 1) @[PCUpdate.scala 25:28]
    node _jalTarget_T = add(io_pc, io_imm) @[PCUpdate.scala 27:25]
    node jalTarget = tail(_jalTarget_T, 1) @[PCUpdate.scala 27:25]
    node _jalrTarget_T = add(io_rs1, io_imm) @[PCUpdate.scala 29:28]
    node _jalrTarget_T_1 = tail(_jalrTarget_T, 1) @[PCUpdate.scala 29:28]
    node _jalrTarget_T_2 = not(UInt<32>("h1")) @[PCUpdate.scala 29:41]
    node jalrTarget = and(_jalrTarget_T_1, _jalrTarget_T_2) @[PCUpdate.scala 29:38]
    node _T = eq(UInt<1>("h0"), io_funct3) @[PCUpdate.scala 34:24]
    node _branchTaken_T = eq(io_aluResult, UInt<1>("h1")) @[PCUpdate.scala 36:37]
    node _T_1 = eq(UInt<1>("h1"), io_funct3) @[PCUpdate.scala 34:24]
    node _branchTaken_T_1 = eq(io_aluResult, UInt<1>("h1")) @[PCUpdate.scala 40:37]
    node _T_2 = eq(UInt<3>("h4"), io_funct3) @[PCUpdate.scala 34:24]
    node _branchTaken_T_2 = eq(io_aluResult, UInt<1>("h1")) @[PCUpdate.scala 44:37]
    node _T_3 = eq(UInt<3>("h5"), io_funct3) @[PCUpdate.scala 34:24]
    node _branchTaken_T_3 = eq(io_aluResult, UInt<1>("h0")) @[PCUpdate.scala 48:37]
    node _T_4 = eq(UInt<3>("h6"), io_funct3) @[PCUpdate.scala 34:24]
    node _branchTaken_T_4 = eq(io_aluResult, UInt<1>("h1")) @[PCUpdate.scala 52:37]
    node _T_5 = eq(UInt<3>("h7"), io_funct3) @[PCUpdate.scala 34:24]
    node _branchTaken_T_5 = eq(io_aluResult, UInt<1>("h0")) @[PCUpdate.scala 56:37]
    node _GEN_0 = mux(_T_5, _branchTaken_T_5, UInt<1>("h0")) @[PCUpdate.scala 34:24 56:21 31:32]
    node _GEN_1 = mux(_T_4, _branchTaken_T_4, _GEN_0) @[PCUpdate.scala 34:24 52:21]
    node _GEN_2 = mux(_T_3, _branchTaken_T_3, _GEN_1) @[PCUpdate.scala 34:24 48:21]
    node _GEN_3 = mux(_T_2, _branchTaken_T_2, _GEN_2) @[PCUpdate.scala 34:24 44:21]
    node _GEN_4 = mux(_T_1, _branchTaken_T_1, _GEN_3) @[PCUpdate.scala 34:24 40:21]
    node _GEN_5 = mux(_T, _branchTaken_T, _GEN_4) @[PCUpdate.scala 34:24 36:21]
    node _GEN_6 = mux(io_branch, _GEN_5, UInt<1>("h0")) @[PCUpdate.scala 33:20 31:32]
    node branchTaken = _GEN_6 @[PCUpdate.scala 31:32]
    node _GEN_7 = mux(branchTaken, branchTarget, pcPlus4) @[PCUpdate.scala 61:13 63:22 64:15]
    node _GEN_8 = mux(io_jump, jalTarget, _GEN_7) @[PCUpdate.scala 67:18 68:15]
    node _GEN_9 = mux(io_jalr, jalrTarget, _GEN_8) @[PCUpdate.scala 71:18 72:15]
    io_nextPc <= _GEN_9

  module Datapath :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    input io_pc : UInt<32>
    output io_nextPc : UInt<32>
    output io_memRead : UInt<1>
    output io_memWrite : UInt<1>
    output io_memAddr : UInt<32>
    output io_memWdata : UInt<32>
    input io_memRdata : UInt<32>
    output io_memFunct3 : UInt<3>
    output io_writeBack : UInt<32>
    output io_debugX1 : UInt<32>
    output io_debugX2 : UInt<32>
    output io_debugX3 : UInt<32>
    output io_debugX4 : UInt<32>
    output io_debugX5 : UInt<32>
    output io_debugX6 : UInt<32>
    output io_debugALU : UInt<32>
    output io_debugImm : UInt<32>

    inst decoder of Decoder @[Datapath.scala 19:23]
    inst control of Control @[Datapath.scala 19:58]
    inst immGen of ImmediateGenerator @[Datapath.scala 20:22]
    inst regFile of RegisterFile @[Datapath.scala 20:71]
    inst alu of ALU @[Datapath.scala 21:19]
    inst pcUpdate of PCUpdate @[Datapath.scala 21:54]
    node aluB = mux(control.io_aluSrc, immGen.io_imm, regFile.io_readData2) @[Datapath.scala 26:17]
    node _isDivRem_T = eq(control.io_aluOp, UInt<5>("h10")) @[Datapath.scala 30:27]
    node _isDivRem_T_1 = eq(control.io_aluOp, UInt<5>("h11")) @[Datapath.scala 30:27]
    node _isDivRem_T_2 = eq(control.io_aluOp, UInt<5>("h12")) @[Datapath.scala 30:27]
    node _isDivRem_T_3 = eq(control.io_aluOp, UInt<5>("h13")) @[Datapath.scala 30:27]
    node _isDivRem_T_4 = or(_isDivRem_T, _isDivRem_T_1) @[Datapath.scala 30:43]
    node _isDivRem_T_5 = or(_isDivRem_T_4, _isDivRem_T_2) @[Datapath.scala 30:43]
    node isDivRem = or(_isDivRem_T_5, _isDivRem_T_3) @[Datapath.scala 30:43]
    reg divStarted : UInt<1>, clock with :
      reset => (UInt<1>("h0"), divStarted) @[Datapath.scala 31:27]
    node _divStart_T = eq(divStarted, UInt<1>("h0")) @[Datapath.scala 32:30]
    node divStart = and(isDivRem, _divStart_T) @[Datapath.scala 32:27]
    node _GEN_0 = mux(divStart, UInt<1>("h1"), divStarted) @[Datapath.scala 34:18 31:27 34:31]
    node _GEN_1 = mux(alu.io_done, UInt<1>("h0"), _GEN_0) @[Datapath.scala 35:{21,34}]
    node _stall_T = eq(alu.io_done, UInt<1>("h0")) @[Datapath.scala 36:27]
    node stall = and(isDivRem, _stall_T) @[Datapath.scala 36:24]
    node _io_memRead_T = eq(stall, UInt<1>("h0")) @[Datapath.scala 38:39]
    node _io_memRead_T_1 = and(control.io_memRead, _io_memRead_T) @[Datapath.scala 38:36]
    node _io_memWrite_T = eq(stall, UInt<1>("h0")) @[Datapath.scala 39:41]
    node _io_memWrite_T_1 = and(control.io_memWrite, _io_memWrite_T) @[Datapath.scala 39:38]
    node _wb_T = or(control.io_jump, control.io_jalr) @[Datapath.scala 44:25]
    node _wb_T_1 = add(io_pc, UInt<3>("h4")) @[Datapath.scala 44:51]
    node _wb_T_2 = tail(_wb_T_1, 1) @[Datapath.scala 44:51]
    node _wb_T_3 = mux(_wb_T, _wb_T_2, alu.io_y) @[Datapath.scala 44:8]
    node wb = mux(control.io_memToReg, io_memRdata, _wb_T_3) @[Datapath.scala 43:15]
    node _regFile_io_writeEnable_T = eq(stall, UInt<1>("h0")) @[Datapath.scala 46:52]
    node _regFile_io_writeEnable_T_1 = and(control.io_regWrite, _regFile_io_writeEnable_T) @[Datapath.scala 46:49]
    node _io_nextPc_T = mux(stall, io_pc, pcUpdate.io_nextPc) @[Datapath.scala 52:19]
    io_nextPc <= _io_nextPc_T @[Datapath.scala 52:13]
    io_memRead <= _io_memRead_T_1 @[Datapath.scala 38:14]
    io_memWrite <= _io_memWrite_T_1 @[Datapath.scala 39:15]
    io_memAddr <= alu.io_y @[Datapath.scala 40:14]
    io_memWdata <= regFile.io_readData2 @[Datapath.scala 40:39]
    io_memFunct3 <= decoder.io_funct3 @[Datapath.scala 41:16]
    io_writeBack <= wb @[Datapath.scala 54:16]
    io_debugX1 <= regFile.io_debugRead_1 @[Datapath.scala 55:14]
    io_debugX2 <= regFile.io_debugRead_2 @[Datapath.scala 55:53]
    io_debugX3 <= regFile.io_debugRead_3 @[Datapath.scala 56:14]
    io_debugX4 <= regFile.io_debugRead_4 @[Datapath.scala 56:53]
    io_debugX5 <= regFile.io_debugRead_5 @[Datapath.scala 57:14]
    io_debugX6 <= regFile.io_debugRead_6 @[Datapath.scala 57:53]
    io_debugALU <= alu.io_y @[Datapath.scala 58:15]
    io_debugImm <= immGen.io_imm @[Datapath.scala 58:40]
    decoder.clock <= clock
    decoder.reset <= reset
    decoder.io_instr <= io_instr @[Datapath.scala 23:20]
    control.clock <= clock
    control.reset <= reset
    control.io_instr <= io_instr @[Datapath.scala 23:50]
    immGen.clock <= clock
    immGen.reset <= reset
    immGen.io_instr <= io_instr @[Datapath.scala 23:79]
    regFile.clock <= clock
    regFile.reset <= reset
    regFile.io_rs1 <= decoder.io_rs1 @[Datapath.scala 24:18]
    regFile.io_rs2 <= decoder.io_rs2 @[Datapath.scala 24:52]
    regFile.io_rd <= decoder.io_rd @[Datapath.scala 24:85]
    regFile.io_writeData <= wb @[Datapath.scala 45:24]
    regFile.io_writeEnable <= _regFile_io_writeEnable_T_1 @[Datapath.scala 46:26]
    alu.clock <= clock
    alu.reset <= reset
    alu.io_a <= regFile.io_readData1 @[Datapath.scala 27:12]
    alu.io_b <= aluB @[Datapath.scala 27:46]
    alu.io_op <= control.io_aluOp @[Datapath.scala 27:65]
    alu.io_start <= divStart @[Datapath.scala 33:16]
    pcUpdate.clock <= clock
    pcUpdate.reset <= reset
    pcUpdate.io_pc <= io_pc @[Datapath.scala 48:18]
    pcUpdate.io_rs1 <= regFile.io_readData1 @[Datapath.scala 48:44]
    pcUpdate.io_imm <= immGen.io_imm @[Datapath.scala 49:19]
    pcUpdate.io_funct3 <= decoder.io_funct3 @[Datapath.scala 49:56]
    pcUpdate.io_branch <= control.io_branch @[Datapath.scala 50:22]
    pcUpdate.io_jump <= control.io_jump @[Datapath.scala 50:61]
    pcUpdate.io_jalr <= control.io_jalr @[Datapath.scala 51:20]
    pcUpdate.io_aluResult <= alu.io_y @[Datapath.scala 51:62]
    divStarted <= mux(reset, UInt<1>("h0"), _GEN_1) @[Datapath.scala 31:{27,27}]

  module DataMemory :
    input clock : Clock
    input reset : UInt<1>
    input io_addr : UInt<32>
    input io_wdata : UInt<32>
    output io_rdata : UInt<32>
    input io_memRead : UInt<1>
    input io_memWrite : UInt<1>
    input io_funct3 : UInt<3>

    mem mem : @[DataMemory.scala 18:16]
      data-type => UInt<8>
      depth => 1024
      read-latency => 0
      write-latency => 1
      reader => byte0
      reader => byte1
      reader => byte2
      reader => byte3
      writer => MPORT
      writer => MPORT_1
      writer => MPORT_2
      writer => MPORT_3
      writer => MPORT_4
      writer => MPORT_5
      writer => MPORT_6
      read-under-write => undefined
    node _byte0_T = bits(io_addr, 9, 0) @[DataMemory.scala 20:18]
    node _byte1_T = add(io_addr, UInt<1>("h1")) @[DataMemory.scala 21:27]
    node _byte1_T_1 = tail(_byte1_T, 1) @[DataMemory.scala 21:27]
    node _byte1_T_2 = bits(_byte1_T_1, 9, 0) @[DataMemory.scala 21:18]
    node _byte2_T = add(io_addr, UInt<2>("h2")) @[DataMemory.scala 22:27]
    node _byte2_T_1 = tail(_byte2_T, 1) @[DataMemory.scala 22:27]
    node _byte2_T_2 = bits(_byte2_T_1, 9, 0) @[DataMemory.scala 22:18]
    node _byte3_T = add(io_addr, UInt<2>("h3")) @[DataMemory.scala 23:27]
    node _byte3_T_1 = tail(_byte3_T, 1) @[DataMemory.scala 23:27]
    node _byte3_T_2 = bits(_byte3_T_1, 9, 0) @[DataMemory.scala 23:18]
    node loadData_lo = cat(mem.byte1.data, mem.byte0.data) @[Cat.scala 33:92]
    node loadData_hi = cat(mem.byte3.data, mem.byte2.data) @[Cat.scala 33:92]
    node loadData = cat(loadData_hi, loadData_lo) @[Cat.scala 33:92]
    node _T = eq(UInt<1>("h0"), io_funct3) @[DataMemory.scala 30:23]
    node _io_rdata_T = bits(mem.byte0.data, 7, 7) @[DataMemory.scala 32:39]
    node _io_rdata_T_1 = bits(_io_rdata_T, 0, 0) @[Bitwise.scala 77:15]
    node _io_rdata_T_2 = mux(_io_rdata_T_1, UInt<24>("hffffff"), UInt<24>("h0")) @[Bitwise.scala 77:12]
    node _io_rdata_T_3 = cat(_io_rdata_T_2, mem.byte0.data) @[Cat.scala 33:92]
    node _T_1 = eq(UInt<1>("h1"), io_funct3) @[DataMemory.scala 30:23]
    node _io_rdata_T_4 = bits(mem.byte1.data, 7, 7) @[DataMemory.scala 37:25]
    node _io_rdata_T_5 = bits(_io_rdata_T_4, 0, 0) @[Bitwise.scala 77:15]
    node _io_rdata_T_6 = mux(_io_rdata_T_5, UInt<16>("hffff"), UInt<16>("h0")) @[Bitwise.scala 77:12]
    node io_rdata_hi = cat(_io_rdata_T_6, mem.byte1.data) @[Cat.scala 33:92]
    node _io_rdata_T_7 = cat(io_rdata_hi, mem.byte0.data) @[Cat.scala 33:92]
    node _T_2 = eq(UInt<2>("h2"), io_funct3) @[DataMemory.scala 30:23]
    node _T_3 = eq(UInt<3>("h4"), io_funct3) @[DataMemory.scala 30:23]
    node _io_rdata_T_8 = cat(UInt<24>("h0"), mem.byte0.data) @[Cat.scala 33:92]
    node _T_4 = eq(UInt<3>("h5"), io_funct3) @[DataMemory.scala 30:23]
    node io_rdata_hi_1 = cat(UInt<16>("h0"), mem.byte1.data) @[Cat.scala 33:92]
    node _io_rdata_T_9 = cat(io_rdata_hi_1, mem.byte0.data) @[Cat.scala 33:92]
    node _GEN_0 = mux(_T_4, _io_rdata_T_9, UInt<1>("h0")) @[DataMemory.scala 27:12 30:23 52:18]
    node _GEN_1 = mux(_T_3, _io_rdata_T_8, _GEN_0) @[DataMemory.scala 30:23 48:18]
    node _GEN_2 = mux(_T_2, loadData, _GEN_1) @[DataMemory.scala 30:23 44:18]
    node _GEN_3 = mux(_T_1, _io_rdata_T_7, _GEN_2) @[DataMemory.scala 30:23 36:18]
    node _GEN_4 = mux(_T, _io_rdata_T_3, _GEN_3) @[DataMemory.scala 30:23 32:18]
    node _GEN_5 = mux(io_memRead, _GEN_4, UInt<1>("h0")) @[DataMemory.scala 27:12 29:20]
    node _T_5 = eq(UInt<1>("h0"), io_funct3) @[DataMemory.scala 62:23]
    node _T_6 = bits(io_addr, 9, 0) @[DataMemory.scala 64:12]
    node _T_7 = bits(io_wdata, 7, 0) @[DataMemory.scala 64:33]
    node _T_8 = eq(UInt<1>("h1"), io_funct3) @[DataMemory.scala 62:23]
    node _T_9 = bits(io_addr, 9, 0) @[DataMemory.scala 68:12]
    node _T_10 = bits(io_wdata, 7, 0) @[DataMemory.scala 68:37]
    node _T_11 = add(io_addr, UInt<1>("h1")) @[DataMemory.scala 69:21]
    node _T_12 = tail(_T_11, 1) @[DataMemory.scala 69:21]
    node _T_13 = bits(_T_12, 9, 0) @[DataMemory.scala 69:12]
    node _T_14 = bits(io_wdata, 15, 8) @[DataMemory.scala 69:39]
    node _T_15 = eq(UInt<2>("h2"), io_funct3) @[DataMemory.scala 62:23]
    node _T_16 = bits(io_addr, 9, 0) @[DataMemory.scala 73:12]
    node _T_17 = bits(io_wdata, 7, 0) @[DataMemory.scala 73:37]
    node _T_18 = add(io_addr, UInt<1>("h1")) @[DataMemory.scala 74:21]
    node _T_19 = tail(_T_18, 1) @[DataMemory.scala 74:21]
    node _T_20 = bits(_T_19, 9, 0) @[DataMemory.scala 74:12]
    node _T_21 = bits(io_wdata, 15, 8) @[DataMemory.scala 74:39]
    node _T_22 = add(io_addr, UInt<2>("h2")) @[DataMemory.scala 75:21]
    node _T_23 = tail(_T_22, 1) @[DataMemory.scala 75:21]
    node _T_24 = bits(_T_23, 9, 0) @[DataMemory.scala 75:12]
    node _T_25 = bits(io_wdata, 23, 16) @[DataMemory.scala 75:39]
    node _T_26 = add(io_addr, UInt<2>("h3")) @[DataMemory.scala 76:21]
    node _T_27 = tail(_T_26, 1) @[DataMemory.scala 76:21]
    node _T_28 = bits(_T_27, 9, 0) @[DataMemory.scala 76:12]
    node _T_29 = bits(io_wdata, 31, 24) @[DataMemory.scala 76:39]
    node _GEN_6 = validif(_T_15, _T_16) @[DataMemory.scala 62:23 73:12]
    node _GEN_7 = validif(_T_15, clock) @[DataMemory.scala 62:23 73:12]
    node _GEN_8 = mux(_T_15, UInt<1>("h1"), UInt<1>("h0")) @[DataMemory.scala 62:23 73:12 18:16]
    node _GEN_9 = validif(_T_15, UInt<1>("h1")) @[DataMemory.scala 62:23 73:26]
    node _GEN_10 = validif(_T_15, _T_17) @[DataMemory.scala 62:23 73:26]
    node _GEN_11 = validif(_T_15, _T_20) @[DataMemory.scala 62:23 74:12]
    node _GEN_12 = validif(_T_15, _T_21) @[DataMemory.scala 62:23 74:28]
    node _GEN_13 = validif(_T_15, _T_24) @[DataMemory.scala 62:23 75:12]
    node _GEN_14 = validif(_T_15, _T_25) @[DataMemory.scala 62:23 75:28]
    node _GEN_15 = validif(_T_15, _T_28) @[DataMemory.scala 62:23 76:12]
    node _GEN_16 = validif(_T_15, _T_29) @[DataMemory.scala 62:23 76:28]
    node _GEN_17 = validif(_T_8, _T_9) @[DataMemory.scala 62:23 68:12]
    node _GEN_18 = validif(_T_8, clock) @[DataMemory.scala 62:23 68:12]
    node _GEN_19 = mux(_T_8, UInt<1>("h1"), UInt<1>("h0")) @[DataMemory.scala 62:23 68:12 18:16]
    node _GEN_20 = validif(_T_8, UInt<1>("h1")) @[DataMemory.scala 62:23 68:26]
    node _GEN_21 = validif(_T_8, _T_10) @[DataMemory.scala 62:23 68:26]
    node _GEN_22 = validif(_T_8, _T_13) @[DataMemory.scala 62:23 69:12]
    node _GEN_23 = validif(_T_8, _T_14) @[DataMemory.scala 62:23 69:28]
    node _GEN_24 = validif(eq(_T_8, UInt<1>("h0")), _GEN_6) @[DataMemory.scala 62:23]
    node _GEN_25 = validif(eq(_T_8, UInt<1>("h0")), _GEN_7) @[DataMemory.scala 62:23]
    node _GEN_26 = mux(_T_8, UInt<1>("h0"), _GEN_8) @[DataMemory.scala 18:16 62:23]
    node _GEN_27 = validif(eq(_T_8, UInt<1>("h0")), _GEN_9) @[DataMemory.scala 62:23]
    node _GEN_28 = validif(eq(_T_8, UInt<1>("h0")), _GEN_10) @[DataMemory.scala 62:23]
    node _GEN_29 = validif(eq(_T_8, UInt<1>("h0")), _GEN_11) @[DataMemory.scala 62:23]
    node _GEN_30 = validif(eq(_T_8, UInt<1>("h0")), _GEN_12) @[DataMemory.scala 62:23]
    node _GEN_31 = validif(eq(_T_8, UInt<1>("h0")), _GEN_13) @[DataMemory.scala 62:23]
    node _GEN_32 = validif(eq(_T_8, UInt<1>("h0")), _GEN_14) @[DataMemory.scala 62:23]
    node _GEN_33 = validif(eq(_T_8, UInt<1>("h0")), _GEN_15) @[DataMemory.scala 62:23]
    node _GEN_34 = validif(eq(_T_8, UInt<1>("h0")), _GEN_16) @[DataMemory.scala 62:23]
    node _GEN_35 = validif(_T_5, _T_6) @[DataMemory.scala 62:23 64:12]
    node _GEN_36 = validif(_T_5, clock) @[DataMemory.scala 62:23 64:12]
    node _GEN_37 = mux(_T_5, UInt<1>("h1"), UInt<1>("h0")) @[DataMemory.scala 62:23 64:12 18:16]
    node _GEN_38 = validif(_T_5, UInt<1>("h1")) @[DataMemory.scala 62:23 64:22]
    node _GEN_39 = validif(_T_5, _T_7) @[DataMemory.scala 62:23 64:22]
    node _GEN_40 = validif(eq(_T_5, UInt<1>("h0")), _GEN_17) @[DataMemory.scala 62:23]
    node _GEN_41 = validif(eq(_T_5, UInt<1>("h0")), _GEN_18) @[DataMemory.scala 62:23]
    node _GEN_42 = mux(_T_5, UInt<1>("h0"), _GEN_19) @[DataMemory.scala 18:16 62:23]
    node _GEN_43 = validif(eq(_T_5, UInt<1>("h0")), _GEN_20) @[DataMemory.scala 62:23]
    node _GEN_44 = validif(eq(_T_5, UInt<1>("h0")), _GEN_21) @[DataMemory.scala 62:23]
    node _GEN_45 = validif(eq(_T_5, UInt<1>("h0")), _GEN_22) @[DataMemory.scala 62:23]
    node _GEN_46 = validif(eq(_T_5, UInt<1>("h0")), _GEN_23) @[DataMemory.scala 62:23]
    node _GEN_47 = validif(eq(_T_5, UInt<1>("h0")), _GEN_24) @[DataMemory.scala 62:23]
    node _GEN_48 = validif(eq(_T_5, UInt<1>("h0")), _GEN_25) @[DataMemory.scala 62:23]
    node _GEN_49 = mux(_T_5, UInt<1>("h0"), _GEN_26) @[DataMemory.scala 18:16 62:23]
    node _GEN_50 = validif(eq(_T_5, UInt<1>("h0")), _GEN_27) @[DataMemory.scala 62:23]
    node _GEN_51 = validif(eq(_T_5, UInt<1>("h0")), _GEN_28) @[DataMemory.scala 62:23]
    node _GEN_52 = validif(eq(_T_5, UInt<1>("h0")), _GEN_29) @[DataMemory.scala 62:23]
    node _GEN_53 = validif(eq(_T_5, UInt<1>("h0")), _GEN_30) @[DataMemory.scala 62:23]
    node _GEN_54 = validif(eq(_T_5, UInt<1>("h0")), _GEN_31) @[DataMemory.scala 62:23]
    node _GEN_55 = validif(eq(_T_5, UInt<1>("h0")), _GEN_32) @[DataMemory.scala 62:23]
    node _GEN_56 = validif(eq(_T_5, UInt<1>("h0")), _GEN_33) @[DataMemory.scala 62:23]
    node _GEN_57 = validif(eq(_T_5, UInt<1>("h0")), _GEN_34) @[DataMemory.scala 62:23]
    node _GEN_58 = validif(io_memWrite, _GEN_35) @[DataMemory.scala 61:21]
    node _GEN_59 = validif(io_memWrite, _GEN_36) @[DataMemory.scala 61:21]
    node _GEN_60 = mux(io_memWrite, _GEN_37, UInt<1>("h0")) @[DataMemory.scala 18:16 61:21]
    node _GEN_61 = validif(io_memWrite, _GEN_38) @[DataMemory.scala 61:21]
    node _GEN_62 = validif(io_memWrite, _GEN_39) @[DataMemory.scala 61:21]
    node _GEN_63 = validif(io_memWrite, _GEN_40) @[DataMemory.scala 61:21]
    node _GEN_64 = validif(io_memWrite, _GEN_41) @[DataMemory.scala 61:21]
    node _GEN_65 = mux(io_memWrite, _GEN_42, UInt<1>("h0")) @[DataMemory.scala 18:16 61:21]
    node _GEN_66 = validif(io_memWrite, _GEN_43) @[DataMemory.scala 61:21]
    node _GEN_67 = validif(io_memWrite, _GEN_44) @[DataMemory.scala 61:21]
    node _GEN_68 = validif(io_memWrite, _GEN_45) @[DataMemory.scala 61:21]
    node _GEN_69 = validif(io_memWrite, _GEN_46) @[DataMemory.scala 61:21]
    node _GEN_70 = validif(io_memWrite, _GEN_47) @[DataMemory.scala 61:21]
    node _GEN_71 = validif(io_memWrite, _GEN_48) @[DataMemory.scala 61:21]
    node _GEN_72 = mux(io_memWrite, _GEN_49, UInt<1>("h0")) @[DataMemory.scala 18:16 61:21]
    node _GEN_73 = validif(io_memWrite, _GEN_50) @[DataMemory.scala 61:21]
    node _GEN_74 = validif(io_memWrite, _GEN_51) @[DataMemory.scala 61:21]
    node _GEN_75 = validif(io_memWrite, _GEN_52) @[DataMemory.scala 61:21]
    node _GEN_76 = validif(io_memWrite, _GEN_53) @[DataMemory.scala 61:21]
    node _GEN_77 = validif(io_memWrite, _GEN_54) @[DataMemory.scala 61:21]
    node _GEN_78 = validif(io_memWrite, _GEN_55) @[DataMemory.scala 61:21]
    node _GEN_79 = validif(io_memWrite, _GEN_56) @[DataMemory.scala 61:21]
    node _GEN_80 = validif(io_memWrite, _GEN_57) @[DataMemory.scala 61:21]
    io_rdata <= _GEN_5
    mem.byte0.addr <= _byte0_T @[DataMemory.scala 20:18]
    mem.byte0.en <= UInt<1>("h1") @[DataMemory.scala 20:18]
    mem.byte0.clk <= clock @[DataMemory.scala 20:18]
    mem.byte1.addr <= _byte1_T_2 @[DataMemory.scala 21:18]
    mem.byte1.en <= UInt<1>("h1") @[DataMemory.scala 21:18]
    mem.byte1.clk <= clock @[DataMemory.scala 21:18]
    mem.byte2.addr <= _byte2_T_2 @[DataMemory.scala 22:18]
    mem.byte2.en <= UInt<1>("h1") @[DataMemory.scala 22:18]
    mem.byte2.clk <= clock @[DataMemory.scala 22:18]
    mem.byte3.addr <= _byte3_T_2 @[DataMemory.scala 23:18]
    mem.byte3.en <= UInt<1>("h1") @[DataMemory.scala 23:18]
    mem.byte3.clk <= clock @[DataMemory.scala 23:18]
    mem.MPORT.addr <= _GEN_58
    mem.MPORT.en <= _GEN_60
    mem.MPORT.clk <= _GEN_59
    mem.MPORT.data <= _GEN_62
    mem.MPORT.mask <= _GEN_61
    mem.MPORT_1.addr <= _GEN_63
    mem.MPORT_1.en <= _GEN_65
    mem.MPORT_1.clk <= _GEN_64
    mem.MPORT_1.data <= _GEN_67
    mem.MPORT_1.mask <= _GEN_66
    mem.MPORT_2.addr <= _GEN_68
    mem.MPORT_2.en <= _GEN_65
    mem.MPORT_2.clk <= _GEN_64
    mem.MPORT_2.data <= _GEN_69
    mem.MPORT_2.mask <= _GEN_66
    mem.MPORT_3.addr <= _GEN_70
    mem.MPORT_3.en <= _GEN_72
    mem.MPORT_3.clk <= _GEN_71
    mem.MPORT_3.data <= _GEN_74
    mem.MPORT_3.mask <= _GEN_73
    mem.MPORT_4.addr <= _GEN_75
    mem.MPORT_4.en <= _GEN_72
    mem.MPORT_4.clk <= _GEN_71
    mem.MPORT_4.data <= _GEN_76
    mem.MPORT_4.mask <= _GEN_73
    mem.MPORT_5.addr <= _GEN_77
    mem.MPORT_5.en <= _GEN_72
    mem.MPORT_5.clk <= _GEN_71
    mem.MPORT_5.data <= _GEN_78
    mem.MPORT_5.mask <= _GEN_73
    mem.MPORT_6.addr <= _GEN_79
    mem.MPORT_6.en <= _GEN_72
    mem.MPORT_6.clk <= _GEN_71
    mem.MPORT_6.data <= _GEN_80
    mem.MPORT_6.mask <= _GEN_73

  module RV32ICore :
    input clock : Clock
    input reset : UInt<1>
    output io_pc : UInt<32>
    output io_nextPc : UInt<32>
    output io_writeBack : UInt<32>
    output io_debugInstr : UInt<32>
    output io_debugX1 : UInt<32>
    output io_debugX2 : UInt<32>
    output io_debugX3 : UInt<32>
    output io_debugX4 : UInt<32>
    output io_debugX5 : UInt<32>
    output io_debugX6 : UInt<32>
    output io_debugALU : UInt<32>
    output io_debugImm : UInt<32>

    inst instructionMemory of InstructionMemory @[RV32ICore.scala 42:31]
    inst datapath of Datapath @[RV32ICore.scala 43:31]
    inst dataMemory of DataMemory @[RV32ICore.scala 44:31]
    reg pcReg : UInt<32>, clock with :
      reset => (UInt<1>("h0"), pcReg) @[RV32ICore.scala 36:20]
    io_pc <= pcReg @[RV32ICore.scala 77:14]
    io_nextPc <= datapath.io_nextPc @[RV32ICore.scala 78:14]
    io_writeBack <= datapath.io_writeBack @[RV32ICore.scala 79:14]
    io_debugInstr <= instructionMemory.io_instr @[RV32ICore.scala 82:15]
    io_debugX1 <= datapath.io_debugX1 @[RV32ICore.scala 85:12]
    io_debugX2 <= datapath.io_debugX2 @[RV32ICore.scala 86:12]
    io_debugX3 <= datapath.io_debugX3 @[RV32ICore.scala 87:12]
    io_debugX4 <= datapath.io_debugX4 @[RV32ICore.scala 88:12]
    io_debugX5 <= datapath.io_debugX5 @[RV32ICore.scala 89:12]
    io_debugX6 <= datapath.io_debugX6 @[RV32ICore.scala 90:12]
    io_debugALU <= datapath.io_debugALU @[RV32ICore.scala 92:13]
    io_debugImm <= datapath.io_debugImm @[RV32ICore.scala 93:13]
    pcReg <= mux(reset, UInt<32>("h0"), datapath.io_nextPc) @[RV32ICore.scala 36:{20,20} 71:7]
    instructionMemory.clock <= clock
    instructionMemory.reset <= reset
    instructionMemory.io_addr <= pcReg @[RV32ICore.scala 50:27]
    datapath.clock <= clock
    datapath.reset <= reset
    datapath.io_instr <= instructionMemory.io_instr @[RV32ICore.scala 52:19]
    datapath.io_pc <= pcReg @[RV32ICore.scala 53:19]
    datapath.io_memRdata <= dataMemory.io_rdata @[RV32ICore.scala 65:22]
    dataMemory.clock <= clock
    dataMemory.reset <= reset
    dataMemory.io_addr <= datapath.io_memAddr @[RV32ICore.scala 59:24]
    dataMemory.io_wdata <= datapath.io_memWdata @[RV32ICore.scala 60:24]
    dataMemory.io_memRead <= datapath.io_memRead @[RV32ICore.scala 61:24]
    dataMemory.io_memWrite <= datapath.io_memWrite @[RV32ICore.scala 62:24]
    dataMemory.io_funct3 <= datapath.io_memFunct3 @[RV32ICore.scala 63:24]
