package rv32i
import chisel3._
import chisel3.util._

object ALUOp {
  val width = 5
  val ADD = 0.U(5.W);  val SUB = 1.U(5.W);  val SLL = 2.U(5.W)
  val SLT = 3.U(5.W);  val SLTU = 4.U(5.W); val XOR = 5.U(5.W)
  val SRL = 6.U(5.W);  val SRA = 7.U(5.W);  val OR = 8.U(5.W)
  val AND = 9.U(5.W);  val MUL = 10.U(5.W); val MULH = 11.U(5.W)
  val MULHSU = 12.U(5.W); val MULHU = 13.U(5.W)
  val EQ = 14.U(5.W);  val NE = 15.U(5.W)
  val DIV = 16.U(5.W); val DIVU = 17.U(5.W)
  val REM = 18.U(5.W); val REMU = 19.U(5.W)
  val NOP = 31.U(5.W)
}

class ALU(p: CoreParams) extends Module {
  require(p.xlen == 32, "This ALU supports RV32 only")

  val io = IO(new Bundle {
    val a = Input(UInt(p.xlen.W)); val b = Input(UInt(p.xlen.W))
    val op = Input(UInt(ALUOp.width.W)); val start = Input(Bool())
    val y = Output(UInt(p.xlen.W))
    val busy = Output(Bool()); val done = Output(Bool())
  })

  val shamt = io.b(4, 0)
  val sa = io.a.asSInt; val sb = io.b.asSInt
  val as64 = Cat(Fill(32, io.a(31)), io.a).asSInt
  val bs64 = Cat(Fill(32, io.b(31)), io.b).asSInt
  val au64 = Cat(0.U(32.W), io.a); val bu64 = Cat(0.U(32.W), io.b)
  val mulSS = as64 * bs64; val mulUU = au64 * bu64
  val mulSU = as64 * bu64.asSInt

  val divOp = io.op === ALUOp.DIV || io.op === ALUOp.DIVU
  val remOp = io.op === ALUOp.REM || io.op === ALUOp.REMU
  val divRem = divOp || remOp
  val signedOp = io.op === ALUOp.DIV || io.op === ALUOp.REM
  val absA = Mux(signedOp && io.a(31), -io.a, io.a)
  val absB = Mux(signedOp && io.b(31), -io.b, io.b)

  val sIdle :: sRun :: sDone :: Nil = Enum(3)
  val state = RegInit(sIdle)
  val q = RegInit(0.U(32.W)); val r = RegInit(0.U(33.W))
  val d = RegInit(0.U(32.W)); val originalA = RegInit(0.U(32.W))
  val count = RegInit(0.U(6.W)); val result = RegInit(0.U(32.W))
  val negQ = RegInit(false.B); val negR = RegInit(false.B)
  val divZero = RegInit(false.B); val overflow = RegInit(false.B)
  val remSaved = RegInit(false.B)

  val shifted = Cat(r(31, 0), q(31))
  val subtract = shifted >= Cat(0.U(1.W), d)
  val nextR = Mux(subtract, shifted - Cat(0.U(1.W), d), shifted)
  val nextQ = Cat(q(30, 0), subtract)

  switch(state) {
    is(sIdle) {
      when(io.start && divRem) {
        q := absA; r := 0.U; d := absB; originalA := io.a; count := 0.U
        negQ := signedOp && (io.a(31) ^ io.b(31))
        negR := signedOp && io.a(31)
        divZero := io.b === 0.U
        overflow := signedOp && io.a === "h80000000".U &&
                    io.b === "hffffffff".U
        remSaved := remOp
        state := sRun
      }
    }
    is(sRun) {
      q := nextQ; r := nextR; count := count + 1.U
      when(count === 31.U) {
        val quotient = Mux(negQ, -nextQ, nextQ)
        val remainder = Mux(negR, -nextR(31, 0), nextR(31, 0))
        val finalQ = Mux(divZero, "hffffffff".U,
                     Mux(overflow, "h80000000".U, quotient))
        val finalR = Mux(divZero, originalA,
                     Mux(overflow, 0.U(32.W), remainder))
        result := Mux(remSaved, finalR, finalQ)
        state := sDone
      }
    }
    is(sDone) { state := sIdle }
  }

  io.busy := state === sRun
  io.done := state === sDone

  val comb = MuxLookup(io.op, 0.U(32.W), Seq(
    ALUOp.ADD -> (io.a + io.b), ALUOp.SUB -> (io.a - io.b),
    ALUOp.SLL -> (io.a << shamt), ALUOp.SLT -> (sa < sb).asUInt,
    ALUOp.SLTU -> (io.a < io.b).asUInt, ALUOp.XOR -> (io.a ^ io.b),
    ALUOp.SRL -> (io.a >> shamt), ALUOp.SRA -> (sa >> shamt).asUInt,
    ALUOp.OR -> (io.a | io.b), ALUOp.AND -> (io.a & io.b),
    ALUOp.MUL -> mulSS(31, 0), ALUOp.MULH -> mulSS(63, 32),
    ALUOp.MULHSU -> mulSU(63, 32), ALUOp.MULHU -> mulUU(63, 32),
    ALUOp.EQ -> (io.a === io.b).asUInt, ALUOp.NE -> (io.a =/= io.b).asUInt
  ))

  io.y := Mux(divRem, result, comb)
}

