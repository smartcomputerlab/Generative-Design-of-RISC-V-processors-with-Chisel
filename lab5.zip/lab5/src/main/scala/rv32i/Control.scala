package rv32i

import chisel3._
import chisel3.util._

class Control extends Module {
  val io = IO(new Bundle {
    val instr    = Input(UInt(32.W))
    val valid    = Output(Bool())
    val aluOp    = Output(UInt(ALUOp.width.W))
    val aluSrc   = Output(Bool())
    val memRead  = Output(Bool())
    val memWrite = Output(Bool())
    val memToReg = Output(Bool())
    val regWrite = Output(Bool())
    val branch   = Output(Bool())
    val jump     = Output(Bool())
    val jalr     = Output(Bool())
  })

  val op = io.instr(6,0)
  val f3 = io.instr(14,12)
  val f7 = io.instr(31,25)

  // Opcodes
  val R     = "b0110011".U
  val I     = "b0010011".U
  val LOAD  = "b0000011".U
  val STORE = "b0100011".U
  val BR    = "b1100011".U
  val JAL   = "b1101111".U
  val JALR  = "b1100111".U
  val LUI   = "b0110111".U
  val AUIPC = "b0010111".U

  // ------------------------------------------------------------
  // R-type / RV32M ALU decoder
  // ------------------------------------------------------------

  val rOp = MuxLookup(
    Cat(f7, f3),
    ALUOp.NOP,
    Seq(
      // RV32I
      "b0000000000".U -> ALUOp.ADD,
      "b0100000000".U -> ALUOp.SUB,
      "b0000000001".U -> ALUOp.SLL,
      "b0000000010".U -> ALUOp.SLT,
      "b0000000011".U -> ALUOp.SLTU,
      "b0000000100".U -> ALUOp.XOR,
      "b0000000101".U -> ALUOp.SRL,
      "b0100000101".U -> ALUOp.SRA,
      "b0000000110".U -> ALUOp.OR,
      "b0000000111".U -> ALUOp.AND,

      // RV32M
      "b0000001000".U -> ALUOp.MUL,
      "b0000001001".U -> ALUOp.MULH,
      "b0000001010".U -> ALUOp.MULHSU,
      "b0000001011".U -> ALUOp.MULHU,
      "b0000001100".U -> ALUOp.DIV,
      "b0000001101".U -> ALUOp.DIVU,
      "b0000001110".U -> ALUOp.REM,
      "b0000001111".U -> ALUOp.REMU
    )
  )

  // ------------------------------------------------------------
  // I-type ALU decoder
  // ------------------------------------------------------------

  val iOp = MuxLookup(
    f3,
    ALUOp.NOP,
    Seq(
      "b000".U -> ALUOp.ADD,      // ADDI
      "b010".U -> ALUOp.SLT,      // SLTI
      "b011".U -> ALUOp.SLTU,     // SLTIU
      "b100".U -> ALUOp.XOR,      // XORI
      "b110".U -> ALUOp.OR,       // ORI
      "b111".U -> ALUOp.AND,      // ANDI

      "b001".U ->
        Mux(f7 === "b0000000".U,
            ALUOp.SLL, ALUOp.NOP),

      "b101".U ->
        Mux(f7 === "b0000000".U,
            ALUOp.SRL,
          Mux(f7 === "b0100000".U,
            ALUOp.SRA, ALUOp.NOP))
    )
  )

  // ------------------------------------------------------------
  // Branch decoder
  // ------------------------------------------------------------

  val bOp = MuxLookup(
    f3,
    ALUOp.NOP,
    Seq(
      "b000".U -> ALUOp.EQ,       // BEQ
      "b001".U -> ALUOp.NE,       // BNE
      "b100".U -> ALUOp.SLT,      // BLT
      "b101".U -> ALUOp.SLT,      // BGE
      "b110".U -> ALUOp.SLTU,     // BLTU
      "b111".U -> ALUOp.SLTU      // BGEU
    )
  )

  // ------------------------------------------------------------
  // Default control signals
  // ------------------------------------------------------------

  io.valid    := false.B
  io.aluOp    := ALUOp.NOP
  io.aluSrc   := false.B
  io.memRead  := false.B
  io.memWrite := false.B
  io.memToReg := false.B
  io.regWrite := false.B
  io.branch   := false.B
  io.jump     := false.B
  io.jalr     := false.B

  // ------------------------------------------------------------
  // Main control decoder
  // ------------------------------------------------------------

  switch(op) {

    is(R) {
      io.aluOp    := rOp
      io.valid    := true.B
      io.regWrite := true.B
    }

    is(I) {
      io.aluOp    := iOp
      io.aluSrc   := true.B
      io.valid    := true.B
      io.regWrite := true.B
    }

    is(LOAD) {
      io.aluOp    := ALUOp.ADD
      io.aluSrc   := true.B
      io.memRead  := true.B
      io.memToReg := true.B
      io.regWrite := true.B
      io.valid    := true.B
    }

    is(STORE) {
      io.aluOp    := ALUOp.ADD
      io.aluSrc   := true.B
      io.memWrite := true.B
      io.valid    := true.B
    }

    is(BR) {
      io.aluOp  := bOp
      io.branch := true.B
      io.valid  := true.B
    }

    is(JAL) {
      io.jump     := true.B
      io.regWrite := true.B
      io.valid    := true.B
    }

    is(JALR) {
      io.aluOp    := ALUOp.ADD
      io.aluSrc   := true.B
      io.jalr     := true.B
      io.regWrite := true.B
      io.valid    := true.B
    }

    is(LUI, AUIPC) {
      io.aluOp    := ALUOp.ADD
      io.aluSrc   := true.B
      io.regWrite := true.B
      io.valid    := true.B
    }
  }
}

