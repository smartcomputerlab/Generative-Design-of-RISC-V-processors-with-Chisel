package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class RV32ICoreTest extends AnyFlatSpec
    with ChiselScalatestTester {

  behavior of "RV32ICore"

  it should "calculate GCD using sequential REM" in {

    test(new RV32ICore(CoreParams()))
      .withAnnotations(Seq(WriteVcdAnnotation)) { dut =>

      // ====================================
      // RESET
      // ====================================

      dut.reset.poke(true.B)
      dut.clock.step(2)
      dut.reset.poke(false.B)

      println("\n========== RV32IM GCD TEST ==========")
      println("Computing GCD(48,18)")
      println("Expected result = 6")

      // ====================================
      // EXECUTION
      // ====================================

      val maxCycles = 500

      var cycle = 0
      var finished = false

      while (cycle < maxCycles && !finished) {

        val pcBefore = dut.io.pc.peek().litValue

        dut.clock.step()

        val pc = dut.io.pc.peek().litValue

        val stalled = pc == pcBefore

        val x1 = dut.io.debugX1.peek().litValue
        val x2 = dut.io.debugX2.peek().litValue
        val x3 = dut.io.debugX3.peek().litValue
        val x4 = dut.io.debugX4.peek().litValue

        if (cycle < 10 || cycle % 10 == 0 || !stalled) {

          println(
            f"cycle=$cycle%3d " +
            f"PC=0x$pc%08x " +
            f"INSTR=0x${dut.io.debugInstr.peek().litValue}%08x " +
            f"STALL=$stalled " +
            f"x1=$x1%d " +
            f"x2=$x2%d " +
            f"x3=$x3%d " +
            f"x4=$x4%d"
          )
        }

        // Final infinite loop at byte address 0x20.
        // x4 contains the expected GCD result.

        if (pc == 0x20 && x4 == 6) {
          finished = true
        }

        cycle += 1
      }

      // ====================================
      // FINAL RESULTS
      // ====================================

      val x1 = dut.io.debugX1.peek().litValue
      val x2 = dut.io.debugX2.peek().litValue
      val x3 = dut.io.debugX3.peek().litValue
      val x4 = dut.io.debugX4.peek().litValue

      println("\n========== FINAL RESULTS ==========")

      println(s"x1 = $x1 (expected 6)")
      println(s"x2 = $x2 (expected 0)")
      println(s"x3 = $x3 (expected 0)")
      println(s"x4 = $x4 (expected 6 - GCD)")

      println(s"Cycles executed = $cycle")

      // ====================================
      // ASSERTIONS
      // ====================================

      assert(finished, "GCD program did not finish")

      assert(x1 == 6, "Incorrect x1")
      assert(x2 == 0, "Incorrect x2")
      assert(x3 == 0, "Incorrect x3")
      assert(x4 == 6, "Incorrect GCD result")

      println("\nALL GCD TESTS PASSED")
      println("GCD(48,18) = 6")
      println("VCD waveform generated.")
    }
  }
}

