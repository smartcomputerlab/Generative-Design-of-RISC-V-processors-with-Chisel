package rv32i

import chisel3._
import chisel3.util._

class Decoder extends Module {
  val io = IO(new Bundle {
    val instr    = Input(UInt(32.W))
    val rs1      = Output(UInt(5.W))
    val rs2      = Output(UInt(5.W))
    val rd       = Output(UInt(5.W))
    val aluOp    = Output(UInt(ALUOp.width.W))
    val aluSrc   = Output(Bool())
    val regWrite = Output(Bool())
    val valid    = Output(Bool())
  })

  // Instruction fields
  val op = io.instr(6, 0)
  val f3 = io.instr(14, 12)
  val f7 = io.instr(31, 25)

  io.rs1 := io.instr(19, 15)
  io.rs2 := io.instr(24, 20)
  io.rd  := io.instr(11, 7)

  // R-type ALU decoder
  val rOp = MuxLookup(
    Cat(f7, f3),
    ALUOp.NOP,
    Seq(
      "b0000000000".U -> ALUOp.ADD,
      "b0100000000".U -> ALUOp.SUB,
      "b0000000001".U -> ALUOp.SLL,
      "b0000000010".U -> ALUOp.SLT,
      "b0000000011".U -> ALUOp.SLTU,
      "b0000000100".U -> ALUOp.XOR,
      "b0000000101".U -> ALUOp.SRL,
      "b0100000101".U -> ALUOp.SRA,
      "b0000000110".U -> ALUOp.OR,
      "b0000000111".U -> ALUOp.AND
    )
  )

  // I-type ALU decoder
  val iOp = MuxLookup(
    f3,
    ALUOp.NOP,
    Seq(
      "b000".U -> ALUOp.ADD,       // ADDI
      "b010".U -> ALUOp.SLT,       // SLTI
      "b011".U -> ALUOp.SLTU,      // SLTIU
      "b100".U -> ALUOp.XOR,       // XORI
      "b110".U -> ALUOp.OR,        // ORI
      "b111".U -> ALUOp.AND,       // ANDI

      "b001".U -> Mux(              // SLLI
        f7 === "b0000000".U,
        ALUOp.SLL,
        ALUOp.NOP
      ),

      "b101".U -> Mux(              // SRLI / SRAI
        f7 === "b0000000".U,
        ALUOp.SRL,
        Mux(
          f7 === "b0100000".U,
          ALUOp.SRA,
          ALUOp.NOP
        )
      )
    )
  )

  // Main opcode decoding
  val isR = op === "b0110011".U
  val isI = op === "b0010011".U

  io.aluOp := Mux(
    isR, rOp,
    Mux(isI, iOp, ALUOp.NOP)
  )

  io.aluSrc   := isI
  io.valid    := io.aluOp =/= ALUOp.NOP
  io.regWrite := io.valid
}

