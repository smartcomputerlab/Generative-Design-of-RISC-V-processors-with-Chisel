package rv32i

object RV32IEncoding {

  def rType(
    funct7: Int,
    rs2: Int,
    rs1: Int,
    funct3: Int,
    rd: Int
  ): BigInt = {
    (BigInt(funct7 & 0x7f) << 25) |
    (BigInt(rs2 & 0x1f) << 20) |
    (BigInt(rs1 & 0x1f) << 15) |
    (BigInt(funct3 & 0x7) << 12) |
    (BigInt(rd & 0x1f) << 7) |
    BigInt(0x33)
  }

  def iType(
    imm: Int,
    rs1: Int,
    funct3: Int,
    rd: Int,
    opcode: Int = 0x13
  ): BigInt = {
    (BigInt(imm & 0xfff) << 20) |
    (BigInt(rs1 & 0x1f) << 15) |
    (BigInt(funct3 & 0x7) << 12) |
    (BigInt(rd & 0x1f) << 7) |
    BigInt(opcode)
  }

  def add(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x00, rs2, rs1, 0x0, rd)

  def sub(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x20, rs2, rs1, 0x0, rd)

  def sll(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x00, rs2, rs1, 0x1, rd)

  def slt(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x00, rs2, rs1, 0x2, rd)

  def sltu(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x00, rs2, rs1, 0x3, rd)

  def xor(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x00, rs2, rs1, 0x4, rd)

  def srl(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x00, rs2, rs1, 0x5, rd)

  def sra(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x20, rs2, rs1, 0x5, rd)

  def or(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x00, rs2, rs1, 0x6, rd)

  def and(rd: Int, rs1: Int, rs2: Int): BigInt =
    rType(0x00, rs2, rs1, 0x7, rd)

  def addi(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x0, rd)

  def slti(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x2, rd)

  def sltiu(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x3, rd)

  def xori(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x4, rd)

  def ori(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x6, rd)

  def andi(rd: Int, rs1: Int, imm: Int): BigInt =
    iType(imm, rs1, 0x7, rd)

  def slli(rd: Int, rs1: Int, shamt: Int): BigInt =
    iType(shamt, rs1, 0x1, rd)

  def srli(rd: Int, rs1: Int, shamt: Int): BigInt =
    iType(shamt, rs1, 0x5, rd)

  def srai(rd: Int, rs1: Int, shamt: Int): BigInt =
    iType(0x400 | (shamt & 0x1f), rs1, 0x5, rd)
}

