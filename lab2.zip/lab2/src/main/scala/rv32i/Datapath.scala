package rv32i

import chisel3._
import chisel3.util._

class Datapath(p: CoreParams) extends Module {

  val io = IO(new Bundle {
    val instr      = Input(UInt(32.W))
    val writeBack  = Output(UInt(p.xlen.W))
    val debugX1    = Output(UInt(p.xlen.W))
    val debugX2    = Output(UInt(p.xlen.W))
    val debugX3    = Output(UInt(p.xlen.W))
    val debugX4    = Output(UInt(p.xlen.W))
    val debugALU   = Output(UInt(p.xlen.W))
    val debugImm   = Output(UInt(p.xlen.W))
  })

  val decoder = Module(new Decoder)
  val immGen  = Module(new ImmediateGenerator(p))
  val regFile = Module(new RegisterFile(p))
  val alu     = Module(new ALU(p))

  decoder.io.instr := io.instr
  immGen.io.instr  := io.instr

  regFile.io.rs1 := decoder.io.rs1
  regFile.io.rs2 := decoder.io.rs2
  regFile.io.rd  := decoder.io.rd

  val aluB = Mux(
    decoder.io.aluSrc,
    immGen.io.imm,
    regFile.io.readData2
  )

  alu.io.a  := regFile.io.readData1
  alu.io.b  := aluB
  alu.io.op := decoder.io.aluOp

  regFile.io.writeData   := alu.io.y
  regFile.io.writeEnable := decoder.io.regWrite

  io.writeBack := alu.io.y

  io.debugX1 := regFile.io.debugRead(1)
  io.debugX2 := regFile.io.debugRead(2)
  io.debugX3 := regFile.io.debugRead(3)
  io.debugX4 := regFile.io.debugRead(4)

  io.debugALU := alu.io.y
  io.debugImm := immGen.io.imm
}

