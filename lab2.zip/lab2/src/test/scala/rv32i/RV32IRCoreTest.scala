package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class RV32IRCoreTest
    extends AnyFlatSpec
    with ChiselScalatestTester {

  behavior of "RV32IRICore"

  it should "execute instructions from memory.hex" in {

    test(new RV32ITestWrapper(CoreParams(), "memory.hex"))
      .withAnnotations(Seq(WriteVcdAnnotation)) { dut =>

      dut.io.debugPC.expect(0.U)

      dut.clock.step()
      dut.io.debugPC.expect(4.U)

      dut.clock.step()
      dut.io.debugPC.expect(8.U)
      dut.io.debugX1.expect(10.U)
      dut.io.debugX2.expect(3.U)

      dut.clock.step()
      dut.io.debugPC.expect(12.U)
      dut.io.debugX3.expect(13.U)

      dut.clock.step()
      dut.io.debugPC.expect(16.U)
      dut.io.debugX4.expect(7.U)

      dut.clock.step()
      dut.io.debugPC.expect(20.U)

      dut.clock.step()
      dut.io.debugPC.expect(24.U)

      dut.clock.step()
      dut.io.debugPC.expect(28.U)

      dut.clock.step()
      dut.io.debugPC.expect(32.U)

      dut.clock.step()
      dut.io.debugPC.expect(36.U)

      dut.clock.step()
      dut.io.debugPC.expect(40.U)
    }
  }
}

