FIRRTL version 1.1.0
circuit Decoder :
  module Decoder :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32>
    output io_rs1 : UInt<5>
    output io_rs2 : UInt<5>
    output io_rd : UInt<5>
    output io_aluOp : UInt<4>
    output io_aluSrc : UInt<1>
    output io_regWrite : UInt<1>
    output io_valid : UInt<1>

    node op = bits(io_instr, 6, 0) @[Decoder.scala 19:20]
    node f3 = bits(io_instr, 14, 12) @[Decoder.scala 20:20]
    node f7 = bits(io_instr, 31, 25) @[Decoder.scala 21:20]
    node _io_rs1_T = bits(io_instr, 19, 15) @[Decoder.scala 23:21]
    node _io_rs2_T = bits(io_instr, 24, 20) @[Decoder.scala 24:21]
    node _io_rd_T = bits(io_instr, 11, 7) @[Decoder.scala 25:21]
    node _rOp_T = cat(f7, f3) @[Cat.scala 33:92]
    node _rOp_T_1 = eq(UInt<1>("h0"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_2 = mux(_rOp_T_1, UInt<4>("h0"), UInt<4>("hf")) @[Mux.scala 81:58]
    node _rOp_T_3 = eq(UInt<9>("h100"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_4 = mux(_rOp_T_3, UInt<4>("h1"), _rOp_T_2) @[Mux.scala 81:58]
    node _rOp_T_5 = eq(UInt<1>("h1"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_6 = mux(_rOp_T_5, UInt<4>("h2"), _rOp_T_4) @[Mux.scala 81:58]
    node _rOp_T_7 = eq(UInt<2>("h2"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_8 = mux(_rOp_T_7, UInt<4>("h3"), _rOp_T_6) @[Mux.scala 81:58]
    node _rOp_T_9 = eq(UInt<2>("h3"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_10 = mux(_rOp_T_9, UInt<4>("h4"), _rOp_T_8) @[Mux.scala 81:58]
    node _rOp_T_11 = eq(UInt<3>("h4"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_12 = mux(_rOp_T_11, UInt<4>("h5"), _rOp_T_10) @[Mux.scala 81:58]
    node _rOp_T_13 = eq(UInt<3>("h5"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_14 = mux(_rOp_T_13, UInt<4>("h6"), _rOp_T_12) @[Mux.scala 81:58]
    node _rOp_T_15 = eq(UInt<9>("h105"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_16 = mux(_rOp_T_15, UInt<4>("h7"), _rOp_T_14) @[Mux.scala 81:58]
    node _rOp_T_17 = eq(UInt<3>("h6"), _rOp_T) @[Mux.scala 81:61]
    node _rOp_T_18 = mux(_rOp_T_17, UInt<4>("h8"), _rOp_T_16) @[Mux.scala 81:58]
    node _rOp_T_19 = eq(UInt<3>("h7"), _rOp_T) @[Mux.scala 81:61]
    node rOp = mux(_rOp_T_19, UInt<4>("h9"), _rOp_T_18) @[Mux.scala 81:58]
    node _iOp_T = eq(f7, UInt<1>("h0")) @[Decoder.scala 58:12]
    node _iOp_T_1 = mux(_iOp_T, UInt<4>("h2"), UInt<4>("hf")) @[Decoder.scala 57:22]
    node _iOp_T_2 = eq(f7, UInt<1>("h0")) @[Decoder.scala 64:12]
    node _iOp_T_3 = eq(f7, UInt<6>("h20")) @[Decoder.scala 67:14]
    node _iOp_T_4 = mux(_iOp_T_3, UInt<4>("h7"), UInt<4>("hf")) @[Decoder.scala 66:12]
    node _iOp_T_5 = mux(_iOp_T_2, UInt<4>("h6"), _iOp_T_4) @[Decoder.scala 63:22]
    node _iOp_T_6 = eq(UInt<2>("h2"), f3) @[Mux.scala 81:61]
    node _iOp_T_7 = mux(_iOp_T_6, UInt<4>("h3"), UInt<4>("h0")) @[Mux.scala 81:58]
    node _iOp_T_8 = eq(UInt<2>("h3"), f3) @[Mux.scala 81:61]
    node _iOp_T_9 = mux(_iOp_T_8, UInt<4>("h4"), _iOp_T_7) @[Mux.scala 81:58]
    node _iOp_T_10 = eq(UInt<3>("h4"), f3) @[Mux.scala 81:61]
    node _iOp_T_11 = mux(_iOp_T_10, UInt<4>("h5"), _iOp_T_9) @[Mux.scala 81:58]
    node _iOp_T_12 = eq(UInt<3>("h6"), f3) @[Mux.scala 81:61]
    node _iOp_T_13 = mux(_iOp_T_12, UInt<4>("h8"), _iOp_T_11) @[Mux.scala 81:58]
    node _iOp_T_14 = eq(UInt<3>("h7"), f3) @[Mux.scala 81:61]
    node _iOp_T_15 = mux(_iOp_T_14, UInt<4>("h9"), _iOp_T_13) @[Mux.scala 81:58]
    node _iOp_T_16 = eq(UInt<1>("h1"), f3) @[Mux.scala 81:61]
    node _iOp_T_17 = mux(_iOp_T_16, _iOp_T_1, _iOp_T_15) @[Mux.scala 81:58]
    node _iOp_T_18 = eq(UInt<3>("h5"), f3) @[Mux.scala 81:61]
    node iOp = mux(_iOp_T_18, _iOp_T_5, _iOp_T_17) @[Mux.scala 81:58]
    node isR = eq(op, UInt<6>("h33")) @[Decoder.scala 76:16]
    node isI = eq(op, UInt<5>("h13")) @[Decoder.scala 77:16]
    node _io_aluOp_T = mux(isI, iOp, UInt<4>("hf")) @[Decoder.scala 81:8]
    node _io_aluOp_T_1 = mux(isR, rOp, _io_aluOp_T) @[Decoder.scala 79:18]
    node _io_valid_T = neq(io_aluOp, UInt<4>("hf")) @[Decoder.scala 85:27]
    io_rs1 <= _io_rs1_T @[Decoder.scala 23:10]
    io_rs2 <= _io_rs2_T @[Decoder.scala 24:10]
    io_rd <= _io_rd_T @[Decoder.scala 25:10]
    io_aluOp <= _io_aluOp_T_1 @[Decoder.scala 79:12]
    io_aluSrc <= isI @[Decoder.scala 84:15]
    io_regWrite <= io_valid @[Decoder.scala 86:15]
    io_valid <= _io_valid_T @[Decoder.scala 85:15]
